﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adqrcodescanner"
	Public title As String = "AD BarCode Scanner"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private btnStartScanning As SDUIButton
	Private btnStopScanning As SDUIButton
	Private SDUIBarCodeReader1 As SDUIBarCodeReader
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesBarCodeReader)
	banano.LoadLayout(app.PageViewer, "adqrcodescannerlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnStartScanning", "btnStartScanning", btnStartScanning.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnStopScanning", "btnStopScanning", btnStopScanning.CustProps)
	pgIndex.AddDesignKV1("SDUIBarCodeReader.SDUIBarCodeReader1", "SDUIBarCodeReader1", SDUIBarCodeReader1.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub btnStopScanning_Click (e As BANanoEvent)
	banano.Await(SDUIBarCodeReader1.StopScanWait)
End Sub

Private Sub btnStartScanning_Click (e As BANanoEvent)
	banano.Await(SDUIBarCodeReader1.ScanWait)
End Sub

Private Sub SDUIBarCodeReader1_ScanSuccess (decodedText As String, decodedResult As Map)
	app.ShowSwal(decodedText)
End Sub

Private Sub SDUIBarCodeReader1_ScanFailure (error As Object)
	Log(error)
End Sub