﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adfrappegantt"
	Public title As String = "AD Frappe Gantt"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIFrappeGantt1 As SDUIFrappeGantt
	Private SDUIFrappeGantt2 As SDUIFrappeGantt
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesFrappeGantt)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adfrappeganttlayout")
	'
	SDUIFrappeGantt1.AddCustomClass("special", "green", "blue", "white")
	'
	SDUIFrappeGantt1.AddCustomClass("jenna", "#FF8E76", "#D95B43", "")
	SDUIFrappeGantt1.AddCustomClass("jeff", "#87576A", "#542437", "")
	SDUIFrappeGantt1.AddCustomClass("eric", "#86AAAD", "#53777A", "")
	SDUIFrappeGantt1.AddCustomClass("client", "#F35C75", "#C02942", "")

	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	SDUIFrappeGantt1.Clear
	SDUIFrappeGantt1.AddTask("T01", "Buy hosting", "2022-01-22", "2022-01-23", 100)
	SDUIFrappeGantt1.AddTask("T02", "Draw wireframes", "2022-01-23", "2022-01-25", 100)
	SDUIFrappeGantt1.AddTask("T03", "Visual Design", "2022-01-25", "2022-01-27", 20).SetTaskDependencies("T03", Array("T02"))
	SDUIFrappeGantt1.AddTask("T04", "Build frontend", "2022-02-01", "2022-02-03", 10).SetTaskDependencies("T04", Array("T03"))
	SDUIFrappeGantt1.AddTask("T05", "Build backend", "2022-02-03", "2022-02-07", 15)
	SDUIFrappeGantt1.AddTask("T06", "Deploy Website", "2022-02-07", "2022-02-09", 25).SetTaskDependencies("T06", Array("T04","T05"))
	SDUIFrappeGantt1.SetTaskClass("T05", "special")
	SDUIFrappeGantt1.SetTaskClass("T06", "special")
	SDUIFrappeGantt1.Refresh
	'
	SDUIFrappeGantt2.Clear
	SDUIFrappeGantt2.AddTask1("Copy Full Site", "[Copy] Full site treatments", "2019-6-23", "2019-6-28", 0, "jenna")
	SDUIFrappeGantt2.AddTask2("Delivery Copy Site", "[Delivery] Copy - Full Site", "2019-6-28", "2019-6-28", 0, "client", Array("Copy Full Site"))
	SDUIFrappeGantt2.AddTask1("Copy Rnd2", "[Copy] All - Round 2", "2019-6-29", "2019-7-5", 0, "jenna")
	SDUIFrappeGantt2.AddTask2("Delivery Copy Site v2", "[Delivery] Copy - Full Site", "2019-7-5", "2019-7-5", 0, "client", Array("Copy Rnd2"))
	SDUIFrappeGantt2.AddTask2("Copy Revision", "[Copy] Miscellaneous Revisions", "2019-7-6", "2019-7-10", 0, "jenna", Null)
	'
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Misc Copy", _
	"name": "[Delivery] Copy - Final Revisions", _
          "start": "2019-7-11", _
          "end": "2019-7-11", _
          "progress": 0, _
          "dependencies": "Copy Revision", _
          "custom_class": "client"))
	
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Design Home Rnd2", _
          "name": "[Design] Home v2", _
          "start": "2019-6-23", _
          "end": "2019-6-23", _
          "progress": 100, _
          "dependencies": "", _
          "custom_class": "jeff"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Home v2", _
          "name": "[Delivery] Home Design v2", _
          "start": "2019-6-24", _
          "end": "2019-6-24", _
          "progress": 100, _
          "dependencies": "Design Home Rnd2", _
          "custom_class": "client"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Design Site Rnd1", _
          "name": "[Design] Full Site Round 1", _
          "start": "2019-6-24", _
          "end": "2019-6-30", _
          "progress": 0, _
          "dependencies": "Design Home Rnd2", _
          "custom_class": "jeff"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Site v1", _
          "name": "[Delivery] Full site v1", _
          "start": "2019-7-1", _
          "end": "2019-7-1", _
          "progress": 0, _
          "dependencies": "Design Site Rnd1", _
          "custom_class": "client"))
 
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Design Site Rnd2", _
          "name": "[Design] Full Site Round 2", _
          "start": "2019-7-1", _
          "end": "2019-7-5", _
          "progress": 0, _
          "dependencies": "Design Site Rnd1", _
          "custom_class": "jeff"))
 
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Site v2", _
          "name": "[Delivery] Full site v2", _
          "start": "2019-7-8", _
          "end": "2019-7-8", _
          "progress": 0, _
          "dependencies": "Design Site Rnd2", _
          "custom_class": "client"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Content Storyboard", _
          "name": "[Content] Storyboard illustrations", _
          "start": "2019-6-24", _
          "end": "2019-6-30", _
          "progress": 50, _
          "dependencies": "", _
          "custom_class": "eric"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Content Illu Rnd1", _
          "name": "[Content] Illustration Round 1", _
          "start": "2019-7-6", _
          "end": "2019-7-12", _
          "progress": 0, _
          "dependencies": "Design Site Rnd2, Content Storyboard", _
          "custom_class": "jeff"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Illu v1", _
          "name": "[Delivery] Illustrations v1", _
          "start": "2019-7-12", _
          "end": "2019-7-12", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd1", _
          "custom_class": "client"))
		  '
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Content Illu Rnd2", _
          "name": "[Content] Illustration Round 2", _
          "start": "2019-7-13", _
          "end": "2019-7-16", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd1", _
          "custom_class": "jeff"))
		
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Illu v2", _
          "name": "[Delivery] Illustrations v2", _
          "start": "2019-7-16", _
          "end": "2019-7-16", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd2", _
          "custom_class": "client"))
	
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Dev Home", _
          "name": "[Dev] Home page", _
          "start": "2019-6-25", _
          "end": "2019-6-26", _
          "progress": 0, _
          "dependencies": "Design Home Rnd2", _
          "custom_class": "eric"))
		
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Dev All Pages", _
          "name": "[Dev] All Pages", _
          "start": "2019-6-27", _
          "end": "2019-7-12", _
          "progress": 0, _
          "dependencies": "Design Home Rnd2", _
          "custom_class": "eric"))
		  
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Dev Motion", _
          "name": "[Dev] Motion", _
          "start": "2019-7-13", _
          "end": "2019-7-15", _
          "progress": 0, _
          "dependencies": "Dev All Pages", _
          "custom_class": "eric"))
		
	SDUIFrappeGantt2.AddTaskObject(CreateMap(  "id": "Dev Illu", _
          "name": "[Dev] Illustrations", _
          "start": "2019-7-16", _
          "end": "2019-7-19", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd2", _
          "custom_class": "eric"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Dev QA", _
          "name": "[Dev] QA", _
          "start": "2019-7-20", _
          "end": "2019-7-23", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd2", _
          "custom_class": "eric"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap(  "id": "CMS Content", _
          "name": "[Client] Final Content entry", _
          "start": "2019-7-17", _
          "end": "2019-7-19", _
          "progress": 40, _
          "dependencies": "", _
          "custom_class": "client"))
		  '
	SDUIFrappeGantt2.AddTaskObject(CreateMap("id": "Delivery Launch", _
          "name": "[Delivery] Launch", _
          "start": "2019-7-24", _
          "end": "2019-7-24", _
          "progress": 0, _
          "dependencies": "Content Illu Rnd2, Dev QA, Copy Revision", _
          "custom_class": "client"))
		  
	SDUIFrappeGantt2.AddTaskObject(CreateMap(  "id": "Dev Support", _
          "name": "[Dev] Post-launch support", _
          "start": "2019-7-25", _
          "end": "2019-7-27", _
          "progress": 0, _
          "dependencies": "", _
          "custom_class": "eric"))
	SDUIFrappeGantt2.Refresh
	
	
	
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIFrappeGantt1_Click (task As Map)
	
End Sub

Private Sub SDUIFrappeGantt1_DateChange (task As Map, startDate As Object, endDate As Object)
	
End Sub

Private Sub SDUIFrappeGantt1_ProgressChange (task As Map, progress As Object)
	
End Sub

Private Sub SDUIFrappeGantt1_ViewChange (mode As Object)
	
End Sub

Private Sub SDUIFrappeGantt2_Click (task As Map)
	
End Sub

Private Sub SDUIFrappeGantt2_DateChange (task As Map, startDate As Object, endDate As Object)
	
End Sub

Private Sub SDUIFrappeGantt2_ProgressChange (task As Map, progress As Object)
	
End Sub

Private Sub SDUIFrappeGantt2_ViewChange (mode As Object)
	
End Sub