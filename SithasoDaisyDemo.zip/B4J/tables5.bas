﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
'Date Formats: https://flatpickr.js.org/formatting/
'localization: https://github.com/flatpickr/flatpickr/tree/master/src/l10n

Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables5"
	Public title As String = "Table 5"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"1999-04-20", "tob":"20:04", "dod":"2004-04-20", "doo":"2004-04-20 10:04"))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"1999-05-21", "tob":"13:00","dod":"2002-04-20", "doo":"2003-01-20 13:00"))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"1999-03-25", "tob":"20:15","dod":"2001-04-20", "doo":"2002-02-20 20:15"))
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table5
	Table5Code
End Sub

Sub Table5Code
Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
c5.AddCode($"Sub Build_Table5"$)
c5.AddCode($"Dim tb4 As SDUITable = page.Cell(1, 1).AddTable("tb4")"$)
c5.AddCode($"tb4.Hover = True"$)
c5.AddCode($"tb4.Zebra"$)
c5.AddCode($"'"$)
c5.AddCode($"Dim countries As List"$)
c5.AddCode($"countries.Initialize"$)
c5.AddCode($"countries.Add("South Africa")"$)
c5.AddCode($"countries.Add("USA")"$)
c5.AddCode($"countries.Add("Nigeria")"$)
c5.AddCode($"Dim options As Map = SDUIShared.ListToSelectOptions(countries)"$)
c5.AddCode($"'"$)
c5.AddCode($"tb4.AddColumn("id", "#")"$)
c5.AddCode($"tb4.AddColumnTextBox("email", "Email", False)"$)
c5.AddCode($"tb4.AddColumnSelect("country", "Country", False, True, options)"$)
c5.AddCode($"tb4.AddColumnTextARea("job", "Job Title", False, 5)"$)
c5.AddCode($"tb4.AddColumnDatePicker("dob", "Date of Birth", False, "Y-m-d", "F j, Y", False, False, False)"$)
c5.AddCode($"tb4.AddColumnTimePicker("tob", "Time of Birth", False, "H:i", True)"$)
c5.AddCode($"tb4.AddColumnDatePicker1("dod", "Date of Death", False, "Y-m-d", "d/m/Y", False, False, False, "it")"$)
c5.AddCode($"tb4.AddColumnDateTimePicker1("doo", "Date of Opening", False, "Y-m-d H:i", "d/m/Y H:i", False, False, False, "es")"$)
c5.AddCode($"tb4.AddColumnRange("hours", "Hours", 8, app.COLOR_ACCENT)"$)
c5.AddCode($"tb4.AddColumnCheckBox("active", "Active", app.COLOR_PRIMARY, False)"$)
c5.AddCode($"tb4.AddColumnRating("rate", "Satisfaction", 3, "item.color")"$)
c5.AddCode($"tb4.AddColumnToggle("on", "Off/On", app.COLOR_PRIMARY, False)"$)
c5.AddCode($"'ad as last columns"$)
c5.AddCode($"tb4.AddColumnEdit(app.COLOR_PRIMARY)"$)
c5.AddCode($"tb4.AddColumnDelete(app.COLOR_SECONDARY)"$)
c5.AddCode($"tb4.SetItemsPaginate(Items)"$)
c5.AddCode($"End Sub"$)
c5.AddCode($"''"$)
c5.AddCode($"Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)"$)
c5.AddCode($"Log("tb4_ChangeRow...")"$)
c5.AddCode($"Log(Row)"$)
c5.AddCode($"Log(Value)"$)
c5.AddCode($"Log(Column)"$)
c5.AddCode($"Log(item)"$)
c5.AddCode($"End Sub"$)
c5.AddCode($"Private Sub tb4_Edit (item As Map)"$)
c5.AddCode($"Log(item)"$)
c5.AddCode($"End Sub"$)
c5.AddCode($"Private Sub tb4_Delete (item As Map)"$)
c5.AddCode($"Log(item)"$)
c5.AddCode($"End Sub"$)
c5.Refresh
End Sub

Sub Build_Table5
	Dim tb4 As SDUITable = page.Cell(1, 1).AddTable("tb4")
	tb4.Hover = True
	tb4.Zebra
	'
	Dim countries As List
	countries.Initialize 
	countries.Add("South Africa")
	countries.Add("USA")
	countries.Add("Nigeria")
	Dim options As Map = SDUIShared.ListToSelectOptions(countries)
	'	
	tb4.AddColumn("id", "#")
	tb4.AddColumnTextBox("email", "Email", False)
	tb4.AddColumnSelect("country", "Country", False, True, options)
	tb4.AddColumnTextARea("job", "Job Title", False, 5)
	tb4.AddColumnDatePicker("dob", "Date of Birth", False, "Y-m-d", "F j, Y", False, False, False)
	tb4.AddColumnTimePicker("tob", "Time of Birth", False, "H:i", True)
	tb4.AddColumnDatePicker1("dod", "Date of Death", False, "Y-m-d", "d/m/Y", False, False, False, "it")
	tb4.AddColumnDateTimePicker1("doo", "Date of Opening", False, "Y-m-d H:i", "d/m/Y H:i", False, False, False, "es")
	tb4.AddColumnRange("hours", "Hours", 8, app.COLOR_ACCENT)
	tb4.AddColumnCheckBox("active", "Active", app.COLOR_PRIMARY, False)
	tb4.AddColumnRating("rate", "Satisfaction", 3, "item.color")
	tb4.AddColumnToggle("on", "Off/On", app.COLOR_PRIMARY, False)
	
	'ad as last columns
	tb4.AddColumnEdit(app.COLOR_PRIMARY)
	tb4.AddColumnDelete(app.COLOR_SECONDARY)
	
	banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate
	'change the select items for all rows
	banano.Await(tb4.SetSelectListItems("country", Array("Afghanistan", "Albania", "Australia", "USA", "Brazil", "Chile", "Guinea", "South Africa", "Nigeria")))
	'change the select items for row 2
	banano.Await(tb4.SetSelectListItemsOfRow("country", 2, Array("Afghanistan1", "Albania1", "Australia1", "USA", "Brazil", "Chile", "Guinea", "South Africa", "Nigeria1")))
	'select Australia1	
	tb4.SetRowColumn("country", 2, "Australia1")
End Sub
''
Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	Log("tb4_ChangeRow...")
	Log(Row)
	Log(Value)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_Edit (item As Map)
	Log(item)
End Sub

Private Sub tb4_Delete (item As Map)
	Log(item)
End Sub