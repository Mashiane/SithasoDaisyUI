﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adgridy"
	Public title As String = "AD Product Grid"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private dprojects As SDUIDiv
	Private pcard As SDUILink
	Private pimage As SDUIImage
	Private pcontent As SDUIDiv
	Private phead As SDUILabel
	Private pprice As SDUILabel
	Private size As SDUISelect
	Private btnBuy As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adgridylayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.dprojects", "dprojects", dprojects.CustProps)
	pgIndex.AddDesignKV1("SDUILink.pcard", "pcard", pcard.CustProps)
	pgIndex.AddDesignKV1("SDUIImage.pimage", "pimage", pimage.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.pcontent", "pcontent", pcontent.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.phead", "phead", phead.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.pprice", "pprice", pprice.CustProps)
	pgIndex.AddDesignKV1("SDUISelect.size", "size", size.CustProps)
	
	'define the child elements
	Dim children As List
	children.Initialize
	children.AddAll(Array("pcard", "pimage", "pcontent", "phead", "pprice", "size", "btnbuy"))
	'the select also has children, add these
	children.AddAll(size.Children)
	children.AddAll(btnBuy.Children)
	
	'save the template to the app and hide it
	app.AddTemplateFromLayout("pcard", True, children)
	
	'template:
	'{{image}}
	'{{alt}}
	'{{product}}
	'{{price}}
	'{{size}}
	'create list with same fields
	
	Dim products As List
	products.Initialize 
	products.Add(CreateMap("id":"p1", "image":"./assets/banner_7.jpg", "alt":"","product":"Amazing Product 1", "price":"3.00", "size":"S", "sizecaption":"TShirt"))
	products.Add(CreateMap("id":"p2", "image":"./assets/10.jpg", "alt":"","product":"Amazing Product 2", "price":"29.00", "size":"M", "sizecaption":"TShirt"))
	products.Add(CreateMap("id":"p3", "image":"./assets/9.jpg", "alt":"","product":"Amazing Product 3", "price":"35.00", "size":"L", "sizecaption":"TShirt"))
	products.Add(CreateMap("id":"p4", "image":"./assets/banner_8.jpg", "alt":"","product":"Amazing Product 4", "price":"360.00", "size":"6", "sizecaption":"Shoes"))
	products.Add(CreateMap("id":"p5", "image":"./assets/nature_01.jpg", "alt":"","product":"Amazing Product 5", "price":"530.00", "size":"9", "sizecaption":"Shoes"))
	products.Add(CreateMap("id":"p6", "image":"./assets/nature_09.jpg", "alt":"","product":"Amazing Product 6", "price":"333.00", "size":"10", "sizecaption":"Shoes"))
	products.Add(CreateMap("id":"p7", "image":"./assets/12.jpg", "alt":"","product":"Amazing Product 7", "price":"100.00", "size":"M", "sizecaption":"Trousers"))
	
	'update the parent fom the template using the list
	'we wont trap click events of elements
	app.SetItemsFromTemplateNoClick("dprojects", "pcard", products)
	'bind the btnBuy buttons per product
	app.SetActionsFromTemplate(Me, "pcard", Array("buy"), "click", products)
	
	'update the selects, define id & label for the selects
	Dim shirts As Map = CreateMap("S":"Small","M":"Medium","L":"Large")
	'for these products, the 'size' select will use shirts
	app.SetSelectItemsFromTemplate(Me, "pcard", "p1", "size", shirts, products)
	app.SetSelectItemsFromTemplate(Me, "pcard", "p2", "size", shirts, products)
	app.SetSelectItemsFromTemplate(Me, "pcard", "p3", "size", shirts, products)
	'
	'for these products, the 'size' select will use shoes
	Dim shoes As Map = CreateMap("1":"1","2":"2","3":"3","4":"4","5":"5","6":"6","7":"7","8":"8","9":"9","10":"10","11":"11","12":"12","13":"13","14":"14")
	app.SetSelectItemsFromTemplate(Me, "pcard", "p4", "size", shoes, products)
	app.SetSelectItemsFromTemplate(Me, "pcard", "p5", "size", shoes, products)
	app.SetSelectItemsFromTemplate(Me, "pcard", "p6", "size", shoes, products)
	
	'for these products, the 'size' select will use shirts
	app.SetSelectItemsFromTemplate(Me, "pcard", "p7", "size", shirts, products)
	
	BuildPage
End Sub

Sub pcard_click (e As BANanoEvent)
	e.PreventDefault
	'get the clicked element id
	Dim item As String = app.GetIDFromEvent(e)
	Dim product As String = SDUIShared.MvField(item, 1, "_")
	Dim action As String = SDUIShared.MvField(item,2,"_")
	action = action.Replace("btn", "")
	
	app.ShowSwal($"product: ${product}, action: ${action}"$)
End Sub

Sub pcard_change (e As BANanoEvent)
	e.PreventDefault
	'get the clicked element id
	Dim item As String = app.GetIDFromEvent(e)
	Dim choice As String = app.GetValue(item)
	
	Dim product As String = SDUIShared.MvField(item, 1, "_")
	
	app.ShowSwal($"product: ${product}, choice: ${choice}"$)
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
