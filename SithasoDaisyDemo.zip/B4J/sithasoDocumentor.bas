﻿B4J=true
Group=Default Group\Tools
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "documentor"
	Public title As String = "Sithaso Documentor"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private fileOpenZip As SDUIFileInput
	Private R1 As SDUIRow
	Private R1C1 As SDUICol
	Private SDUIMockupCode1 As SDUIMockupCode
	Private txtCode As SDUITextArea
	Private sbBuild As StringBuilder
	Private sbPreviewComponent As StringBuilder
	private sbComponents as stringbuilder
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "documentorlayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Sub fileOpenZip_change(e As BANanoEvent)
	Dim sbLine As StringBuilder
	sbLine.Initialize
	'
	sbBuild.Initialize
	sbPreviewComponent.Initialize
	sbComponents.Initialize
	Dim sbAPI As StringBuilder
	sbAPI.Initialize 
	Dim sbStyles As StringBuilder
	sbStyles.Initialize  
	'
	'has the file been specified
	Dim fileObj As Map = fileOpenZip.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'fileDet = SDUIShared.UploadFileOptionsWait(fileObj, "../assets", "n")
	'get the file name
	Dim fn As String = fileDet.FileName
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
	Case "error"
		app.ShowSwalError("File could not be uploaded!")
		Return
	Case "success"
		app.ShowSwalSuccess($"${fn} has been uploaded to server!"$)
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	'update state of some element like an image
	'unzip the file
	Dim php As SDUIPhp
	php.Initialize("", False)
	banano.Await(php.DirectoryDeleteWait("./documents"))
	banano.Await(php.DirectoryCreateWait("./documents/views"))
	banano.Await(php.UnZipWait(fp, "./documents"))
	Dim files As List = banano.Await(php.DirectoryListRecursiveWait("./documents"))
	files.Sort(True)
	Dim basFiles As List
	basFiles.Initialize 
	For Each s As String In files
		If s.ToLowerCase.EndsWith(".bas") Then
			'get the file details
			Dim fo As FileObject = banano.Await(php.FileDetailsWait(s))
			'get the file contents
			Dim sc As String = banano.Await(php.FileReadWait(s))
			'code handle
			Dim ch As SDUICodeHandler
			ch.Initialize
			ch.IncludePublicMethodsOnly = True
			ch.IncludeArguments = False
			ch.IncludeCode = False
			ch.IncludeSignatures = False
			ch.CleanSignatures = True
			'get stuff of file
			banano.await(ch.ScanWait(sc))
			'how many props
			Dim dps As Int = ch.DesignerProperties.Size
			'does not have props
			If dps = 0 Then Continue
			basFiles.Add(s)
			'copy the file
			'banano.Await(php.FileCopyWait(s, nfn))
			'
			Dim jsonFileName As String = SDUIShared.MvField(fo.FileName,1, ".")
			Dim nfn As String = $"./documents/views/${jsonFileName}.json"$
			Dim nm As Map = CreateMap()
			nm.Put("properties", ch.DesignerProperties)
			nm.Put("events", ch.EventsMap)
			nm.Put("methods", ch.MethodsList)
			Dim fc As String = banano.ToJson(nm)
			banano.Await(php.FileCreateWait(nfn, fc))
			'
			sbAPI.Append($"ionicComponents.Add("${jsonFileName}")"$).Append(CRLF)
			If jsonFileName.EndsWith("Style") Then
				sbStyles.Append(jsonFileName).Append(CRLF)
			End If
			
			If jsonFileName.StartsWith("SDU") Then
				sbLine.Append($"drawer.AddItemChild("api", "api-${jsonFileName}", "${jsonFileName}")"$).Append(CRLF)
			End If
			'
			sbBuild.Append($"Sub Build${jsonFileName}(component As Map)"$).Append(CRLF)
			sbBuild.Append($"Dim sComponentName As String = component.Get("ComponentName")"$).Append(CRLF)
			sbBuild.Append($"Dim sComponentParentID As String = component.GetDefault("ComponentParentID", "")"$).Append(CRLF)
			sbBuild.Append($"Dim bParentDevice As Boolean = modSithasoIonic.CBool(component.Get("ParentDevice"))"$).Append(CRLF)
			sbBuild.Append($"Dim thisComp As ${jsonFileName}"$).Append(CRLF)
			sbBuild.Append($"thisComp.Initialize(Me, sComponentName, sComponentName)"$).Append(CRLF)
			sbBuild.Append($"If bParentDevice Then"$).Append(CRLF)
			sbBuild.Append($"thisComp.AddToParent(SHIonMarvelDevice1.getHereScreen, component)"$).Append(CRLF)
			sbBuild.Append($"Else"$).Append(CRLF)
			sbBuild.Append($"thisComp.AddToParent(sComponentParentID, component)"$).Append(CRLF)
			sbBuild.Append($"End If"$).Append(CRLF)
			sbBuild.Append($"End Sub"$).Append(CRLF).Append(CRLF)
			'
			sbPreviewComponent.Append($"Case "${jsonFileName}""$).Append(CRLF)
			sbPreviewComponent.Append($"Build${jsonFileName}(component)"$).Append(CRLF)
			sbComponents.Append($"ComponentLink.put("${jsonFileName.tolowercase}", "${jsonFileName}")"$).Append(CRLF)
		End If
	Next
	app.ShowSwalSuccess(basFiles.Size & " file(s) have been processed!")
	Dim out As String = sbLine.ToString
	out = out & CRLF & CRLF & CRLF & sbBuild.ToString
	out = out & CRLF & CRLF & CRLF & sbPreviewComponent.ToString
	out = out & CRLF & CRLF & CRLF & sbComponents.ToString
	out = out & CRLF & CRLF & CRLF & sbAPI.ToString
	
	out = ""
	out = out & CRLF & CRLF & CRLF & sbStyles.tostring
	SDUIMockupCode1.Value = out
	banano.Await(app.CopyToClipboard(out))
End Sub

Private Sub txtCode_Prepend_Click (event As BANanoEvent)
	txtCode.Value = banano.Await(app.CopyFromClipBoard)
End Sub

Private Sub txtCode_Append_Click (event As BANanoEvent)
	Dim spCode As List = SDUIShared.StrParse(CRLF, txtCode.Value)
	Dim sb As StringBuilder
	sb.Initialize
	sb.Append($"pgIndex.ShowDesign"$).Append(CRLF)
	sb.Append("pgIndex.ClearDesign").Append(CRLF)
	sb.Append($"pgIndex.AddDesignKV("", "--Nothing Selected--")"$).Append(CRLF)
	sb.append($"pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)"$).Append(CRLF)
		 
	For Each item As String In spCode
		item = item.Trim
		If item.StartsWith("Private") = False Then Continue
		Dim varName As String = SDUIShared.MvField(item,2, " ")
		Dim varType As String = SDUIShared.MvField(item,4, " ")
		sb.append($"pgIndex.AddDesignKV1("${varType}.${varName}", "${varName}", ${varName}.CustProps)"$).Append(CRLF)
	Next
	Dim out As String = sb.ToString
	SDUIMockupCode1.Value = out
	banano.Await(app.CopyToClipboard(out))
End Sub