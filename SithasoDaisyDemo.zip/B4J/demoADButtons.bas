﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adbuttons"
	Public title As String = "AD Buttons"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIButton1 As SDUIButton
	Private SDUIButton2 As SDUIButton
	Private SDUIButton3 As SDUIButton
	Private SDUIButton4 As SDUIButton
	Private SDUIButton5 As SDUIButton
	Private SDUIButton6 As SDUIButton
	Private SDUIButton7 As SDUIButton
	Private SDUIButton4 As SDUIButton
	Private SDUIButton5 As SDUIButton
	Private SDUIButton6 As SDUIButton
	Private SDUIButton7 As SDUIButton
	Private SDUIButton10 As SDUIButton
	Private SDUIButton8 As SDUIButton
	Private SDUIButton9 As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adbuttonslayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton1", "SDUIButton1", SDUIButton1.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton2", "SDUIButton2", SDUIButton2.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton3", "SDUIButton3", SDUIButton3.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton4", "SDUIButton4", SDUIButton4.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton5", "SDUIButton5", SDUIButton5.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton6", "SDUIButton6", SDUIButton6.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton7", "SDUIButton7", SDUIButton7.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton8", "SDUIButton8", SDUIButton8.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton9", "SDUIButton9", SDUIButton9.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton10", "SDUIButton10", SDUIButton10.CustProps)
	'
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIButton1_Click (e As BANanoEvent)
	app.ShowSwalAlertWait("Click", "This is a button click event...", "Ok")
End Sub