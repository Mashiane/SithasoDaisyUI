﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "designgrid"
	Public title As String = "Grid Design"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(True)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows1.AddColumns11.AddColumns1
	page.Root.AddRows1.AddColumns10.AddColumns2
	page.Root.AddRows1.AddColumns9.AddColumns3
	page.Root.AddRows1.AddColumns8.AddColumns4
	page.Root.AddRows1.AddColumns7.AddColumns5
	page.Root.AddRows1.AddColumns6.AddColumns6
	page.Root.AddRows1.AddColumns5.AddColumns7
	page.Root.AddRows1.AddColumns4.AddColumns8
	page.Root.AddRows1.AddColumns3.AddColumns9
	page.Root.AddRows1.AddColumns2.AddColumns10
	page.Root.AddRows1.AddColumns1.AddColumns11
	page.Root.AddRows1.AddColumns6.AddColumns3.Addcolumns3
	page.Root.AddRows1.AddColumns2.AddColumns8.Addcolumns2
	page.Root.AddRows1.AddColumns1.AddColumns9.Addcolumns2
	'start adding you components here
	page.Root.AddRows1.AddColumns12
	
	'build the grid
	page.Root.BuildGrid
	
	Dim c20 As SDUIMockupCode = page.Cell(16, 1).AddMockUpCode("c20", "vb")
	c20.AddCode($"page.Root.AddRows1.AddColumns12"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns11.AddColumns1"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns10.AddColumns2"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns9.AddColumns3"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns8.AddColumns4"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns7.AddColumns5"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns6.AddColumns6"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns5.AddColumns7"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns4.AddColumns8"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns3.AddColumns9"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns2.AddColumns10"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns1.AddColumns11"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns6.AddColumns3.Addcolumns3"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns2.AddColumns8.Addcolumns2"$)
	c20.AddCode($"page.Root.AddRows1.AddColumns1.AddColumns9.Addcolumns2"$)
	c20.AddCode($"'build the grid"$)
	c20.AddCode($"page.Root.BuildGrid"$)
	c20.Refresh

'	
'	page.Cell(1, 1).Caption = "Container.AddRows1.AddColumns12"
'	page.Cell(1, 1).Root.BGColorIntensity(app.COLOR_YELLOW, 300)
'	'page.Cell(1, 1).Root.TextColor = app.COLOR_WHITE
'	page.Cell(1, 1).Root.TextSize = app.SIZE_XS
'	'
'	page.Cell(2, 1).Caption = ".AddColumns11"
'	page.Cell(2, 1).Root.BGColorIntensity(app.COLOR_PURPLE, 700)
'	page.Cell(2, 2).Caption = ".AddColumns1"
'	page.Cell(2, 2).Root.BGColorIntensity(app.COLOR_YELLOW, 700)
'	page.Cell(2, 1).Root.TextColor = app.COLOR_WHITE
'	page.Cell(2, 2).Root.TextColor = app.COLOR_WHITE
'	page.Cell(2, 1).Root.TextSize = app.SIZE_XS
'	page.Cell(2, 2).Root.TextSize = app.SIZE_XS
'	
'	'
'	page.Cell(3, 1).Caption = ".AddColumns10"
'	page.Cell(3, 1).Root.BGColorIntensity(app.COLOR_PURPLE, 700)
'	page.Cell(3, 2).Caption = ".AddColumns2"
'	page.Cell(3, 2).Root.BGColorIntensity(app.COLOR_YELLOW, 700)
'	page.Cell(3, 1).Root.TextColor = app.COLOR_WHITE
'	page.Cell(3, 2).Root.TextColor = app.COLOR_WHITE
'	page.Cell(3, 1).Root.TextSize = app.SIZE_XS
'	page.Cell(3, 2).Root.TextSize = app.SIZE_XS
'	'
'	page.Cell(3, 1).Caption = ".AddColumns10"
'	page.Cell(3, 1).Root.BGColorIntensity(app.COLOR_PURPLE, 700)
'	page.Cell(3, 2).Caption = ".AddColumns2"
'	page.Cell(3, 2).Root.BGColorIntensity(app.COLOR_YELLOW, 700)
'	page.Cell(3, 1).Root.TextColor = app.COLOR_WHITE
'	page.Cell(3, 2).Root.TextColor = app.COLOR_WHITE
'	page.Cell(3, 1).Root.TextSize = app.SIZE_XS
'	page.Cell(3, 2).Root.TextSize = app.SIZE_XS
End Sub
