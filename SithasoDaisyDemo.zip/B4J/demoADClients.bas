﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adclients"
	Public title As String = "AD Clients"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private tblClients As SDUITable
	Private masterClients As List
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	''banano.Await(app.UsesTable)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adclientslayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUITable.tblClients", "tblClients", tblClients.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	tblClients.AddColumn("title", "Title")
	tblClients.AddColumn("first", "First Name")
	tblClients.AddColumn("last", "Last Name")
	tblClients.AddColumn("email", "Email")
	tblClients.AddColumn("phone", "Phone")
	tblClients.AddColumn("cell", "Cellphone")
	tblClients.AddColumn("nat", "Nationality")
	'***COMPULSORY
	tblClients.AddDesignerColums
	'***
	
	tblClients.AddToolbarActionButtonIcon("print", "fa-solid fa-print", app.COLOR_INDIGO)
	tblClients.AddToolbarActionButtonIcon("lesson", "fa-solid fa-wand-magic-sparkles", app.COLOR_AMBER)
	mounted
End Sub

Sub tblClients_lesson (e As BANanoEvent)
	'open the lesson link
	SDUIShared.OpenURLTab("https://www.b4x.com/android/forum/threads/sithasodaisy-how-to-create-a-client-list-report-in-ms-word.144355/")
End Sub

Sub tblClients_print (e As BANanoEvent)
	'do we have a client list
	If masterClients.Size = 0 Then
		app.ShowSwalError("No clients to process!")
		Return
	End If
	'
	'show a loading indicator on print button
	tblClients.SetToolbarButtonLoading("print", True)
	
	'initialize the ms word document builder
	
	Dim doc As SDUIDocxTemplator
	'this will raise an event called docx_finished.
	'we give it the template we created and the name of the download we want
	doc.Initialize(Me, "docx", "./assets/users_report.docx", "client_report.docx")
	'we set the 'clients' field, passing it the list of clients
	doc.SetField("clients", masterClients)
	'we build our document
	banano.Await(doc.BuildWait)
	
	tblClients.SetToolbarButtonLoading("print", False)
	
End Sub

Sub docx_finished
	app.ShowSwalSuccess("Report finished!")
End Sub

Sub mounted
	'show a loading indicato
	tblClients.SetToolbarButtonLoading("Refresh", True)
	
	'initialize the list to store our clients
	masterClients.Initialize 
	'initialize BANanoFetch
	Dim clients As SDUIFetch
	'pass the base url for the api
	clients.Initialize("https://randomuser.me/api")
	'we want only 100 client records
	clients.AddParameter("results", 100)
	'the content type should be JSON
	clients.SetContentTypeApplicationJSON
	'execute the GET call
	banano.Await(clients.GetWait)
	If clients.Success Then
		'on success, get the results
		Dim Response As Map = clients.response
		Dim results As List = Response.get("results")
		'loop through each to get the schema that we want for the list
		'as per fields we have defined.
		For Each client As Map In results
			Dim c As Map = CreateMap()
			c.Put("email", client.Get("email"))
			c.Put("title", SDUIShared.GetRecursive(client, "name.title"))
			c.Put("first", SDUIShared.GetRecursive(client, "name.first"))
			c.Put("last", SDUIShared.GetRecursive(client, "name.last"))
			c.Put("phone", client.Get("phone"))
			c.Put("cell", client.Get("cell"))
			c.Put("nat", client.Get("nat"))
			'add to the master client list
			masterClients.Add(c)
		Next
		'update the table and use pagination
		tblClients.SetItemsPaginate(masterClients)
	Else
		Log(clients.ErrorMessage)
	End If
	tblClients.SetToolbarButtonLoading("Refresh", False)
End Sub


Private Sub tblClients_Refresh (e As BANanoEvent)
	banano.Await(mounted)
End Sub

'Private Sub tblClients_PrevPage (e As BANanoEvent)
'	tblClients.ShowPreviousPage
'End Sub
'
'Private Sub tblClients_NextPage (e As BANanoEvent)
'	tblClients.ShowNextPage
'End Sub