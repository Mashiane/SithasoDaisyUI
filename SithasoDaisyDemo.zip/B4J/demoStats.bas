﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "stats"
	Public title As String = "Stats"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano			'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows10.AddColumns5p7
	page.Root.BuildGrid
	'
	Dim stats1 As SDUIStats = page.Cell(1, 1).AddStats("stats1")
	'stats1.Vertical
	'stats1.HorizontalResponsive(False, True, False, False)
	stats1.AddItem("pageviews", "Total Page Views", "89, 400", "21% more than last month")
	stats1.Root.Shadow("")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim stats1 As SDUIStats = page.Cell(1, 1).AddStats("stats1")"$)
	c1.AddCode($"stats1.AddItem("pageviews", "Total Page Views", "89, 400", "21% more than last month")"$)
	c1.AddCode($"stats1.Root.Shadow= True"$)
	c1.Refresh
	'
	Dim stats2 As SDUIStats = page.Cell(2, 1).AddStats("stats2")
	'stats2.VerticalOnSmallOnly
	stats2.Vertical
	'stats2.HorizontalResponsive(False, True, False, False)
	stats2.Root.Shadow("")
	
	stats2.AddItem("likes", "Total Likes", "25.6K", "21% more than last month")
	stats2.GetItemFigure("likes").TextColor(app.color_Primary)
	stats2.GetItemValue("likes").TextColor(app.color_Primary)
	stats2.GetItemIcon("likes").IconName = "fa-solid fa-circle-info"
	stats2.GetItemIcon("likes").SizeOwn = 2
	'	
	stats2.AddItem("views", "Page Views", "2.6M", "21% more than last month")
	stats2.GetItemFigure("views").TextColor(app.Color_Secondary)
	stats2.GetItemValue("views").TextColor(app.COlor_Secondary)
	'	
	stats2.AddItem1("tasks", "Tasks Done", "80%", "31 tasks remaining")
	stats2.GetItemFigure("tasks").TextColor(app.color_Secondary)
	stats2.GetItemDesc("tasks").TextColor(app.color_Secondary)
	stats2.GetItemAvatar("tasks").Src = "./assets/face5.jpg"
	stats2.GetItemAvatar("tasks").Online = True
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim stats2 As SDUIStats = page.Cell(2, 1).AddStats("stats2")"$)
	c2.AddCode($"stats2.Root.Shadow= True"$)
	c2.AddCode($"stats2.AddItem("likes", "Total Likes", "25.6K", "21% more than last month")"$)
	c2.AddCode($"stats2.ItemFigure("likes").TextColor = app.color_Primary"$)
	c2.AddCode($"stats2.ItemValue("likes").TextColor = app.color_Primary"$)
	c2.AddCode($"stats2.ItemIcon("likes").IconName = "fa-solid fa-circle-info""$)
	c2.AddCode($"stats2.ItemIcon("likes").SizeOwn = 2"$)
	c2.AddCode($"'"$)
	c2.AddCode($"stats2.AddItem("views", "Page Views", "2.6M", "21% more than last month")"$)
	c2.AddCode($"stats2.ItemFigure("views").TextColor = app.Color_Secondary"$)
	c2.AddCode($"stats2.ItemValue("views").TextColor = app.COlor_Secondary"$)
	c2.AddCode($"'"$)
	c2.AddCode($"stats2.AddItem1("tasks", "Tasks Done", "80%", "31 tasks remaining")"$)
	c2.AddCode($"stats2.ItemFigure("tasks").TextColor = app.color_Secondary"$)
	c2.AddCode($"stats2.ItemDesc("tasks").TextColor = app.color_Secondary"$)
	c2.AddCode($"stats2.ItemAvatar("tasks").Src = "./assets/face5.jpg""$)
	c2.AddCode($"stats2.ItemAvatar("tasks").Online = True"$)
	c2.Refresh
	'
	Dim stats3 As SDUIStats = page.Cell(3, 1).AddStats("stats3")
	'stats3.Vertical
	'stats3.HorizontalResponsive(False, True, False, False)
	stats3.AddItem("downs", "Downloads", "25.6K", "From January 1st To February 1st")
	stats3.GetItem("downs").PlaceItemsCenter
	'
	stats3.AddItem("users", "Users", "4, 200", "↗︎ 40 (2%)")
	stats3.GetItem("users").PlaceItemsCenter
	stats3.GetItemValue("users").TextColor(app.color_Secondary)
	stats3.GetItemDesc("users").TextCOlor(app.color_Secondary)
	'
	stats3.AddItem1("new", "New Registrations", "1, 200", "↘︎ 90 (14%)")
	stats3.GetItem("new").PlaceItemsCenter
	stats3.Root.Shadow("")
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim stats3 As SDUIStats = page.Cell(3, 1).AddStats("stats3")"$)
	c3.AddCode($"stats3.Root.Shadow= True"$)
	c3.AddCode($"stats3.AddItem("downs", "Downloads", "25.6K", "From January 1st To February 1st")"$)
	c3.AddCode($"stats3.Item("downs").PlaceItemsCenter"$)
	c3.AddCode($"'"$)
	c3.AddCode($"stats3.AddItem("users", "Users", "4, 200", "↗︎ 40 (2%)")"$)
	c3.AddCode($"stats3.Item("users").PlaceItemsCenter"$)
	c3.AddCode($"stats3.ItemValue("users").TextColor = app.color_Secondary"$)
	c3.AddCode($"stats3.ItemDesc("users").TextCOlor = app.color_Secondary"$)
	c3.AddCode($"'"$)
	c3.AddCode($"stats3.AddItem1("new", "New Registrations", "1, 200", "↘︎ 90 (14%)")"$)
	c3.AddCode($"stats3.Item("new").PlaceItemsCenter"$)
	c3.Refresh
	'
	Dim stats4 As SDUIStats = page.Cell(4, 1).AddStats("stats4")
	'stats4.vertical
	'stats4.HorizontalResponsive(False, True, False, False)
	stats4.AddItem("downs1", "Downloads", "25.6K", "From January 1st To February 1st")
	stats4.GetItem("downs1").PlaceItemsCenter
	'
	stats4.AddItem("users1", "Users", "4, 200", "↗︎ 40 (2%)")
	stats4.GetItem("users1").PlaceItemsCenter
	stats4.GetItemValue("users1").TextColor(app.color_Secondary)
	stats4.GetItemDesc("users1").TextColor(app.color_Secondary)
	'
	stats4.AddItem1("new1", "New Registrations", "1, 200", "↘︎ 90 (14%)")
	stats4.GetItem("new1").PlaceItemsCenter
	stats4.Root.Shadow("")
	
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim stats4 As SDUIStats = page.Cell(4, 1).AddStats("stats4")"$)
	c4.AddCode($"stats4.AddItem("downs1", "Downloads", "25.6K", "From January 1st To February 1st")"$)
	c4.AddCode($"stats4.Item("downs1").PlaceItemsCenter"$)
	c4.AddCode($"'"$)
	c4.AddCode($"stats4.AddItem("users1", "Users", "4, 200", "↗︎ 40 (2%)")"$)
	c4.AddCode($"stats4.Item("users1").PlaceItemsCenter"$)
	c4.AddCode($"stats4.ItemValue("users1").TextColor = app.color_Secondary"$)
	c4.AddCode($"stats4.ItemDesc("users1").TextColor = app.color_Secondary"$)
	c4.AddCode($"'"$)
	c4.AddCode($"stats4.AddItem1("new1", "New Registrations", "1, 200", "↘︎ 90 (14%)")"$)
	c4.AddCode($"stats4.Item("new1").PlaceItemsCenter"$)
	c4.AddCode($"stats4.Root.Shadow= True"$)
	c4.AddCode($"stats4.Vertical"$)
	c4.Refresh
	
	Dim stats5 As SDUIStats = page.Cell(5, 1).AddStats("stats5")
	'stats5.Vertical
	'stats5.HorizontalResponsive(False, True, False, False)
	stats5.Root.BGColor(app.color_Primary)
	stats5.Root.TextColorIntensity(app.COLOR_PRIMARY,"content")
	'
	stats5.AddItem("downs2", "Account Balance", "$89,400", "")
	stats5.AddItemActionButton("downs2", "addfunds", "Add Funds")
	stats5.GetItemAction("downs2", "addfunds").Size = app.SIZE_SM
	stats5.GetItemAction("downs2", "addfunds").Color = app.COLOR_SUCCESS
	
	'
	stats5.AddItem("users2", "Current Balance", "$89,400", "")
	stats5.AddItemActionButton("users2", "withdrawal", "Withdrawal")
	stats5.GetItemAction("users2", "withdrawal").Size = app.SIZE_SM
	'
	stats5.AddItemActionButton("users2", "deposit", "Deposit")
	stats5.GetItemAction("users2", "deposit").Size = app.SIZE_SM
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim stats5 As SDUIStats = page.Cell(5, 1).AddStats("stats5")"$)
	c5.AddCode($"stats5.Root.BGColor = app.color_Primary"$)
	c5.AddCode($"stats5.Root.TextColorIntensity(app.COLOR_PRIMARY,"content")"$)
	c5.AddCode($"'"$)
	c5.AddCode($"stats5.AddItem("downs2", "Account Balance", "~89,400", "")"$)
	c5.AddCode($"stats5.AddItemActionButton("downs2", "addfunds", "Add Funds")"$)
	c5.AddCode($"stats5.ItemAction("downs2", "addfunds").Size = app.SIZE_SM"$)
	c5.AddCode($"stats5.ItemAction("downs2", "addfunds").Color = app.COLOR_SUCCESS"$)
	c5.AddCode($"'"$)
	c5.AddCode($"stats5.AddItem("users2", "Current Balance", "~89,400", "")"$)
	c5.AddCode($"stats5.AddItemActionButton("users2", "withdrawal", "Withdrawal")"$)
	c5.AddCode($"stats5.ItemAction("users2", "withdrawal").Size = app.SIZE_SM"$)
	c5.AddCode($"'"$)
	c5.AddCode($"stats5.AddItemActionButton("users2", "deposit", "Deposit")"$)
	c5.AddCode($"stats5.ItemAction("users2", "deposit").Size = app.SIZE_SM"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Sub downs2_addfunds_click (e As BANanoEvent)"$)
	c5.AddCode($"page.Cell(6, 1).Caption = "Add Funds""$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Sub users2_withdrawal_click (e As BANanoEvent)"$)
	c5.AddCode($"page.Cell(6, 1).Caption = "Widthdrawal""$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Sub users2_deposit_click (e As BANanoEvent)"$)
	c5.AddCode($"page.Cell(6, 1).Caption = "Deposit""$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
	
	'Dim ic As SDUIStats = page.Cell(6, 1).AddInfoCard("ic1", "fa-solid fa-users", "orange", "2345", "Users")
End Sub

Sub downs2_addfunds_click (e As BANanoEvent)
	page.Cell(6, 1).Caption = "Add Funds"
End Sub

Sub users2_withdrawal_click (e As BANanoEvent)
	page.Cell(6, 1).Caption = "Widthdrawal"
End Sub

Sub users2_deposit_click (e As BANanoEvent)
	page.Cell(6, 1).Caption = "Deposit"
End Sub

