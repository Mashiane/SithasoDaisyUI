﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adindicators"
	Public title As String = "AD Indicators"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIAvatar1 As SDUIAvatar
	Private SDUIDiv1 As SDUIDiv
	Private SDUIIndicator1 As SDUIIndicator
	Private SDUIIndicator2 As SDUIIndicator
	Private SDUIIndicator3 As SDUIIndicator
	Private SDUITextBox1 As SDUITextBox
	Private SDUIImage1 As SDUIImage
	Private SDUIIndicator4 As SDUIIndicator
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adindicatorslayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar1", "SDUIAvatar1", SDUIAvatar1.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv1", "SDUIDiv1", SDUIDiv1.CustProps)
	pgIndex.AddDesignKV1("SDUIIndicator.SDUIIndicator1", "SDUIIndicator1", SDUIIndicator1.CustProps)
	pgIndex.AddDesignKV1("SDUIIndicator.SDUIIndicator2", "SDUIIndicator2", SDUIIndicator2.CustProps)
	pgIndex.AddDesignKV1("SDUIIndicator.SDUIIndicator3", "SDUIIndicator3", SDUIIndicator3.CustProps)
	pgIndex.AddDesignKV1("SDUIIndicator.SDUIIndicator4", "SDUIIndicator4", SDUIIndicator4.CustProps)
	pgIndex.AddDesignKV1("SDUITextBox.SDUITextBox1", "SDUITextBox1", SDUITextBox1.CustProps)
	pgIndex.AddDesignKV1("SDUIImage.SDUIImage1", "SDUIImage1", SDUIImage1.CustProps)

	SDUIIndicator3.Card.Title.Caption = "Job Title"
	SDUIIndicator3.Card.Container.Caption = "Do you want to apply?"
	SDUIIndicator3.Card.Bordered
	SDUIIndicator3.Card.Shadow = "md"
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
