﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adbuttongroup"
	Public title As String = "AD ButtonGroup"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIButtonGroup1 As SDUIButtonGroup
	Private SDUIButtonGroup2 As SDUIButtonGroup
	Private SDUIButtonGroup3 As SDUIButtonGroup
	Private SDUIButtonGroup4 As SDUIButtonGroup
	Private SDUIButtonGroup5 As SDUIButtonGroup
	Private SDUIButtonGroup6 As SDUIButtonGroup
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adbuttongrouplayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup1", "SDUIButtonGroup1", SDUIButtonGroup1.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup2", "SDUIButtonGroup2", SDUIButtonGroup2.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup3", "SDUIButtonGroup3", SDUIButtonGroup3.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup4", "SDUIButtonGroup4", SDUIButtonGroup4.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup5", "SDUIButtonGroup5", SDUIButtonGroup5.CustProps)
	pgIndex.AddDesignKV1("SDUIButtonGroup.SDUIButtonGroup6", "SDUIButtonGroup6", SDUIButtonGroup6.CustProps)

	'BuildPage
	SDUIButtonGroup1.AddItem("home", "Home")
	SDUIButtonGroup1.AddItem("docs", "Documents")
	SDUIButtonGroup1.AddItem("adddocs", "Add Documents")
	'
	SDUIButtonGroup2.AddItemIcon("home1", "fa-solid fa-house")
	SDUIButtonGroup2.AddItemIcon("docs1", "fa-regular fa-folder-open")
	SDUIButtonGroup2.AddItemIcon("adddocs1", "fa-solid fa-plus")
	'
	SDUIButtonGroup3.AddItemColor("home1", "Home", app.color_primary)
	SDUIButtonGroup3.AddItemColor("docs1", "Documents", app.color_secondary)
	SDUIButtonGroup3.AddItemColor("adddocs1", "Help", app.COLOR_ERROR)
	'
	SDUIButtonGroup4.AddItem("grp1", "<<")
	SDUIButtonGroup4.AddItem("grp2", "Page 22")
	SDUIButtonGroup4.AddItem("grp3", ">>")
	SDUIButtonGroup4.Active = "grp1"
	'
	SDUIButtonGroup5.AddItem("grp1", "1")
	SDUIButtonGroup5.AddItem("grp2", "2")
	SDUIButtonGroup5.AddItem("grp3", "...")
	SDUIButtonGroup5.AddItem("grp4", "4")
	SDUIButtonGroup5.Button("grp3").Disable
	'
	SDUIButtonGroup6.Root.Grid
	SDUIButtonGroup6.Root.GridCols(2)
	SDUIButtonGroup6.AddItem("grp1", "Previous")
	SDUIButtonGroup6.AddItem("grp2", "Next")
	SDUIButtonGroup6.Button("grp1").Outline
	SDUIButtonGroup6.Button("grp2").Outline
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIButtonGroup2_Click (item As String)
	app.ShowSwalInfo(item)
End Sub

Private Sub SDUIButtonGroup1_Click (item As String)
	app.ShowSwalInfo(item)
End Sub


Private Sub SDUIButtonGroup3_Click (item As String)
	app.ShowSwalInfo(item)
End Sub

Private Sub SDUIButtonGroup6_Click (item As String)
	
End Sub

Private Sub SDUIButtonGroup5_Click (item As String)
	
End Sub

Private Sub SDUIButtonGroup4_Click (item As String)
	
End Sub