﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "ranges"
	Public title As String = "Range"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private rng As SDUIRange
	Private rng3 As SDUIRange
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns4p8
	page.Root.BuildGrid
	'start adding you components here
	
	rng = page.Cell(1, 1).AddRange("rng")
	
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"rng = page.Cell(1, 1).AddRange("rng")"$)
	c1.Refresh
	
	'
	Dim rngp As SDUIRange = page.Cell(2, 1).AddRange("rngp")
	rngp.color = app.COLOR_PRIMARY
	rngp.size = app.SIZE_SM
	rngp.Value = 80
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim rngp As SDUIRange = page.Cell(2, 1).AddRange("rngp")"$)
	c2.AddCode($"rngp.color = app.COLOR_PRIMARY"$)
	c2.AddCode($"rngp.size = app.SIZE_SM"$)
	c2.AddCode($"rngp.Value = 80"$)
	c2.Refresh
	
	Dim btnGet As SDUIButton = page.Cell(1,1).AddButton("btnget", "Get")
	'
	Dim btnSet As SDUIButton = page.Cell(1,1).AddButton("btnset", "Set")
	'
	
	rng3 = page.Cell(3, 1).AddRangeLabel("rng3", "Tasks done", "Hint", 10)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"rng3 = page.Cell(3, 1).AddRangeLabel("rng3", "Tasks done", "Hint", 10)"$)
	c3.Refresh
End Sub

'this is needed to reflect changes to value indicators
Private Sub rng3_Change (value As Int)
	page.Cell(4, 1).Caption = value
End Sub


Private Sub rng_Change (value As Int)
	page.Cell(4, 1).Caption = value
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	Dim i As Int = rng.Value
	page.Cell(4, 1).Caption = i
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	'set a random number between 1 and 100
	rng.value = Rnd(1, 100)
	page.Cell(4, 1).Caption = rng.value
End Sub
