﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "mylists"
	Public title As String = "Lists"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here

	Dim ul1 As SDUIList = page.Cell(1, 1).AddList("ul1", False, 3, 5)
	ul1.textSize("md")
	ul1.textColorIntensity("gray", 600).listDisc.markerTextColorIntensity("orange", 700)
	ul1.AddListItemLabel("ul1li1", "List style with marker class 1")
	ul1.AddListItemLabel("ul1li2", "List style with marker class 2")
	ul1.AddListItemLabel("ul1li3", "List style with marker class 3")
	ul1.AddListItemLabel("ul1li4", "List style with marker class 4")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim ul1 As SDUIList = page.Cell(1, 1).AddList("ul1", False, 3, 5)"$)
	c1.AddCode($"ul1.textSize("md")"$)
	c1.AddCode($"ul1.textColorIntensity("gray", 600).listDisc.markerTextColorIntensity("orange", 700)"$)
	c1.AddCode($"ul1.AddListItemLabel("ul1li1", "List style with marker class 1")"$)
	c1.AddCode($"ul1.AddListItemLabel("ul1li2", "List style with marker class 2")"$)
	c1.AddCode($"ul1.AddListItemLabel("ul1li3", "List style with marker class 3")"$)
	c1.AddCode($"ul1.AddListItemLabel("ul1li4", "List style with marker class 4")"$)
	c1.Refresh
	'	
	Dim ul2 As SDUIList = page.Cell(2, 1).AddList("ul2", False, 3, 5)
	ul2.textSize("lg")
	ul2.textColorIntensity("gray", 600).listDecimal.markerTextColorIntensity("purple", 600)
	ul2.AddListItemLabel("li1", "List style with marker class 1")
	ul2.AddListItemLabel("li2", "List style with marker class 2")
	ul2.AddListItemLabel("li3", "List style with marker class 3")
	ul2.AddListItemLabel("li4", "List style with marker class 4")
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim ul2 As SDUIList = page.Cell(2, 1).AddList("ul2", False, 3, 5)"$)
	c2.AddCode($"ul2.textSize("lg")"$)
	c2.AddCode($"ul2.textColorIntensity("gray", 600).listDecimal.markerTextColorIntensity("purple", 600)"$)
	c2.AddCode($"ul2.AddListItemLabel("li1", "List style with marker class 1")"$)
	c2.AddCode($"ul2.AddListItemLabel("li2", "List style with marker class 2")"$)
	c2.AddCode($"ul2.AddListItemLabel("li3", "List style with marker class 3")"$)
	c2.AddCode($"ul2.AddListItemLabel("li4", "List style with marker class 4")"$)
	c2.Refresh
	'
	Dim ul3 As SDUIList = page.Cell(3, 1).AddList("ul3", False, 3, 5)
	ul3.textSize("2xl")
	ul3.textColorIntensity("gray", 600).listDecimal.markertextColor("#ff0000")
	ul3.AddListItemLabel("li31", "List style with marker class 1")
	ul3.AddListItemLabel("li32", "List style with marker class 2")
	ul3.AddListItemLabel("li33", "List style with marker class 3")
	ul3.AddListItemLabel("li34", "List style with marker class 4")
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim ul3 As SDUIList = page.Cell(3, 1).AddList("ul3", False, 3, 5)"$)
	c3.AddCode($"ul3.textSize("2xl")"$)
	c3.AddCode($"ul3.textColorIntensity("gray", 600).listDecimal.markertextColor("#ff0000")"$)
	c3.AddCode($"ul3.AddListItemLabel("li31", "List style with marker class 1")"$)
	c3.AddCode($"ul3.AddListItemLabel("li32", "List style with marker class 2")"$)
	c3.AddCode($"ul3.AddListItemLabel("li33", "List style with marker class 3")"$)
	c3.AddCode($"ul3.AddListItemLabel("li34", "List style with marker class 4")"$)
	c3.Refresh
End Sub
