﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "ratings"
	Public title As String = "Rating"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private rat1 As SDUIRating
	Private rat2 As SDUIRating
	Private rat3 As SDUIRating
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows7.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	
	rat1 = page.Cell(1,1).AddRating("rat1", 5)
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"rat1 = page.Cell(1,1).AddRating("rat1", 5)"$)
	c1.Refresh
	
	rat2 = page.Cell(2,1).AddRating("rat2", 5)
	rat2.Mask = app.MASK_HEART
	rat2.BGColorIntensity(app.COLOR_RED, 700)
	rat2.size = app.SIZE_MD
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"rat2 = page.Cell(2,1).AddRating("rat2", 5)"$)
	c2.AddCode($"rat2.Mask = app.MASK_HEART"$)
	c2.AddCode($"rat2.BGColorIntensity(app.COLOR_RED, 700)"$)
	c2.AddCode($"rat2.size = app.SIZE_MD"$)
	c2.Refresh
	'
	rat3 = page.Cell(3,1).AddRating("rat3", 5)
	'change color of itms
	rat3.ItemBGColorIntensity(1, app.color_red, 700)
	rat3.ItemBGColorIntensity(2, app.color_orange, 700)
	rat3.ItemBGColorIntensity(3, app.color_yellow, 700)
	rat3.ItemBgColorIntensity(4, app.color_lime, 700)
	rat3.ItemBGColorIntensity(5, app.color_green, 700)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"rat3 = page.Cell(3,1).AddRating("rat3", 5)"$)
	c3.AddCode($"'change color of itms"$)
	c3.AddCode($"rat3.ItemBGColorIntensity(1, app.color_red, 700)"$)
	c3.AddCode($"rat3.ItemBGColorIntensity(2, app.color_orange, 700)"$)
	c3.AddCode($"rat3.ItemBGColorIntensity(3, app.color_yellow, 700)"$)
	c3.AddCode($"rat3.ItemBGColorIntensity(4, app.color_lime, 700)"$)
	c3.AddCode($"rat3.ItemBGColorIntensity(5, app.color_green, 700)"$)
	c3.Refresh
	'
	page.Cell(1, 1).AddBR
	Dim btnGet As SDUIButton = page.Cell(1,1).AddButton("btnget", "Get")
	'
	Dim btnSet As SDUIButton = page.Cell(1, 1).AddButton("btnset", "Set")
	'
	Dim rat4 As SDUIRating = page.Cell(4, 1).AddRatingLabel("rat4", "Performance", "Employee Performance", 5)
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim rat4 As SDUIRating = page.Cell(4, 1).AddRatingLabel("rat4", "Performance", "Employee Performance", 5)"$)
	c4.AddCode("'trap change event")
	c4.AddCode($"Private Sub rat4_Change (value As Double)"$)
	c4.AddCode($"page.Cell(5, 1).Caption = value"$)
	c4.AddCode($"End Sub"$)
	c4.Refresh
End Sub

Private Sub rat4_Change (value As Double)
	page.Cell(5, 1).Caption = value
End Sub


Private Sub rat1_Change (value As Double)
	page.Cell(5, 1).Caption = value
End Sub

Private Sub rat2_Change (value As Double)
	page.Cell(5, 1).Caption = value
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	Dim i As Int = rat1.Value
	Dim z As Int = rat2.Value
	'
	page.Cell(5, 1).Caption = i
	page.Cell(6, 1).Caption = z
	
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	'set a random number between 1 and 100
	rat1.value = Rnd(1, 5)
	rat2.value = Rnd(1, 5)
	page.Cell(5, 1).Caption = rat1.value
	page.Cell(6, 1).Caption = rat2.value
End Sub
