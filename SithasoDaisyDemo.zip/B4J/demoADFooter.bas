﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adfooter"
	Public title As String = "AD Footer"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIFooter1 As SDUIFooter
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adfooterlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIFooter.SDUIFooter1", "SDUIFooter1", SDUIFooter1.CustProps)

	'
	Dim c1 As SDUIDiv = SDUIFooter1.AddColumn("c1", "")
	c1.AddFooterTitle("ft1", "Services")
	c1.AddLink("ft1l1", "Branding", "#").Hover
	c1.AddLink("ft1l2", "Design", "#").Hover
	c1.AddLink("ft1l3", "Marketing", "#").Hover
	c1.AddLink("ft1l4", "Advertisement", "#").Hover
	
	'
	Dim c2 As SDUIDiv = SDUIFooter1.AddColumn("c2", "")
	c2.AddFooterTitle("ft2", "Company")
	c2.AddLink("ft2l1", "About Us", "#").Hover
	c2.AddLink("ft2l2", "Contact", "#").Hover
	c2.AddLink("ft2l3", "Jobs", "#").Hover
	c2.AddLink("ft2l4", "Press Kit", "#").Hover
	'
	Dim c3 As SDUIDiv = SDUIFooter1.AddColumn("c3", "")
	c3.AddFooterTitle("ft3", "Legal")
	c3.AddLink("ft3l1", "Terms of Use", "#").Hover
	c3.AddLink("ft3l2", "Privacy Policy", "#").Hover
	c3.AddLink("ft3l3", "Cookie Policy", "#").Hover
	
	BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
