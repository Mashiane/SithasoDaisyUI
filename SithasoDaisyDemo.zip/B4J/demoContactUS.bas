﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "contactus"
	Public title As String = "Contact Us"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns2x6
	page.Root.AddRows5.AddColumns12
	
	'build the grid
	page.Root.BuildGrid
	page.Root.Shrink
	'start adding you components here
	
	Dim lbl As SDUILabel = page.Cell(1, 1).AddH1("git", "Get in Touch")
	lbl.Root.TextSize(app.SIZE_5XL)
	lbl.Root.FontBold
	
	Dim lbl2 As SDUILabel = page.Cell(1, 2).AddParagraph("lbl2", "Fields with * are required.")
	
	Dim lname As SDUITextBox = page.Cell(2, 2).AddTextBoxLabel("lname", "Last Name", "")
	lname.Required = True
	
	Dim fname As SDUITextBox = page.Cell(2, 1).AddTextBoxLabel("fname", "First Name", "")
	fname.required = True
	
	Dim cname As SDUITextBox = page.Cell(3, 1).AddTextBoxLabel("cname", "Company Name", "")
	'
	Dim email As SDUITextBox = page.Cell(4, 1).AddEmail("email", "Email", "")
	email.Required = True
	'
	Dim subject As SDUITextBox = page.Cell(5, 1).AddTextBoxLabel("subject", "Subject", "")
	subject.required = True
	'
	Dim message As SDUITextArea = page.Cell(6, 1).AddTextAreaLabel("message", "Message", "")
	message.Required = True
	message.Rows = 6
	'
	Dim btnSend As SDUIButton = page.Cell(7, 1).AddButtonLabel("btnSend", "Send")
	btnSend.Color = app.COLOR_SUCCESS
End Sub
