﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adswap"
	Public title As String = "AD Swap"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUISwap1 As SDUISwap
	Private SDUISwap2 As SDUISwap
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adswaplayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUISwap.SDUISwap1", "SDUISwap1", SDUISwap1.CustProps)
	pgIndex.AddDesignKV1("SDUISwap.SDUISwap2", "SDUISwap2", SDUISwap2.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUISwap2_On_Click (e As BANanoEvent)
	app.ShowSwal("On")
End Sub

Private Sub SDUISwap2_Off_Click (e As BANanoEvent)
	app.ShowSwal("Off")
End Sub

Private Sub SDUISwap1_On_Click (e As BANanoEvent)
	app.ShowSwal("On")
End Sub

Private Sub SDUISwap1_Off_Click (e As BANanoEvent)
	app.ShowSwal("Off")
End Sub