﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "artboardpage"
	Public title As String = "ArtBoard"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim ab As SDUIArtboard = page.Cell(1, 1).AddArtBoard("ab", 1)
	ab.Root.Shadow("")
	ab.Caption = "320×568"
	ab.Demo
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim ab As SDUIArtboard = page.Cell(1, 1).AddArtBoard("ab", 1)"$)
	c1.AddCode($"ab.Root.Shadow = True"$)
	c1.AddCode($"ab.Caption = "320×568""$)
	c1.AddCode($"ab.Demo"$)
	c1.Refresh

End Sub
