﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "buttongrouppage"
	Public title As String = "Button Group"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Dim btnGroup As SDUIButtonGroup = page.Cell(1, 1).AddButtonGroup("btnGroup", app.SIZE_SM)
	btnGroup.AddItem("grp1", "Button 1")
	btnGroup.AddItem("grp2", "Button 2")
	btnGroup.AddItem("grp3", "Button 3")
	'set the active button
	btnGroup.Active = "grp2"
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim btnGroup As SDUIButtonGroup = page.Cell(1, 1).AddButtonGroup("btnGroup", app.SIZE_SM)"$)
	c1.AddCode($"btnGroup.AddItem("grp1", "Button 1")"$)
	c1.AddCode($"btnGroup.AddItem("grp2", "Button 2")"$)
	c1.AddCode($"btnGroup.AddItem("grp3", "Button 3")"$)
	c1.AddCode($"'set the active button"$)
	c1.AddCode($"btnGroup.Active = "grp2""$)
	'
	c1.AddCode($"'*** click events."$)
	c1.AddCode($"Private Sub btnGroup_Click (item As String)"$)
	c1.AddCode($"page.Cell(4, 1).Caption = item"$)
	c1.AddCode($"End Sub"$)
	
	c1.Refresh
	'
	
	Dim btnGroup1 As SDUIButtonGroup = page.Cell(2, 1).AddButtonGroup("btnGroup1", app.SIZE_MD)
	btnGroup1.Vertical 
	btnGroup1.AddItem("grp1", "Button 1")
	btnGroup1.AddItem("grp2", "Button 2")
	btnGroup1.AddItem("grp3", "Button 3")
	'set the active button
	btnGroup1.Active = "grp3"
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim btnGroup1 As SDUIButtonGroup = page.Cell(2, 1).AddButtonGroup("btnGroup1", app.SIZE_MD)"$)
	c2.AddCode($"btnGroup1.Vertical"$)
	c2.AddCode($"btnGroup1.AddItem("grp1", "Button 1")"$)
	c2.AddCode($"btnGroup1.AddItem("grp2", "Button 2")"$)
	c2.AddCode($"btnGroup1.AddItem("grp3", "Button 3")"$)
	c2.AddCode($"'set the active button"$)
	c2.AddCode($"btnGroup1.Active = "grp3""$)
	c2.Refresh
	
	Dim btnGroup2 As SDUIButtonGroup = page.Cell(3, 1).AddButtonGroup("btnGroup2", app.SIZE_MD)
	btnGroup2.AddRadio("grp1", "1")
	btnGroup2.AddRadio("grp2", "2")
	btnGroup2.AddRadio("grp3", "3")
	btnGroup2.AddRadio("grp4", "4")
	btnGroup2.AddRadio("grp5", "5")
	btnGroup2.AddRadio("grp6", "6")	
	'set the active button
	btnGroup2.Active = "grp6"
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim btnGroup2 As SDUIButtonGroup = page.Cell(3, 1).AddButtonGroup("btnGroup2", app.SIZE_MD)"$)
	c3.AddCode($"btnGroup2.AddRadio("grp1", "1")"$)
	c3.AddCode($"btnGroup2.AddRadio("grp2", "2")"$)
	c3.AddCode($"btnGroup2.AddRadio("grp3", "3")"$)
	c3.AddCode($"btnGroup2.AddRadio("grp4", "4")"$)
	c3.AddCode($"btnGroup2.AddRadio("grp5", "5")"$)
	c3.AddCode($"btnGroup2.AddRadio("grp6", "6")"$)
	c3.AddCode($"'set the active button"$)
	c3.AddCode($"btnGroup2.Active = "grp6""$)
	c3.Refresh
	'
	Dim btnGroupx As SDUIButtonGroup = page.Cell(4, 1).AddButtonGroup("btnGroupx", app.SIZE_SM)
	btnGroupx.AddItem("grp1", "<<")
	btnGroupx.AddItem("grp2", "Page 22")
	btnGroupx.AddItem("grp3", ">>")
	btnGroupx.Active = "grp1"
	'
	Dim c1x As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c1x", "vb")
	c1x.AddCode($"Dim btnGroupx As SDUIButtonGroup = page.Cell(4, 1).AddButtonGroup("btnGroupx", app.SIZE_SM)"$)
	c1x.AddCode($"btnGroupx.AddItem("grp1", "<<")"$)
	c1x.AddCode($"btnGroupx.AddItem("grp2", "Page 22")"$)
	c1x.AddCode($"btnGroupx.AddItem("grp3", ">>")"$)
	c1x.AddCode($"btnGroupx.Active = "grp1""$)
	c1x.AddCode($"'trap click event"$)
	c1x.AddCode($"Private Sub btnGroupx_Click (item As String)"$)
	c1x.AddCode($"page.Cell(1, 2).Caption = item"$)
	c1x.AddCode($"End Sub"$)
	c1x.Refresh
	
	Dim btnGroup1x As SDUIButtonGroup = page.Cell(5, 1).AddButtonGroup("btnGroup1x", app.SIZE_MD)
	btnGroup1x.AddItem("grp1", "1")
	btnGroup1x.AddItem("grp2", "2")
	btnGroup1x.AddItem("grp3", "...")
	btnGroup1x.AddItem("grp4", "4")
	btnGroup1x.Button("grp3").Disable
	'
	Dim c2x As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c2x", "vb")
	c2x.AddCode($"Dim btnGroup1x As SDUIButtonGroup = page.Cell(5, 1).AddButtonGroup("btnGroup1x", app.SIZE_MD)"$)
	c2x.AddCode($"btnGroup1x.AddItem("grp1", "1")"$)
	c2x.AddCode($"btnGroup1x.AddItem("grp2", "2")"$)
	c2x.AddCode($"btnGroup1x.AddItem("grp3", "...")"$)
	c2x.AddCode($"btnGroup1x.AddItem("grp4", "4")"$)
	c2x.AddCode($"btnGroup1x.Button("grp3").Disable"$)
	c2x.Refresh
	
	Dim btnGroup2x As SDUIButtonGroup = page.Cell(6, 1).AddButtonGroup("btnGroup2x", app.SIZE_XS)
	btnGroup2x.Root.Grid
	btnGroup2x.Root.GridCols(2)
	btnGroup2x.AddItem("grp1", "Previous")
	btnGroup2x.AddItem("grp2", "Next")
	btnGroup2x.Button("grp1").Outline
	btnGroup2x.Button("grp2").Outline
	'
	Dim c3x As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c3x", "vb")
	c3x.AddCode($"Dim btnGroup2 As SDUIButtonGroup = page.Cell(6, 1).AddButtonGroup("btnGroup2x", app.SIZE_XS)"$)
	c3x.AddCode($"btnGroup2.Root.Grid"$)
	c3x.AddCode($"btnGroup2.Root.GridCols = 2"$)
	c3x.AddCode($"btnGroup2.AddItem("grp1", "Previous")"$)
	c3x.AddCode($"btnGroup2.AddItem("grp2", "Next")"$)
	c3x.AddCode($"btnGroup2.Button("grp1").Outline"$)
	c3x.AddCode($"btnGroup2.Button("grp2").Outline"$)
	c3x.Refresh
End Sub

'*** click events finalize the setting.

Private Sub btnGroup_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub


Private Sub btnGroup1_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub


Private Sub btnGroup2_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub


Private Sub btnGroupx_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub


Private Sub btnGroup1x_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub


Private Sub btnGroup2x_Click (item As String)
	page.Cell(7, 1).Caption = item
End Sub