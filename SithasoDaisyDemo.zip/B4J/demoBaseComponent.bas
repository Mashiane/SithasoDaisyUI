﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "page2"
	Public title As String = "Base Component"
	Public icon As String = "fa-solid fa-pager"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private chitchatouter As SDUIDiv
	Private imgOuter As SDUIDiv
	Private enrin1 As SDUIDiv
	Private SDUIDiv1 As SDUIDiv
	Private SDUILabel1 As SDUILabel
	Private SDUIImage1 As SDUIImage
	Private woman As SDUIDiv
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'load the page layout to the pageviewer
	banano.LoadLayout(app.PageViewer, "page2layout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container To be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	banano.LoadLayout(page.Cell(1,1).Here, "chitchat")
	banano.LoadLayout(page.Cell(1,2).Here, "enrinlayout")
	banano.LoadLayout(page.Cell(2, 1).Here, "womanlayout")
End Sub
