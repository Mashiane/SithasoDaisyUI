﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "collapse"
	Public title As String = "Collapse"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private expnl As SDUICollapsePanels
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim panels1 As List = Array("SithasoDaisy", "TailWindCSS", "DaisyUI", "B4x", "BANano")
	Dim expnl1 As SDUICollapsePanels = page.Cell(1, 1).AddCollapsePanels("expnl1", True, panels1)
	expnl1.Panel(1).AddH1("p1h", "Coming soon...")
	expnl1.Panel(2).AddH1("p2h", "Coming soon...")
	expnl1.Panel(3).AddH1("p3h","Coming soon...")
	expnl1.Panel(4).AddH1("p4h", "Coming soon...")
	expnl1.Panel(5).AddH1("p5h", "Coming soon...")
	'
	Dim c3 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim panels1 As List = Array("SithasoDaisy", "TailWindCSS", "DaisyUI", "B4x", "BANano")"$)
	c3.AddCode($"Dim expnl1 As SDUICollapsePanels = page.Cell(1, 1).AddCollapsePanels("expnl1", True, panels1)"$)
	c3.AddCode($"expnl1.Panel(1).AddH1("p1h", "Coming soon...")"$)
	c3.AddCode($"expnl1.Panel(2).AddH1("p2h", "Coming soon...")"$)
	c3.AddCode($"expnl1.Panel(3).AddH1("p3h","Coming soon...")"$)
	c3.AddCode($"expnl1.Panel(4).AddH1("p4h", "Coming soon...")"$)
	c3.AddCode($"expnl1.Panel(5).AddH1("p5h", "Coming soon...")"$)
	c3.Refresh
	
	
	Dim panels As List = Array("Focus to see content", "I have a class", "Noted here")
	expnl = page.Cell(3, 1).AddCollapsePanels("expnl", False, panels)
	'expnl.Active = 3
	'
	BuildPanel1
	BuildPanel2
	BuildPanel3
	'
	Dim c1 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim panels As List = Array("Focus to see content", "I have a class", "Noted here")"$)
	c1.AddCode($"expnl = page.Cell(1, 1).AddCollapsePanels("expnl", False, panels)"$)
	c1.AddCode($"BuildPanel1"$)
	c1.AddCode($"BuildPanel2"$)
	c1.AddCode($"BuildPanel3"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(5, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Sub BuildPanel1"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = expnl.Panel(1)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns12"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddTextBoxLabel("lastname", "Last Name", "")"$)
	c2.AddCode($"cont.Cell(3, 1).AddButtonLabel("next1", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Sub BuildPanel2"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = expnl.Panel(2)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns12"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddTextBoxLabel("street2", "Street Address 2", "")"$)
	c2.AddCode($"cont.Cell(3, 1).AddTextBoxLabel("street3", "Street Address 3", "")"$)
	c2.AddCode($"cont.Cell(4, 1).AddButtonLabel("next2", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Sub BuildPanel3"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = expnl.Panel(3)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns12"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddTextBoxLabel("qualification", "University Qualification", "")"$)
	c2.AddCode($"cont.Cell(3, 1).AddButtonLabel("next3", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
	'expnl.Active = 3
End Sub

Sub BuildPanel1
	'get container at position
	Dim cont As SDUIDiv = expnl.Panel(1)
	cont.DesignMode(False)
	cont.AddRows5.AddColumns12
	cont.BuildGrid
	'
	cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")
	cont.Cell(2, 1).AddTextBoxLabel("lastname", "Last Name", "")
	cont.Cell(3, 1).AddButtonLabel("next1", "Next")
End Sub

Sub BuildPanel2
	'get container at position
	Dim cont As SDUIDiv = expnl.Panel(2)
	cont.DesignMode(False)
	cont.AddRows5.AddColumns12
	cont.BuildGrid
	'
	cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")
	cont.Cell(2, 1).AddTextBoxLabel("street2", "Street Address 2", "")
	cont.Cell(3, 1).AddTextBoxLabel("street3", "Street Address 3", "")
	cont.Cell(4, 1).AddButtonLabel("next2", "Next")
End Sub

Sub BuildPanel3
	'get container at position
	Dim cont As SDUIDiv = expnl.Panel(3)
	cont.DesignMode(False)
	cont.AddRows5.AddColumns12
	cont.BuildGrid
	'
	cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")
	cont.Cell(2, 1).AddTextBoxLabel("qualification", "University Qualification", "")
	cont.Cell(3, 1).AddButtonLabel("next3", "Next")
End Sub
'
Private Sub expnl_Change (pos As Int)
	page.Cell(1, 2).Caption = pos
End Sub