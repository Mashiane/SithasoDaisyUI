﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adtreeview"
	Public title As String = "AD Tree View"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUICol1 As SDUICol
	Private SDUICol2 As SDUICol
	Private SDUIRow1 As SDUIRow
	Private SDUITreeView1 As SDUITreeView
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesGijgo)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adtreeviewlayout")
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub

Private Sub SDUITreeView1_SelectNode (id As String)
	app.ShowSwalInfo(id)
End Sub

Private Sub SDUITreeView1_UnSelectNode (id As String)
	app.ShowSwalInfo(id)
End Sub

Private Sub SDUITreeView1_NodeDrop (id As String, parentID As String, orderNumber As String)
	app.ShowSwalInfo($"${id}, ${parentID}, ${orderNumber}"$)
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	SDUITreeView1.Clear
	SDUITreeView1.AddItem("", "page", "Page", "", "fa-solid fa-folder", False)
	SDUITreeView1.AddItem("page", "page1", "Page 1", "", "fa-regular fa-file", False)
	SDUITreeView1.AddItem("page", "page2", "Page 2", "", "fa-regular fa-file", False)
	SDUITreeView1.AddItem("page", "page3", "Page 3", "", "fa-regular fa-file", False)
	SDUITreeView1.refresh
End Sub
