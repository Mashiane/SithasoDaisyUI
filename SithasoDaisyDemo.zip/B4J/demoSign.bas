﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "demosign"
	Public title As String = "Signature Pad - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private signp As SDUISignaturePad
	Private btnClear As SDUIButton
	Private btnDownload As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesSignaturePad)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	signp.Initialize(Me, "signp","signp")
	signp.AddToParent(page.Cell(1, 1).Name, CreateMap())
	'
	btnClear = page.Cell(2, 1).AddButton("btnClear", "Clear")
	btnDownload = page.Cell(2, 1).AddButton("btnDownload", "Download")
	btnDownload.Root.mx(2)
	'
	Dim c2 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"signp = page.Cell(1, 1).AddSignaturePad("signp")"$)
	c2.AddCode($"btnClear = page.Cell(2, 1).AddButton("btnClear", "Clear")"$)
	c2.AddCode($"btnDownload = page.Cell(2, 1).AddButton("btnDownload", "Download")"$)
	c2.AddCode($"btnDownload.Root.mx(2)"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Private Sub btnClear_Click (e As BANanoEvent)"$)
	c2.AddCode($"signp.clear"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"Private Sub btnDownload_Click (e As BANanoEvent)"$)
	c2.AddCode($"signp.download"$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
End Sub

Private Sub btnClear_Click (e As BANanoEvent)
	signp.clear
End Sub

Private Sub btnDownload_Click (e As BANanoEvent)
	signp.download
End Sub