﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "textcontrol"
	Public title As String = "Line Through"
	Public icon As String = "fa-solid fa-text-slash"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim p1 As SDUILabel = page.Cell(1, 1).AddParagraph("p1", "strike tag (cut text)")
	p1.Root.linethrough(True)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim p1 As SDUILabel = page.Cell(1, 1).AddParagraph("p1", "strike tag (cut text)")"$)
	c1.AddCode($"p1.Root.linethrough(True)"$)
	c1.Refresh
	'
	Dim p2 As SDUILabel = page.Cell(2, 1).AddParagraph("p2", "strike tag (cut text) red color")
	p2.Root.linethrough(True).textsize("xl").textColorIntensity("red", 600)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim p2 As SDUILabel = page.Cell(2, 1).AddParagraph("p2", "strike tag (cut text) red color")"$)
	c2.AddCode($"p2.Root.linethrough(True).textsize("xl").textColorIntensity("red", 600)"$)
	c2.Refresh
	'
	Dim p3 As SDUILabel = page.Cell(3, 1).AddParagraph("p3", "strike tag (cut text) green color")
	p3.Root.linethrough(True).textsize("xl").textColorIntensity("green", 600)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim p3 As SDUILabel = page.Cell(3, 1).AddParagraph("p3", "strike tag (cut text) green color")"$)
	c3.AddCode($"p3.Root.linethrough(True).textsize("xl").textColorIntensity("green", 600)"$)
	c3.Refresh
	'
	Dim p4 As SDUILabel = page.Cell(4, 1).AddParagraph("p4", "strike tag (cut text) blue color")
	p4.Root.linethrough(True).textsize("xl").textColorIntensity("blue", 600)
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim p4 As SDUILabel = page.Cell(4, 1).AddParagraph("p4", "strike tag (cut text) blue color")"$)
	c4.AddCode($"p4.Root.linethrough(True).textsize("xl").textColorIntensity("blue", 600)"$)
	c4.Refresh
	'
	Dim p5 As SDUILabel = page.Cell(5, 1).AddParagraph("p5", "hover strike tag (cut text)")
	p5.Root.hover("line-through").textsize("xl")
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim p5 As SDUILabel = page.Cell(5, 1).AddParagraph("p5", "hover strike tag (cut text)")"$)
	c5.AddCode($"p5.Root.hover("line-through").textsize("xl")"$)
	c5.Refresh
End Sub
