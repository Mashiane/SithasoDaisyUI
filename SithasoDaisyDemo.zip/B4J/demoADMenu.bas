﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "admenu"
	Public title As String = "AD Menu"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIMenu1 As SDUIMenu
	Private SDUIMenu2 As SDUIMenu
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "admenulayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIMenu.SDUIMenu1", "SDUIMenu1", SDUIMenu1.CustProps)

	SDUIMenu1.AddItem("item1", "Item 1")
	SDUIMenu1.AddItem("item2", "Item 2")
	SDUIMenu1.AddItem("item3", "Item 3")
	SDUIMenu1.AddItem("item4", "Item 4")
	SDUIMenu1.SetItemBadgeValue("item2", 5)
	SDUIMenu1.AddTitle("cat2", "Category 2")
	SDUIMenu1.AddItem("item5", "Item 5")
	SDUIMenu1.AddItem("item6", "Item 6")
	SDUIMenu1.AddItem("item7", "Item 7")
	SDUIMenu1.AddItem("item8", "Item 8")
	SDUIMenu1.DisableItem("item6")
	SDUIMenu1.AddItemParent("item9", "Child Menu")
	SDUIMenu1.AddItemChild("item9", "item4", "Child 1")
	SDUIMenu1.AddItemChild("item9", "item5", "Child 2")
	SDUIMenu1.AddItemChild("item9", "item6", "Child 3")
	SDUIMenu1.AddItemIcon("item10", "fa-solid fa-wifi",  "Item 3")
	SDUIMenu1.AddItemIconOnly("item11", "fa-solid fa-circle-info")
	SDUIMenu1.AddItemIconOnly("item12", "fa-solid fa-wifi")
	'
	SDUIMenu2.AddItem("item1", "Item 1")
	SDUIMenu2.AddItem("item2", "Item 2")
	SDUIMenu2.AddItem("item3", "Item 3")
	SDUIMenu2.SetItemBadgeValue("item2", 5)
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIMenu1_Click (item As String)
	app.ShowSwal(item)
End Sub


Private Sub SDUIMenu2_Click (item As String)
	app.ShowSwal(item)
End Sub