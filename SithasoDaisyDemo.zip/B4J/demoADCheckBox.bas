﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcheckbox"
	Public title As String = "AD CheckBox"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUICheckbox1 As SDUICheckbox
	Private SDUICheckbox2 As SDUICheckbox
	Private SDUICheckbox3 As SDUICheckbox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adcheckboxlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUICheckbox.SDUICheckbox1", "SDUICheckbox1", SDUICheckbox1.CustProps)
	pgIndex.AddDesignKV1("SDUICheckbox.SDUICheckbox2", "SDUICheckbox2", SDUICheckbox2.CustProps)
	pgIndex.AddDesignKV1("SDUICheckbox.SDUICheckbox3", "SDUICheckbox3", SDUICheckbox3.CustProps)

	
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub



Private Sub SDUICheckbox3_Change (Checked As Boolean)
	app.ShowSwal(Checked)
End Sub

Private Sub SDUICheckbox2_Change (Checked As Boolean)
	app.ShowSwal(Checked)
End Sub

Private Sub SDUICheckbox1_Change (Checked As Boolean)
	app.ShowSwal(Checked)
End Sub