﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables6"
	Public title As String = "Table 6"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
	Private tb4 As SDUITable
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"", "tob":""))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"","tob":""))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"","tob":""))
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table5
	Table5Code
End Sub

Sub Table5Code
	Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
	c5.AddCode($"Sub Build_Table5"$)
	c5.AddCode($"tb4 = page.Cell(1, 1).AddTable("tb4")"$)
	c5.AddCode($"tb4.Hover = True"$)
	c5.AddCode($"tb4.Zebra"$)
	c5.AddCode($"'"$)
	c5.AddCode($"tb4.AddColumnColor("color", "Category", "name")"$)
	c5.AddCode($"tb4.AddColumnNumber("rate", "Rate", False)"$)
	c5.AddCode($"tb4.AddColumnFileInput("product", "Choose Product")"$)
	c5.AddCode($"tb4.AddColumnTextBoxGroup("email", "Email", False, "", "fa-regular fa-envelope", "", "fa-solid fa-share")"$)
	
	c5.AddCode($"'ad as last columns"$)
	c5.AddCode($"tb4.AddColumnEdit(app.COLOR_PRIMARY)"$)
	c5.AddCode($"tb4.AddColumnDelete(app.COLOR_SECONDARY)"$)
	c5.AddCode($"banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"''"$)
	c5.AddCode($"Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_ChangeRow...")"$)
	c5.AddCode($"Select Case Column"$)
	c5.AddCode($"Case "product""$)
	c5.AddCode($"'value is the file object"$)
	c5.AddCode($"Dim fd As FileObject = SDUIShared.UploadFileWait(Value)"$)
	c5.AddCode($"Log(fd)"$)
	c5.AddCode($"'get the file name"$)
	c5.AddCode($"Dim fn As String = fd.FileName"$)
	c5.AddCode($"'get the status of the upload"$)
	c5.AddCode($"Dim sstatus As String = fd.Status"$)
	c5.AddCode($"Select Case sstatus"$)
	c5.AddCode($"Case "error""$)
	c5.AddCode($"Return"$)
	c5.AddCode($"Case "success""$)
	c5.AddCode($"End Select"$)
	c5.AddCode($"'get the upload full path"$)
	c5.AddCode($"Dim fp As String = fd.FullPath"$)
	c5.AddCode($"tb4.SetRowColumn("avatar", Row, fp)"$)
	c5.AddCode($"End Select"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Value)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Edit (item As Map)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Delete (item As Map)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	'
	c5.AddCode($"Private Sub tb4_PrependClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"app.ShowSwal(~"tb4_PrependClick: ~{Column}"~)"$)
	c5.AddCode($"Log("tb4_PrependClick....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_AppendClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"app.ShowSwal(~"tb4_AppendClick: ~{Column}"~)"$)
	c5.AddCode($"Log("tb4_AppendClick....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	
	c5.Refresh
End Sub

Sub Build_Table5
	tb4 = page.Cell(1, 1).AddTable("tb4")
	tb4.Hover = True
	tb4.Zebra
	'
	tb4.AddColumnColor("color", "Category", "name")
	tb4.AddColumnNumber("rate", "Rate", False)
	tb4.AddColumnFileInput("product", "Choose Product")
	tb4.AddColumnTextBoxGroup("email", "Email", False, "", "fa-regular fa-envelope", "", "fa-solid fa-share")
	
	'ad as last columns
	tb4.AddColumnEdit(app.COLOR_PRIMARY)
	tb4.AddColumnDelete(app.COLOR_SECONDARY)
	
	banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate
End Sub


Private Sub tb4_PrependClick (Row As Int, Column As String, item As Map)
	app.ShowSwal($"tb4_PrependClick: ${Column}"$)
	Log("tb4_PrependClick....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_AppendClick (Row As Int, Column As String, item As Map)
	app.ShowSwal($"tb4_AppendClick: ${Column}"$)
	Log("tb4_AppendClick....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	Log("tb4_ChangeRow...")
	Select Case Column
	Case "product"
		'value is the file object
		Dim fd As FileObject = SDUIShared.UploadFileWait(Value)
		Log(fd)
		'get the file name
		Dim fn As String = fd.FileName
		'get the status of the upload
		Dim sstatus As String = fd.Status
		Select Case sstatus
		Case "error"
			Return
		Case "success"
		End Select
		'get the upload full path
		Dim fp As String = fd.FullPath
		tb4.SetRowColumn("avatar", Row, fp)
	End Select
	Log(Row)
	Log(Value)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_Edit (item As Map)
	Log(item)
End Sub

Private Sub tb4_Delete (item As Map)
	Log(item)
End Sub