﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adstat"
	Public title As String = "AD Stats"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIStats1 As SDUIStats
	Private SDUIStats2 As SDUIStats
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adstatlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIStats.SDUIStats1", "SDUIStats1", SDUIStats1.CustProps)
	pgIndex.AddDesignKV1("SDUIStats.SDUIStats2", "SDUIStats2", SDUIStats2.CustProps)

	'
	SDUIStats1.AddItem("likes", "Total Likes", "25.6K", "21% more than last month")
	SDUIStats1.GetItemFigure("likes").TextColor(app.color_Primary)
	SDUIStats1.GetItemValue("likes").TextColor(app.color_Primary)
	SDUIStats1.GetItemIcon("likes").IconName = "fa-solid fa-circle-info"
	SDUIStats1.GetItemIcon("likes").SizeOwn = 2
	'
	SDUIStats1.AddItem("views", "Page Views", "2.6M", "21% more than last month")
	SDUIStats1.GetItemFigure("views").TextColor(app.Color_Secondary)
	SDUIStats1.GetItemValue("views").TextColor(app.COlor_Secondary)
	'
	SDUIStats1.AddItem1("tasks", "Tasks Done", "80%", "31 tasks remaining")
	SDUIStats1.GetItemFigure("tasks").TextColor(app.color_Secondary)
	SDUIStats1.GetItemDesc("tasks").TextColor(app.color_Secondary)
	SDUIStats1.GetItemAvatar("tasks").Src = "./assets/face5.jpg"
	SDUIStats1.GetItemAvatar("tasks").Online = True
	
	'
	SDUIStats2.AddItem("downs2", "Account Balance", "$89,400", "")
	SDUIStats2.AddItemActionButton("downs2", "addfunds", "Add Funds")
	SDUIStats2.GetItemAction("downs2", "addfunds").Size = app.SIZE_SM
	SDUIStats2.GetItemAction("downs2", "addfunds").Color = app.COLOR_SUCCESS
	'
	SDUIStats2.AddItem("users2", "Current Balance", "$89,400", "")
	SDUIStats2.AddItemActionButton("users2", "withdrawal", "Withdrawal")
	SDUIStats2.GetItemAction("users2", "withdrawal").Size = app.SIZE_SM
	'
	SDUIStats2.AddItemActionButton("users2", "deposit", "Deposit")
	SDUIStats2.GetItemAction("users2", "deposit").Size = app.SIZE_SM
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
