﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "tabspage"
	Public title As String = "Tabs"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private tabs4 As SDUITabs
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns12
	page.Root.BuildGrid
	'
'	Dim tabs1 As SDUITabs
'	tabs1.AddTabs(Me, page.CellID(1, 1), "tabs1", app.SIZE_DEFAULT, app.TAB_DEFAULT)
'	tabs1.AddItems(Array("Tab 1", "Tab 2", "Tab 3"))
'	tabs1.Active = 2
'	tabs1.Panel(1).AddH1("t1p1", "Coming Soon...")
'	tabs1.Panel(2).AddH1("t1p2", "Coming Soon...")
'	tabs1.Panel(3).AddH1("t1p3", "Coming Soon...")
'	'
'	Dim tabs2 As SDUITabs
'	tabs2.AddTabs(Me, page.CellID(3, 1), "tabs2", app.SIZE_SM, app.TAB_BORDERED)
'	tabs2.AddItems(Array("Tab 1", "Tab 2", "Tab 3"))
'	tabs2.Active = 2
'	tabs2.Panel(1).AddH1("t2p1", "Coming Soon...")
'	tabs2.Panel(2).AddH1("t2p2", "Coming Soon...")
'	tabs2.Panel(3).AddH1("t2p3", "Coming Soon...")
'	'
'	Dim tabs3 As SDUITabs
'	tabs3.AddTabs(Me, page.CellID(5, 1), "tabs3", app.SIZE_DEFAULT, app.TAB_BOXED)
'	tabs3.AddItems(Array("Tab 1", "Tab 2", "Tab 3"))
'	tabs3.Active = 2
'	tabs3.Panel(1).AddH1("t3p1", "Coming Soon...")
'	tabs3.Panel(2).AddH1("t3p2", "Coming Soon...")
'	tabs3.Panel(3).AddH1("t3p3", "Coming Soon...")
	'
	
	tabs4.AddTabs(Me, page.CellID(1, 1), "tabs4", app.SIZE_LG, app.TAB_LIFTED)
	tabs4.Grow = True
	tabs4.AddItems(Array("Messages", "Notifications", "Requests"))
	tabs4.Active = 1
	tabs4.SetItemBadgeValue(2, 8)
	tabs4.SetItemBadgeColor(2, app.COLOR_PRIMARY)
	'
	BuildTab1
	BuildTab2
	BuildTab3
	Tabs4Code
End Sub

Sub Tabs4Code
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"tabs4.AddTabs(Me, page.CellID(1, 1), "tabs4", app.SIZE_LG, app.TAB_LIFTED)"$)
	c1.AddCode($"tabs4.AddItems(Array("Messages", "Notifications", "Requests"))"$)
	c1.AddCode($"tabs4.Active = 1"$)
	c1.AddCode($"tabs4.SetItemBadgeValue(2, 8)"$)
	c1.AddCode($"tabs4.SetItemBadgeColor(2, app.COLOR_PRIMARY)"$)
	c1.AddCode($"'"$)
	c1.AddCode($"BuildTab1"$)
	c1.AddCode($"BuildTab2"$)
	c1.AddCode($"BuildTab3"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Sub BuildTab1"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = tabs4.Panel(1)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("lastname", "Last Name", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddButtonLabel("next1", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"Sub BuildTab2"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = tabs4.Panel(2)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("street2", "Street Address 2", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddTextBoxLabel("street3", "Street Address 3", "")"$)
	c2.AddCode($"cont.Cell(2, 2).AddButtonLabel("next2", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"Sub BuildTab3"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = tabs4.Panel(3)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows5.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("qualification", "University Qualification", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddButtonLabel("next3", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
End Sub

Sub BuildTab1
	'get container at position
	Dim cont As SDUIDiv = tabs4.Panel(1)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")
	cont.Cell(1, 2).AddTextBoxLabel("lastname", "Last Name", "")
	cont.Cell(2, 1).AddButtonLabel("next1", "Next")
End Sub


Sub BuildTab2
	'get container at position
	Dim cont As SDUIDiv = tabs4.Panel(2)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.Shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")
	cont.Cell(1, 2).AddTextBoxLabel("street2", "Street Address 2", "")
	cont.Cell(2, 1).AddTextBoxLabel("street3", "Street Address 3", "")
	cont.Cell(2, 2).AddButtonLabel("next2", "Next")
End Sub

Sub BuildTab3
	'get container at position
	Dim cont As SDUIDiv = tabs4.Panel(3)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")
	cont.Cell(1, 2).AddTextBoxLabel("qualification", "University Qualification", "")
	cont.Cell(2, 1).AddButtonLabel("next3", "Next")
End Sub

Private Sub tabs1_Change (pos As Int)
	'Log(pos)
End Sub


Private Sub tabs2_Change (pos As Int)
	'Log(pos)
End Sub


Private Sub tabs3_Change (pos As Int)
	'Log(pos)
End Sub


Private Sub tabs4_Change (pos As Int)
	If pos <> 1 Then	
		'Log(page.Cell(1, 1).HTML)
	End If	
End Sub

