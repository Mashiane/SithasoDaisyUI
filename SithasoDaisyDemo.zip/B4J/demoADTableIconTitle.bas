﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adtableicontitle"
	Public title As String = "AD Table Icon Title"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUITable1 As SDUITable
	Private Items As List
	Private srowcount As String
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	banano.Await(app.UsesEnjoyHint)
	''banano.Await(app.UsesTable)
	banano.Await(app.UsesCSV)
	banano.await(app.UsesExcel)
	banano.Await(app.UsesPDF)
	banano.LoadLayout(app.PageViewer, "adtablelayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUITable.SDUITable1", "SDUITable1", SDUITable1.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
	
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'trap the menu actions
Private Sub SDUITable1_ddown_Click (item As String)
	Select Case item
		Case "export2pdf"
			Dim pdf As SDUIJSPDF
			pdf.Initialize(Me, "SDUITable1", SDUIShared.DateTimeNowBackUp & " " & SDUITable1.ExcelTitle & ".pdf")
			pdf.ExportTable(SDUITable1.ExcelTitle, SDUITable1.Orientation, SDUITable1.PageSize, _
		SDUITable1.Unit, SDUITable1.FontSize, SDUITable1.PdfTheme, SDUITable1.PageBreakRepeat, _
		SDUITable1.GetFieldNames, SDUITable1.GetTitleNames, SDUITable1.Originals)
		Case "export2csv"
			Dim content As String = banano.Await(SDUITable1.ExportToCSV(True, ",", True))
			app.Download(content, "table2csv.csv")
		Case "export2xls"
			Dim excel As SDUIExcel
			excel.Initialize(Me, "SDUITable1", SDUIShared.DateTimeNowBackUp & " " & SDUITable1.ExcelTitle & ".xlsx")
			excel.ExportTable(SDUITable1.ExcelTitle, True, SDUITable1.GetFieldNames, SDUITable1.GetTitleNames, SDUITable1.Originals)
	End Select
End Sub

Private Sub SDUITable1_ExcelDownload
	app.ShowSwalSuccess("Excel Report downloaded!")
End Sub

Private Sub SDUITable1_PDFDownload (e As BANanoEvent)
	app.ShowSwalSuccess("PDF Report downloaded!")
End Sub

'start building the page
private Sub BuildPage
	'add a drop down menu to the toolbar item
	Dim ddown As SDUIDropDown = SDUITable1.AddToolbarDropDownIcon("ddown", "fa-solid fa-bars", app.COLOR_ORANGE)
	ddown.AtEnd
	ddown.RoundedBox
	ddown.shadow("")
	'set the colors of the menu
	ddown.ItemHoverColorIntensity("blue", "100")
	ddown.ItemFocusColorIntensity("blue", "100")
	ddown.ItemActiveColorIntensity("blue", "100")
	'add the menu items
	ddown.AddItemIcon("export2pdf", "fa-regular fa-file-pdf", "Export to PDF")
	ddown.AddItemIcon("export2xls", "fa-regular fa-file-excel", "Export to XLS")
	ddown.AddItemIcon("export2csv", "fa-solid fa-file-csv", "Export to CSV")
	'
	SDUITable1.SetAddNewTooltip("Add a new Customer", app.COLOR_PRIMARY, "left", True)
	SDUITable1.SetRefreshTooltip("Refresh list of Customers", app.COLOR_PRIMARY, "left", True)
	SDUITable1.SetBackTooltip("Close this page", app.COLOR_PRIMARY, "left", True)
	'
	SDUITable1.SetToolbarButtonBadgeColor("deleteall", app.COLOR_PRIMARY)
	SDUITable1.SetToolbarButtonBadgeRound("deleteall")
	SDUITable1.SetToolbarButtonBadge("deleteall", 10)
	SDUITable1.AddToolbarButtonIcon("help", "fa-solid fa-question", app.COLOR_INFO)
	
	SDUITable1.AddColumn("id", "#")
	SDUITable1.AddColumnIconTitle("sm", "Social Media", app.SIZE_LG, "name", "item.color")
	SDUITable1.AddColumnTitleSubTitle("job", "Job", "country")
	SDUITable1.AddDesignerColums
	SDUITable1.SetColumnChooser(True, "8", app.COLOR_PRIMARY)
		
	Items.Initialize
	Items.Add(CreateMap("hours":4, "status":"online", "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "status":"offline", "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "status":"offline", "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	Items.Add(CreateMap("hours":4, "status":"online", "on":True, "id":4, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "status":"offline", "on":False, "id":5, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "status":"online", "on":True, "id":6, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	Items.Add(CreateMap("hours":4, "status":"online", "on":True, "id":7, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "status":"offline", "on":False, "id":8, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "status":"online", "on":True, "id":9, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	
	banano.Await(SDUITable1.SetItemsPaginate(Items))
	banano.Await(Mounted)
End Sub

Sub Mounted
	'
	SDUITable1.SetToolbarSelectAllChecked(False)
	SDUITable1.SetToolbarButtonEnable("deleteall", False)
	
'	Dim summary As Map = SDUITable1.SetFooterTotalSumCountColumns(Array("progress"))
'	srowcount = summary.Get("rowcount")
'	srowcount = SDUIShared.Thousands(srowcount)
'	SDUITable1.SetFooterColumn("avatar", $"Total (${srowcount})"$)
	app.PageResume
End Sub

Sub SDUITable1_help (e As BANanoEvent)
	e.PreventDefault
	Dim help As SDUIEnjoyHint
	help.Initialize(Me, "demohelp")
	help.AddStep(SDUITable1.getTitleID, "This is the title of this table.")
	help.AddStep(SDUITable1.getSearchID, "You can search for a customer by typing your criteria here.</br>Search is performed after 3 letters are entered at each key-press.")
	help.AddStep(SDUITable1.getToolBarPrevPageID, "To view the previous page, click here.")
	help.AddStep(SDUITable1.getToolBarNextPageID, "To view the next page, click here.")
	help.AddStep(SDUITable1.getToolBarButtonID("add"), "To add a new customer, click this button.")
	help.AddStep(SDUITable1.getToolBarButtonID("refresh"), "This option will refresh the customer listing with all customers in the database.")
	help.AddStep(SDUITable1.getToolBarButtonID("back"), "To go to the dashboard, select this option.")
	help.AddStep(SDUITable1.getToolBarButtonID("deletell"), "When selected, this will activate the delete all records process.")
	help.AddStep(SDUITable1.getColumnChooserID, "This section enables one to toggle the visibility of the columns in the table.")
	'
	help.AddStep(SDUITable1.getHeadingID , "One is also able to click a column header to sort the columns in ascending or descending order.")
	help.AddStep(SDUITable1.getSelectAllID, "One is able to select / unselect all customers here.</br>This can be done to send an email to selected customers.")
	help.AddStep(SDUITable1.getColumnID("active") , "On this column, you can toggle the customer to make them active.")
	help.AddStep(SDUITable1.getColumnID("verified") , "On this column, you can toggle the customer to make them verified.")
	help.AddStep(SDUITable1.getColumnID("tools") , "The tools menu provides links to Send Email,</br>Add Reminder,</br>Add Communication,</br>Add Appointment</br>and Add Task for the selected customer.")
	help.AddStep(SDUITable1.getColumnID("edit") , "To make changes to a customer, click the 'Edit' column that corresponds to it.")
	help.AddStep(SDUITable1.getColumnID("delete") , "To delete a customer, click the 'Delete' column that corresponds to it.")
	help.AddStep(SDUITable1.getColumnID("clone") , "To clone / copy a customer, click the 'Clone' column that corresponds to it.")
	help.AddStep(SDUITable1.getFooterID , "On the footer, one is able to see the total number of customers.")
	help.EndsOn(SDUITable1.getFooterID, "Got it")
	help.Run(Me)
End Sub

Private Sub SDUITable1_SelectRow (Status As Boolean, Row As Int, item As Map)
	Dim selected As List = SDUITable1.GetAllChecked(True)
	If selected.Size = 0 Then
		SDUITable1.SetToolbarButtonEnable(SDUITable1.BUTTON_DELETEALL, False)
		SDUITable1.SetToolbarButtonBadge(SDUITable1.BUTTON_DELETEALL, "0")
	Else
		SDUITable1.SetToolbarButtonEnable(SDUITable1.BUTTON_DELETEALL, True)
		SDUITable1.SetToolbarButtonBadge(SDUITable1.BUTTON_DELETEALL, selected.size)
	End If
End Sub

Private Sub SDUITable1_SelectAll (Checked As Boolean)
	Dim selected As List = SDUITable1.GetAllChecked(True)
	If selected.Size = 0 Then
		SDUITable1.SetToolbarButtonEnable(SDUITable1.BUTTON_DELETEALL, False)
		SDUITable1.SetToolbarButtonBadge(SDUITable1.BUTTON_DELETEALL, "0")
	Else
		SDUITable1.SetToolbarButtonEnable(SDUITable1.BUTTON_DELETEALL, True)
		SDUITable1.SetToolbarButtonBadge(SDUITable1.BUTTON_DELETEALL, selected.size)
	End If
End Sub

Private Sub SDUITable1_Edit (item As Map)
	app.ShowSwal("Edit")
End Sub

Private Sub SDUITable1_Clone (item As Map)
	app.ShowSwal("Clone")
End Sub

Private Sub SDUITable1_Menu (item As Map)
	app.ShowSwal("Menu")
End Sub

Private Sub SDUITable1_Download (item As Map)
	app.ShowSwal("Download")
End Sub

Private Sub SDUITable1_Upload (item As Map)
	app.ShowSwal("Upload")
End Sub

Private Sub SDUITable1_Delete (item As Map)
	app.ShowSwal("Delete")
End Sub

Private Sub SDUITable1_Add (e As BANanoEvent)
	app.ShowSwal("Add")
End Sub

Private Sub SDUITable1_Refresh (e As BANanoEvent)
	app.ShowSwal("Refresh")
End Sub

Private Sub SDUITable1_Back (e As BANanoEvent)
	app.ShowSwal("Back")
End Sub

Private Sub SDUITable1_DeleteAll (e As BANanoEvent)
	app.ShowSwal("Delete All")
End Sub