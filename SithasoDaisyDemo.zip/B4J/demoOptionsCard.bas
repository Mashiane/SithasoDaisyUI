﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "optioncards"
	Public title As String = "Options Card"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim oc As SDUIOptionsCard
	oc.AddOptionsCard(Me, page.CellID(1, 1), "oc1")
	oc.AddItem("b4a", "b4a", "Create Android Apps", "./assets/8.jpg")
	oc.AddItem("b4j", "b4j", "Create Desktop Apps", "./assets/9.jpg")
	oc.AddItem("b4r", "b4r", "Create Arduino Apps", "./assets/10.jpg")
	oc.AddItem("b4i", "b4i", "Create iOS Apps", "./assets/11.jpg")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim oc As SDUIOptionsCard"$)
	c1.AddCode($"oc.AddOptionsCard(Me, page.CellID(1, 1), "oc1")"$)
	c1.AddCode($"oc.AddItem("b4a", "b4a", "Create Android Apps", "./assets/8.jpg")"$)
	c1.AddCode($"oc.AddItem("b4j", "b4j", "Create Desktop Apps", "./assets/9.jpg")"$)
	c1.AddCode($"oc.AddItem("b4r", "b4r", "Create Arduino Apps", "./assets/10.jpg")"$)
	c1.AddCode($"oc.AddItem("b4i", "b4i", "Create iOS Apps", "./assets/11.jpg")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub oc1_Change (item As String)"$)
	c1.AddCode($"page.Cell(2, 1).Caption = item"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Private Sub oc1_Change (item As String)
	page.Cell(2, 1).Caption = item
End Sub