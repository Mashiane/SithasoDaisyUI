﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "videodemo"
	Public title As String = "Video - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private vid As SDUIVideo
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	vid = page.Cell(1, 1).AddVideo("vid1", "", "", "", "./assets/video2.webm")
	vid.Height = "500px"
	vid.Width = "500px"
	'
	Dim c2 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"vid = page.Cell(1, 1).AddVideo("vid1", "", "", "", "./assets/video2.webm")"$)
	c2.AddCode($"vid.Height = "500px""$)
	c2.AddCode($"vid.Width = "500px""$)
	c2.Refresh
End Sub
