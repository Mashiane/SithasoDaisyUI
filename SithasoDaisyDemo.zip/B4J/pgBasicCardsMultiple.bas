﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.96
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "basiccardsmultiple"
	Public title As String = "Basic Cards - Multiple"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	app.PagePause
	'load the page layout to the pageviewwe
	banano.LoadLayout(app.PageViewer, "basiccardslayoutmultiple")
	'define our products, these can be obtained from the database
	Dim items As List
	items.Initialize
	items.Add(CreateMap("id":1, "title":"Puss in Boots", "description":"Product 1", "price":299.00, "img":"./assets/m1.jpg"))
	items.Add(CreateMap("id":2, "title":"Dragon Hunting", "description":"Product 2", "price":99.00, "img":"./assets/m2.jpg"))
	items.Add(CreateMap("id":3, "title":"Avengers Infinity War", "description":"Product 3", "price":399.00, "img":"./assets/m3.jpg"))
	items.Add(CreateMap("id":4, "title":"Bumble Bee", "description":"Product 4", "price":499.00, "img":"./assets/m4.jpg"))
	items.Add(CreateMap("id":5, "title":"Fast n Furious 6", "description":"Product 5", "price":599.00, "img":"./assets/m5.jpg"))
	items.Add(CreateMap("id":6, "title":"Avatar", "description":"Product 6", "price":699.00, "img":"./assets/m6.jpg"))
	items.Add(CreateMap("id":7, "title":"Die Hart", "description":"Product 7", "price":199.00, "img":"./assets/m7.jpg"))
	items.Add(CreateMap("id":8, "title":"Blood Shot", "description":"Product 8", "price":98.00, "img":"./assets/m8.jpg"))
	'
	'load each card using banano loadlayoutarray
	For Each item As Map In items
		Dim Ret As Long
		Dim AllViews As Map
   		'load each generic product
		Ret = banano.LoadLayoutArray("#basiccards", "eachcardlayout", False)
		'get all the views in the layout
		AllViews = banano.GetAllViewsFromLayoutArray(Me, "eachcardlayout", Ret)
		'get the image layout
		Dim img1 As SDUIImage = AllViews.Get("img1")
		'assign the product image from the list
		img1.Src = item.Get("img")
		'get the title & update it
		Dim title1 As SDUICardTitle = AllViews.Get("title1")
		title1.Caption = item.Get("title")
		Dim p1 As SDUILabel = AllViews.Get("p1")
		p1.Caption = item.Get("description")
		'get the buy button and set its tag to be the product
		Dim buy1 As SDUIButton = AllViews.Get("buy1")
		buy1.Tag = item
		'add a click event to the button
		buy1.On("click", Me, "buy_click")
		'get and update the price badge
		Dim price1 As SDUIBadge = AllViews.Get("price1")
		price1.Caption = "R " & SDUIShared.NiceMoney(item.Get("price"))
		'get the wish button and assign the product
		Dim wishlist1 As SDUIButton = AllViews.Get("wishlist1")
		wishlist1.Tag = item
		'assign a click event to the wish button
		wishlist1.On("click", Me, "wishlist_click")
		'set color to red
		wishlist1.HoverBGColor = "#ff0000"
		wishlist1.BGColor = "#ff0000"
	Next
	app.PageResume
End Sub

'when a wish button is clicked
Sub wishlist_click(e As BANanoEvent)
	e.PreventDefault
	'get the sender
	Dim btnWish As SDUIButton = Sender
	'get the tag from the button
	app.ShowSwal("Wish: " & banano.ToJson(btnWish.Tag))
End Sub

'when the buy button is clicked
Sub buy_click(e As BANanoEvent)
	e.PreventDefault
	'get the sender
	Dim btnBuy As SDUIButton = Sender
	'get the tag
	app.ShowSwal("Buy: " & banano.ToJson(btnBuy.Tag))
End Sub