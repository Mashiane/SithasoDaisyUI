﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adalerts"
	Public title As String = "AD Alerts"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIAlert1 As SDUIAlert
	Private SDUIAlert2 As SDUIAlert
	Private SDUIAlert3 As SDUIAlert
	Private SDUIAlert4 As SDUIAlert
	Private SDUIAlert5 As SDUIAlert
	Private SDUIAlert6 As SDUIAlert
	Private SDUIAlert7 As SDUIAlert
	Private SDUIButton1 As SDUIButton
	Private SDUIGrid1 As SDUIGrid
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "alertslayout")
	
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert1", "SDUIAlert1", SDUIAlert1.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert2", "SDUIAlert2", SDUIAlert2.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert3", "SDUIAlert3", SDUIAlert3.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert4", "SDUIAlert4", SDUIAlert4.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert5", "SDUIAlert5", SDUIAlert5.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert6", "SDUIAlert6", SDUIAlert6.CustProps)
	pgIndex.AddDesignKV1("SDUIAlert.SDUIAlert7", "SDUIAlert7", SDUIAlert7.CustProps)
	pgIndex.AddDesignKV1("SDUIGrid.SDUIGrid1", "SDUIGrid1", SDUIGrid1.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton1", "SDUIButton1", SDUIButton1.CustProps)
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIButton1_Click (e As BANanoEvent)
	SDUIAlert7.Show
End Sub