﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adbottomnav"
	Public title As String = "AD Bottom Nav"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIBottomNav1 As SDUIBottomNav
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adbottomnavlayout")
	pgIndex.drawer.AdjustClippedLeft(True)
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIBottomNav.SDUIBottomNav1", "SDUIBottomNav1", SDUIBottomNav1.CustProps)

	'BuildPage
	SDUIBottomNav1.AddItemBadge("home", "fa-solid fa-house", "Home", app.COLOR_PRIMARY, 10)
	SDUIBottomNav1.AddItem("info", "fa-solid fa-hospital", "Hospital", app.COLOR_SUCCESS)
	SDUIBottomNav1.AddItem("graph", "fa-solid fa-pen-clip", "Graph", app.COLOR_WARNING)
	SDUIBottomNav1.AddItem("like", "fa-solid fa-user-friends", "Friends", app.COLOR_INFO)
	SDUIBottomNav1.AddItem("comment", "fa-solid fa-pastafarianism", "Comment", app.COLOR_ERROR)
	SDUIBottomNav1.SetItemBadgeValue("info", 10)
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIBottomNav1_Click (item As String)
	app.ShowSwalInfo(item)
End Sub