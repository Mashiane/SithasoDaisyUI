﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "signup"
	Public title As String = "Register"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	'
	Private mdlRegister As SDUIModal
	Private txtFirstName As SDUITextBox
	Private txtLastName As SDUITextBox
	Private txtEmail As SDUITextBox
	Private txtAddress As SDUITextArea
	Private txtTelephone As SDUITextBox
	Private radGender As SDUIRadioGroup
	Private chkAgree As SDUICheckbox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	
	Dim c1 As SDUIMockupCode = page.Cell(1, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Private mdlRegister As SDUIModal"$)
	c1.AddCode($"Private txtFirstName As SDUITextBox"$)
	c1.AddCode($"Private txtLastName As SDUITextBox"$)
	c1.AddCode($"Private txtEmail As SDUITextBox"$)
	c1.AddCode($"Private txtAddress As SDUITextArea"$)
	c1.AddCode($"Private txtTelephone As SDUITextBox"$)
	c1.AddCode($"Private radGender As SDUIRadioGroup"$)
	c1.AddCode($"Private chkAgree As SDUICheckbox"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"mdlRegister = page.root.AddModal("mdlregister", "Sign Up", "Register", "Cancel", "", "700px")"$)
	c2.AddCode($"mdlRegister.Container.AddRows2.AddColumns2x6"$)
	c2.AddCode($"mdlRegister.Container.AddRows3.AddColumns12"$)
	c2.AddCode($"mdlRegister.Container.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"txtFirstName = mdlRegister.Container.Cell(1, 1).AddTextBoxLabel("txtfirstname", "First Name", "")"$)
	c2.AddCode($"txtFirstName.PrependIcon = "fa-user""$)
	c2.AddCode($"txtFirstName.Required = True"$)
	c2.AddCode($"txtFirstName.AutoFocus = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"txtLastName = mdlRegister.Container.Cell(1, 2).AddTextBoxLabel("txtlastname", "Last Name", "")"$)
	c2.AddCode($"txtLastName.PrependIcon = "fa-user""$)
	c2.AddCode($"txtLastName.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"txtEmail = mdlRegister.Container.Cell(2, 1).AddTextBoxLabel("txtEmail", "Email Address", "")"$)
	c2.AddCode($"txtEmail.PrependIcon = "fa-envelope""$)
	c2.AddCode($"txtEmail.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"txtTelephone = mdlRegister.Container.Cell(2, 2).AddTextBoxLabel("txttelphone", "Telephone", "")"$)
	c2.AddCode($"txtTelephone.PrependIcon = "fa-phone""$)
	c2.AddCode($"txtTelephone.Required = True"$)
	c2.AddCode($"txtAddress = mdlRegister.Container.Cell(3, 1).AddTextAreaLabel("txtaddress", "Residential Address", "")"$)
	c2.AddCode($"txtAddress.PrependIcon = "fa-building""$)
	c2.AddCode($"txtAddress.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim g As Map = CreateMap()"$)
	c2.AddCode($"g.Put("male", "Male")"$)
	c2.AddCode($"g.Put("female", "Female")"$)
	c2.AddCode($"g.Put("other", "Other")"$)
	c2.AddCode($"radGender = mdlRegister.Cell(4, 1).AddRadioGroup("radGender", "Gender", "", True, g)"$)
	c2.AddCode($"radGender.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"chkAgree = mdlRegister.Cell(5, 1).AddCheckBoxLabel("agree", "I agree", "left")"$)
	c2.AddCode($"mdlRegister.Show"$)
	c2.Refresh
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Private Sub mdlregister_Yes_Click (e As BANanoEvent)"$)
	c3.AddCode($"'reset the validations"$)
	c3.AddCode($"mdlRegister.ResetValidation"$)
	c3.AddCode($"'validate each of the entries"$)
	c3.AddCode($"mdlRegister.Validate(txtFirstName.IsBlank)"$)
	c3.AddCode($"mdlRegister.Validate(txtLastName.IsBlank)"$)
	c3.AddCode($"mdlRegister.Validate(txtEmail.IsBlank)"$)
	c3.AddCode($"mdlRegister.Validate(txtTelephone.IsBlank)"$)
	c3.AddCode($"mdlRegister.Validate(txtAddress.IsBlank)"$)
	c3.AddCode($"mdlRegister.Validate(radGender.IsBlank)"$)
	c3.AddCode($"'check the form status"$)
	c3.AddCode($"If mdlRegister.IsValid = False Then Return"$)
	c3.AddCode($"'mdlregister.hide"$)
	c3.AddCode($"End Sub"$)
	c3.AddCode($"Private Sub mdlregister_No_Click (e As BANanoEvent)"$)
	c3.AddCode($"mdlRegister.Hide"$)
	c3.AddCode($"End Sub"$)
	c3.Refresh
	
	
	mdlRegister = page.Root.AddModal( "mdlregister", "Sign Up", "Register", "Cancel", "", "700px")
	mdlRegister.Form.AddRows2.AddColumns2x6
	mdlRegister.Form.AddRows3.AddColumns12
	mdlRegister.Form.BuildGrid
	mdlRegister.Form.Shrink
	'
	txtFirstName = mdlRegister.Form.Cell(1, 1).AddTextBoxLabel("txtfirstname", "First Name", "")
	txtFirstName.PrependIcon = "fa-solid fa-user"
	txtFirstName.Required = True
	txtFirstName.AutoFocus = True
	'
	txtLastName = mdlRegister.Form.Cell(1, 2).AddTextBoxLabel("txtlastname", "Last Name", "")
	txtLastName.PrependIcon = "fa-solid fa-user"
	txtLastName.Required = True
	'
	txtEmail = mdlRegister.Form.Cell(2, 1).AddTextBoxLabel("txtEmail", "Email Address", "")
	txtEmail.PrependIcon = "fa-solid fa-envelope"
	txtEmail.Required = True
	'
	txtTelephone = mdlRegister.Form.Cell(2, 2).AddTextBoxLabel("txttelphone", "Telephone", "")
	txtTelephone.PrependIcon = "fa-solid fa-phone"
	txtTelephone.Required = True
		
	txtAddress = mdlRegister.Form.Cell(3, 1).AddTextAreaLabel("txtaddress", "Residential Address", "")
	txtAddress.PrependIcon = "fa-solid fa-building"
	txtAddress.Required = True
	'
	Dim g As Map = CreateMap()
	g.Put("male", "Male")
	g.Put("female", "Female")
	g.Put("other", "Other")
	radGender = mdlRegister.Cell(4, 1).AddRadioGroup("radGender", "Gender", "", False, "md", "primary", g)
	'
	chkAgree = mdlRegister.Cell(5, 1).AddCheckBoxLabel("agree", "I agree", "left")
	
	mdlRegister.Show
End Sub


Private Sub mdlregister_Yes_Click (e As BANanoEvent)
	'reset the validations
	mdlRegister.ResetValidation
	'validate each of the entries
	mdlRegister.Validate(txtFirstName.IsBlank)
	mdlRegister.Validate(txtLastName.IsBlank)
	mdlRegister.Validate(txtEmail.IsBlank)
	mdlRegister.Validate(txtTelephone.IsBlank)
	mdlRegister.Validate(txtAddress.IsBlank)
	mdlRegister.Validate(radGender.IsBlank)
	'check the form status
	If mdlRegister.IsValid = False Then Return
	
	mdlRegister.hide
End Sub

Private Sub mdlregister_No_Click (e As BANanoEvent)
	mdlRegister.Hide
End Sub