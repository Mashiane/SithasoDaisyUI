﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "radios"
	Public title As String = "Radio"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private rad1 As SDUIRadioGroup
	Private rad2 As SDUIRadioGroup
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows1.AddColumns3x4
	page.Root.AddRows5.AddColumns4p8
	page.Root.BuildGrid
	'start adding you components here
		
	rad1 = page.Cell(2, 1).AddRadioGroup("rad1", "Choices", "Here are some choices", False, "md", "primary", CreateMap())
	rad1.AddItem("blue", "Blue Pill")
	rad1.AddItem("red", "Red Pill")
	rad1.SetItemColor("blue", "primary")
	rad1.SetItemColor("red", "secondary")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"rad1 = page.Cell(1, 1).AddRadioGroup("rad1", "Choices", "Here are some choices", False, "md", "primary", CreateMap())"$)
	c1.AddCode($"rad1.AddItem("blue", "Blue Pill")"$)
	c1.AddCode($"rad1.AddItem("red", "Red Pill")"$)
	c1.AddCode($"rad1.SetItemColor("blue", "primary")"$)
	c1.AddCode($"rad1.SetItemColor("red", "secondary")"$)
	c1.AddCode("'trap change event")
	c1.AddCode($"Private Sub rad1_Change (item As String)"$)
	c1.AddCode($"page.Cell(4, 1).Caption = item"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	'
	Dim btnGet As SDUIButton = page.Cell(1,2).AddButton("btnget", "Get")
	Dim btnSet As SDUIButton = page.Cell(1,3).AddButton("btnset", "Set")
	'
	rad2 = page.Cell(3, 1).AddRadioGroup("rad2", "Gender", "Select a gender", True, "md", "secondary", CreateMap())
	rad2.AddItem("male", "Male")
	rad2.AddItem("female", "Female")
	rad2.AddItem("other", "Other")
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"rad2 = page.Cell(3, 1).AddRadioGroup("rad2", "Gender", "Select a gender", True, "md", "secondary", CreateMap())"$)
	c2.AddCode($"rad2.AddItem("male", "Male")"$)
	c2.AddCode($"rad2.AddItem("female", "Female")"$)
	c2.AddCode($"rad2.AddItem("other", "Other")"$)
	c2.Refresh
End Sub

Private Sub rad1_Change (item As String)
	page.Cell(4, 1).Caption = item
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = rad2.value
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	rad1.value = "blue"
	rad2.value = "other"
End Sub
