﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "masks"
	Public title As String = "Mask"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Dim img1 As SDUIImage
	img1.AddImage(Me, page.CellID(1, 1), "img1", "./assets/arch.jpg", "", 20, 20)
	img1.Mask.Heart
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim img1 As SDUIImage"$)
	c1.AddCode($"img1.AddImage(Me, page.CellID(1, 1), "img1", "./assets/arch.jpg", "", 20, 20)"$)
	c1.AddCode($"img1.Mask.Heart"$)
	c1.Refresh
	'
	Dim img2 As SDUIImage = page.Cell(2, 1).AddImage("img2", "./assets/arch.jpg", "", 20, 20)
	img2.Mask.Hexagon
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim img2 As SDUIImage = page.Cell(2, 1).AddImage("img2", "./assets/arch.jpg", "", 20, 20)"$)
	c2.AddCode($"img2.Mask.Hexagon"$)
	c2.Refresh
	'
	Dim img3 As SDUIImage
	img3.AddImage(Me, page.CellID(3, 1), "img3", "./assets/arch.jpg", "", 20, 20)
	img3.Mask.Circle
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim img3 As SDUIImage"$)
	c3.AddCode($"img3.AddImage(Me, page.CellID(3, 1), "img3", "./assets/arch.jpg", "", 20, 20)"$)
	c3.AddCode($"img3.Mask.Circle"$)
	c3.Refresh
	'
	Dim img4 As SDUIImage
	img4.AddImage(Me, page.CellID(4, 1), "img4", "./assets/arch.jpg", "", 20, 20)
	img4.Mask.Squircle
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim img4 As SDUIImage"$)
	c4.AddCode($"img4.AddImage(Me, page.CellID(4, 1), "img4", "./assets/arch.jpg", "", 20, 20)"$)
	c4.AddCode($"img4.Mask.Squircle"$)
	c4.Refresh
	'
	Dim img5 As SDUIIndicator
	img5.AddIndicator(Me, page.cellid(5, 1), "img5")
	img5.AtCenter
	img5.AtMiddle
	img5.Badge.Color = app.COLOR_SECONDARY
	img5.Badge.Caption = "loading..."
	img5.Root.AddImage("img5_1", "./assets/arch.jpg", "", "300", "150")
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim img5 As SDUIIndicator"$)
	c5.AddCode($"img5.AddIndicator(Me, page.cellid(5, 1), "img5")"$)
	c5.AddCode($"img5.AtCenter"$)
	c5.AddCode($"img5.AtMiddle"$)
	c5.AddCode($"img5.Badge.Color = app.COLOR_SECONDARY"$)
	c5.AddCode($"img5.Badge.Caption = "loading...""$)
	c5.AddCode($"img5.Root.AddImage("img5_1", "./assets/arch.jpg", "", "300", "150")"$)
	c5.Refresh
End Sub
