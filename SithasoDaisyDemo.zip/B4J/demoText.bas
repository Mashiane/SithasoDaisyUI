﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "textboxes"
	Public title As String = "Text Boxes"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private txt1 As SDUITextBox
	Private txt2 As SDUITextBox
	Private txtPassword As SDUITextBox
	Private txtPassword1 As SDUITextBox
	Private txtEmail As SDUITextBox
	Private txtTelephone As SDUITextBox
	Private txtNumber As SDUITextBox

End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows1.AddColumns4x3
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows12.AddColumns4p8
	
	page.Root.BuildGrid
	'start adding you components here
	
	txt1.AddTextBox(Me, page.CellID(1,1) , "txt1")
	txt1.Placeholder = "Type here..."
	txt1.Bordered = True
	txt1.color = app.COLOR_PRIMARY
	txt1.Value = "Sithaso DaisyUI"
	'
	Dim btnGet As SDUIButton = page.Cell(1, 2).AddButton("btnget", "Get Text")
	'
	Dim btnSet As SDUIButton = page.Cell(1, 3).AddButton("btnset", "Set Text")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Private txt1 As SDUITextBox"$)
	c1.AddCode($"txt1.AddTextBox(Me, page.CellID(1,1) , "txt1")"$)
	c1.AddCode($"txt1.Placeholder = "Type here...""$)
	c1.AddCode($"txt1.Bordered = True"$)
	c1.AddCode($"txt1.color = app.COLOR_PRIMARY"$)
	c1.AddCode($"txt1.Value = "Sithaso DaisyUI""$)
	c1.Refresh
		
	'
	txt2 = page.Cell(3, 1).AddTextBoxLabel("txt2", "Enter your first name", "First name")
	txt2.Placeholder = "Ghost"
	txt2.Ghost = True
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"txt2 = page.Cell(3, 1).AddTextBoxLabel("txt2", "Enter your first name", "First name")"$)
	c2.AddCode($"txt2.Placeholder = "Ghost""$)
	c2.AddCode($"txt2.Ghost = True"$)
	c2.Refresh
	'
	Dim txt3 As SDUITextBox = page.Cell(4, 1).AddTextBoxLabel("txt3", "Enter your last name", "Last name")
	txt3.SizeSM
	'
	Dim c3 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim txt3 As SDUIText = page.Cell(4, 1).AddTextBoxLabel("txt3", "Enter your last name", "Last name")"$)
	c3.AddCode($"txt3.SizeSM"$)
	c3.Refresh
	'
	Dim txt4 As SDUITextBox = page.Cell(5, 1).AddTextBoxLabel("txt4", "MC Hammer", "")
	txt4.Disable
	txt4.Placeholder = "You can't touch this!"
	'
	Dim c4 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim txt4 As SDUIText = page.Cell(5, 1).AddTextBoxLabel("txt4", "MC Hammer", "")"$)
	c4.AddCode($"txt4.Disable"$)
	c4.AddCode($"txt4.Placeholder = "You can't touch this!""$)
	c4.Refresh
	'
	txtPassword = page.Cell(6, 1).AddPassword("txtpassword", "Password", "Enter your password", True)
	txtPassword.Value = "password"
	txtPassword.PrependIcon = "fa-solid fa-lock"
	'
	Dim c5 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"txtPassword = page.Cell(6, 1).AddPassword("txtpassword", "Password", "Enter your password", True)"$)
	c5.AddCode($"txtPassword.Value = "password""$)
	c5.AddCode($"txtPassword.PrependIcon = "fa-lock""$)
	c5.Refresh
	
	'
	txtPassword1 = page.Cell(7, 1).AddPassword("txtpassword1", "Password", "", False)
	txtPassword1.Value = "password"
	txtPassword1.PrependIcon = "fa-solid fa-lock"
	'
	Dim c6 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"txtPassword1 = page.Cell(7, 1).AddPassword("txtpassword1", "Password", "", False)"$)
	c6.AddCode($"txtPassword1.Value = "password""$)
	c6.AddCode($"txtPassword1.PrependIcon = "fa-solid fa-lock""$)
	c6.Refresh
	'
	txtEmail = page.Cell(8, 1).AddEmail("txtemail", "Email", "")
	txtEmail.Value = "sithasodaisyui@tailwind.com"
	txtEmail.PrependIcon = "fa-solid fa-envelope"
	'
	Dim c7 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"txtEmail = page.Cell(8, 1).AddEmail("txtemail", "Email", "")"$)
	c7.AddCode($"txtEmail.Value = "sithasodaisyui@tailwind.com""$)
	c7.AddCode($"txtEmail.PrependIcon = "fa-solid fa-envelope""$)
	c7.Refresh
	'
	txtTelephone = page.Cell(9, 1).AddTelephone("txttel", "Mobile #", "")
	txtTelephone.Pattern = "[0-9]{3}-[0-9]{4}-[0-9]{4}"
	txtTelephone.Value = "12334567890"
	txtTelephone.PrependIcon = "fa-solid fa-phone"
	'
	Dim c8 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"txtTelephone = page.Cell(9, 1).AddTelephone("txttel", "Mobile #", "")"$)
	c8.AddCode($"txtTelephone.Pattern = "[0-9]{3}-[0-9]{4}-[0-9]{4}""$)
	c8.AddCode($"txtTelephone.Value = "12334567890""$)
	c8.AddCode($"txtTelephone.PrependIcon = "fa-solid fa-phone""$)
	c8.Refresh
	'
	txtNumber = page.Cell(10, 1).AddNumber("txtnumber", "Quantity", "", 1, 5)
	'
	Dim c9 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"txtNumber = page.Cell(10, 1).AddNumber("txtnumber", "Quantity", "", 1, 5)"$)
	c9.Refresh

End Sub

Private Sub btnget_Click (e As BANanoEvent)
	Dim value As String = txt1.Value
	page.Cell(1, 4).caption	= value
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	txt1.Value = "Welcome to Sithaso DaisyUI"
End Sub

Private Sub txt2_Change (event As BANanoEvent)
	page.Cell(11, 1).Caption = txt2.Value
End Sub

Private Sub txtpassword_Append_Click (event As BANanoEvent)
	txtPassword.toggleEyes
End Sub