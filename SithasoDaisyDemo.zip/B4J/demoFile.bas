﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "files"
	Public title As String = "File Input"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private fi As SDUIFileInput
	Private img1 As SDUIImage
	Private f3 As SDUIFileInput
	Private myCamera As SDUIFileInput
	Private myExcel As SDUITextBox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub



'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	fi = page.Cell(1, 1).AddFileInputLabel("fi", "Upload File", "(png, jpg, jpeg)", False)
	fi.AcceptImagesOnly
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"fi = page.Cell(1, 1).AddFileInputLabel("fi", "Upload File", "(png, jpg, jpeg)", False)"$)
	c1.Refresh
	
	img1 = page.Cell(2, 1).AddImage("img1", "./assets/mashy.jpg", "Mashy", 80, 80)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"img1 = page.Cell(2, 1).AddImage("img1", "./assets/mashy.jpg", "Mashy", 80, 80)"$)
	c2.Refresh
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Sub fi_change(e As BANanoEvent)"$)
	c3.AddCode($"'	'has the file been specified"$)
	c3.AddCode($"Dim fileObj As Map = fi.GetFile"$)
	c3.AddCode($"If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return"$)
	c3.AddCode($"'get file details"$)
	c3.AddCode($"Dim fileDet As FileObject"$)
	c3.AddCode($"fileDet = SDUIShared.GetFileDetails(fileObj)"$)
	c3.AddCode($"'you can check the size here"$)
	c3.AddCode($"Dim fs As Long = fileDet.FileSize"$)
	c3.AddCode($"If fs >= 5000 Then"$)
	c3.AddCode($"End If"$)
	c3.AddCode($"'start uploading the file to assets folder"$)
	c3.AddCode($"fileDet = SDUIShared.UploadFileWait(fileObj)"$)
	c3.AddCode($"'get the file name"$)
	c3.AddCode($"Dim fn As String = fileDet.FileName"$)
	c3.AddCode($"'get the status of the upload"$)
	c3.AddCode($"Dim sstatus As String = fileDet.Status"$)
	c3.AddCode($"Select Case sstatus"$)
	c3.AddCode($"Case "error""$)
	c3.AddCode($"Return"$)
	c3.AddCode($"Case "success""$)
	c3.AddCode($"End Select"$)
	c3.AddCode($"'get the upload full path"$)
	c3.AddCode($"Dim fp As String = fileDet.FullPath"$)
	c3.AddCode($"img1.Src = fp"$)
	c3.AddCode($"End Sub"$)
	c3.Refresh
	'
	f3 = page.Cell(4, 1).AddFileInputProgress("f3", "110px", "gray")
	f3.AcceptImagesOnly
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"f3 = page.Cell(4, 1).AddFileInputProgress("f3", "110px", "gray")"$)
	c4.AddCode($"Private Sub f3_Change (event As BANanoEvent)"$)
	c4.AddCode($"'has the file been specified"$)
	c4.AddCode($"Dim fileObj As Map = f3.GetFile"$)
	c4.AddCode($"If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return"$)
	c4.AddCode($"'get file details"$)
	c4.AddCode($"Dim fileDet As FileObject"$)
	c4.AddCode($"fileDet = SDUIShared.GetFileDetails(fileObj)"$)
	c4.AddCode($"'you can check the size here"$)
	c4.AddCode($"Dim fs As Long = fileDet.FileSize"$)
	c4.AddCode($"If fs >= 5000 Then"$)
	c4.AddCode($"End If"$)
	c4.AddCode($"f3.LoadingFile = True"$)
	c4.AddCode($"'start uploading the file to assets folder"$)
	c4.AddCode($"fileDet = SDUIShared.UploadFileWait(fileObj)"$)
	c4.AddCode($"'get the file name"$)
	c4.AddCode($"Dim fn As String = fileDet.FileName"$)
	c4.AddCode($"'get the status of the upload"$)
	c4.AddCode($"Dim sstatus As String = fileDet.Status"$)
	c4.AddCode($"Select Case sstatus"$)
	c4.AddCode($"Case "error""$)
	c4.AddCode($"'*"$)
	c4.AddCode($"f3.LoadingFile = False"$)
	c4.AddCode($"Return"$)
	c4.AddCode($"Case "success""$)
	c4.AddCode($"End Select"$)
	c4.AddCode($"'get the upload full path"$)
	c4.AddCode($"Dim fp As String = fileDet.FullPath"$)
	c4.AddCode($"f2.PreviewImage = fp"$)
	c4.AddCode($"'cancel the loading"$)
	c4.AddCode($"f3.LoadingFile = False"$)
	c4.AddCode($"End Sub"$)
	c4.Refresh
	'
	myCamera = page.Cell(5, 1).AddFileInputCamera("mycamera", "110px", "secondary")
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"myCamera = page.Cell(5, 1).AddFileInputCamera("mycamera", "110px", "secondary")"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Private Sub mycamera_Change (event As BANanoEvent)"$)
	c5.AddCode($"'has the file been specified"$)
	c5.AddCode($"Dim fileObj As Map = myCamera.GetFile"$)
	c5.AddCode($"If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return"$)
	c5.AddCode($"'get file details"$)
	c5.AddCode($"Dim fileDet As FileObject"$)
	c5.AddCode($"fileDet = SDUIShared.GetFileDetails(fileObj)"$)
	c5.AddCode($"'get the file name"$)
	c5.AddCode($"Dim fn As String = fileDet.FileName"$)
	c5.AddCode($"'you can check the size here"$)
	c5.AddCode($"Dim fs As Long = fileDet.FileSize"$)
	c5.AddCode($"If fs >= 5000 Then"$)
	c5.AddCode($"End If"$)
	c5.AddCode($"'read the file details as JSON"$)
	c5.AddCode($"Dim fText As String = banano.Await(SDUIShared.readAsDataURLWait(fileObj))"$)
	c5.AddCode($"img1.src = fText"$)
	c5.AddCode($"'save content to the tag"$)
	c5.AddCode($"img1.Tag = fText"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh

End Sub

Private Sub mycamera_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = myCamera.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'read the file details as JSON
	Dim fText As String = banano.Await(SDUIShared.GetFileAsDataURL(fileObj))
	img1.src = fText
	'save content to the tag
	img1.Tag = fText
End Sub

Private Sub f3_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = f3.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	f3.LoadingFile = True
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
	Case "error"
		'*
		f3.LoadingFile = False
		Return
	Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	img1.Src = fp
	'cancel the loading
	f3.LoadingFile = False
End Sub

Sub fi_change(e As BANanoEvent)
'	'has the file been specified
	Dim fileObj As Map = fi.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	img1.Src = fp
End Sub