﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "demochat"
	Public title As String = "Chat Demo"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIChat1 As SDUIChat
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	
	'start adding you components here
	SDUIChat1 = page.Cell(1, 1).AddChat("chat1")
	SDUIChat1.Clear
	SDUIChat1.AddConversation("c1", True, "", "", "", _
	"It's over Anakin, <br/>I have the high ground.", "")
	'
	SDUIChat1.AddConversation("c2", False, "", "", "", _
	"You underestimate my power!", "")
	'
	SDUIChat1.AddConversation("c3", True, "./assets/Anna.jpg", "Anna", "45 minutes ago", _
	"It was said that you would, destroy the Sith, not join them.", "")
	'
	SDUIChat1.AddConversation("c4", True, "./assets/yadit.jpg", "Yadit", "40 minutes ago", _
	"It was you who would bring balance to the Force", "")
	'
	SDUIChat1.AddConversation("c5", True, "./assets/lula.jpg", "Lula", "35 minutes ago", _
	"Not leave it in Darkness", "")
	'
	SDUIChat1.AddConversation("c6", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "30 minutes ago", _
	"You were the Chosen One!", "").SetConversationFooter("c6", "Delivered")
	'
	SDUIChat1.AddConversation("c7", False, "./assets/face13.jpg", "Anakin", "25 minutes ago", _
	"I hate you!", "").SetConversationFooter("c7", "Seen 26 minutes ago")
	'
	SDUIChat1.AddConversation("c8", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "20 minutes ago", _
	"You were my brother, Anakin.", "").SetConversationFooter("c8", "Seen")
	'
	SDUIChat1.AddConversation("c9", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "21 minutes ago", _
	"I loved you.", "").SetConversationFooter("c9", "Delivered")
	'
	SDUIChat1.AddConversationFromBasic("c10", "What kind of nonsense is this??").SetConversationColor("c10", app.COLOR_PRIMARY)
	'
	SDUIChat1.AddConversationToBasic("c11", "Calm down, Anakin.").SetConversationColor("c11", app.COLOR_SUCCESS)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("mc2", "vb")
	c2.AddCode($"'start adding you components here"$)
	c2.AddCode($"SDUIChat1 = page.Cell(1, 1).AddChat("chat1")"$)
	c2.AddCode($"SDUIChat1.Clear"$)
	c2.AddCode($"SDUIChat1.AddConversation("c1", True, "", "", "", _"$)
	c2.AddCode($""It's over Anakin, <br/>I have the high ground.", "")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c2", False, "", "", "", _"$)
	c2.AddCode($""You underestimate my power!", "")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c3", True, "./assets/Anna.jpg", "Anna", "45 minutes ago", _"$)
	c2.AddCode($""It was said that you would, destroy the Sith, not join them.", "")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c4", True, "./assets/yadit.jpg", "Yadit", "40 minutes ago", _"$)
	c2.AddCode($""It was you who would bring balance to the Force", "")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c5", True, "./assets/lula.jpg", "Lula", "35 minutes ago", _"$)
	c2.AddCode($""Not leave it in Darkness", "")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c6", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "30 minutes ago", _"$)
	c2.AddCode($""You were the Chosen One!", "").SetConversationFooter("c6", "Delivered")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c7", False, "./assets/face13.jpg", "Anakin", "25 minutes ago", _"$)
	c2.AddCode($""I hate you!", "").SetConversationFooter("c7", "Seen 26 minutes ago")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c8", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "20 minutes ago", _"$)
	c2.AddCode($""You were my brother, Anakin.", "").SetConversationFooter("c8", "Seen")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversation("c9", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "21 minutes ago", _"$)
	c2.AddCode($""I loved you.", "").SetConversationFooter("c9", "Delivered")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversationFromBasic("c10", "What kind of nonsense is this??").SetConversationColor("c10", app.COLOR_PRIMARY)"$)
	c2.AddCode($"'"$)
	c2.AddCode($"SDUIChat1.AddConversationToBasic("c11", "Calm down, Anakin.").SetConversationColor("c11", app.COLOR_SUCCESS)"$)
	c2.Refresh
End Sub
