﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "gradbuttons"
	Public title As String = "Gradient Buttons"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim b1 As SDUIButton = page.Cell(1, 1).AddButtonNormal("b1", "Button")
	b1.Root.py(2).px(6).textColorIntensity("gray", 100).isrounded.bgGradientToR.fromColorIntensity("gray", 600).toColorIntensity("gray", 400)
	b1.Root.hover("from-gray-600").hover("to-gray-800")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim b1 As SDUIButton = page.Cell(1, 1).AddButtonNormal("b1", "Button")"$)
	c1.AddCode($"b1.Root.py(2).px(6).textColorIntensity("gray", 100).isrounded.bgGradientToR.fromColorIntensity("gray", 600).toColorIntensity("gray", 400)"$)
	c1.AddCode($"b1.Root.hover("from-gray-600").hover("to-gray-800")"$)
	c1.Refresh
	'
	Dim b2 As SDUIButton = page.Cell(2, 1).AddButtonNormal("b2", "Button")
	b2.Root.py(2).px(6).textColorIntensity("blue", 100).isrounded.bgGradientToR.fromColorIntensity("blue", 600).toColorIntensity("blue", 400)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim b2 As SDUIButton = page.Cell(2, 1).AddButtonNormal("b2", "Button")"$)
	c2.AddCode($"b2.Root.py(2).px(6).textColorIntensity("blue", 100).isrounded.bgGradientToR.fromColorIntensity("blue", 600).toColorIntensity("blue", 400)"$)
	c2.Refresh
	'
	Dim b3 As SDUIButton = page.Cell(3, 1).AddButtonNormal("b3", "Button")
	b3.Root.py(2).px(6).textColorIntensity("green", 100).isrounded.bgGradientToR.fromColorIntensity("green", 600).toColorIntensity("green", 400)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim b3 As SDUIButton = page.Cell(3, 1).AddButtonNormal("b3", "Button")"$)
	c3.AddCode($"b3.Root.py(2).px(6).textColorIntensity("green", 100).isrounded.bgGradientToR.fromColorIntensity("green", 600).toColorIntensity("green", 400)"$)
	c3.Refresh
	'
	Dim b4 As SDUIButton = page.Cell(4, 1).AddButtonNormal("b4", "Button")
	b4.Root.py(2).px(6).textColorIntensity("red", 100).isrounded.bgGradientToR.fromColorIntensity("red", 600).toColorIntensity("red", 400)
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim b4 As SDUIButton = page.Cell(4, 1).AddButtonNormal("b4", "Button")"$)
	c4.AddCode($"b4.Root.py(2).px(6).textColorIntensity("red", 100).isrounded.bgGradientToR.fromColorIntensity("red", 600).toColorIntensity("red", 400)"$)
	c4.Refresh
	'
	Dim b5 As SDUIButton = page.Cell(5, 1).AddButtonNormal("b5", "Button")
	b5.Root.py(2).px(6).textColorIntensity("purple", 100).isrounded.bgGradientToR.fromColorIntensity("purple", 600).toColorIntensity("purple", 400)
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim b5 As SDUIButton = page.Cell(5, 1).AddButtonNormal("b5", "Button")"$)
	c5.AddCode($"b5.Root.py(2).px(6).textColorIntensity("purple", 100).isrounded.bgGradientToR.fromColorIntensity("purple", 600).toColorIntensity("purple", 400)"$)
	c5.Refresh
	'
	Dim b6 As SDUIButton = page.Cell(6, 1).AddButtonNormal("b6", "Button")
	b6.Root.py(2).px(6).textColorIntensity("gray", 100).isrounded.bgGradientToR
	b6.Root.fromColorIntensity("gren", 300).viaColorIntensity("blue", 500).toColorIntensity("purple", 600)
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim b6 As SDUIButton = page.Cell(6, 1).AddButtonNormal("b6", "Button")"$)
	c6.AddCode($"b6.Root.py(2).px(6).textColorIntensity("gray", 100).isrounded.bgGradientToR"$)
	c6.AddCode($"b6.Root.fromColorIntensity("gren", 300).viaColorIntensity("blue", 500).toColorIntensity("purple", 600)"$)
	c6.Refresh
	'
	Dim b7div As SDUIDiv = page.Cell(7, 1).AddDiv("b7div")
	b7div.p(1).isrounded.bgGradientToR.fromColorIntensity("green", 500).toColorIntensity("purple", 500)
	Dim b7 As SDUIButton = b7div.AddButtonNormal("b7", "Button")
	b7.Root.px(6).py(2).textColorIntensity("blue", 800).bgColor("white")
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim b7div As SDUIDiv = page.Cell(7, 1).AddDiv("b7div")"$)
	c7.AddCode($"b7div.p(1).isrounded.bgGradientToR.fromColorIntensity("green", 500).toColorIntensity("purple", 500)"$)
	c7.AddCode($"Dim b7 As SDUIButton = b7div.AddButtonNormal("b7", "Button")"$)
	c7.AddCode($"b7.Root.px(6).py(2).textColorIntensity("blue", 800).bgColor("white")"$)
	c7.Refresh
	
	
	Dim b8 As SDUIButton = page.Cell(8, 1).AddButtonNormal("b8", "Button")
	b8.Root.px(6).py(2).fontSemiBold.textColor("white").transition.duration(300).addClass("ease-in-out").delay(300).skewY(6).bgColorIntensity("red", 600)
	b8.Root.isrounded.Shadow("lg").hover("skew-x-6").hover("border-red-600").borderB(4)
	b8.Root.shadowColorIntensity("red", "600/50")
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"Dim b8 As SDUIButton = page.Cell(8, 1).AddButtonNormal("b8", "Button")"$)
	c8.AddCode($"b8.Root.px(6).py(2).fontSemiBold.textColor("white").transition.duration(300).addClass("ease-in-out").delay(300).skewY(6).bgColorIntensity("red", 600)"$)
	c8.AddCode($"b8.Root.isrounded.Shadow("lg").hover("skew-x-6").hover("border-red-600").borderB(4)"$)
	c8.AddCode($"b8.Root.shadowColorIntensity("red", "600/50")"$)
	c8.Refresh
	
End Sub
