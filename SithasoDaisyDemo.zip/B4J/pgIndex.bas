﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=8.5
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public app As SDUIApp		'ignore
	Public BANano As BANano		'ignore
	Public drawer As SDUIDrawer
	Private navbar As SDUINavBar
	Private drwLeft As SDUIModal
	Private drwRight As SDUIModal
	Private btnCode As SDUIButton
	Private btnNotif As SDUIButton
	Private cboDesign As SDUISelect
	Private cboTheme As SDUISelect
'	Private pb As SDUIPocketBase
	Private page As SDUIPage
	Private appTitle As String = "SithasoDaisy 2.24"
	Private themeName As String
End Sub

Sub Initialize					'ignoreDeadCode
	'initialize the app
	BANano.Await(app.AddApp(Me, Main.AppName))
	'app.RTL = True
	BANano.Await(AddUses)
	'set theme
	themeName = $"${Main.AppName}_theme"$
	Dim ctheme As String = BANano.GetLocalStorage2(themeName)
	ctheme = SDUIShared.CStr(ctheme)
	Select Case ctheme
	Case ""
		app.Theme = app.THEME_LIGHT
	Case Else
		app.Theme = ctheme
	End Select
	'SDUIShared.ShowLoader
	'set the font of the app
	app.Font = "font-sans"
	'
	'https://developers.google.com/maps/documentation/javascript/get-api-key
	app.UseGMap("AIzaSyBQzAobMRMW7H4duTQunhSI2MpYAsyPWxQ", demoGMap, "SDUIGMap1")
	
	'add a navbar to the content for PAGE
	'add appbar inside drawer
	CreateAppNavBar
	'add a drawer to the body
	CreateAppDrawer
	'add any other page not added to the drawer menu
	AddPages
	'if you need additional d
	AddOtherDrawers
	
	'navbar.Title.HideOnSmall
	'navbar.LogoAvatar.HideOnSmall
	'
	'initialize pocketbase
'	pb.Initialize(Me, "pb", "https://sithasodaisyui.pockethost.io", "notifications")
'	'define the fiels of the collection
'	pb.SchemaAddText(Array("id", "title", "description", "url", "icon"))
'	pb.SchemaAddInt1("seconds")
'	pb.SchemaAddBoolean(Array("vibrate"))
'	pb.Subscribe(Me, "notifications")
	'
	'Dim ec As String = SDUIShared.AESEncrypt("Anele Mbanga", "SithasoDaisy")
	'Log(ec)
	'Dim dc As String = SDUIShared.AESDecrypt(ec, "SithasoDaisy")
	'Log(dc)
	'show the welcome page
	BANano.Await(welcome.Show(app))
	app.PageResume
End Sub

#if javascript
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
		var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
		s1.async=true;
		s1.src='https://embed.tawk.to/63e5e7e5c2f1ac1e203276ee/1got13mna';
		s1.charset='UTF-8';
		s1.setAttribute('crossorigin','*');
		s0.parentNode.insertBefore(s1,s0);
	})();
#End If

Sub AddUses
	'uncomment unused
	BANano.Await(app.UsesPDF)
	BANano.Await(app.UsesExcel)
	BANano.Await(app.UsesCSV)	
	BANano.Await(app.UsesDropZone)
	BANano.Await(app.UsesFlatPickDateTime)
	BANano.Await(app.UsesRollDate)
	BANano.Await(app.UsesPocketBase)
	BANano.Await(app.UsesFlipPage)
	BANano.Await(app.UsesTimeLine)
	BANano.Await(app.UsesGridNav)
	BANano.Await(app.UsesChartKick)
	BANano.Await(app.UsesQRCode)
	BANano.Await(app.UsesBarCodeReader)
	BANano.Await(app.UsesWebCam)
	BANano.Await(app.UsesAxios)
	BANano.Await(app.UsesLottiePlayer)
	BANano.Await(app.UsesDocxTemplator)
	BANano.Await(app.UsesHTMLParser)
	BANano.Await(app.UsesLZCompressString)
	BANano.Await(app.UsesFullCalendar)
	BANano.Await(app.UsesDevice)
	BANano.Await(app.UsesKanBan)
	BANano.Await(app.UsesAES)
	BANano.Await(app.UsesGMaps)
	BANano.Await(app.UsesAES4PHP)
	BANano.Await(app.UsesToastChart)
	BANano.Await(app.UsesMockupCode)
	BANano.Await(app.UsesFireBase)
	BANano.Await(app.UsesSupaBase)
	BANano.Await(app.UsesRelax)
	BANano.Await(app.UsesGijgo)
	BANano.Await(app.UsesJustGage)
	BANano.Await(app.UsesFluidMeter)
	BANano.Await(app.UsesFrappeGantt)
	BANano.Await(app.UsesEvoCalendar)
	BANano.Await(app.UsesCollectJS)
	BANano.Await(app.UsesSwiper)
	BANano.Await(app.UsesStories)
	BANano.Await(app.UsesEnjoyHint)
End Sub


Private Sub pb_Change (Action As String, Record As Map, TableName As String)
	Select Case TableName
	Case "notifications"
		Select Case Action
		Case "create", "update"
			'a new notification has arrived
			Dim sdescription As String = Record.Get("description")
			Dim sicon As String = Record.Get("icon")
			Dim sseconds As String = SDUIShared.CInt(Record.Get("seconds"))
			Dim stitle As String = Record.Get("title")
			Dim surl As String = Record.Get("url")
			Dim simage As String = Record.Get("image")
			Dim bvibrate As String = SDUIShared.CBool(Record.Get("vibrate"))
			app.ShowBrowserNotification(stitle, sdescription, surl, sicon, simage, bvibrate, sseconds)
		End Select
	End Select
End Sub

Private Sub Notification_Click (link As String)
	If link = "" Then Return
	SDUIShared.OpenURLTab(link)
End Sub


Sub AddOtherDrawers
	'****add right and left drawer to the body of the page
	'***** RIGHT DRAWER
	drwLeft = app.AddLeftDrawer("leftdrawer", "300px", "500")
	drwLeft.OverlayTransparent = True
	'define the form g
	drwLeft.Form.AddRows2.AddColumns12
	drwLeft.Form.BuildGrid
	'
	drwLeft.Cell(1, 1).Caption = "This is the left drawer"
	'add a button to close the drawer
	Dim btnL As SDUIButton = drwLeft.Cell(2, 1).AddButtonLabel("btnCloseLeft", "Close Left Drawer")
	btnL.Toggle = drwLeft.Name
	
	'***** RIGHT DRAWER	
	drwRight = app.AddRightDrawer("rightdrawer", "300px", "500")
	drwRight.OverlayTransparent = True
	drwRight.Form.AddRows2.AddColumns12
	drwRight.Form.BuildGrid
	
	'add a button to close the drawer
	drwRight.Cell(1, 1).Caption = "This is the right drawer"
	Dim btnR As SDUIButton = drwRight.Cell(2, 1).AddButtonLabel("btnCloseRight", "Close Right Drawer")
	btnR.Toggle = drwRight.Name
End Sub


'NB: use this to add pages that are not added to the side nav bar
Sub AddPages
	'example
	'app.AddPage(demoGradients.name, demoGradients)
End Sub

Sub CreateAppDrawer
	'add a drawer to the body of the page
	drawer = app.AddAppDrawer("80", False)
	drawer.NonMobile
	'drawer = app.AddAppDrawer2("80", False, True, True)
	'overlay transparent
	drawer.OverlayTransparent = True
	drawer.ItemHoverColorIntensity("blue", "100")
	drawer.ItemFocusColorIntensity("blue", "100")
	drawer.ItemActiveColorIntensity("blue", "100")
	'
	drawer.Menu.Divider = True
	drawer.Menu.DivideColor = "gray-200"
	drawer.Menu.DivideStyle = "solid"
	drawer.Menu.DivideWidth = "y-2"
	'create the drawer menu and page linkages
	CreateDrawerMenu
End Sub

Private Sub appnavbar_Title_Click (e As BANanoEvent)
	app.ShowSwal("Title clicked!")
End Sub


Sub CreateAppNavBar
	'add a navbar to the body of the page
	navbar = app.AddAppNavBar
	'make the navbar sticky at the top
	navbar.Fixed = True
	'set the background color of the navba
	navbar.BGColorIntensity(app.COLOR_BASE, 100)
	'add a hamburger button that will toggle a drawer named 'appdrawer'
	navbar.AddHamburgerButton("appdrawer")
	'set the hamburger to only show on small devices
	'navbar.Hamburger.ShowOnSmallOnly
	'add a logo that is an avatar with a size of 12
	navbar.AddLogoAvatar("./assets/daisywoman3.png", 12)
	'make the avatar to be a Squircle
	navbar.LogoAvatar.Mask.Squircle
	navbar.LogoAvatar.HideOnSmall
	'add a title with normal case
	navbar.AddTitle(appTitle)
	'
	btnNotif = navbar.Root.AddButtonIcon("btnNotif", "", "fa-solid fa-bell")
	'set the color to primary
	btnNotif.Color = app.COLOR_SUCCESS
	'set the size to small
	btnNotif.SizeSM.Circle.Root.mx(2)
	btnNotif.HideOnSmall
	
	'add a button to the navbar
	btnCode = navbar.Root.AddButtonIcon("btncode", "", "fas fa-code")
	'set the color to primary
	btnCode.Color = app.COLOR_PRIMARY
	'set the size to small
	btnCode.SizeSM
	'make the button to be roun
	btnCode.Circle
	btnCode.HideOnSmall
	'
	cboTheme = navbar.root.AddSelectNormal("cboTheme", False, CreateMap())
	cboTheme.w = "10rem"
	cboTheme.SizeSM
	cboTheme.Root.mx(2)
	cboTheme.SetThemes
	cboTheme.HideOnSmall
	'
	cboDesign = navbar.Root.AddSelectNormal("cboDesign", False, CreateMap())
	cboDesign.w = "10rem"
	cboDesign.SizeSM
	cboDesign.Root.mx(2)
	cboDesign.Hide
	cboDesign.HideOnSmall
	'
	'add a menu button to the navbar
	navbar.AddMenuButton
	navbar.Menu.HideOnSmall
End Sub

Sub btnNotif_click (e As BANanoEvent)
	app.ShowBrowserNotification("SithasoDaisy", _
	"Thank you so much for activating the Notifications, this will help us keep you informed about SithasoDaisy developments.", _
	"https://www.b4x.com/android/forum/threads/sithasodaisy-tailwindcss-daisyui-toolbox.143549/#content", _
	"./assets/SithasoDaisyLogo.jpg", "./assets/daisyui.jpg", True, 5)
End Sub

Sub btncode_click (e As BANanoEvent)
	'get the elemnt html
	Dim allCode As String = BANano.GetElement($"#pageview"$).GetHTML
	'execute web scraping
	Dim treeItems As List = app.parseHTML(allCode)
	Log(treeItems)
End Sub

'Sub CreateAppBottomNavBar
'	appbottomnavbar = drawer.AddAppBottomNav
'	appbottomnavbar.Bordered = True
'	appbottomnavbar.AddItem("home", "fa-solid fa-house", "Home", app.COLOR_PRIMARY)
'	appbottomnavbar.AddItem("info", "fa-solid fa-hospital", "Hospital", app.COLOR_SUCCESS)
'	appbottomnavbar.AddItem("graph", "fa-solid fa-pen-clip", "Graph", app.COLOR_WARNING)
'	appbottomnavbar.AddItem("like", "fa-solid fa-user-friends", "Friends", app.COLOR_INFO)
'	appbottomnavbar.AddItem("comment", "fa-solid fa-pastafarianism", "Comment", app.COLOR_ERROR)
'	'set badge value
'	appbottomnavbar.SetItemBadgeValue("home", 5)
'	appbottomnavbar.SetItemBadgeColor("home", app.COLOR_PRIMARY)
'End Sub

'Sub CreateAppFooter
'	appfooter = drawer.AddAppFooter
'	'
'	appfooter.Root.P(10)
'	appfooter.Root.BGColorIntensity(app.COLOR_BASE, 200)
'	appfooter.TextColorIntensity(app.COLOR_BASE,"content")
'	
'	Dim t1 As SDUIDiv = appfooter.AddTitle("services", "Services")
'	t1.AddLink("branding", "Branding", "#").Hover
'	t1.AddLink("design", "Design", "#").Hover
'	t1.AddLink("marketing", "Marketing", "#").Hover
'	t1.AddLink("advertising", "Advertising", "#").Hover
'	'	
'	Dim t2 As SDUIDiv = appfooter.AddTitle("company", "Company")
'	t2.AddLink("aboutus", "About Us", "#").Hover
'	t2.AddLink("contactusf", "Contact Us", "#").Hover
'	t2.AddLink("jobs", "Jobs", "#").Hover
'	t2.AddLink("press", "Press Kit", "#").Hover
'		
'	Dim t3 As SDUIDiv = appfooter.AddTitle("legal", "Legal")
'	t3.AddLink("tou", "Terms of Use", "#").Hover
'	t3.AddLink("privacy", "Privacy Policy", "#").Hover
'	t3.AddLink("cookies", "Cookie Policy", "#").Hover
'End Sub

'Private Sub appnavbar_Hamburger_Click (e As BANanoEvent)
'	drawer.Toggle
'End Sub

Sub CreateDrawerMenu
	'clear the menu
	drawer.Clear("")
	'add a page reference
	drawer.AddItemPage(welcome)
	drawer.AddItem("new224", "What's New v2.24")
	drawer.AddItemChildPage("new224", demoTeam)
	drawer.AddItemChildPage("new224", pgLeafLet)
	
	drawer.AddItem("new218", "What's New v2.18")
	drawer.AddItemChildPage("new218", demoAutoComplete)
	'
	drawer.AddItem("new216", "What's New v2.16")
	drawer.AddItemChildPage("new216", pgCalendarTimeSlots)
	drawer.AddItemChildPage("new216", pgBasicMenus)
	drawer.AddItemChildPage("new216", pgSwiper)
	drawer.AddItemChildPage("new216", pgswiper1)
	drawer.AddItemChildPage("new216", pgSwiper2)
	drawer.AddItemChildPage("new216", pgTextColorWheel)
	drawer.AddItemChildPage("new216", pgBasicCards)
	drawer.AddItemChildPage("new216", pgbasiccards2)
	drawer.AddItemChildPage("new216", pgbasiccard3)
	drawer.AddItemChildPage("new216", pgbasiccards4)
	drawer.AddItemChildPage("new216", pgbasiccards5)
	drawer.AddItemChildPage("new216", pgbasiccards6)
	drawer.AddItemChildPage("new216", pgbasiccards7)
	drawer.AddItemChildPage("new216", pgbasiccards8)
	drawer.AddItemChildPage("new216", pgbasiccards9)
	drawer.AddItemChildPage("new216", pgbasiccards10)
	drawer.AddItemChildPage("new216", pgbasiccards11)
	drawer.AddItemChildPage("new216", pgbasiccards12)
	drawer.AddItemChildPage("new216", pgBasicCardsMultiple)
	drawer.AddItemChildPage("new216", pgDropZone)
	drawer.AddItemChildPage("new216", pgZuck)
	drawer.AddItemChildPage("new216", pgMDToast)
	
	
	drawer.AddItem("gridx", "The Grid")
	drawer.AddItemChildPage("gridx", demoADGridX)
	drawer.AddItemChildPage("gridx", demoADGrid01)
	drawer.AddItemChildPage("gridx", demoADGrid02)
	drawer.AddItemChildPage("gridx", demoADGrid03)
	drawer.AddItemChildPage("gridx", demoADGrid04)
	
	'ACTIONS
	drawer.AddItem("dbs", "PB Expense Tracker")
	drawer.AddItemChildPage("dbs", demoPBDashboard)
	drawer.AddItemChildPage("dbs", demoPBExpenseCategories)
	drawer.AddItemChildPage("dbs", demoPBIncomeCategories)
	'	
	drawer.AddItem("actions", "Actions - Code")
	drawer.AddItemChildPage("actions", demoButtons)
	drawer.AddItemChildPage("actions", demoButtonGroup)
	drawer.AddItemChildPage("actions", demoDropDowns)
	drawer.AddItemChildPage("actions", demoSwap)
	'DATA INPUT
	drawer.AddItem("inputs", "Form Controls - Code")
	drawer.AddItemChildPage("inputs", demoCheckBoxes)
	drawer.AddItemChildPage("inputs", demoText)
	drawer.AddItemChildPage("inputs", demoInputGroups)
	drawer.AddItemChildPage("inputs", demoTextArea)
	drawer.AddItemChildPage("inputs", demoRadio)
	drawer.AddItemChildPage("inputs", demoRange)
	drawer.AddItemChildPage("inputs", demoRating)
	drawer.AddItemChildPage("inputs", demoSelect)
	drawer.AddItemChildPage("inputs", demoToggle)
	drawer.AddItemChildPage("inputs", demoFile)
	drawer.AddItemChildPage("inputs", demoRollDate)
	drawer.AddItemChildPage("inputs", demoFlatPick)
	drawer.AddItemChildPage("inputs", demoLogin)
	drawer.AddItemChildPage("inputs", demoRegister)
	drawer.AddItemChildPage("inputs", demoContactUS)
	drawer.AddItemChildPage("inputs", demoModals)
	drawer.AddItemChildPage("inputs", pgModal)
	'
	drawer.AddItem("tables", "Tables - Code")
	drawer.AddItemChildPage("tables", demoTables)
	drawer.AddItemChildPage("tables", tables2)
	drawer.AddItemChildPage("tables", tables3)
	drawer.AddItemChildPage("tables", tables4)
	drawer.AddItemChildPage("tables", tables5)
	drawer.AddItemChildPage("tables", table6)
	drawer.AddItemChildPage("tables", table7)
	drawer.AddItemChildPage("tables", table8)
	drawer.AddItemChildPage("tables", table9)
	drawer.AddItemChildPage("tables", table10)
	drawer.AddItemChildPage("tables", table11)
	'DISPLAY
	drawer.AddItem("display", "Display - Code")
	drawer.AddItemChildPage("display", demoAlert)
	drawer.AddItemChildPage("display", demoAvatar)
	drawer.AddItemChildPage("display", demoBadge)
	drawer.AddItemChildPage("display", demoCard)
	drawer.AddItemChildPage("display", demoCarousel)
	drawer.AddItemChildPage("display", demoChat)
	drawer.AddItemChildPage("display", demoCollapse)
	'drawer.AddItemChildPage("display", demoCountDown)
	drawer.AddItemChildPage("display", demoKeys)
	drawer.AddItemChildPage("display", demoProgress)
	drawer.AddItemChildPage("display", demoRadialProgress)
	drawer.AddItemChildPage("display", demoStats)
	drawer.AddItemChildPage("display", demoTooltip)
	drawer.AddItemChildPage("display", demoOptionsCard)
	drawer.AddItemChildPage("display", demoMasonry)
	'LAYOUT
	drawer.AddItem("layouts", "Layouts - Code")
	drawer.AddItemChildPage("layouts", demoDesignGrid)
	drawer.AddItemChildPage("layouts", demoArtBoard)
	drawer.AddItemChildPage("layouts", demoDivider)
	'these activate other things
	drawer.AddItemChild("layouts", "rightdrawer", "Right Drawer")
	drawer.AddItemChild("layouts", "leftdrawer", "Left Drawer")
	
	drawer.AddItemChildPage("layouts", demoFooter)
	drawer.AddItemChildPage("layouts", demoHero)
	drawer.AddItemChildPage("layouts", demoIndicator)
	drawer.AddItemChildPage("layouts", demoMask)
	drawer.AddItemChildPage("layouts", demoStack)
	drawer.AddItemChildPage("layouts", demoToast)
	
	'NAVIGATION
	drawer.AddItem("navigation", "Navigation - Code")
	drawer.AddItemChildPage("navigation", demoBreadCrumbs)
	drawer.AddItemChildPage("navigation", demoLinks)
	drawer.AddItemChildPage("navigation", demoMenu)
	drawer.AddItemChildPage("navigation", demoNavBar)
	drawer.AddItemChildPage("navigation", demoBottomNav)
	drawer.AddItemChildPage("navigation", demoSteps)
	drawer.AddItemChildPage("navigation", demoTabs)
	drawer.AddItemChildPage("navigation", demoListView)
	drawer.AddItemChildPage("navigation", demoListView1)
	'MOCKUPS
	drawer.AddItem("mockups", "Mock Ups - Code")
	drawer.AddItemChildPage("mockups", demoMockPhone)
	drawer.AddItemChildPage("mockups", demoCode)
	drawer.AddItemChildPage("mockups", demoMockWindow)
	'BLOCKS	
	drawer.AddItem("blocks", "Blocks - Code")
	drawer.AddItemChildPage("blocks", demoBlocks)
	'TYPO
	drawer.AddItem("formatting", "Typography - Code")
	drawer.AddItemChildPage("formatting", demoTypoGraphy)
	drawer.AddItemChildPage("formatting", demoShadows)
	drawer.AddItemChildPage("formatting", demoCustomColors)
	drawer.AddItemChildPage("formatting", demoLists)
	drawer.AddItemChildPage("formatting", demoSelectedTextColor)
	drawer.AddItemChildPage("formatting", demoGradients)
	drawer.AddItemChildPage("formatting", demoGradientButtons)
	drawer.AddItemChildPage("formatting", demoAnime)
	
	'**********
	drawer.AddItem("actions_ad", "Actions - Designer")
	drawer.AddItemChildPage("actions_ad", demoADButtons)
	drawer.AddItemChildPage("actions_ad", demoADButtonGroup)
	drawer.AddItemChildPage("actions_ad", demoADDropDown)
	drawer.AddItemChildPage("actions_ad", demoADModal)
	drawer.AddItemChildPage("actions_ad", demoADSwap)
	'
	drawer.AddItem("inputs_ad", "Form Controls - Designer")
	drawer.AddItemChildPage("inputs_ad", demoADCheckBox)
	drawer.AddItemChildPage("inputs_ad", demoADTextBox)
	drawer.AddItemChildPage("inputs_ad", demoADTextArea)
	drawer.AddItemChildPage("inputs_ad", demoADRadioGroup)
	drawer.AddItemChildPage("inputs_ad", demoADRange)
	drawer.AddItemChildPage("inputs_ad", demoADRating)
	drawer.AddItemChildPage("inputs_ad", demoADSelect)
	drawer.AddItemChildPage("inputs_ad", demoADToggle)
	drawer.AddItemChildPage("inputs_ad", demoADFileInput)
	drawer.AddItemChildPage("inputs_ad", demoADRollDate)
	drawer.AddItemChildPage("inputs_ad", demoADDatePicker)
	'
	drawer.AddItem("tables_ad", "Tables - Designer")
	drawer.AddItemChildPage("tables_ad", demoADTable)
	drawer.AddItemChildPage("tables_ad", demoADTableOnline)
	drawer.AddItemChildPage("tables_ad", demoADTableRings)
	drawer.AddItemChildPage("tables_ad", demoADTableColorRings)
	drawer.AddItemChildPage("tables_ad", demoADTableIconTitle)
	drawer.AddItemChildPage("tables_ad", demoADTableKPI)
	drawer.AddItemChildPage("tables_ad", demoADPropertyTable)
	drawer.AddItemChildPage("tables_ad", pgtablecrud)
	drawer.AddItemChildPage("tables_ad", pgtablerowcolumn)
	'
	drawer.AddItem("display_ad", "Display - Designer")
	drawer.AddItemChildPage("display_ad", demoADAlerts)
	drawer.AddItemChildPage("display_ad", demoADAvatar)
	drawer.AddItemChildPage("display_ad", demoADBadge)
	drawer.AddItemChildPage("display_ad", demoADCard)
	drawer.AddItemChildPage("display_ad", demoADCarousel)
	drawer.AddItemChildPage("display_ad", demoADChat)
	drawer.AddItemChildPage("display_ad", demoADCollapse)
'	drawer.AddItemChildPage("display_ad", demoCountDown)
	drawer.AddItemChildPage("display_ad", demoADKYB)
	drawer.AddItemChildPage("display_ad", demoADProgress)
	drawer.AddItemChildPage("display_ad", demoADRadial)
	drawer.AddItemChildPage("display_ad", demoADStats)
	drawer.AddItemChildPage("display_ad", demoADTooltip)
	drawer.AddItemChildPage("display_ad", demoADOptionsCard)
'	drawer.AddItemChildPage("display_ad", demoMasonry)
	'
	drawer.AddItem("layouts_ad", "Layouts - Designer")
'	drawer.AddItemChildPage("layouts_ad", demoDesignGrid)
	drawer.AddItemChildPage("layouts_ad", demoADArtBoard)
	drawer.AddItemChildPage("layouts_ad", demoADDivider)
	drawer.AddItemChildPage("layouts_ad", demoADFooter)
	drawer.AddItemChildPage("layouts_ad", demoADHero)
	drawer.AddItemChildPage("layouts_ad", demoADIndicators)
	drawer.AddItemChildPage("layouts_ad", demoADMask)
	drawer.AddItemChildPage("layouts_ad", demoADStack)
	drawer.AddItemChildPage("layouts_ad", demoADToast)
	'
	drawer.AddItem("navigation_ad", "Navigation - Designer")
	drawer.AddItemChildPage("navigation_ad", demoADBreadCrumbs)
	drawer.AddItemChildPage("navigation_ad", demoADLink)
	drawer.AddItemChildPage("navigation_ad", demoADMenu)
	drawer.AddItemChildPage("navigation_ad", demoADNavBar)
	drawer.AddItemChildPage("navigation_ad", demoADBottomNav)
	drawer.AddItemChildPage("navigation_ad", demoADSteps)
	drawer.AddItemChildPage("navigation_ad", demoADTabs)
	drawer.AddItemChildPage("navigation_ad", demoADListView)
	
	drawer.AddItem("mockups_ad", "Mock Ups - Designer")
	drawer.AddItemChildPage("mockups_ad", demoADMockPhone)
	drawer.AddItemChildPage("mockups_ad", demoADMockCode)
	drawer.AddItemChildPage("mockups_ad", demoADMockWindow)
	'
	'
	drawer.AddItem("adesign", "Abstract Designer")
	drawer.AddItemChildPage("adesign", demoAbstractDesigner)
	drawer.AddItemChildPage("adesign", demoBaseComponent)
	
	drawer.AddItem("plugins", "Plug-Ins")
	'drawer.AddItemChildPage("plugins", pgSwiper)
	'drawer.AddItemChildPage("plugins", pgswiper1)
	'drawer.AddItemChildPage("plugins", pgSwiper2)
	drawer.AddItemChildPage("plugins", demoSwal)
	drawer.AddItemChildPage("plugins", demoADFullCalendar)
	drawer.AddItemChildPage("plugins", demoFCTitle)
	drawer.AddItemChildPage("plugins", demoFC)
	'drawer.AddItemChildPage("plugins", pgTextColorWheel)
	
	drawer.AddItemChildPage("plugins", demoCompressStrings)
	drawer.AddItemChildPage("plugins", demoADLottiePlayer)
	drawer.AddItemChildPage("plugins", demoADTreeView)
	drawer.AddItemChildPage("plugins", demoADEditor)
	drawer.AddItemChildPage("plugins", demoADJustGage)
	drawer.AddItemChildPage("plugins", demoADFluidMeter)
	drawer.AddItemChildPage("plugins", demoADTChart)
	'drawer.AddItemChildPage("plugins", demoADKML)
	drawer.AddItemChildPage("plugins", demoADFrappeGantt)
	drawer.AddItemChildPage("plugins", demoGMap)
	drawer.AddItemChildPage("plugins", adDevice)
	'
	drawer.AddItemChildPage("plugins", demoAdCameyo)
	drawer.AddItemChildPage("plugins", demoWebCam)
	drawer.AddItemChildPage("plugins", demoADCam)
	
	'
	drawer.AddItemChildPage("plugins", demoEvo)
	drawer.AddItemChildPage("plugins", demoADKanban)
	'
	drawer.AddItemChildPage("plugins", demoQRCode)
	drawer.AddItemChildPage("plugins", demoADQRCode)
	
	drawer.AddItemChildPage("plugins", demoBarCodeScanner)
	drawer.AddItemChildPage("plugins", demoADBarCodeScanner)
	'
	drawer.AddItemChildPage("plugins", demoSign)
	drawer.AddItemChildPage("plugins", demoADSig)
	'
	drawer.AddItemChildPage("plugins", demoVideo)
	drawer.AddItemChildPage("plugins", demoADVideo)
	
	drawer.AddItemChildPage("plugins", demoTimeLines)
	drawer.AddItemChildPage("plugins", demoADAES)
	'
	drawer.AddItem("api", "API")
	BANano.Await(AddAPI)
	'
	'PAGES
	drawer.AddItem("pages", "Pages - Code")
	drawer.AddItemChildPage("pages", demoCalculator)
	drawer.AddItemChildPage("pages", demoFetch)
	drawer.AddItemChildPage("pages", demoGridY)
	drawer.AddItemChildPage("pages", demoMultiCard)
	drawer.AddItemChildPage("pages", demoADClients)
	drawer.AddItemChildPage("pages", demoCallMeBot)
	'
	drawer.AddItem("tw", "Needful Things")
	drawer.AddItemChildLinkIcon("tw", "link-twa", "Tailwind Awesome", "https://www.tailwindawesome.com", "_blank", "fa-solid fa-swatchbook")
	drawer.AddItemChildLink("tw", "link-pb", "PocketBase", "https://pocketbase.io/", "_blank")
	drawer.AddItemChildLink("tw", "link-pbh", "PocketBase Host", "https://pockethost.io/", "_blank")
	drawer.AddItemChildLink("tw", "link-pouchdb", "PouchDb", "https://pouchdb.com", "_blank")
	drawer.AddItemChildLink("tw", "link-sb", "SupaBase", "https://supabase.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twc", "Tailwind Components", "https://tailwindcomponents.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twfb", "FlowBite", "https://flowbite.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twui", "TailwindUI", "https://tailwindui.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twwui", "WindUI", "https://wind-ui.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twmui", "MambaUI", "https://mambaui.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twmerui", "MerakiUI", "https://merakiui.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-pwafire", "PWA Fire", "https://pwafire.org/", "_blank")
	drawer.AddItemChildLink("tw", "link-pwaag", "PWA Asset Generator", "https://github.com/elegantapp/pwa-asset-generator", "_blank")
	drawer.AddItemChildLink("tw", "link-codeh", "CodeHim", "https://www.codehim.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-onair", "OnAirCode", "https://onaircode.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twcss", "TailwindCSS", "https://tailwindcss.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twtlb", "Tailwind ToolBox", "https://www.tailwindtoolbox.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-twelee", "Tailwind Elements", "https://tailwind-elements.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-hypeui", "Hyper UI", "https://www.hyperui.dev/", "_blank")
	drawer.AddItemChildLink("tw", "link-preline", "Preline", "https://preline.co/index.html", "_blank")
	drawer.AddItemChildLink("tw", "link-mattail", "Material TailWind", "https://www.material-tailwind.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-kitwind", "KitWind", "https://kitwind.io/", "_blank")
	drawer.AddItemChildLink("tw", "link-fancy", "FancyTailWind", "https://fancytailwind.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-tgrids", "TailGrids", "https://tailgrids.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-bot", "BestOfTailWind", "https://bestoftailwind.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-bashooka", "Bashooka", "https://bashooka.com/", "_blank")
	drawer.AddItemChildLink("tw", "link-essbooks", "Essential Books", "https://www.programming-books.io", "_blank")
	drawer.AddItemChildLink("tw", "link-pnotes", "Programming Notes", "https://books.goalkicker.com/", "_blank")
		
	
'	'***** BUILD APILIST
'	Dim sbLine As StringBuilder
'	sbLine.Initialize
'	 
'	'get all files with json
'	Dim php As SDUIPhp
'	php.Initialize("", False)
'	Dim jsonFiles As List = php.DirectoryListRecursiveWait("./assets")
'	jsonFiles.Sort(True)
'	Dim jfiles As List
'	jfiles.Initialize
'	For Each f As String In jsonFiles
'		If f.ToLowerCase.EndsWith(".json") Then
'			Dim fn As String = SDUIShared.MvField(f,-1,"/")
'			fn = SDUIShared.mvfield(fn, 1, ".")
'			If fn.StartsWith("SDU") Then
'				sbLine.Append($"drawer.AddItemChild("api", "api-${fn}", "${fn}")"$).Append(CRLF)
'			End If
'		End If
'	Next
'	Log(sbLine.ToString)
'	app.Download(sbLine.ToString, "api.txt")
	'**** END BUILD
	
	'tools
	drawer.AddItem("tools", "My Tools")
	'drawer.AddItemChildPage("tools", pgProperties)
	drawer.AddItemChildPage("tools", demoCodeBuilder)
	'drawer.AddItemChildPage("tools", demoClassBuilder)
	'drawer.AddItemChildPage("tools", attributePage)
	drawer.AddItemChildPage("tools", sithasoDocumentor)
End Sub

Sub AddAPI
	drawer.AddItemChild("api", "api-SDUIAlert", "SDUIAlert")
	drawer.AddItemChild("api", "api-SDUIArtboard", "SDUIArtboard")
	drawer.AddItemChild("api", "api-SDUIAvatar", "SDUIAvatar")
	drawer.AddItemChild("api", "api-SDUIBadge", "SDUIBadge")
	drawer.AddItemChild("api", "api-SDUIBarCodeReader", "SDUIBarCodeReader")
	drawer.AddItemChild("api", "api-SDUIBasicCard", "SDUIBasicCard")
	drawer.AddItemChild("api", "api-SDUIBottomNav", "SDUIBottomNav")
	drawer.AddItemChild("api", "api-SDUIBreadCrumbs", "SDUIBreadCrumbs")
	drawer.AddItemChild("api", "api-SDUIButton", "SDUIButton")
	drawer.AddItemChild("api", "api-SDUIButtonGroup", "SDUIButtonGroup")
	drawer.AddItemChild("api", "api-SDUICamera", "SDUICamera")
	drawer.AddItemChild("api", "api-SDUICard", "SDUICard")
	drawer.AddItemChild("api", "api-SDUICardActions", "SDUICardActions")
	drawer.AddItemChild("api", "api-SDUICardBody", "SDUICardBody")
	drawer.AddItemChild("api", "api-SDUICardTitle", "SDUICardTitle")
	drawer.AddItemChild("api", "api-SDUICarousel", "SDUICarousel")
	drawer.AddItemChild("api", "api-SDUIChartKick", "SDUIChartKick")
	drawer.AddItemChild("api", "api-SDUIChat", "SDUIChat")
	drawer.AddItemChild("api", "api-SDUICheckbox", "SDUICheckbox")
	drawer.AddItemChild("api", "api-SDUICol", "SDUICol")
	drawer.AddItemChild("api", "api-SDUICollapsePanels", "SDUICollapsePanels")
	drawer.AddItemChild("api", "api-SDUIDataSource", "SDUIDataSource")
	drawer.AddItemChild("api", "api-SDUIDevice", "SDUIDevice")
	drawer.AddItemChild("api", "api-SDUIDiv", "SDUIDiv")
	drawer.AddItemChild("api", "api-SDUIDivider", "SDUIDivider")
	drawer.AddItemChild("api", "api-SDUIDrawer", "SDUIDrawer")
	drawer.AddItemChild("api", "api-SDUIDropDown", "SDUIDropDown")
	drawer.AddItemChild("api", "api-SDUIDropZone", "SDUIDropZone")
	drawer.AddItemChild("api", "api-SDUIEditor", "SDUIEditor")
	drawer.AddItemChild("api", "api-SDUIEmailJS", "SDUIEmailJS")
	drawer.AddItemChild("api", "api-SDUIEvoCalendar", "SDUIEvoCalendar")
	drawer.AddItemChild("api", "api-SDUIFileInput", "SDUIFileInput")
	drawer.AddItemChild("api", "api-SDUIFlex", "SDUIFlex")
	drawer.AddItemChild("api", "api-SDUIFlipPage", "SDUIFlipPage")
	drawer.AddItemChild("api", "api-SDUIFluidMeter", "SDUIFluidMeter")
	drawer.AddItemChild("api", "api-SDUIFooter", "SDUIFooter")
	drawer.AddItemChild("api", "api-SDUIFrappeGantt", "SDUIFrappeGantt")
	drawer.AddItemChild("api", "api-SDUIFullCalendar", "SDUIFullCalendar")
	drawer.AddItemChild("api", "api-SDUIGMap", "SDUIGMap")
	drawer.AddItemChild("api", "api-SDUIGrid", "SDUIGrid")
	drawer.AddItemChild("api", "api-SDUIGridNav", "SDUIGridNav")
	drawer.AddItemChild("api", "api-SDUIHero", "SDUIHero")
	drawer.AddItemChild("api", "api-SDUIImage", "SDUIImage")
	drawer.AddItemChild("api", "api-SDUIIndicator", "SDUIIndicator")
	drawer.AddItemChild("api", "api-SDUIJustGage", "SDUIJustGage")
	drawer.AddItemChild("api", "api-SDUIKanban", "SDUIKanban")
	drawer.AddItemChild("api", "api-SDUIKbd", "SDUIKbd")
	drawer.AddItemChild("api", "api-SDUILabel", "SDUILabel")
	drawer.AddItemChild("api", "api-SDUILink", "SDUILink")
	drawer.AddItemChild("api", "api-SDUIList", "SDUIList")
	drawer.AddItemChild("api", "api-SDUIListView", "SDUIListView")
	drawer.AddItemChild("api", "api-SDUILottiePlayer", "SDUILottiePlayer")
	drawer.AddItemChild("api", "api-SDUIMDToast", "SDUIMDToast")
	drawer.AddItemChild("api", "api-SDUIMenu", "SDUIMenu")
	drawer.AddItemChild("api", "api-SDUIMenuItem", "SDUIMenuItem")
	drawer.AddItemChild("api", "api-SDUIMenuTitle", "SDUIMenuTitle")
	drawer.AddItemChild("api", "api-SDUIMockupCode", "SDUIMockupCode")
	drawer.AddItemChild("api", "api-SDUIMockupPhone", "SDUIMockupPhone")
	drawer.AddItemChild("api", "api-SDUIMockupWindow", "SDUIMockupWindow")
	drawer.AddItemChild("api", "api-SDUIModal", "SDUIModal")
	drawer.AddItemChild("api", "api-SDUINavBar", "SDUINavBar")
	drawer.AddItemChild("api", "api-SDUIOptionsCard", "SDUIOptionsCard")
	drawer.AddItemChild("api", "api-SDUIPage", "SDUIPage")
	drawer.AddItemChild("api", "api-SDUIProgress", "SDUIProgress")
	drawer.AddItemChild("api", "api-SDUIQRCode", "SDUIQRCode")
	drawer.AddItemChild("api", "api-SDUIRadialProgress", "SDUIRadialProgress")
	drawer.AddItemChild("api", "api-SDUIRadioGroup", "SDUIRadioGroup")
	drawer.AddItemChild("api", "api-SDUIRange", "SDUIRange")
	drawer.AddItemChild("api", "api-SDUIRating", "SDUIRating")
	drawer.AddItemChild("api", "api-SDUIRow", "SDUIRow")
	drawer.AddItemChild("api", "api-SDUISelect", "SDUISelect")
	drawer.AddItemChild("api", "api-SDUISignaturePad", "SDUISignaturePad")
	drawer.AddItemChild("api", "api-SDUIStats", "SDUIStats")
	drawer.AddItemChild("api", "api-SDUISteps", "SDUISteps")
	drawer.AddItemChild("api", "api-SDUIStories", "SDUIStories")
	drawer.AddItemChild("api", "api-SDUISwap", "SDUISwap")
	drawer.AddItemChild("api", "api-SDUISwiper", "SDUISwiper")
	drawer.AddItemChild("api", "api-SDUITable", "SDUITable")
	drawer.AddItemChild("api", "api-SDUITabs", "SDUITabs")
	drawer.AddItemChild("api", "api-SDUITextArea", "SDUITextArea")
	drawer.AddItemChild("api", "api-SDUITextBox", "SDUITextBox")
	drawer.AddItemChild("api", "api-SDUITimeLine", "SDUITimeLine")
	drawer.AddItemChild("api", "api-SDUIToast", "SDUIToast")
	drawer.AddItemChild("api", "api-SDUIToastChart", "SDUIToastChart")
	drawer.AddItemChild("api", "api-SDUIToggle", "SDUIToggle")
	drawer.AddItemChild("api", "api-SDUITooltip", "SDUITooltip")
	drawer.AddItemChild("api", "api-SDUITreeView", "SDUITreeView")
	drawer.AddItemChild("api", "api-SDUIVideo", "SDUIVideo")
	drawer.AddItemChild("api", "api-SDUIWebcam", "SDUIWebcam")

End Sub


Private Sub appdrawer_menu_Click (item As String)
	'hide the drawer
	drawer.Close
	'remove the demo bottom navigation
	SDUIShared.Remove("bn1")
	'we have navigated to a page, exit
	If app.ShowPage(item) Then Return
	'
	If item.StartsWith("api-") Then
		sithasoAPI.compname = item
		sithasoAPI.Show(app)
		Return
	End If
	
	If item.StartsWith("link-") Then
		drawer.ItemLink(item).NavigateTo
		Return
	End If
	
	'we have code that does not open a page
	Select Case item
	Case "rightdrawer"
		drwRight.show
	Case "leftdrawer"
		drwLeft.show
	End Select
End Sub

Private Sub cboDesign_Change (item As String)
	If item = "" Then Return
	Dim compType As String = SDUIShared.MvField(item, 1, ".")
	Dim compName As String = SDUIShared.MvField(item, 2, ".")
	Dim m As Map = GetSettings(item)
	'
	Dim doc As SDUIDocxTemplator
	doc.Initialize(Me, "docx", "./assets/compapi.docx", $"${compName}.docx"$)
	doc.DocumentComponent(m, compType, compName)
	BANano.Await(doc.BuildWait)
	
End Sub

Private Sub cboTheme_Change (item As String)
	If item = "" Then Return
	app.Theme = item
	BANano.SetLocalStorage2(themeName, item)
End Sub

Sub ClearDesign
	cboDesign.Clear
End Sub

Sub HideDesign
	cboDesign.Hide
End Sub

Sub ShowDesign
	cboDesign.Show
End Sub

Sub AddDesignKV(k As String, v As String)
	cboDesign.AddItem(k, v)
End Sub

Sub AddDesignKV1(k As String, v As String, m As Map)
	cboDesign.AddItem(k, v)
	Dim sout As String = BANano.ToJson(m)
	BANano.SetSessionStorage2(k, sout)
End Sub

Sub SaveSettings(k As String, m As Map)
	Dim sout As String = BANano.ToJson(m)
	BANano.SetSessionStorage2(k, sout)
End Sub

Sub GetSettings(k As String) As Map
	Dim sout As String = BANano.GetSessionStorage2(k)
	Dim m As Map = BANano.fromjson(sout)
	Return m
End Sub

Private Sub appnavbar_Menu_Click (e As BANanoEvent)
	app.ShowSwal("Menu...")
End Sub