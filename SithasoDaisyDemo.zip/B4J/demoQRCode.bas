﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "qrcodepage"
	Public title As String = "QRCode - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtCode As SDUITextBox
	Private btnCode As SDUIButton
	Private qrcode1 As SDUIQRCode
	Private btnDownload As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesQRCode)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows3.AddColumns2x6
	page.Root.AddRows1.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	txtCode = page.Cell(1, 1).AddTextBoxLabel("txtcode", "Text For QR Code", "")
	txtCode.Value = "https://sithaso-daisy-ui.vercel.app/"
	btnCode = page.Cell(2, 1).AddButton("btnCode1", "Generate QR Code")
	btnDownload = page.Cell(2, 2).AddButton("btnDownload", "Download QR Code")
	
	qrcode1.AddQRCode(Me, page.Cell(3, 1).Name, "qrcode1")
	qrcode1.Size = 300
	qrcode1.Text = txtCode.value
	qrcode1.Refresh
	'
	Dim c1 As SDUIMockupCode = page.Cell(4,1).AddMockUpCode("c1", "vb")
	c1.AddCode($"txtCode = page.Cell(1, 1).AddTextBoxLabel("txtcode", "Text For QR Code", "")"$)
	c1.AddCode($"txtCode.Value = "https://sithaso-daisy-ui.vercel.app/""$)
	c1.AddCode($"btnCode = page.Cell(2, 1).AddButton("btnCode1", "Generate QR Code")	"$)
	c1.AddCode($"btnDownload = page.Cell(2, 2).AddButton("btnDownload", "Download QR Code")"$)
	
	c1.AddCode($"qrcode1.AddQRCode(Me, page.Cell(3, 1).Name, "qrcode1")"$)
	c1.AddCode($"qrcode1.Size = 300"$)
	c1.AddCode($"qrcode1.Text = txtCode.value"$)
	c1.AddCode($"qrcode1.Refresh"$)	
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnCode1_click (e As BANanoEvent)"$)
	c1.AddCode($"qrcode1.Text = txtCode.value"$)
	c1.AddCode($"qrcode1.Refresh"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub qrcode1_CodeSuccess (dataURL As String)"$)
	c1.AddCode($"Log(dataURL)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnDownload_click (e As BANanoEvent)"$)
	c1.AddCode($"qrcode1.Download("qrcode1.png")"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Sub btnDownload_click (e As BANanoEvent)
	qrcode1.Download("qrcode1.png")
End Sub

Sub btnCode1_click (e As BANanoEvent)
	qrcode1.Text = txtCode.value
	qrcode1.Refresh
End Sub

Sub qrcode1_CodeSuccess (dataURL As String)
	Log(dataURL)
End Sub
