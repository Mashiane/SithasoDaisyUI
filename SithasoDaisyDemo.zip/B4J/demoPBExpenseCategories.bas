﻿B4J=true
Group=Default Group\PocketBase
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "pbexpensecategories"
	Public title As String = "Expense Categories"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private pageNav As SDUIDiv
	Private tblCategories As SDUITable
	Private mdl As SDUIModal
	Private mdlConfirm As SDUIModal
	Private txtID As SDUITextBox
	Private txtName As SDUITextBox
	Private txtColor As SDUITextBox
	Private imgCat As SDUIImage
	Private imgFile As SDUIFileInput
	Private chkActive As SDUICheckbox
	Private pbCategories As SDUIPocketBase
	Private ServerLocation As String = "http://127.0.0.1:8090"
	'Private ServerLocation As String = "https://sithasodaisyui.pockethost.io"
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	''banano.Await(app.UsesTable)
	banano.Await(app.UsesPocketBase)
	'build the page, via code or loadlayouts
	BuildPage
	'mount the records from the database
	'initialize the connection to PocketBase
	pbCategories.Initialize(Me, "categories", ServerLocation, "expense_categories")
	'define the fiels of the collection
	pbCategories.SchemaAddBoolean1("active")
	pbCategories.SchemaAddText(Array("id", "name", "color", "image"))
	'define the display value
	pbCategories.DisplayField = "name"
	pbCategories.Singular = "Expense Category"
	pbCategories.Plural = "Expense Categories"
	'subscribe to changes (optional)
	'pbCategories.Subscribe
	'load records from the db
	banano.Await(mounted)
	app.PageResume
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	AddModal
	'add the confirm modal
	mdlConfirm = page.Root.AddModal( "mdlconfirm", "Confirm", "Yes", "No", "", "1500px")
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'add page toolbar
	pageNav = page.Cell(1, 1).AddDiv("pageNav")
	'
	tblCategories = page.Cell(1, 1).AddTableCard("tbcat")
	tblCategories.Title = "Expense Categories"
	tblCategories.Search = True
	tblCategories.SearchSize = app.SIZE_SM
	tblCategories.ItemsPerPage = 5
	tblCategories.ToolbarActions = True
	tblCategories.ButtonsOutlined = False
	tblCategories.ButtonSize = app.SIZE_SM
	tblCategories.BadgesSize = app.SIZE_MD
	tblCategories.BadgesOutlined = False
	tblCategories.HasAddNew = True
	tblCategories.HasRefresh = True
	tblCategories.Pagination = True
	tblCategories.Compact
	tblCategories.NormalCase = True
	'
	'tblCategories.AddColumn("id", "Category ID")
	'tblCategories.AddColumn("name", "Category Name")
	tblCategories.AddColumnBadge("name", "Category", "item.color")
	'tblCategories.AddColumnColor("color", "Category", "name")
	tblCategories.AddColumnImage("image", "Image", "4rem", "4rem", app.MASK_SQUIRCLE)
	tblCategories.AddColumnToggle("active", "Active", app.COLOR_ACCENT, False)
	'ad as last columns
	tblCategories.AddColumnEdit(app.COLOR_PRIMARY)
	tblCategories.AddColumnDelete(app.COLOR_SECONDARY)
End Sub


'Sub tbcat_nextpage (e As BANanoEvent)
'	tblCategories.ShowNextPage
'End Sub
'
'Sub tbcat_prevpage (e As BANanoEvent)
'	tblCategories.ShowPreviousPage
'End Sub


Sub AddModal
	mdl = page.Root.AddModal( "mdl", "Categories", "Yes", "No", "", "500px")
	'build the grid for the modal
	'*IMPORTANT
	'add 2 columns spanning 12 spaces
	mdl.Form.AddRows3.AddColumns12
	mdl.Form.AddRows1.AddColumns2x6
	mdl.Form.AddRows1.AddColumns12
	mdl.Form.BuildGrid
	mdl.Form.Shrink
	
	'add the components
	txtID = mdl.Cell(1, 1).AddTextBoxLabel("txtid", "Category ID", "")
	txtID.Required = True
	txtID.Hide
	'
	txtName = mdl.Cell(2, 1).AddTextBoxLabel("txtname", "Category Name", "")
	txtName.Required = True
	txtName.AutoFocus = True
	'
	txtColor = mdl.Cell(3, 1).AddTextBoxGroup("txtcolor", "Hex Color", "", "", "")
	txtColor.Required = True
	txtColor.AppendIcon = "fa-solid fa-palette"
	'
	mdl.Cell(4, 1).CenterChildren
	imgCat = mdl.Cell(4, 1).AddImage("imgcat", "./assets/placeholderimg.jpg", "", 20 , 20)
	imgCat.Mask.Squircle	
	
	imgFile = mdl.Cell(4, 2).AddFileInputCamera("imgfile", "5rem", "primary")
		
	chkActive = mdl.Cell(5,1).AddCheckBoxLabel("chkActive", "Active", "left")
	chkActive.Color = app.COLOR_ACCENT
End Sub

Private Sub imgfile_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = imgFile.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'read the file details as JSON
	Dim fText As String = banano.Await(SDUIShared.GetFileAsDataURL(fileObj))
	imgCat.Src = fText
	imgCat.Tag = fText
End Sub

Private Sub txtcolor_Blur (event As BANanoEvent)
	txtColor.AppendIconBGColor = txtColor.value
	txtColor.AppendIconHoverBGColor = txtColor.value
End Sub


Private Sub txtcolor_Append_Click (event As BANanoEvent)
	txtColor.Value = SDUIShared.RandomHexColor
	txtColor.AppendIconBGColor = txtColor.value
	txtColor.AppendIconHoverBGColor = txtColor.value
End Sub

Private Sub mdlconfirm_Yes_Click (e As BANanoEvent)
	'execute the delete of the record
	Dim sprocess As String = mdlConfirm.Process
	Select Case sprocess
	Case "delete"
		mdlConfirm.YesLoading = True
		'get the key of the record
		Dim rKey As String = pbCategories.GetString("id")
		Dim res As Boolean = banano.Await(pbCategories.DELETE(rKey))
		mdlConfirm.YesLoading = False
		mdlConfirm.Hide
		If res Then
			banano.Await(mounted)
		Else
			app.ShowSwalError("The record could not be delete, try again later!")
		End If	
	End Select
End Sub

Private Sub mdlconfirm_No_Click (e As BANanoEvent)
	'cancel delete
	mdlConfirm.hide
End Sub

Private Sub tbcat_Change (Value As Object, Column As String, item As Map)
	'process the old record
	pbCategories.AssignRealRecord(item)
	'update the new changes
	pbCategories.SetField(Column, Value)
	'execute an update
	banano.Await(pbCategories.CREATE_OR_UPDATE)
	're-mount the records
	banano.Await(mounted)
End Sub

Private Sub tbcat_Edit (item As Map)
	'edit a record on the table
	'exclude the extra content from the database
	pbCategories.AssignRealRecord(item)
	'read the record from the db and display what is ther
	Dim sid As String = pbCategories.GetString("id")
	banano.Await(pbCategories.READ(sid))
	
	'change the title of the modal
	mdl.Title.Caption = "Edit " & pbCategories.singular
	'set the mode to C-reate
	mdl.Updating
	'change the caption of the Yes button
	mdl.YesCaption = "Update"
	'change the caption of the No button
	mdl.NoCaption = "Cancel"
	'generate the next id from pocketbase
	txtID.Value = pbCategories.GetString("id")
	'clea the contents
	txtName.Value = pbCategories.GetString("name")
	chkActive.Checked = pbCategories.GetBoolean("active")
	txtColor.Value = pbCategories.GetString("color")
	txtColor.AppendIconBGColor = txtColor.value
	txtColor.AppendIconHoverBGColor = txtColor.value
	'uses a default image if none is available
	imgCat.Src = pbCategories.GetImage("image")
	'assign src to tag for saving
	imgCat.Tag = imgCat.Src
	'show the modal
	mdl.Show
End Sub

Private Sub tbcat_Delete (item As Map)
	'delete a record in the table
	pbCategories.AssignRealRecord(item)
	Dim sMsg As String = $"<h2 class="text-2xl font-bold m-2">${pbCategories.DisplayValue}</h2><br>Are you sure that you want to delete this ${pbCategories.Singular.ToLowerCase}?"$
	mdlConfirm.Confirm("delete", "Confirm Delete", sMsg, "Yes", "No")
End Sub

Private Sub tbcat_Add (e As BANanoEvent)
	'change the title of the modal
	mdl.Title.Caption = "Add " & pbCategories.Singular
	'set the mode to C-reate
	mdl.Creating
	'change the caption of the Yes button
	mdl.YesCaption = "Save"
	'change the caption of the No button
	mdl.NoCaption = "Cancel"
	'generate the next id from pocketbase
	txtID.Value = pbCategories.nextid
	'clea the contents
	txtName.Value = ""
	txtColor.Value = SDUIShared.RandomHexColor
	txtColor.AppendIconBGColor = txtColor.value
	txtColor.AppendIconHoverBGColor = txtColor.value
	imgCat.Src = app.PlaceholderImage
	chkActive.Checked = True
	'show the modal
	mdl.Show
End Sub

Private Sub tbcat_Refresh (e As BANanoEvent)
	banano.Await(mounted)
End Sub

'modal events
Private Sub mdl_Yes_Click (e As BANanoEvent)
	'reset the validations
    mdl.ResetValidation
    'validate each of the entries
    mdl.Validate(txtID.IsBlank)
    mdl.Validate(txtName.IsBlank)
	mdl.Validate(txtColor.IsBlank)
    'check the form status, if not valid, show warnings and exit
    If mdl.IsValid = False Then Return
	'
	mdl.YesLoading = True
	'
	'prepare for a new record on PocketBase
	pbCategories.PrepareRecord
	pbCategories.SetField("id", txtID.Value)
	pbCategories.SetField("name", txtName.Value)
	pbCategories.SetField("active", chkActive.checked)
	pbCategories.SetField("color", txtColor.Value)
	pbCategories.SetField("image", imgCat.tag)
	'
	Dim nid As String = banano.Await(pbCategories.CREATE_OR_UPDATE)
	mdl.YesLoading = False
	'hide the dialog
	mdl.hide
	'reload the records
	banano.Await(mounted)
End Sub

'cancel the addition
Private Sub mdl_No_Click (e As BANanoEvent)
	mdl.Hide
End Sub

'load all the records from the database
Sub mounted
	tblCategories.AddDisabled = True
	tblCategories.RefreshLoading = True
	'select all records
	banano.Await(pbCategories.SELECT_ALL)
	'set the records to table
	tblCategories.SetItemsPaginate(pbCategories.result)
	tblCategories.AddDisabled = False
	tblCategories.RefreshLoading = False
End Sub

Private Sub categories_Changes (e As Map)
	Log("categories_Changes...")
	Log(e)
End Sub