﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "gridapage"
	Public title As String = "Grid Explorations"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'add a theme
	app.AddTheme("video", Array("px-12", "py-14", "bg-gray-200", "text-center", "shadow-md", "h-36", "w-36"))
	
	'clear the page, remove root container
	page.Root.Clear
	page.Root.contentCenter
	page.Root.MinHScreen
	page.Root.justifyCenter
	page.Root.Grid
	page.Root.Gap(6)
	page.Root.BGColorIntensity(app.COLOR_GRAY, 100)
	'each row must have 3 columns
	'page.Root.GridCols = 3
	page.Root.GridColsResponsive("1", "", "", "3", "", "")
	
	'add 6 divs
	Dim b1 As SDUIDiv = page.Root.AddDiv("b1")
	'set text
	b1.Caption = "Video 1"
	b1.FontBold
	b1.TextSize(app.size_2xl)
	b1.ApplyTheme(app, "video")
	
	Dim b2 As SDUIDiv = page.Root.AddDiv("b2")
	b2.Caption = "Video 2"
	b2.ApplyTheme(app, "video")
	
	Dim b3 As SDUIDiv = page.Root.AddDiv("b3")
	b3.Caption = "Video 3"
	b3.ApplyTheme(app, "video")
	
	Dim b4 As SDUIDiv = page.Root.AddDiv("b4")
	b4.Caption = "Video 4"
	b4.ApplyTheme(app, "video")
	
	'
	Dim b5 As SDUIDiv = page.Root.AddDiv("b5")
	b5.Caption = "Video 5"
	b5.ApplyTheme(app, "video")
	
	Dim b6 As SDUIDiv = page.Root.AddDiv("b6")
	b6.Caption = "Video 6"
	b6.ApplyTheme(app, "video")
	
End Sub
