﻿B4J=true
Group=Default Group\PocketBase
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "etdashboard"
	Public title As String = "ET Dashboard"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private frmTrans As SDUICard
	Private cboTranType As SDUISelect
	Private cboCategory As SDUISelect
	Private txtAmount As SDUITextBox
	Private txtDate As SDUITextBox
	Private btnCreate As SDUIButton
	Private pbExpenseCategories As SDUIPocketBase
	Private pbIncomeCategories As SDUIPocketBase
	Private pbIncomeExpenses As SDUIPocketBase
	Private mExpenseCategories As Map
	Private mIncomeCategories As Map
	Private txttranid As SDUITextBox
	Private incomeChart As SDUIChartKick			'ignore
	Private expenseChart As SDUIChartKick			'ignore
	Private stats As SDUIStats
	Private lExpenseCategories As List
	Private lIncomeCategories As List
	Private mExpenseColors As Map
	Private mIncomeColors As Map
	Private ServerLocation As String = "http://127.0.0.1:8090"
	'Private ServerLocation As String = "https://sithasodaisyui.pockethost.io"
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.m(0)
	page.Root.p(0)
	page.backGroundImage("./assets/money.png")
	page.FullPage = True
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesChartKick)
	banano.Await(app.UsesPocketBase)
	banano.Await(app.UsesRollDate)
	'build the page, via code or loadlayouts
	BuildPage
	'
	pbExpenseCategories.Initialize(Me, "expense_categories", ServerLocation, "expense_categories")
	pbExpenseCategories.SchemaAddText(Array("id", "name"))
	
	pbIncomeCategories.Initialize(Me, "income_categories", ServerLocation, "income_categories")
	pbIncomeCategories.SchemaAddText(Array("id", "name"))
	'
	pbIncomeExpenses.Initialize(Me, "income_expenses", ServerLocation, "income_expenses")
	pbIncomeExpenses.SchemaAddText(Array("id", "trantype", "trancategoryid", "tranamount", "trandate"))
	
	banano.Await(mounted)
	app.PageResume
End Sub

Sub mounted
	'get a list of all expense cats
	lExpenseCategories = banano.Await(pbExpenseCategories.SELECT_ALL)
	'convert to a map of id and name
	mExpenseCategories = SDUIShared.GetKeyValues(True, lExpenseCategories, "id", "name")
	'convert to a map of id and color
	mExpenseColors = SDUIShared.GetKeyValues(True, lExpenseCategories, "id", "color")
	
	'get a list of all income cats
	lIncomeCategories = banano.Await(pbIncomeCategories.SELECT_ALL)
	'convert to id, name 
	mIncomeCategories = SDUIShared.GetKeyValues(True, lIncomeCategories,  "id", "name")
	'convert to id, color
	mIncomeColors = SDUIShared.GetKeyValues(True, lIncomeCategories, "id", "color")
	'
	'clear transaction entry
	ClearTransaction
	RefreshCharts
End Sub

Sub RefreshCharts
	Dim tExpense As Int = 0
	Dim tIncome As Int = 0
	Dim tBalance As Int = 0
	Dim incomes As Map = CreateMap()
	Dim expenses As Map = CreateMap()
	Dim icolors As Map = CreateMap()
	Dim ecolors As Map = CreateMap()
	stats.SetItemValue("income", $"R 0.00"$)
	stats.SetItemValue("expenses", $"R 0.00"$)
	stats.SetItemValue("balance", $"R 0.00"$)
	'
	incomeChart.Clear
	incomeChart.Refresh
	expenseChart.Clear
	expenseChart.Refresh
	'select all transactions
	banano.Await(pbIncomeExpenses.SELECT_ALL)
	For Each tran As Map In pbIncomeExpenses.result
		
		Dim stranamount As String = tran.GetDefault("tranamount", 0)
		Dim trancategoryid As String = tran.GetDefault("trancategoryid", "")
		Dim strantype As String = tran.GetDefault("trantype", "")
		Dim damount As Double = SDUIShared.CDbl(stranamount)
		'		
		Select Case strantype
		Case "income"
			tIncome = SDUIShared.CDbl(tIncome) + SDUIShared.CDbl(stranamount)
			'
			Dim scatname As String = mIncomeCategories.Get(trancategoryid)
			Dim scatcolor As String = mIncomeColors.Get(trancategoryid)
			icolors.Put(scatname, scatcolor)
			'
			If incomes.ContainsKey(scatname) = False Then
				incomes.Put(scatname, damount)
			Else
				Dim lamount As Double = incomes.Get(scatname)
				lamount = SDUIShared.CDbl(lamount) + SDUIShared.CDbl(damount)
				incomes.Put(scatname, lamount)
			End If
		Case "expense"		
			tExpense = SDUIShared.CDbl(tExpense) + SDUIShared.CDbl(stranamount)
			'
			Dim scatname As String = mExpenseCategories.Get(trancategoryid)
			Dim scatcolor As String = mExpenseColors.Get(trancategoryid)
			ecolors.Put(scatname, scatcolor)
			'
			If expenses.ContainsKey(scatname) = False Then
				expenses.Put(scatname, damount)
			Else	
				Dim lamount As Double = expenses.Get(scatname)
				lamount = SDUIShared.CDbl(lamount) + SDUIShared.CDbl(damount)
				expenses.Put(scatname, lamount)
			End If
		End Select
	Next
	stats.SetItemValue("income", $"R ${SDUIShared.nicemoney(tIncome)}"$)
	stats.SetItemValue("expenses", $"R ${SDUIShared.nicemoney(tExpense)}"$)
	'define the balance
	tBalance = SDUIShared.CDbl(tIncome) - SDUIShared.CDbl(tExpense)
	Dim sBalance As String = SDUIShared.NiceMoney(tBalance)
	stats.SetItemValue("balance", $"R ${sBalance}"$)
	'				
	incomeChart.Donut = True
	incomeChart.Title = "Total Income"
	For Each im As String In incomes.Keys
		Dim a As String = incomes.Get(im)
		Dim c As String = icolors.Get(im)
		incomeChart.AddXYColor(im, a, c)
	Next
	incomeChart.Refresh
	'
	expenseChart.Clear
	expenseChart.Donut = True
	expenseChart.Title = "Total Expenses"
	For Each em As String In expenses.Keys
		Dim ac As String = expenses.Get(em)
		Dim cc As String = ecolors.Get(em)
		expenseChart.AddXYColor(em, ac, cc)
	Next
	expenseChart.Refresh
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows1.AddColumns3x4
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	page.Row(1).pt(5)
	page.Row(2).pt(5)
	
	'we add stats
	BuildStats
	BuildIncomeChart
	BuildTransactionForm
	BuildExpenseChart
End Sub

Sub BuildTransactionForm
	page.Cell(2, 2).CenterChildren
	frmTrans = page.Cell(2, 2).AddCardForm("frmtrans", "Transactions")
	
	'
	frmTrans.Container.AddRows2.AddColumns2x6
	frmTrans.Container.AddRows1.AddColumns12
	frmTrans.Container.BuildGrid
	frmTrans.Container.Shrink
	'
	txttranid = frmTrans.Cell(1, 1).AddTextBoxLabel("txttranid","Transaction ID", "")
	txttranid.Required = True
	txttranid.Hide
	'
	Dim expType As Map = CreateMap()
	expType.Put("", "-- Nothing Selected --")
	expType.Put("income", "Income")
	expType.Put("expense", "Expense")
	cboTranType = frmTrans.Cell(1, 1).AddSelect("cbotrantype", "Type", "", expType)
	cboTranType.Required = True
	
	cboCategory = frmTrans.Cell(1, 2).AddSelect("cbocategory", "Category", "", CreateMap())
	cboCategory.Required = True
	
	txtAmount = frmTrans.Cell(2, 1).AddNumber("txtamount", "Amount", "", 0, 2000)
	txtAmount.Required = True
	'
	Dim dt1Options As RollDateOptions = app.InitRollDateTime
	dt1Options.beginYear = 2000
	dt1Options.endYear = 2100
	dt1Options.DateTimeFormat = "YYYY-MM-DD"
	txtDate = frmTrans.Cell(2, 2).AddRollDateTime("txtdate", "Date", "", "", "", dt1Options)
	txtDate.Placeholder = "YYYY-MM-DD"
	txtDate.Required = True
	
	btnCreate = frmTrans.Cell(3, 1).AddButton("btncreate", "Create")
	btnCreate.block
End Sub

Sub ClearTransaction
	txttranid.Value = ""
	cboTranType.Value = ""
	cboCategory.Clear
	txtAmount.Value = ""
	txtDate.Value = ""
End Sub

'load the respective categories
Sub cbotrantype_Change (item As String)
	Select Case item
	Case ""
		cboCategory.clear
	Case "income"
		banano.Await(cboCategory.SetItems(mIncomeCategories))
	Case "expense"
		banano.Await(cboCategory.SetItems(mExpenseCategories))
	End Select
End Sub

Private Sub btnCreate_Click (e As BANanoEvent)
	e.PreventDefault
	e.StopPropagation
	'reset the validations
	frmTrans.ResetValidation
	'validate each of the elements
	frmTrans.Validate(cboTranType.IsBlank)
	frmTrans.Validate(cboCategory.IsBlank)
	frmTrans.Validate(txtAmount.IsBlank)
	frmTrans.Validate(txtDate.IsBlank)
	'check the form status
	If frmTrans.IsValid = False Then Return
	'save the record
	If txttranid.Value = "" Then txttranid.Value = pbIncomeExpenses.NextID
	pbIncomeExpenses.PrepareRecord
	pbIncomeExpenses.SetField("id", txttranid.value)
	pbIncomeExpenses.SetField("trancategoryid", cboCategory.value)
	pbIncomeExpenses.SetField("trantype", cboTranType.Value)
	pbIncomeExpenses.SetField("tranamount", txtAmount.Value)
	pbIncomeExpenses.SetField("trandate", txtDate.Value)
	Dim ie As String = banano.Await(pbIncomeExpenses.CREATE_OR_UPDATE)
	ClearTransaction
	RefreshCharts
End Sub

Sub BuildIncomeChart
	page.Cell(2, 1).CenterChildren
	banano.LoadLayout(page.Cell(2, 1).Here, "incomelayout")
	incomeChart.Root.shadow("2xl")
	incomeChart.Root.roundedBox
	incomeChart.Root.p(2)
End Sub

Sub BuildExpenseChart
	page.Cell(2, 3).CenterChildren
	banano.LoadLayout(page.Cell(2, 3).Here, "expenselayout")
	expenseChart.Root.shadow("2xl")
	expenseChart.Root.roundedBox
	expenseChart.Root.p(2)
End Sub

Sub BuildStats
	page.Cell(1, 1).CenterChildren
	stats = page.Cell(1, 1).AddStats("stats")
	stats.Root.shadow("2xl")
	'stats.VerticalOnSmallOnly
	'
	stats.AddItem("income", "Income", "R 00.00", "")
	stats.GetItem("income").textColor(app.COLOR_SUCCESS)
	
	'stats.Item("income").bgColor(app.COLOR_SUCCESS)
	'stats.Item("income").TextColorIntensity(app.COLOR_SUCCESS,"content")
	'
	stats.AddItem("expenses", "Expenses", "R 0.00", "")
	stats.GetItem("expenses").textColor(app.COLOR_ERROR)
	
	'stats.Item("expenses").bgColor(app.COLOR_ERROR)
	'stats.Item("expenses").TextColorIntensity(app.COLOR_ERROR,"content")
	'
	stats.AddItem("balance", "Balance", "R 0.00", "")
	'stats.Item("balance").bgColor(app.COLOR_PRIMARY)
	'stats.Item("balance").TextColorIntensity(app.COLOR_PRIMARY,"content")
End Sub

'Sub downs2_addfunds_click (e As BANanoEvent)
'    page.Cell(6, 1).Caption = "Add Funds"
'End Sub
''
'Sub users2_withdrawal_click (e As BANanoEvent)
'    page.Cell(6, 1).Caption = "Widthdrawal"
'End Sub
''
'Sub users2_deposit_click (e As BANanoEvent)
'    page.Cell(6, 1).Caption = "Deposit"
'End Sub
'End Sub

