﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables8"
	Public title As String = "Table 8"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
	Private tb4 As SDUITable
	Private timeUpdate As Timer
	Private tblPos As Int
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "gender":"male", "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"", "tob":"", "agroup":""))
	Items.Add(CreateMap("hours": 5, "gender":"female", "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Anna Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/Anna.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"","tob":"","agroup":""))
	Items.Add(CreateMap("hours": 8, "gender":"male", "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"","tob":"","agroup":""))
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table5
	Table5Code
End Sub

Sub Table5Code
	Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
	c5.AddCode($"Sub Build_Table5"$)
	c5.AddCode($"tb4 = page.Cell(1, 1).AddTable("tb4")"$)
	c5.AddCode($"Items.Initialize"$)
	c5.AddCode($"Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"", "tob":""))"$)
	c5.AddCode($"Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"","tob":""))"$)
	c5.AddCode($"Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"","tob":""))"$)
	c5.AddCode($"'"$)
	c5.AddCode($"tb4.AddColumnAvatarTitle("avatar", "User", "4rem", "name", app.MASK_ROUNDED)"$)
	c5.AddCode($"tb4.AddColumnRadioGroup("gender", "Gender", False, app.COLOR_PRIMARY, CreateMap("male":"Male","female":"Female"))"$)
	c5.AddCode($"tb4.AddColumnProgress("progress", "Progress", 40, 100, app.COLOR_CYAN)"$)
	c5.AddCode($"tb4.AddColumnRadialProgress("rate", "Progress", "4rem", app.COLOR_EMERALD, "%")"$)
	c5.AddCode($"tb4.AddColumnRange("clicklink", "Progress", 100, app.COLOR_GREEN)"$)
	c5.AddCode($"tb4.AddColumnAvatarGroup("agroup", "Resources", "2rem", app.MASK_CIRCLE)"$)
	c5.AddCode($"tb4.AddColumnAvatarPlaceholder("hours", "Hours", "3rem", app.MASK_CIRCLE, "primary")"$)
	c5.AddCode($"tb4.AddColumnAction("btnstart", "Start/Stop", "fa-solid fa-play", app.COLOR_FUCHSIA)"$)
	c5.AddCode($"tb4.SetColumnComputeValue("agroup", "Computeagroup")"$)
	c5.AddCode($"banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate"$)
	c5.AddCode($"tb4.SetRowColumn("agroup", 2, ~"./assets/team-1.jpg;./assets/team-2.jpg;./assets/team-3.jpg;./assets/team-4.jpg;./assets/team-5.jpg"~)"$)
	c5.AddCode($"tb4.SetRowColumn("hours", 1, "99+")"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Sub tb4_btnstart(item As Map)"$)
	c5.AddCode($"'get the id of the record"$)
	c5.AddCode($"Dim sid As String = item.Get("id")"$)
	c5.AddCode($"'find the position of the record using the id"$)
	c5.AddCode($"Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))"$)
	c5.AddCode($"tblPos = pos"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Dim cicon As String = tb4.GetRowColumn("btnstart", pos)"$)
	c5.AddCode($"Select Case cicon"$)
	c5.AddCode($"Case "fa-solid fa-play""$)
	c5.AddCode($"tb4.SetRowColumn("btnstart", pos, "fa-solid fa-stop")"$)
	c5.AddCode($"timeUpdate.Initialize("timeUpdate", 1000)"$)
	c5.AddCode($"timeUpdate.Enabled = True"$)
	c5.AddCode($"Case "fa-solid fa-stop""$)
	c5.AddCode($"tb4.SetRowColumn("btnstart", pos, "fa-solid fa-play")"$)
	c5.AddCode($"timeUpdate.Enabled = False"$)
	c5.AddCode($"End Select"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub timeUpdate_Tick"$)
	c5.AddCode($"Dim iprogress As Int = tb4.GetRowColumn("progress", tblPos)"$)
	c5.AddCode($"iprogress = banano.parseInt(iprogress) + 1"$)
	c5.AddCode($"If iprogress > 100 Then iprogress = 1"$)
	c5.AddCode($"tb4.SetRowColumn("progress", tblPos, iprogress)"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Dim irate As Int = tb4.GetRowColumn("rate", tblPos)"$)
	c5.AddCode($"irate = banano.parseInt(irate) + 1"$)
	c5.AddCode($"If irate > 100 Then irate = 1"$)
	c5.AddCode($"tb4.SetRowColumn("rate", tblPos, irate)"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Dim iclicklink As Int = tb4.GetRowColumn("clicklink", tblPos)"$)
	c5.AddCode($"iclicklink = banano.parseInt(iclicklink) + 1"$)
	c5.AddCode($"If iclicklink > 100 Then iclicklink = 1"$)
	c5.AddCode($"tb4.SetRowColumn("clicklink", tblPos, iclicklink)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Sub Computeagroup(item As String) As String"$)
	c5.AddCode($"Return ~"./assets/Angela.jpg;./assets/Anna.jpg;./assets/daisywoman3.png;./assets/daisywoman1.jpg;./assets/face13.jpg;./assets/profile12.jpg"~"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
End Sub

Sub Build_Table5
	tb4 = page.Cell(1, 1).AddTable("tb4")
	
	tb4.AddColumnAvatarTitle("avatar", "User", "4rem", "name", app.MASK_ROUNDED)
	tb4.AddColumnRadioGroup("gender", "Gender", False, app.COLOR_PRIMARY, CreateMap("male":"Male","female":"Female"))
	tb4.AddColumnProgress("progress", "Progress", 40, 100, app.COLOR_SUCCESS)
	tb4.AddColumnRadialProgress("rate", "Progress", "4rem", app.COLOR_PRIMARY, "%")
	tb4.AddColumnRange("clicklink", "Progress", 100, app.COLOR_WARNING)
	tb4.AddColumnAvatarGroup("agroup", "Resources", "2rem", app.MASK_CIRCLE)
	tb4.AddColumnAvatarPlaceholder("hours", "Hours", "3rem", app.MASK_CIRCLE, "primary")
	tb4.SetColumnTextColor("hours", app.COLOR_WHITE)
	tb4.AddColumnAction("btnstart", "Start/Stop", "fa-solid fa-play", app.COLOR_FUCHSIA)
	tb4.SetColumnComputeValue("agroup", "Computeagroup")
	banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate
	tb4.SetRowColumn("agroup", 2, $"./assets/team-1.jpg;./assets/team-2.jpg;./assets/team-3.jpg;./assets/team-4.jpg;./assets/team-5.jpg"$)
	tb4.SetRowColumn("hours", 1, "99+")
End Sub

Sub Computeagroup(item As Map) As String
	Return $"./assets/Angela.jpg;./assets/Anna.jpg;./assets/daisywoman3.png;./assets/daisywoman1.jpg;./assets/face13.jpg;./assets/profile12.jpg"$
End Sub

Sub tb4_btnstart(item As Map)
	'get the id of the record
	Dim sid As String = item.Get("id")
	'find the position of the record using the id
	Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))
	tblPos = pos
	'
	Dim cicon As String = tb4.GetRowColumn("btnstart", pos)
	Select Case cicon
	Case "fa-solid fa-play"
		tb4.SetRowColumn("btnstart", pos, "fa-solid fa-stop")
		timeUpdate.Initialize("timeUpdate", 1000)
		timeUpdate.Enabled = True
	Case "fa-solid fa-stop"
		tb4.SetRowColumn("btnstart", pos, "fa-solid fa-play")
		timeUpdate.Enabled = False
	End Select
End Sub

Private Sub timeUpdate_Tick
	Dim iprogress As Int = tb4.GetRowColumn("progress", tblPos)
	iprogress = banano.parseInt(iprogress) + 1
	If iprogress > 100 Then iprogress = 1
	tb4.SetRowColumn("progress", tblPos, iprogress)
	'
	Dim irate As Int = tb4.GetRowColumn("rate", tblPos)
	irate = banano.parseInt(irate) + 1
	If irate > 100 Then irate = 1
	tb4.SetRowColumn("rate", tblPos, irate)
	'
	Dim iclicklink As Int = tb4.GetRowColumn("clicklink", tblPos)
	iclicklink = banano.parseInt(iclicklink) + 1
	If iclicklink > 100 Then iclicklink = 1
	tb4.SetRowColumn("clicklink", tblPos, iclicklink)
End Sub


''
'Private Sub tb4_btnicon (item As Map)
'	'get the id of the record
'	Dim sid As String = item.Get("id")
'	'find the position of the record using the id
'	Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))
'	'get the caption of the button
'	Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnicon", pos))
'	'
'	Select Case btnCaption
'		Case "Flag"
'			'change the caption to
'			tb4.SetRowColumn("btnicon", pos, "Insta")
'			'set the append icon to insta
'			tb4.SetRowColumnAppendIcon("country", pos, "fa-brands fa-instagram")
'			tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-twitter")
'		Case "Insta"
'			'change the caption to
'			tb4.SetRowColumn("btnicon", pos, "Flag")
'			'set the append icon to flag
'			tb4.SetRowColumnAppendIcon("country", pos, "fa-regular fa-flag")
'			tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-linkedin")
'	End Select
'End Sub


'Private Sub tb4_btnload (item As Map)
'	'get the id of the record
'	Dim sid As String = item.Get("id")
'	'find the position of the record using the id
'	Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))
'	'get the caption of the button
'	Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnload", pos))
'	'
'	Select Case btnCaption
'		Case "Process"
'			'change the caption to
'			tb4.SetRowColumn("btnload", pos, "Loading")
'			'set the append icon to loading
'			tb4.SetRowColumnAppendLoading("country", pos, True)
'			tb4.SetRowColumnPrependLoading("country", pos, True)
'		Case "Loading"
'			'change the caption to
'			tb4.SetRowColumn("btnload", pos, "Process")
'			'set the append icon to not-loading
'			tb4.SetRowColumnAppendLoading("country", pos, False)
'			tb4.SetRowColumnPrependLoading("country", pos, False)
'	End Select
'End Sub

Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	Dim x As Map = CreateMap()
	x.Put("row", Row)
	x.Put("column", Column)
	x.Put("value", Value)
	Dim s As String = banano.ToJson(x)
	app.ShowSwal(s)
End Sub