﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "mdtoastx"
	Public title As String = "MD Toast"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private btnShowToast As SDUIButtonGroup		'ignore
	Private SDUIMDToast1 As SDUIMDToast			'ignore
	Private btnToastType As SDUIButtonGroup		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "mdtoastlayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIMDToast1_Action (e As BANanoEvent)
	Log("Action Done!")
	SDUIMDToast1.Hide
End Sub

Private Sub btnShowToast_Click (item As String)
	Select Case item
	Case "tl"
		SDUIMDToast1.Position = SDUIMDToast1.POSITION_TOP_LEFT
		SDUIMDToast1.Text = "Toast showing at top left"
		SDUIMDToast1.Show
	Case "bl"
		SDUIMDToast1.Position = SDUIMDToast1.POSITION_BOTTOM_LEFT
		SDUIMDToast1.Text = "Toast showing at bottom left"
		SDUIMDToast1.Show
	Case "tc"
		SDUIMDToast1.Position = SDUIMDToast1.POSITION_TOP_CENTER
		SDUIMDToast1.Text = "Toast showing at top center"
		SDUIMDToast1.Show
	Case "tr"
		SDUIMDToast1.Position = SDUIMDToast1.POSITION_TOP_RIGHT
		SDUIMDToast1.Text = "Toast showing at top right"
		SDUIMDToast1.Show
	Case "br"
		SDUIMDToast1.Position = SDUIMDToast1.POSITION_BOTTOM_RIGHT
		SDUIMDToast1.Text = "Toast showing at bottom right"
		SDUIMDToast1.Show
	End Select
End Sub

Private Sub btnToastType_Click (item As String)
	Select Case item
	Case "info"
		SDUIMDToast1.TypeOf = SDUIMDToast1.TYPEOF_INFO
		SDUIMDToast1.Show
	Case "warning"
		SDUIMDToast1.TypeOf = SDUIMDToast1.TYPEOF_WARNING
		SDUIMDToast1.Show
	Case "success"
		SDUIMDToast1.TypeOf = SDUIMDToast1.TYPEOF_SUCCESS
		SDUIMDToast1.Show
	Case "error"
		SDUIMDToast1.TypeOf = SDUIMDToast1.TYPEOF_ERROR
		SDUIMDToast1.Show
	End Select
End Sub