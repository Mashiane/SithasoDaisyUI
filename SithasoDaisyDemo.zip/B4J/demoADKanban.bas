﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adkanban"
	Public title As String = "Kanban"
	Public icon As String = "fa-solid fa-pager"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIKanban1 As SDUIKanban
End Sub

#if css
.kanban-container {
    position: relative;
    width: auto;
    overflow: scroll
}

.kanban-container,
.kanban-container * {
    box-sizing: border-box
}

.kanban-container:after {
    clear: both;
    display: block;
    content: ""
}

.kanban-board {
    position: relative;
    float: left;
    background: #e9ecef;
    transition: all .3s cubic-bezier(.23, 1, .32, 1);
    border-radius: .5rem
}

.kanban-board.disabled-board {
    opacity: .3
}

.kanban-board.is-moving.gu-mirror {
    transform: rotate(3deg)
}

.kanban-board.is-moving.gu-mirror .kanban-drag {
    overflow: hidden;
    padding-right: 50px
}

.kanban-board header {
    font-size: 16px;
    padding: 20px
}

.kanban-board header .kanban-title-board {
    font-weight: 600;
    margin: 0;
    padding: 0;
    display: inline;
    color: #344767
}

.kanban-board header .kanban-title-button {
    float: right
}

.kanban-board .kanban-drag {
    min-height: 200px;
    padding: 20px
}

.kanban-board:after {
    clear: both;
    display: block;
    content: ""
}

.kanban-item {
    background: #fff;
    padding: 15px;
    margin-bottom: 20px;
    transition: all .3s cubic-bezier(.23, 1, .32, 1)
}

.kanban-item img.w-100 {
    border-radius: .5rem
}

.kanban-item:hover {
    cursor: move
}

.kanban-item:last-child {
    margin: 0
}

.kanban-item.is-moving.gu-mirror {
    transform: rotate(3deg);
    height: auto !important
}

.gu-mirror {
    position: fixed !important;
    margin: 0 !important;
    z-index: 9999 !important
}

.gu-hide {
    display: none !important
}

.gu-unselectable {
    -webkit-user-select: none !important;
    -moz-user-select: none !important;
    -ms-user-select: none !important;
    user-select: none !important
}

.gu-transit {
    box-shadow: inset 0 0 2px #fefefed1;
    -webkit-backdrop-filter: saturate(200%) blur(30px);
    backdrop-filter: saturate(200%) blur(30px);
    background-color: hsla(0, 0%, 100%, .8) !important;
    box-shadow: inset 0 0 1px 1px hsla(0, 0%, 100%, .9), 0 20px 27px 0 rgba(0, 0, 0, .05) !important
}

.drag_handler {
    background: #fff;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    position: relative;
    float: left;
    top: -3px;
    margin-right: 4px
}

.drag_handler:hover {
    cursor: move
}

.drag_handler_icon {
    position: relative;
    display: block;
    background: #000;
    width: 24px;
    height: 2px;
    top: 12px;
    transition: .5s ease-in-out
}

.drag_handler_icon:after,
.drag_handler_icon:before {
    background: #000;
    content: "";
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    transition: .5s ease-in-out
}

.drag_handler_icon:before {
    top: 6px
}

.drag_handler_icon:after {
    bottom: 6px
}
#End If


'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesKanBan)
	'load the page layout to the pageviewer
	banano.LoadLayout(app.PageViewer, "adkanbanlayout")
	SDUIKanban1.Clear
	SDUIKanban1.AddBoard("backlog", "Backlog", "", Null)
	SDUIKanban1.AddBoardItem("backlog", "task_1", "Task 1", "", Null)
	SDUIKanban1.AddBoardItem("backlog", "task_2", "Drag me to 'In progress' section", "", Null)
	SDUIKanban1.AddBoardItem("backlog", "task_2", _
	$"<img src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/office-dark.jpg" class="w-100"><span class="mt-3 badge badge-sm bg-gradient-primary">Pending</span><p class="text mt-2">Website Design: New cards for blog section and profile details</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">3</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-1.jpg" class=""></a><a href="#" class="avatar avatar-xs rounded-circle me-2" data-toggle="tooltip" data-original-title="Audrey Love"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-2.jpg" class="rounded-circle"></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Michael Lewis"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-3.jpg" class="rounded-circle"></a></div></div>"$, "", _
	CreateMap("assignee":"Done Joe", "description":"This task's description is for something, but not for anything"))
	
	SDUIKanban1.AddBoard("progress", "In Progress", "", Null)
	SDUIKanban1.AddBoardItem("progress", "task_3", _
	$"<span class="mt-2 badge badge-sm bg-gradient-warning">Errors</span><p class="text mt-2">Fix Firefox errors</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">11</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jana Lucie"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-3.jpg" class=""></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-2.jpg" class=""></a></div></div>"$, "", Null)
	
	SDUIKanban1.AddBoardItem("progress", "task_4", _
	$"<span class="mt-2 badge badge-sm bg-gradient-info">Updates</span><p class="text mt-2">Argon Dashboard PRO - Angular 11</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">3</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jana Lucie"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-5.jpg" class=""></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-4.jpg" class=""></a></div></div>"$, "", Null)
	'
	SDUIKanban1.AddBoardItem("progress", "task_5", _
	$"<img src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/meeting.jpg" class="w-100"><span class="mt-3 badge badge-sm bg-gradient-info">Updates</span><p class="text mt-2">Vue 3 Updates</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">9</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-1.jpg" class=""></a><a href="#" class="avatar avatar-xs rounded-circle me-2" data-toggle="tooltip" data-original-title="Audrey Love"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-2.jpg" class="rounded-circle"></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Michael Lewis"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-4.jpg" class="rounded-circle"></a></div></div>"$, "", Null)
	
	SDUIKanban1.AddBoard("todo", "Review", "", Null)
	SDUIKanban1.AddBoardItem("todo", "task_6", _
	$"<span class="mt-2 badge badge-sm bg-gradient-warning">In Testing</span><p class="text mt-2">Responsive Changes</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">11</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jana Lucie"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-3.jpg" class=""></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-2.jpg" class=""></a></div></div>"$, "", Null)
	'
	SDUIKanban1.AddBoardItem("todo", "task_7", _
	$"<span class="mt-2 badge badge-sm bg-gradient-success">In review</span><p class="text mt-2 mb-1">Change images dimension</p><div class="col"><div class="progress progressm mb-3 w5"><div class="progress-bar bg-gradient-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;"></div></div></div><div class="d-flex"><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-3.jpg" class=""></a></div></div>"$, "", Null)
'
	SDUIKanban1.AddBoardItem("todo", "task_8", _
	$"<span class="mt-2 badge badge-sm bg-gradient-info">In Review</span><p class="text mt-2 mb-1">Update Links</p><div class="col"><div class="progress progressm mb-3 w5"><div class="progress-bar bg-gradient-info" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div></div></div><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">6</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jana Lucie"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-5.jpg" class=""></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Mike Alis"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-1.jpg" class=""></a></div></div>"$, "", Null)
	'
	SDUIKanban1.AddBoard("done", "Done", "", Null)
	SDUIKanban1.AddBoardItem("done", "task_10", _
	$"<img src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/home-decor-1.jpg" class="w-100"><span class="mt-3 badge badge-sm bg-gradient-success">Done</span><p class="text mt-2">Redesign for the home page</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">8</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Jessica Rowland"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-5.jpg" class=""></a><a href="#" class="avatar avatar-xs rounded-circle me-2" data-toggle="tooltip" data-original-title="Audrey Love"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-1.jpg" class="rounded-circle"></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Michael Lewis"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-4.jpg" class="rounded-circle"></a></div></div>"$, "", Null)
	'
	SDUIKanban1.AddBoardItem("done", "task_11", _
	$"<span class="mt-2 badge badge-sm bg-gradient-success">Done</span><p class="text mt-2">Schedule winter campaign</p><div class="d-flex"><div> <i class="fa fa-paperclip me-1 text-sm"></i><span class="text-sm">2</span></div><div class="avatar-group ms-auto"><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Michael Laurence"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-1.jpg" class=""></a><a href="#" class="avatar avatar-xs me-2 rounded-circle" data-toggle="tooltip" data-original-title="Michael Lewis"><img alt="Image placeholder" src="https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/team-4.jpg" class="rounded-circle"></a></div></div>"$, "", Null)
	
	SDUIKanban1.Refresh
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	'page.Root.DesignMode(True)
	'center the page container
	'page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	'page.Root.AddRows5.AddColumns2x6
	'build the grid
	'page.Root.BuildGrid
	'start adding you components here
End Sub


Private Sub SDUIKanban1_ButtonClick (el As Map, boardId As String)
	
End Sub

Private Sub SDUIKanban1_Click (el As Map)
	
End Sub

Private Sub SDUIKanban1_DragItem (el As Map, source As Map)
	
End Sub

Private Sub SDUIKanban1_DragItemEnd (el As Map)
	
End Sub

Private Sub SDUIKanban1_DropItem (el As Map)
	
End Sub

Private Sub SDUIKanban1_ClickItem (el As Map)
	
End Sub

Private Sub SDUIKanban1_ContextItem (el As Map, event As BANanoEvent)
	
End Sub