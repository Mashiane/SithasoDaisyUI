﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tooltips"
	Public title As String = "Tooltip"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim btn1 As SDUITooltip = page.Cell(1, 1).AddTooltipButton("btn1", "Hover Me", "hello")
	btn1.Color = app.color_secondary
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim btn1 As SDUITooltip = page.Cell(1, 1).AddTooltipButton("btn1", "Hover Me", "hello")"$)
	c1.AddCode($"btn1.AddButton(Me, page.CellID(1, 1), "btn1", "Hover Me", "hello")"$)
	c1.AddCode($"btn1.Color = app.color_secondary"$)
	c1.Refresh
	'
	Dim btn2 As SDUITooltip = page.Cell(2, 1).AddTooltipButton("btn2", "Open Right Tooltip", "I am open")
	btn2.AtRight
	btn2.Open = True
	btn2.Color = app.COLOR_Secondary
	btn2.Button.Color = app.COLOR_SECONDARY
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim btn2 As SDUITooltip = page.Cell(2, 1).AddTooltipButton("btn2", "Open Right Tooltip", "I am open")"$)
	c2.AddCode($"btn2.AtRight"$)
	c2.AddCode($"btn2.Open = True"$)
	c2.AddCode($"btn2.Color = app.COLOR_Secondary"$)
	c2.AddCode($"btn2.Button.Color = app.COLOR_SECONDARY"$)
	c2.Refresh
	
End Sub

Private Sub btn1_Click (e As BANanoEvent)
	banano.Alert("Done!")
End Sub