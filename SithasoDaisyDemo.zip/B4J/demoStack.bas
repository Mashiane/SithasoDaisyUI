﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "stack"
	Public title As String = "Stack"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	'a div without a stack
	'add a div in R1C1
	Dim without As SDUIDiv = page.Cell(1, 1).AddDiv("without")
	'add a div inside the div
	Dim done As SDUIDiv = without.AddDiv("done")
	done.Caption = "1"
	done.Grid.isrounded.PlaceContentCenter
	done.H(20)
	done.W(20)
	done.BGColor(app.COLOR_Primary)
	done.TextColorIntensity(app.COLOR_Primary,"content")
	'
	Dim d2 As SDUIDiv = without.AddDiv("d2")
	d2.Caption = "2"
	d2.Grid.isrounded.PlaceContentCenter
	d2.H(20)
	d2.W(20)
	d2.BGColor(app.COLOR_accent)
	d2.TextColorIntensity(app.COLOR_accent,"content")
	'
	Dim d3 As SDUIDiv = without.AddDiv("d3")
	d3.Caption = "3"
	d3.Grid.isrounded.PlaceContentCenter
	d3.H(20)
	d3.W(20)
	d3.BGColor(app.COLOR_secondary)
	d3.TextColorIntensity(app.COLOR_secondary,"content")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim without As SDUIDiv = page.Cell(1, 1).AddDiv("without")"$)
	c1.AddCode($"'add a div inside the div"$)
	c1.AddCode($"Dim done As SDUIDiv = without.AddDiv("done")"$)
	c1.AddCode($"done.Caption = "1""$)
	c1.AddCode($"done.Root.Grid.isrounded.PlaceContentCenter"$)
	c1.AddCode($"done.H = 20"$)
	c1.AddCode($"done.W = 20"$)
	c1.AddCode($"done.Root.BGColor = app.COLOR_Primary"$)
	c1.AddCode($"done.Root.TextColorIntensity(app.COLOR_Primary,"content")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Dim d2 As SDUIDiv = without.AddDiv("d2")"$)
	c1.AddCode($"d2.Caption = "2""$)
	c1.AddCode($"d2.Root.Grid.isrounded.PlaceContentCenter"$)
	c1.AddCode($"d2.H = 20"$)
	c1.AddCode($"d2.W = 20"$)
	c1.AddCode($"d2.Root.BGColor = app.COLOR_accent"$)
	c1.AddCode($"d2.Root.TextColorIntensity(app.COLOR_accent,"content")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Dim d3 As SDUIDiv = without.AddDiv("d3")"$)
	c1.AddCode($"d3.Caption = "3""$)
	c1.AddCode($"d3.Root.Grid.isrounded.PlaceContentCenter"$)
	c1.AddCode($"d3.H = 20"$)
	c1.AddCode($"d3.W = 20"$)
	c1.AddCode($"d3.Root.BGColor = app.COLOR_secondary"$)
	c1.AddCode($"d3.Root.TextColorIntensity(app.COLOR_secondary,"content")"$)
	c1.Refresh
	
	
	'a stacked grid
	Dim withstack As SDUIDiv = page.Cell(2, 1).AddStack("withstack")
	Dim done1 As SDUIDiv = withstack.AddDiv("done1")
	done1.Caption = "1"
	done1.Grid.isrounded.PlaceContentCenter
	done1.H(20)
	done1.W(20)
	done1.BGColor(app.COLOR_Primary)
	done1.TextColorIntensity(app.COLOR_Primary,"content")
	'
	Dim d21 As SDUIDiv = withstack.AddDiv("d21")
	d21.Caption = "2"
	d21.Grid.isrounded.PlaceContentCenter
	d21.H(20)
	d21.W(20)
	d21.BGColor(app.COLOR_accent)
	d21.TextColorIntensity(app.COLOR_accent,"content")
	'
	Dim d33 As SDUIDiv = withstack.AddDiv("d33")
	d33.Caption = "3"
	d33.Grid.isrounded.PlaceContentCenter
	d33.H(20)
	d33.W(20)
	d33.BGColor(app.COLOR_secondary)
	d33.TextColorIntensity(app.COLOR_secondary,"content")
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"'a stacked grid"$)
	c2.AddCode($"Dim withstack As SDUIDiv = page.Cell(2, 1).AddStack("withstack")"$)
	c2.AddCode($"Dim done1 As SDUIDiv = withstack.AddDiv("done1")"$)
	c2.AddCode($"done1.Caption = "1""$)
	c2.AddCode($"done1.Root.Grid.isrounded.PlaceContentCenter"$)
	c2.AddCode($"done1.H = 20"$)
	c2.AddCode($"done1.W = 20"$)
	c2.AddCode($"done1.Root.BGColor = app.COLOR_Primary"$)
	c2.AddCode($"done1.Root.TextColorIntensity(app.COLOR_Primary,"content")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim d21 As SDUIDiv = withstack.AddDiv("d21")"$)
	c2.AddCode($"d21.Caption = "2""$)
	c2.AddCode($"d21.Root.Grid.isrounded.PlaceContentCenter"$)
	c2.AddCode($"d21.H = 20"$)
	c2.AddCode($"d21.W = 20"$)
	c2.AddCode($"d21.Root.BGColor = app.COLOR_accent"$)
	c2.AddCode($"d21.Root.TextColorIntensity(app.COLOR_accent,"content")"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim d33 As SDUIDiv = withstack.AddDiv("d33")"$)
	c2.AddCode($"d33.Caption = "3""$)
	c2.AddCode($"d33.Root.Grid.isrounded.PlaceContentCenter"$)
	c2.AddCode($"d33.H = 20"$)
	c2.AddCode($"d33.W = 20"$)
	c2.AddCode($"d33.Root.BGColor = app.COLOR_secondary"$)
	c2.AddCode($"d33.Root.TextColorIntensity(app.COLOR_secondary, "content")"$)
	c2.Refresh
	'
	Dim imageStack As SDUIDiv = page.Cell(3, 1).AddStack("imgstack")
	'
	Dim img1 As SDUIImage = imageStack.AddImage("img1", "./assets/1.jpg","", "100px", "100px")
	img1.Root.isrounded
	'
	Dim img2 As SDUIImage = imageStack.AddImage("img2", "./assets/2.jpg", "", "100px", "100px")
	img2.Root.isrounded
	'
	Dim img3 As SDUIImage = imageStack.AddImage("img3", "./assets/3.jpg", "", "100px", "100px")
	img3.Root.isrounded
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim imageStack As SDUIDiv = page.Cell(3, 1).AddStack("imgstack")"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim img1 As SDUIImage = imageStack.AddImage("img1", "./assets/1.jpg","", "100px", "100px")"$)
	c3.AddCode($"img1.Root.isrounded"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim img2 As SDUIImage = imageStack.AddImage("img2", "./assets/2.jpg", "", "100px", "100px")"$)
	c3.AddCode($"img2.Root.isrounded"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim img3 As SDUIImage = imageStack.AddImage("img3", "./assets/3.jpg", "", "100px", "100px")"$)
	c3.AddCode($"img3.Root.isrounded"$)
	c3.Refresh
	
End Sub
