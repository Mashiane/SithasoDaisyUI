﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "fctimeslots"
	Public title As String = "FullCalendar Time Slots"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIFullCalendar1 As SDUIFullCalendar			'ignore
	Private txtEndTime As SDUITextBox						'ignore
	Private txtScrollTime As SDUITextBox					'ignore
	Private txtScrollTo As SDUITextBox						'ignore
	Private txtSlotDuration As SDUITextBox					'ignore
	Private txtStartTime As SDUITextBox						'ignore
	Private SDUIMDToast1 As SDUIMDToast
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "fctimeslotslayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'refresh the calendar to show it
	SDUIFullCalendar1.Clear
	SDUIFullCalendar1.Refresh
	
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub txtScrollTo_Append_Click (event As BANanoEvent)
	event.PreventDefault
	SDUIFullCalendar1.SlotMinTime = txtStartTime.value
	SDUIFullCalendar1.SlotMaxTime = txtEndTime.Value
	SDUIFullCalendar1.ScrollTime = txtScrollTime.Value
	SDUIFullCalendar1.SlotDuration = txtSlotDuration.Value
	'IMPORTANT
	SDUIFullCalendar1.Refresh
	'then scroll to expected time slot
	SDUIFullCalendar1.scrollToTime(txtScrollTo.Value)
	
End Sub

Private Sub SDUIFullCalendar1_DateRangeChange (startDate As String, endDate As String, lastView As String)
	Log(startDate)
	Log(endDate)
	Log(lastView)
End Sub