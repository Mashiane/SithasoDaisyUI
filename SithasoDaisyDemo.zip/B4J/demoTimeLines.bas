﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "timelines"
	Public title As String = "Time Lines"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesTimeLine)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim bt1 As SDUITimeLine
	bt1.AddBeautifulTimeLine(Me, page.Cell(1, 1).Name, "bt1")
	bt1.AddBeautifulTimeLineItem("bt1_1", "June 2022", "An awesome b4xlib", "./assets/face11.jpg", _
	SDUIShared.LoremIpsumSentence(3), False)
	'
	bt1.AddBeautifulTimeLineItem("bt1_2", "October 2022", "More Usage, More Love", "./assets/sponge.png", _
	SDUIShared.LoremIpsumSentence(3), True)
	'
	bt1.AddBeautifulTimeLineItem("bt1_3", "November 2022", "Launch SithasoDaisy...", "./assets/13.jpg", _
	SDUIShared.LoremIpsumSentence(4), False)
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim bt1 As SDUITimeLine = page.Cell(1, 1).AddBeautifulTimeLine("bt1")"$)
	c1.AddCode($"bt1.AddBeautifulTimeLineItem("bt1_1", "June 2022", "An awesome b4xlib", "./assets/face11.jpg", _"$)
	c1.AddCode($"SDUIShared.LoremIpsumSentence(3), False)"$)
	c1.AddCode($"'"$)
	c1.AddCode($"bt1.AddBeautifulTimeLineItem("bt1_2", "October 2022", "More Usage, More Love", "./assets/sponge.png", _"$)
	c1.AddCode($"SDUIShared.LoremIpsumSentence(3), True)"$)
	c1.AddCode($"'"$)
	c1.AddCode($"bt1.AddBeautifulTimeLineItem("bt1_3", "November 2022", "Launch SithasoDaisy...", "./assets/13.jpg", _"$)
	c1.AddCode($"SDUIShared.LoremIpsumSentence(4), False)"$)
	c1.Refresh
	
	'
	Dim bt2 As SDUITimeLine
	bt2.AddTimeLine1(Me, page.Cell(3, 1).Name, "bt2")
	bt2.AddTimeLine1Success("bt2_s1", "Package Booked", "21 July 2021, 04:30 PM")
	bt2.AddTimeLine1Success("bt2_s2", "Out for Delivery", "22 July 2021, 01:00 PM")
	bt2.AddTimeLine1Warning("bt2_w1", "Driver Stuck in Traffic", "22 July 2021, 04:30 PM")
	bt2.AddTimeLine1Error("bt2_e1", "Eish...", "22 July 2021, 04:31 PM")
	bt2.AddTimeLine1Gray("bt2_e2", "Missing in Action", "22 July 2021, 05:00 PM")
	'
	Dim c2 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim bt2 As SDUITimeLine = page.Cell(3, 1).AddTimeLine1("bt2")"$)
	c2.AddCode($"bt2.AddTimeLine1Success("bt2_s1", "Package Booked", "21 July 2021, 04:30 PM")"$)
	c2.AddCode($"bt2.AddTimeLine1Success("bt2_s2", "Out for Delivery", "22 July 2021, 01:00 PM")"$)
	c2.AddCode($"bt2.AddTimeLine1Warning("bt2_w1", "Driver Stuck in Traffic", "22 July 2021, 04:30 PM")"$)
	c2.AddCode($"bt2.AddTimeLine1Error("bt2_e1", "Eish...", "22 July 2021, 04:31 PM")"$)
	c2.AddCode($"bt2.AddTimeLine1Gray("bt2_e2", "Missing in Action", "22 July 2021, 05:00 PM")"$)
	c2.Refresh
End Sub
