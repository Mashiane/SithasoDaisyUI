﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "listview"
	Public title As String = "ListView"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim lv As SDUIListView = page.Cell(1, 1).AddListView("lv1")
	lv.RoundedBox
	lv.shadow("2xl")
	lv.AddItem("p1", "./assets/face5.jpg", "John Doe", "Missisipi", "48")
	lv.AddItem("p2", "./assets/face1.jpg", "John Doe 1", "Missisip", "47")
	lv.AddItem("p3", "./assets/face2.jpg", "John Doe 2", "Missisi", "46")
	lv.AddItem("p4", "./assets/face3.jpg", "John Doe 3", "Missis", "")
	lv.AddItem("p5", "./assets/face4.jpg", "John Doe 3", "Missi", "44")
	lv.SetItemRightIconVisible("p1",False)
	
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim lv As SDUIListView = page.Cell(1, 1).AddListView("lv1")"$)
	c1.AddCode($"lv.RoundedBox"$)
	c1.AddCode($"lv.shadow("2xl")"$)
	c1.AddCode($"lv.AddItem("p1", "./assets/face5.jpg", "John Doe", "Missisipi", "48")"$)
	c1.AddCode($"lv.AddItem("p2", "./assets/face1.jpg", "John Doe 1", "Missisip", "47")"$)
	c1.AddCode($"lv.AddItem("p3", "./assets/face2.jpg", "John Doe 2", "Missisi", "46")"$)
	c1.AddCode($"lv.AddItem("p4", "./assets/face3.jpg", "John Doe 3", "Missis", "")"$)
	c1.AddCode($"lv.AddItem("p5", "./assets/face4.jpg", "John Doe 3", "Missi", "44")"$)
	c1.AddCode($"lv.SetItemRightIconVisible("p1", False)"$)
	c1.AddCode($"'trap click event"$)
	c1.AddCode($"Private Sub lv1_Click (item As String)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = item"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Private Sub lv1_Click (item As String)
	page.Cell(2, 1).Caption = item
End Sub