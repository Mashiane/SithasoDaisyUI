﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "customc"
	Public title As String = "Custom Colors"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim p1 As SDUILabel = page.Cell(1, 1).AddH1("p1", "Custom text color")
	p1.Root.textsize("2xl").textColor("#cc00ff")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim p1 As SDUILabel = page.Cell(1, 1).AddH1("p1", "Custom text color")"$)
	c1.AddCode($"p1.Root.textsize("2xl").textColor("#cc00ff")"$)
	c1.Refresh
	'
	Dim p2 As SDUILabel = page.Cell(2, 1).AddH1("p2", "Custom text color")
	p2.Root.textsize("2xl").textColor("#0066ff")
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim p2 As SDUILabel = page.Cell(2, 1).AddH1("p2", "Custom text color")"$)
	c2.AddCode($"p2.Root.textsize("2xl").textColor("#0066ff")"$)
	c2.Refresh
	'
	Dim p3 As SDUILabel = page.Cell(3, 1).AddH1("p3", "Custom text color")
	p3.Root.textsize("2xl").textColor("#8cff1a")
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim p3 As SDUILabel = page.Cell(3, 1).AddH1("p3", "Custom text color")"$)
	c3.AddCode($"p3.Root.textsize("2xl").textColor("#8cff1a")"$)
	c3.Refresh
	
	Dim p4 As SDUILabel = page.Cell(4, 1).AddH1("p4", "Custom text color")
	p4.Root.textsize("2xl").textColor("#ffffff").bgColor("#cc00ff")
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim p4 As SDUILabel = page.Cell(4, 1).AddH1("p4", "Custom text color")"$)
	c4.AddCode($"p4.Root.textsize("2xl").textColor("#ffffff").bgColor("#cc00ff")"$)
	c4.Refresh
	'
	Dim p5 As SDUILabel = page.Cell(5, 1).AddH1("p5", "Custom text color")
	p5.Root.textsize("2xl").textColor("#80b3ff").bgColor("#0066ff")
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim p5 As SDUILabel = page.Cell(5, 1).AddH1("p5", "Custom text color")"$)
	c5.AddCode($"p5.Root.textsize("2xl").textColor("#80b3ff").bgColor("#0066ff")"$)
	c5.Refresh
	'
	Dim p6 As SDUILabel = page.Cell(6, 1).AddH1("p6", "Custom text color")
	p6.Root.textsize("2xl").textColor("#006600").bgColor("#8cff1a")
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim p6 As SDUILabel = page.Cell(6, 1).AddH1("p6", "Custom text color")"$)
	c6.AddCode($"p6.Root.textsize("2xl").textColor("#006600").bgColor("#8cff1a")"$)
	c6.Refresh
	
End Sub
