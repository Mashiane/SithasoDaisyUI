﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcollapse"
	Public title As String = "AD Collapse"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUICollapsePanels1 As SDUICollapsePanels
	Private SDUICollapsePanels2 As SDUICollapsePanels
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adcollapselayout")
	'
	banano.LoadLayout(SDUICollapsePanels1.Panel(1).Here, "collapse1")
	banano.LoadLayout(SDUICollapsePanels1.Panel(2).Here, "collapse2")
	banano.LoadLayout(SDUICollapsePanels1.Panel(3).Here, "collapse3")
		
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUICollapsePanels.SDUICollapsePanels1", "SDUICollapsePanels1", SDUICollapsePanels1.CustProps)
	pgIndex.AddDesignKV1("SDUICollapsePanels.SDUICollapsePanels2", "SDUICollapsePanels2", SDUICollapsePanels2.CustProps)

	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUICollapsePanels2_Change (pos As Int)
	app.ShowSwal(pos)
End Sub

Private Sub SDUICollapsePanels1_Change (pos As Int)
	app.ShowSwal(pos)
End Sub