﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adrolldate"
	Public title As String = "AD Roll Date"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUITextBox1 As SDUITextBox
	Private SDUITextBox2 As SDUITextBox
	Private SDUITextBox3 As SDUITextBox
	Private SDUITextBox4 As SDUITextBox
	Private SDUITextBox5 As SDUITextBox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adrolldatelayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUITextBox.SDUITextBox1", "SDUITextBox1", SDUITextBox1.CustProps)
	pgIndex.AddDesignKV1("SDUITextBox.SDUITextBox2", "SDUITextBox2", SDUITextBox2.CustProps)
	pgIndex.AddDesignKV1("SDUITextBox.SDUITextBox3", "SDUITextBox3", SDUITextBox3.CustProps)
	pgIndex.AddDesignKV1("SDUITextBox.SDUITextBox4", "SDUITextBox4", SDUITextBox4.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUITextBox3_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub SDUITextBox3_CancelDate (event As BANanoEvent)
	
End Sub

Private Sub SDUITextBox2_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub SDUITextBox2_CancelDate (event As BANanoEvent)
	
End Sub

Private Sub SDUITextBox1_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub SDUITextBox1_CancelDate (event As BANanoEvent)
	
End Sub

Private Sub SDUITextBox4_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub SDUITextBox4_CancelDate (event As BANanoEvent)
	
End Sub

Private Sub SDUITextBox5_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub SDUITextBox5_CancelDate (event As BANanoEvent)
	
End Sub