﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcallmebot"
	Public title As String = "AD CallMeBot"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private btnSend As SDUIButton
	Private txtAPIKey As SDUITextBox
	Private txtMessage As SDUITextBox
	Private txtTelephone As SDUITextBox
	Private btnSendTelegram As SDUIButton
	Private btnSendMessenger As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adcallmebotlayout")
	'
	Dim callmebot As String = banano.GetLocalStorage2("callmebot")
	callmebot = SDUIShared.CStr(callmebot)
	If callmebot <> "" Then
		Dim m As Map = banano.FromJson(callmebot)
		txtTelephone.Value = m.GetDefault("phone", "")
		txtAPIKey.Value = m.GetDefault("api", "")
	End If
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub btnSend_Click (e As BANanoEvent)
	'save settings
	Dim ls As Map = CreateMap()
	ls.Put("phone", txtTelephone.Value)
	ls.Put("api", txtAPIKey.Value)
	banano.SetLocalStorage2("callmebot", banano.ToJson(ls))
	'
	btnSend.Loading = True
	Dim api As SDUIFetch
	api.Initialize("https://api.callmebot.com/whatsapp.php")
	api.AddParameter("source", "web")
	api.AddParameter("phone", txtTelephone.Value)
	api.AddParameter("apikey", txtAPIKey.Value)
	api.AddParameter("text", txtMessage.Value)
	banano.Await(api.GetWait)
	btnSend.Loading = False
End Sub

Private Sub btnSendTelegram_Click (e As BANanoEvent)
	'save settings
	Dim ls As Map = CreateMap()
	ls.Put("phone", txtTelephone.Value)
	ls.Put("api", txtAPIKey.Value)
	banano.SetLocalStorage2("callmebot", banano.ToJson(ls))
	'
	btnSendTelegram.Loading = True
	Dim api As SDUIFetch
	api.Initialize("https://api.callmebot.com/text.php")
	api.AddParameter("user", txtTelephone.Value)
	api.AddParameter("text", txtMessage.Value)
	banano.Await(api.GetWait)
	btnSendTelegram.Loading = False
End Sub

Private Sub btnSendMessenger_Click (e As BANanoEvent)
	'save settings
	Dim ls As Map = CreateMap()
	ls.Put("phone", txtTelephone.Value)
	ls.Put("api", txtAPIKey.Value)
	banano.SetLocalStorage2("callmebot", banano.ToJson(ls))
	'
	btnSendMessenger.Loading = True
	Dim api As SDUIFetch
	api.Initialize("https://api.callmebot.com/facebook/send.php")
	api.AddParameter("apikey", txtAPIKey.Value)
	api.AddParameter("text", txtMessage.Value)
	banano.Await(api.GetWait)
	btnSendMessenger.Loading = False
End Sub