﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "footerx"
	Public title As String = "Footer"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	
	Dim f1 As SDUIFooter = page.Cell(1, 1).AddFooter("f1")
	f1.Root.P(10)
	f1.Root.BGColorIntensity(app.COLOR_BASE, 200)
	f1.TextColorIntensity(app.COLOR_BASE, "content")
	
	Dim c1 As SDUIDiv = f1.AddColumn("c1", "")
	c1.AddFooterTitle("services", "Services")
	c1.AddLink("branding", "Branding", "#").Hover
	c1.AddLink("design", "Design", "#").Hover
	c1.AddLink("marketing", "Marketing", "#").Hover
	c1.AddLink("advertising", "Advertising", "#").Hover
	
	
	Dim c2 As SDUIDiv = f1.AddColumn("c2", "")
	c2.AddFooterTitle("company", "Company")
	c2.AddLink("aboutus", "About Us", "#").Hover
	c2.AddLink("contactusfp", "Contact Us", "#").Hover
	c2.AddLink("jobs", "Jobs", "#").Hover
	c2.AddLink("press", "Press Kit", "#").Hover
	
	Dim c3 As SDUIDiv = f1.AddColumn("c3", "")
	c3.AddFooterTitle("legal", "Legal")
	c3.AddLink("tou", "Terms of Use", "#").Hover
	c3.AddLink("privacy", "Privacy Policy", "#").Hover
	c3.AddLink("cookies", "Cookie Policy", "#").Hover
	'
	Dim c4 As SDUIDiv = f1.AddColumn("c4", "")
	c4.AddFooterTitle("news", "Newsletter")
	c4.AddTextBoxLabel("subscribe", "Enter your email address", "").Suffix = "Subscribe"
	'
	Dim co1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("co1", "vb")
	co1.AddCode($"Dim f1 As SDUIFooter = page.Cell(1, 1).AddFooter("f1")"$)
	co1.AddCode($"f1.Root.P(10)"$)
	co1.AddCode($"f1.Root.BGColorIntensity(app.COLOR_BASE, 200)"$)
	co1.AddCode($"f1.TextColorIntensity(app.COLOR_BASE, "content")"$)
	 co1.AddCode($"Dim c1 As SDUIDiv = f1.AddColumn("c1", "")"$)
	 co1.AddCode($"c1.AddFooterTitle("services", "Services")"$)
	 co1.AddCode($"c1.AddLink("branding", "Branding", "#").Hover"$)
	 co1.AddCode($"c1.AddLink("design", "Design", "#").Hover"$)
	 co1.AddCode($"c1.AddLink("marketing", "Marketing", "#").Hover"$)
	 co1.AddCode($"c1.AddLink("advertising", "Advertising", "#").Hover"$)
	 co1.AddCode($"Dim c2 As SDUIDiv = f1.AddColumn("c2", "")"$)
	 co1.AddCode($"c2.AddFooterTitle("company", "Company")"$)
	 co1.AddCode($"c2.AddLink("aboutus", "About Us", "#").Hover"$)
	 co1.AddCode($"c2.AddLink("contactusfp", "Contact Us", "#").Hover"$)
	 co1.AddCode($"c2.AddLink("jobs", "Jobs", "#").Hover"$)
	 co1.AddCode($"c2.AddLink("press", "Press Kit", "#").Hover"$)
	 co1.AddCode($"Dim c3 As SDUIDiv = f1.AddColumn("c3", "")"$)
	 co1.AddCode($"c3.AddFooterTitle("legal", "Legal")"$)
	 co1.AddCode($"c3.AddLink("tou", "Terms of Use", "#").Hover"$)
	 co1.AddCode($"c3.AddLink("privacy", "Privacy Policy", "#").Hover"$)
	 co1.AddCode($"c3.AddLink("cookies", "Cookie Policy", "#").Hover"$)
	 co1.AddCode($"'"$)
	 co1.AddCode($"Dim c4 As SDUIDiv = f1.AddColumn("c4", "")"$)
	 co1.AddCode($"c4.AddFooterTitle("news", "Newsletter")"$)
	 co1.AddCode($"c4.AddTextBoxLabel("subscribe", "Enter your email address", "").Suffix = "Subscribe""$)
	 co1.Refresh
	'
	Dim f2 As SDUIFooter = page.Cell(3, 1).AddFooter("f2")
	f2.Root.P(10)
	f2.Root.BGColor(app.COLOR_PRIMARY)
	f2.TextColorIntensity(app.COLOR_PRIMARY,"content")
	f2.Center
	f2.Root.isrounded
	'
	Dim col1 As SDUIDiv = f2.AddColumn("title", "Sithaso Holdings")
	col1.FontBold
	col1.AddParagraph("col1p", "Copyright © 2022 - All right reserved")
	'
	Dim co2 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("co2", "vb")
	co2.AddCode($"Dim f2 As SDUIFooter = page.Cell(3, 1).AddFooter("f2")"$)
	co2.AddCode($"f2.Root.PA = 10"$)
	co2.AddCode($"f2.Root.BGColor = app.COLOR_PRIMARY"$)
	co2.AddCode($"f2.TextColorIntensity(app.COLOR_PRIMARY,"content")"$)
	co2.AddCode($"f2.Center"$)
	co2.AddCode($"f2.Root.isRounded"$)
	co2.AddCode($"'"$)
	co2.AddCode($"Dim col1 As SDUIDiv = f2.AddColumn("title", "Sithaso Holdings")"$)
	co2.AddCode($"col1.Root.FontBold"$)
	co2.AddCode($"col1.AddParagraph("col1p", "Copyright © 2022 - All right reserved")"$)
	co2.Refresh
End Sub
