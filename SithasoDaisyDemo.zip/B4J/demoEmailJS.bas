﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "ademailjs"
	Public title As String = "AD EmailJS"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIEmailJS1 As SDUIEmailJS
	Private tbEmail As SDUITable
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	''banano.Await(app.UsesTable)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "ademailjslayout")
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	tbEmail.ClearPropertyBag
	tbEmail.AddPropertyTextBox("ServiceId", "Service Id", "", "", True, "")
	tbEmail.AddPropertyTextBox("UserId", "Public Key", "", "", True, "")
	tbEmail.AddPropertyTextBox("TemplateId", "Template Id", "", "", True, "")
	tbEmail.AddPropertyTextBox("FromName", "From Name", "", "", False, "")
	tbEmail.AddPropertyTextBox("ReplyTo", "Reply To", "", "", False, "")
	tbEmail.AddPropertyTextBox("ToEmail", "To Email", "", "", True, "")
	tbEmail.AddPropertyTextBox("ToName", "To Name", "", "", False, "")
	tbEmail.AddPropertyTextBox("CcTo", "Cc To", "", "", False, "")
	tbEmail.AddPropertyTextArea("Subject", "Subject", "", "", True, "")
	tbEmail.AddPropertyTextArea("Message", "Message", "", "", False, "")
	
	tbEmail.AddPropertyActionButton("btnSend", "Send Email", app.COLOR_CYAN)
End Sub

Sub tbEmail_btnSend (e As BANanoEvent)
	Dim pValid As Boolean = tbEmail.PropertyBagIsValid
	If pValid = False Then
		app.ShowSwalError("The property bag content is not complete!")
		Return
	End If
	tbEmail.SetPropertyActionButtonLoading("btnSend", True)
'	Dim pbag As Map = tbEmail.GetPropetyBag
'	Log(pbag)
	
	SDUIEmailJS1.CcTo = tbEmail.GetPropertyValue("CcTo")
	SDUIEmailJS1.FromName = tbEmail.GetPropertyValue("FromName")
	SDUIEmailJS1.Message = tbEmail.GetPropertyValue("Message")
	SDUIEmailJS1.ReplyTo = tbEmail.GetPropertyValue("ReplyTo")
	SDUIEmailJS1.ServiceId = tbEmail.GetPropertyValue("ServiceId")
	SDUIEmailJS1.Subject = tbEmail.GetPropertyValue("Subject")
	SDUIEmailJS1.TemplateId = tbEmail.GetPropertyValue("TemplateId")
	SDUIEmailJS1.ToEmail = tbEmail.GetPropertyValue("ToEmail")
	SDUIEmailJS1.ToName = tbEmail.GetPropertyValue("ToName")
	SDUIEmailJS1.PublicKey = tbEmail.GetPropertyValue("UserId")
	Dim x As String = banano.Await(SDUIEmailJS1.SendEmail)
	tbEmail.SetPropertyActionButtonLoading("btnSend", False)
	app.ShowSwal(x)
End Sub

Private Sub tbEmail_Add (e As BANanoEvent)
	'clear the contents of the bag
	'tbEmail.ResetPropetyBag
End Sub