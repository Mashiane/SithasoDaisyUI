﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "admulticard"
	Public title As String = "AD Multi Card"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private dprojects As SDUIDiv
	Private pcard As SDUICard
	Private btnLike As SDUIButton
	Private btnComment As SDUIButton
	Private btnShare As SDUIButton
	Private btnWish As SDUIButton
	Private btnBuy As SDUIButton
End Sub


'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "admulticardlayout")
	btnLike = pcard.AddActionButtonIcon("like", "fa-solid fa-thumbs-up", app.COLOR_GHOST)
	btnLike.Circle.Icon.SizeXLarge.Color = "success"
	'
	btnComment = pcard.AddActionButtonIcon("comment", "fa-solid fa-comment", app.COLOR_GHOST)
	btnComment.Circle.Icon.SizeXLarge.Color = "warning"
	'
	btnShare = pcard.AddActionButtonIcon("share", "fa-solid fa-share", app.COLOR_GHOST)
	btnShare.Circle.Icon.SizeXLarge.Color = "accent"
	'
	btnWish = pcard.AddActionButtonIcon("wish", "fa-solid fa-heart", app.COLOR_GHOST)
	btnWish.Circle.Icon.SizeXLarge.Color = "red"
	'
	btnBuy = pcard.AddActionButton("buy", "Buy", "")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.dprojects", "dprojects", dprojects.CustProps)
	pgIndex.AddDesignKV1("SDUICard.pcard", "pcard", pcard.CustProps)
	
	'save the template to the app and hide it
	app.AddTemplateFromLayout("pcard", True, pcard.Children)
	
	'template:
	'{{image}}
	'{{title}}
	'{{price}}
	'{{pricecolor}}
	'{{description}}
	'create list with same fields
	
	Dim products As List
	products.Initialize
	products.Add(CreateMap("id":"p1", "image":"./assets/banner_7.jpg", "alt":"","title":"Amazing Product 1", "price":"3.00", "pricecolor":"success","description":"This product is..."))
	products.Add(CreateMap("id":"p2", "image":"./assets/10.jpg", "alt":"","title":"Amazing Product 2", "price":"29.00", "pricecolor":"accent","description":"This product is..."))
	products.Add(CreateMap("id":"p3", "image":"./assets/9.jpg", "alt":"","title":"Amazing Product 3", "price":"35.00", "pricecolor":"neutral","description":"This product is..."))
	products.Add(CreateMap("id":"p4", "image":"./assets/banner_8.jpg", "alt":"","title":"Amazing Product 4", "price":"360.00", "pricecolor":"secondary","description":"This product is..."))
	products.Add(CreateMap("id":"p5", "image":"./assets/nature_01.jpg", "alt":"","title":"Amazing Product 5", "price":"530.00", "pricecolor":"info","description":"This product is..."))
	products.Add(CreateMap("id":"p6", "image":"./assets/nature_09.jpg", "alt":"","title":"Amazing Product 6", "price":"333.00", "pricecolor":"warning","description":"This product is..."))
	products.Add(CreateMap("id":"p7", "image":"./assets/12.jpg", "alt":"","title":"Amazing Product 7", "price":"100.00", "pricecolor":"error","description":"This product is..."))
	
	'update the parent fom the template using the list
	app.SetItemsFromTemplate(Me, "dprojects", "pcard", "", products)
	'bind the action buttons
	pcard.BindActions(products)
	'
	BuildPage
End Sub

Sub pcard_click (e As BANanoEvent)
	e.PreventDefault
	'get the clicked element id
	Dim item As String = app.GetIDFromEvent(e)
	Dim strItem As String = SDUIShared.MvField(item, 1, "_")
	Dim strAction As String = SDUIShared.MvField(item, 2, "_")
	Select Case strAction
	Case "like", "comment", "share", "wish", "buy"
		app.ShowSwal($"${strAction}:${strItem}"$)
	Case Else
		app.showswal(item)
	End Select
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
