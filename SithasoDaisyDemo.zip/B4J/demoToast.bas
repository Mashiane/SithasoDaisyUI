﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "toasts"
	Public title As String = "Toast"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub



private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns8
	page.Root.BuildGrid
	'
	Dim t1 As SDUIToast
	t1.AddToast(Me, page.CellID(1, 1), "t1", "A new message has arrived!")
	t1.Alert.Info
	t1.TopRight
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim t1 As SDUIToast"$)
	c1.AddCode($"t1.AddToast(Me, page.CellID(1, 1), "t1", "A new message has arrived!")"$)
	c1.AddCode($"t1.Alert.Info"$)
	c1.AddCode($"t1.TopRight"$)
	c1.Refresh
	'
	Dim t2 As SDUIToast = page.Cell(2, 1).AddToast("t2", "A new message has arrived!")
	t2.Alert.Success
	t2.BottomRight
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim t2 As SDUIToast = page.Cell(2, 1).AddToast("t2", "A new message has arrived!")"$)
	c2.AddCode($"t2.Alert.Success"$)
	c2.AddCode($"t2.BottomRight"$)
	c2.Refresh
End Sub