﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adsignature"
	Public title As String = "AD Signature"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private btnClear As SDUIButton
	Private btnSave As SDUIButton
	Private SDUICol1 As SDUICol
	Private SDUICol2 As SDUICol
	Private SDUIRow1 As SDUIRow
	Private SDUISignaturePad1 As SDUISignaturePad
	Private SDUICol3 As SDUICol
	Private SDUIRow2 As SDUIRow
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesSignaturePad)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adsignaturelayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnClear", "btnClear", btnClear.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnSave", "btnSave", btnSave.CustProps)
	pgIndex.AddDesignKV1("SDUICol.SDUICol1", "SDUICol1", SDUICol1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.SDUICol2", "SDUICol2", SDUICol2.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.SDUIRow1", "SDUIRow1", SDUIRow1.CustProps)
	pgIndex.AddDesignKV1("SDUISignaturePad.SDUISignaturePad1", "SDUISignaturePad1", SDUISignaturePad1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.SDUICol3", "SDUICol3", SDUICol3.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.SDUIRow2", "SDUIRow2", SDUIRow2.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub btnSave_Click (e As BANanoEvent)
	SDUISignaturePad1.download
End Sub

Private Sub btnClear_Click (e As BANanoEvent)
	SDUISignaturePad1.clear
End Sub