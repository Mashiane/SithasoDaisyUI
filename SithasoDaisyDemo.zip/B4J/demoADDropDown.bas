﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "addropdown"
	Public title As String = "AD DropDown"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIDropDown1 As SDUIDropDown
	Private SDUIDropDown2 As SDUIDropDown
	Private SDUIDropDown3 As SDUIDropDown
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "addropdownlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIDropDown.SDUIDropDown1", "SDUIDropDown1", SDUIDropDown1.CustProps)
	pgIndex.AddDesignKV1("SDUIDropDown.SDUIDropDown2", "SDUIDropDown2", SDUIDropDown2.CustProps)
	pgIndex.AddDesignKV1("SDUIDropDown.SDUIDropDown3", "SDUIDropDown3", SDUIDropDown3.CustProps)

	'
	'SDUIDropDown1.SetItemColorIntensity(app.COLOR_PINK, 200)
	SDUIDropDown1.AddItem("item1", "Item 1")
	SDUIDropDown1.AddItem("item2", "Item 2")
	SDUIDropDown1.AddItem("item3", "Item 3")
	SDUIDropDown1.AddItemIcon("item4", "fa-solid fa-house", "Item 4")
	SDUIDropDown1.AddItemIcon("item5", "fa-solid fa-circle-info",  "Item 5")
	SDUIDropDown1.AddItemIcon("item6", "fa-solid fa-wifi",  "Item 6")
	SDUIDropDown1.SetItemBadgeValue("item3", "20")
	SDUIDropDown1.SetItemBadgeColor("item6", app.COLOR_WARNING)
	'BuildPage
	SDUIDropDown2.AddItem("item1", "Item 1")
	SDUIDropDown2.AddItem("item2", "Item 2")
	SDUIDropDown2.AddItem("item3", "Item 3")
	SDUIDropDown2.AddItemIcon("item4", "fa-solid fa-house", "Item 4")
	SDUIDropDown2.AddItemIcon("item5", "fa-solid fa-circle-info",  "Item 5")
	SDUIDropDown2.AddItemIcon("item6", "fa-solid fa-wifi",  "Item 6")
	'
	SDUIDropDown3.AddItem("item1", "Item 1")
	SDUIDropDown3.AddItem("item2", "Item 2")
	SDUIDropDown3.AddItem("item3", "Item 3")
	SDUIDropDown3.AddItemIcon("item4", "fa-solid fa-house", "Item 4")
	SDUIDropDown3.AddItemIcon("item5", "fa-solid fa-circle-info",  "Item 5")
	SDUIDropDown3.AddItemIcon("item6", "fa-solid fa-wifi",  "Item 6")
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIDropDown1_Click (item As String)
	app.ShowSwalInfo(item)	
End Sub

Private Sub SDUIDropDown3_Click (item As String)
	app.ShowSwalInfo(item)
End Sub

Private Sub SDUIDropDown2_Click (item As String)
	app.ShowSwalInfo(item)
End Sub