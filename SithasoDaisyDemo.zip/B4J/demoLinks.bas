﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "links"
	Public title As String = "Links"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim lnk As SDUILink = page.Cell(1, 1).AddLink("lnk", "Normal Link", "#")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim lnk As SDUILink = page.Cell(1, 1).AddLink("lnk", "Normal Link", "#")"$)
	c1.Refresh
	'
	Dim lnk1 As SDUILink = page.cell(2,1).AddLink("lnk1", "Primary Link", "#")
	lnk1.color = app.COLOR_PRIMARY
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim lnk1 As SDUILink = page.cell(2,1).AddLink("lnk1", "Primary Link", "#")"$)
	c2.AddCode($"lnk1.color = app.COLOR_PRIMARY"$)
	c2.Refresh
	'
	Dim lnk2 As SDUILink = page.cell(3,1).AddLink("lnk2", "Secondary Link", "#")
	lnk2.Color = app.COLOR_SECONDARY
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim lnk2 As SDUILink = page.cell(3,1).AddLink("lnk2", "Secondary Link", "#")"$)
	c3.AddCode($"lnk2.Color = app.COLOR_SECONDARY"$)
	c3.Refresh
	'
	Dim lnk3 As SDUILink = page.cell(4,1).AddLink("lnk3", "Hover Link", "#")
	lnk3.Hover
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim lnk3 As SDUILink = page.cell(4,1).AddLink("lnk3", "Hover Link", "#")"$)
	c4.AddCode($"lnk3.Hover"$)
	c4.Refresh
End Sub
