﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "buttons"
	Public title As String = "Buttons"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private btn As SDUIButton
	Private btn27 As SDUIButton
	Private btnx As SDUIButton
	Private btnbmp As SDUIButton
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows12.AddColumns4p8
	page.Root.AddRows12.AddColumns4p8
	page.Root.AddRows12.AddColumns4p8
	page.Root.AddRows12.AddColumns4p8
	page.Root.BuildGrid
	'start adding you components here
		
	btn = page.Cell(1, 1).AddButton("btn1", "Click Me")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode("'add a button on R1C1 of the grid")
	c1.AddCode($"btn = page.Cell(1, 1).AddButton("btn1", "Click Me")"$)
	c1.AddCode("'trap click event")
	c1.AddCode($"Private Sub btn1_Click (e As BANanoEvent)"$)
	c1.AddCode($"btn.Caption = "Clicked!""$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	
	Dim btnRounded As SDUIButton = page.Cell(2, 1).AddButton("btn2", "Round Full")
	btnRounded.NormalCase = True
	btnRounded.RoundedFull
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim btnRounded As SDUIButton = page.Cell(1, 1).AddButton("btn2", "Round Full")"$)
	c2.AddCode($"btnisrounded.NormalCase = True"$)
	c2.AddCode($"btnisrounded.RoundedFull"$)
	c2.Refresh
	
	Dim btnOutline As SDUIButton = page.Cell(3, 1).AddButton("btn3", "Outline")
	btnOutline.Outline
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim btnOutline As SDUIButton = page.Cell(3, 1).AddButton("btn3", "Outline")"$)
	c3.AddCode($"btnOutline.Outline"$)
	c3.Refresh
	
	'
	Dim btnPrimary As SDUIButton = page.Cell(4, 1).AddButton("btn4", "Primary")
	btnPrimary.color = app.COLOR_PRIMARY
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim btnPrimary As SDUIButton = page.Cell(4, 1).AddButton("btn4", "Primary")"$)
	c4.AddCode($"btnPrimary.color = app.COLOR_PRIMARY"$)
	c4.Refresh
	
	'
	Dim btn5 As SDUIButton = page.Cell(5, 1).AddButton("btn5", "Secondary")
	btn5.color = app.COLOR_SECONDARY
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim btn5 As SDUIButton = page.Cell(5, 1).AddButton("btn5", "Secondary")"$)
	c5.AddCode($"btn5.color = app.COLOR_SECONDARY"$)
	c5.Refresh
	
	Dim btn6 As SDUIButton = page.Cell(6, 1).AddButton("btn6", "Accent")
	btn6.Color = app.COLOR_ACCENT
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim btn6 As SDUIButton = page.Cell(6, 1).AddButton("btn6", "Accent")"$)
	c6.AddCode($"btn6.Color = app.COLOR_ACCENT"$)
	c6.Refresh
	
	'
	Dim btn7 As SDUIButton = page.Cell(7, 1).AddButton("btn7", "Info")
	btn7.color = app.COLOR_INFO
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim btn7 As SDUIButton = page.Cell(7, 1).AddButton("btn7", "Info")"$)
	c7.AddCode($"btn7.color = app.COLOR_INFO"$)
	c7.Refresh
	
	'
	Dim btn8 As SDUIButton = page.Cell(8, 1).AddButton("btn8", "Success")
	btn8.color = app.COLOR_SUCCESS
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"Dim btn8 As SDUIButton = page.Cell(8, 1).AddButton("btn8", "Success")"$)
	c8.AddCode($"btn8.color = app.COLOR_SUCCESS"$)
	c8.Refresh
	
	'
	Dim btn9 As SDUIButton = page.Cell(9, 1).AddButton("btn9", "Warning")
	btn9.color = app.COLOR_WARNING
	'
	Dim c9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"Dim btn9 As SDUIButton = page.Cell(9, 1).AddButton("btn9", "Warning")"$)
	c9.AddCode($"btn9.color = app.COLOR_WARNING"$)
	c9.Refresh
	
	'
	Dim btn10 As SDUIButton = page.Cell(10, 1).AddButton("btn10", "Error")
	btn10.color = app.COLOR_ERROR
	'
	Dim c10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c10", "vb")
	c10.AddCode($"Dim btn10 As SDUIButton = page.Cell(10, 1).AddButton("btn10", "Error")"$)
	c10.AddCode($"btn10.color = app.COLOR_ERROR"$)
	c10.Refresh
	
	'
	Dim btn11 As SDUIButton = page.Cell(11, 1).AddButton("btn11", "Ghost")
	btn11.Ghost
	'
	Dim c11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("c11", "vb")
	c11.AddCode($"Dim btn11 As SDUIButton = page.Cell(11, 1).AddButton("btn11", "Ghost")"$)
	c11.AddCode($"btn11.Ghost"$)
	c11.Refresh
	
	
	'
	Dim btn12 As SDUIButton = page.Cell(12, 1).AddButton("btn12", "Active")
	btn12.Active = True
	'
	Dim c12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("c12", "vb")
	c12.AddCode($"Dim btn12 As SDUIButton = page.Cell(12, 1).AddButton("btn12", "Active")"$)
	c12.AddCode($"btn12.Active = True"$)
	c12.Refresh
	
	'
	Dim btn13 As SDUIButton = page.Cell(13, 1).AddButton("btn13", "Disabled")
	btn13.Disable
	'
	Dim c13 As SDUIMockupCode = page.Cell(13, 2).AddMockUpCode("c13", "vb")
	c13.AddCode($"Dim btn13 As SDUIButton = page.Cell(13, 1).AddButton("btn13", "Disabled")"$)
	c13.AddCode($"btn13.Disable"$)
	c13.Refresh
	
	
	
	'
	Dim btn14 As SDUIButton = page.Cell(14, 1).AddButton("btn14", "Glass")
	btn14.Glass
	page.Cell(14, 1).BackgroundImage("./assets/arch.jpg")
	page.Cell(14, 1).RoundedBox
	page.Cell(14, 1).PlaceItemsCenter
	'
	Dim c14 As SDUIMockupCode = page.Cell(14, 2).AddMockUpCode("c14", "vb")
	c14.AddCode($"Dim btn14 As SDUIButton = page.Cell(14, 1).AddButton("btn14", "Glass")"$)
	c14.AddCode($"btn14.Glass"$)
	c14.AddCode($"page.Cell(14, 1).BackgroundImage("./assets/arch.jpg")"$)
	c14.AddCode($"page.Cell(14, 1).Root.RoundedBox"$)
	c14.AddCode($"page.Cell(14, 1).Root.PlaceItemsCenter"$)
	c14.Refresh
	
	'
	Dim btn15 As SDUIButton = page.Cell(15, 1).AddButton("btn15", "No Animation")
	btn15.Root.NoAnimation
	'
	Dim c15 As SDUIMockupCode = page.Cell(15, 2).AddMockUpCode("c15", "vb")
	c15.AddCode($"Dim btn15 As SDUIButton = page.Cell(15, 1).AddButton("btn15", "No Animation")"$)
	c15.AddCode($"btn15.Root.NoAnimation"$)
	c15.Refresh
	
	
	'
	Dim btn16 As SDUIButton = page.Cell(16, 1).AddButton("btn16", "Loading")
	btn16.Loading = True
	'
	Dim c16 As SDUIMockupCode = page.Cell(16, 2).AddMockUpCode("c16", "vb")
	c16.AddCode($"Dim btn16 As SDUIButton = page.Cell(16, 1).AddButton("btn16", "Loading")"$)
	c16.AddCode($"btn16.Loading = True"$)
	c16.Refresh
	
	
	'
	Dim btn17 As SDUIButton = page.Cell(17, 1).AddButton("btn17", "Link")
	btn17.Link
	'
	Dim c17 As SDUIMockupCode = page.Cell(17, 2).AddMockUpCode("c17", "vb")
	c17.AddCode($"Dim btn17 As SDUIButton = page.Cell(17, 1).AddButton("btn17", "Link")"$)
	c17.AddCode($"btn17.Link"$)
	c17.Refresh
	
	'
	Dim btn18 As SDUIButton = page.Cell(18, 1).AddButton("btn18", "Large")
	btn18.size = app.SIZE_LG
	'
	Dim c18 As SDUIMockupCode = page.Cell(18, 2).AddMockUpCode("c18", "vb")
	c18.AddCode($"Dim btn18 As SDUIButton = page.Cell(18, 1).AddButton("btn18", "Large")"$)
	c18.AddCode($"btn18.size = app.SIZE_LG"$)
	c18.Refresh
	
	
	'
	Dim btn19 As SDUIButton = page.Cell(19, 1).AddButton("btn19", "Small")
	btn19.size = app.SIZE_SM
	'
	Dim c19 As SDUIMockupCode = page.Cell(19, 2).AddMockUpCode("c19", "vb")
	c19.AddCode($"Dim btn19 As SDUIButton = page.Cell(19, 1).AddButton("btn19", "Small")"$)
	c19.AddCode($"btn19.size = app.SIZE_SM"$)
	c19.Refresh
	
	'
	Dim btn20 As SDUIButton = page.Cell(20, 1).AddButton("btn20", "Tiny")
	btn20.size = app.SIZE_XS
	'
	Dim c20 As SDUIMockupCode = page.Cell(20, 2).AddMockUpCode("c20", "vb")
	c20.AddCode($"Dim btn20 As SDUIButton = page.Cell(20, 1).AddButton("btn20", "Tiny")"$)
	c20.AddCode($"btn20.size = app.SIZE_XS"$)
	c20.Refresh
		
	Dim btn21 As SDUIButton = page.Cell(21, 1).AddButtonIcon("btn21", "S", "fa-solid fa-hospital")
	btn21.Square
	'
	Dim c21 As SDUIMockupCode = page.Cell(21, 2).AddMockUpCode("c21", "vb")
	c21.AddCode($"Dim btn21 As SDUIButton = page.Cell(21, 1).AddButtonIcon("btn21", "S", "fa-solid fa-hospital")"$)
	c21.AddCode($"btn21.Square"$)
	c21.Refresh
	
	'
	Dim btn22 As SDUIButton = page.Cell(22, 1).AddButtonIcon("btn22", "C", "fa-solid fa-house")
	btn22.Circle 
	'
	Dim c22 As SDUIMockupCode = page.Cell(22, 2).AddMockUpCode("c22", "vb")
	c22.AddCode($"Dim btn22 As SDUIButton = page.Cell(22, 1).AddButtonIcon("btn22", "C", "fa-house")"$)
	c22.AddCode($"btn22.Circle"$)
	c22.Refresh
	'
	Dim btn23 As SDUIButton = page.Cell(23, 1).AddButton("btn23", "Mashy")
	btn23.RightIconName = "fa-solid fa-house"
	'
	Dim c23 As SDUIMockupCode = page.Cell(23, 2).AddMockUpCode("c23", "vb")
	c23.AddCode($"Dim btn23 As SDUIButton = page.Cell(23, 1).AddButton("btn23", "Mashy")"$)
	c23.AddCode($"btn23.RightIconName = "fa-solid fa-house""$)
	c23.Refresh
	
	Dim btn24 As SDUIButton = page.Cell(24, 1).AddButton("btn24", "Mashy")
	btn24.LeftIconName = "fa-solid fa-house"
	'
	Dim c24 As SDUIMockupCode = page.Cell(24, 2).AddMockUpCode("c24", "vb")
	c24.AddCode($"Dim btn24 As SDUIButton = page.Cell(24, 1).AddButton("btn24", "Mashy")"$)
	c24.AddCode($"btn24.LeftIcon = "fa-solid fa-house""$)
	c24.Refresh
	'
	btnx = page.Cell(25, 1).AddButtonBadge("btnx", "Inbox", "+99")
	btnx.Badge.color = app.COLOR_SECONDARY
	'
	Dim c25 As SDUIMockupCode = page.Cell(25, 2).AddMockUpCode("c25", "vb")
	c25.AddCode($"Dim btnx As SDUIButton = page.Cell(25, 1).AddButtonBadge("btnx", "Inbox", "+99")"$)
	c25.AddCode($"btnx.Badge.color = app.COLOR_SECONDARY"$)
	c25.Refresh
	'
	Dim three3 As SDUIButton = page.Cell(26, 1).AddButton("test2", "Button")
	three3.Root.BGColorIntensity("blue", 500)
	three3.Root.HoverBGColorIntensity("blue", 400)
	three3.Root.AddClass("border-b-4")
	three3.Root.BorderColorIntensity("blue", 700)
	three3.Root.HoverBorderColorIntensity("blue", 500)
	three3.Root.TextColor(app.COLOR_WHITE)
	three3.Root.TextCenter
	three3.Root.isrounded
	'
	Dim c29 As SDUIMockupCode = page.Cell(26, 2).AddMockUpCode("c29", "vb")
	c29.AddCode($"Dim three3 As SDUIButton = page.Cell(26, 1).AddButton("test2", "Button")"$)
	c29.AddCode($"three3.Root.BGColorIntensity("blue", 500)"$)
	c29.AddCode($"three3.Root.HoverBGColorIntensity("blue", 400)"$)
	c29.AddCode($"three3.Root.AddClass("border-b-4")"$)
	c29.AddCode($"three3.Root.BorderColorIntensity("blue", 700)"$)
	c29.AddCode($"three3.Root.HoverBorderColorIntensity("blue", 500)"$)
	c29.AddCode($"three3.Root.TextColor(app.COLOR_WHITE)"$)
	c29.AddCode($"three3.Root.TextCenter"$)
	c29.AddCode($"three3.Root.isrounded"$)
	c29.Refresh
	
	page.Root.AddFAB("fab", "fa-solid fa-house", "20", "20")
	
	btn27 = page.Cell(27, 1).AddButtonIndicator("btn27", "Messages", "20")
	btn27.BadgeColor = app.color_primary
	'
	Dim c30 As SDUIMockupCode = page.Cell(27, 2).AddMockUpCode("c30", "vb")
	c30.AddCode($"Dim btn27 As SDUIButton = page.Cell(27, 1).AddButtonIndicator("btn27", "Messages", "20")"$)
	c30.AddCode($"btn27.BadgeColor = app.color_primary"$)
	c30.Refresh

	Dim c28 As SDUIMockupCode = page.Cell(28, 2).AddMockUpCode("c28", "vb")
	c28.AddCode($"page.Root.AddFAB("fab", "fa-house", "20", "20")"$)
	c28.Refresh
	'
	btnbmp = page.Cell(29, 1).AddButtonMinusPlus("bmp", app.COLOR_PRIMARY, app.SIZE_MD)
	'
	Dim c31 As SDUIMockupCode = page.Cell(29, 2).AddMockUpCode("c31", "vb")
	c31.AddCode($"btnbmp = page.Cell(29, 1).AddButtonMinusPlus("bmp", app.COLOR_PRIMARY, app.SIZE_MD)"$)
	c31.AddCode($"'"$)
	c31.AddCode($"Private Sub bmp_Minus_Click (e As BANanoEvent)"$)
	c31.AddCode($"btnbmp.Decrement"$)
	c31.AddCode($"End Sub"$)
	c31.AddCode($"'"$)
	c31.AddCode($"Private Sub bmp_Plus_Click (e As BANanoEvent)"$)
	c31.AddCode($"btnbmp.Increment"$)
	c31.AddCode($"End Sub"$)
	c31.Refresh
End Sub

Private Sub bmp_Minus_Click (e As BANanoEvent)
	btnbmp.Decrement
End Sub

Private Sub bmp_Plus_Click (e As BANanoEvent)
	btnbmp.Increment
End Sub

Private Sub btn1_Click (e As BANanoEvent)
	btn.Caption = "Clicked!"
End Sub

Private Sub btn27_Click (e As BANanoEvent)
	btn27.BadgeValue = Rnd(1, 100)	
End Sub

Sub btnx_click(e As BANanoEvent)
	btnx.BadgeValue = Rnd(1, 100)
End Sub