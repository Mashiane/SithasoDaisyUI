﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "indicators"
	Public title As String = "Indicators"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	
	'start adding you components here
	Dim ind1 As SDUIIndicator
	ind1.AddIndicator(Me, page.CellID(1, 1), "ind1")
	ind1.Badge.color = app.COLOR_SECONDARY
	Dim div1 As SDUIDiv = ind1.AddDiv("div1", 32, 32)
	div1.Grid.BGColorIntensity(app.COLOR_BASE, 300).PlaceItemsCenter
	div1.Caption = "content"
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim ind1 As SDUIIndicator"$)
	c1.AddCode($"ind1.AddIndicator(Me, page.CellID(1, 1), "ind1")"$)
	c1.AddCode($"ind1.Badge.color = app.COLOR_SECONDARY"$)
	c1.AddCode($"Dim div1 As SDUIDiv = ind1.AddDiv("div1", 32, 32)"$)
	c1.AddCode($"div1.Root.Grid"$)
	c1.AddCode($"div1.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c1.AddCode($"div1.Root.PlaceItemsCenter"$)
	c1.AddCode($"div1.Caption = "content""$)
	c1.Refresh
	'
	Dim ind2 As SDUIIndicator = page.Cell(2, 1).AddIndicator("ind2")
	ind2.Badge.color = app.COLOR_PRIMARY
	ind2.Badge.Caption = "new"
	'
	Dim div2 As SDUIDiv = ind2.AddDiv("div2", 32, 32)
	div2.Grid
	div2.BGColorIntensity(app.COLOR_BASE, 300)
	div2.PlaceItemsCenter
	div2.Caption = "content"
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim ind2 As SDUIIndicator = page.Cell(2, 1).AddIndicator("ind2")"$)
	c2.AddCode($"ind2.Badge.color = app.COLOR_PRIMARY"$)
	c2.AddCode($"ind2.Badge.Caption = "new""$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim div2 As SDUIDiv = ind2.AddDiv("div2", 32, 32)"$)
	c2.AddCode($"div2.Root.Grid"$)
	c2.AddCode($"div2.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c2.AddCode($"div2.Root.PlaceItemsCenter"$)
	c2.AddCode($"div2.Caption = "content""$)
	c2.Refresh
	'
	Dim ind3 As SDUIIndicator
	ind3.AddIndicator(Me, page.CellID(3, 1), "ind3")
	ind3.Badge.color = app.COLOR_SECONDARY
	ind3.AtStart
	Dim div3 As SDUIDiv = ind3.AddDiv("div3", 32, 32)
	div3.Grid
	div3.BGColorIntensity(app.COLOR_BASE, 300)
	div3.PlaceItemsCenter
	div3.Caption = "content"
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim ind3 As SDUIIndicator"$)
	c3.AddCode($"ind3.AddIndicator(Me, page.CellID(3, 1), "ind3")"$)
	c3.AddCode($"ind3.Badge.color = app.COLOR_SECONDARY"$)
	c3.AddCode($"ind3.AtStart"$)
	c3.AddCode($"Dim div3 As SDUIDiv = ind3.AddDiv("div3", 32, 32)"$)
	c3.AddCode($"div3.Root.Grid"$)
	c3.AddCode($"div3.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c3.AddCode($"div3.Root.PlaceItemsCenter"$)
	c3.AddCode($"div3.Caption = "content""$)
	c3.Refresh
	'
	Dim ind4 As SDUIIndicator
	ind4.AddIndicator(Me, page.CellID(4, 1), "ind4")
	ind4.Badge.color = app.COLOR_SECONDARY
	ind4.AtCenter
	Dim div4 As SDUIDiv = ind4.AddDiv("div4", 32, 32)
	div4.Grid 
	div4.BGColorIntensity(app.COLOR_BASE, 300)
	div4.PlaceItemsCenter
	div4.Caption = "content"
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim ind4 As SDUIIndicator"$)
	c4.AddCode($"ind4.AddIndicator(Me, page.CellID(4, 1), "ind4")"$)
	c4.AddCode($"ind4.Badge.color = app.COLOR_SECONDARY"$)
	c4.AddCode($"ind4.AtCenter"$)
	c4.AddCode($"Dim div4 As SDUIDiv = ind4.AddDiv("div4", 32, 32)"$)
	c4.AddCode($"div4.Root.Grid"$)
	c4.AddCode($"div4.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c4.AddCode($"div4.Root.PlaceItemsCenter"$)
	c4.AddCode($"div4.Caption = "content""$)
	c4.Refresh
	'
	Dim ind5 As SDUIIndicator
	ind5.AddIndicator(Me, page.CellID(5, 1), "ind5")
	ind5.Badge.color = app.COLOR_SECONDARY
	ind5.AtCenter
	ind5.AtMiddle
	Dim div5 As SDUIDiv = ind5.AddDiv("div5", 32, 32)
	div5.Grid
	div5.BGColorIntensity(app.COLOR_BASE, 300)
	div5.PlaceItemsCenter
	div5.Caption = "content"
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim ind5 As SDUIIndicator"$)
	c5.AddCode($"ind5.AddIndicator(Me, page.CellID(5, 1), "ind5")"$)
	c5.AddCode($"ind5.Badge.color = app.COLOR_SECONDARY"$)
	c5.AddCode($"ind5.AtCenter"$)
	c5.AddCode($"ind5.AtMiddle"$)
	c5.AddCode($"Dim div5 As SDUIDiv = ind5.AddDiv("div5", 32, 32)"$)
	c5.AddCode($"div5.Root.Grid"$)
	c5.AddCode($"div5.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c5.AddCode($"div5.Root.PlaceItemsCenter"$)
	c5.AddCode($"div5.Caption = "content""$)
	c5.Refresh
	'
	Dim ind6 As SDUIIndicator
	ind6.AddIndicator(Me, page.CellID(6, 1), "ind6")
	ind6.Badge.color = app.COLOR_SECONDARY
	ind6.AtMiddle
	Dim div6 As SDUIDiv = ind6.AddDiv("div6", 32, 32)
	div6.Grid 
	div6.BGColorIntensity(app.COLOR_BASE, 300)
	div6.PlaceItemsCenter
	div6.Caption = "content"
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim ind6 As SDUIIndicator"$)
	c6.AddCode($"ind6.AddIndicator(Me, page.CellID(6, 1), "ind6")"$)
	c6.AddCode($"ind6.Badge.color = app.COLOR_SECONDARY"$)
	c6.AddCode($"ind6.AtMiddle"$)
	c6.AddCode($"Dim div6 As SDUIDiv = ind6.AddDiv("div6", 32, 32)"$)
	c6.AddCode($"div6.Root.Grid"$)
	c6.AddCode($"div6.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c6.AddCode($"div6.Root.PlaceItemsCenter"$)
	c6.AddCode($"div6.Caption = "content""$)
	c6.Refresh
	'
	Dim ind7 As SDUIIndicator
	ind7.AddIndicator(Me, page.CellID(7, 1), "ind7")
	ind7.Badge.color = app.COLOR_SECONDARY
	ind7.AtBottom
	ind7.AtCenter
	Dim div7 As SDUIDiv = ind7.AddDiv("div7", 32, 32)
	div7.Grid
	div7.BGColorIntensity(app.COLOR_BASE, 300)
	div7.PlaceItemsCenter
	div7.Caption = "content"
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim ind7 As SDUIIndicator"$)
	c7.AddCode($"ind7.AddIndicator(Me, page.CellID(7, 1), "ind7")"$)
	c7.AddCode($"ind7.Badge.color = app.COLOR_SECONDARY"$)
	c7.AddCode($"ind7.AtBottom"$)
	c7.AddCode($"ind7.AtCenter"$)
	c7.AddCode($"Dim div7 As SDUIDiv = ind7.AddDiv("div7", 32, 32)"$)
	c7.AddCode($"div7.Root.Grid"$)
	c7.AddCode($"div7.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c7.AddCode($"div7.Root.PlaceItemsCenter"$)
	c7.AddCode($"div7.Caption = "content""$)
	c7.Refresh
	'
	Dim ind8 As SDUIIndicator
	ind8.AddIndicator(Me, page.CellID(8, 1), "ind8")
	ind8.Badge.color = app.COLOR_SECONDARY
	ind8.AtBottom
	Dim div8 As SDUIDiv = ind8.AddDiv("div8", 32, 32)
	div8.Grid 
	div8.BGColorIntensity(app.COLOR_BASE, 300)
	div8.PlaceItemsCenter
	div8.Caption = "content"
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"Dim ind8 As SDUIIndicator"$)
	c8.AddCode($"ind8.AddIndicator(Me, page.CellID(8, 1), "ind8")"$)
	c8.AddCode($"ind8.Badge.color = app.COLOR_SECONDARY"$)
	c8.AddCode($"ind8.AtBottom"$)
	c8.AddCode($"Dim div8 As SDUIDiv = ind8.AddDiv("div8", 32, 32)"$)
	c8.AddCode($"div8.Root.Grid"$)
	c8.AddCode($"div8.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c8.AddCode($"div8.Root.PlaceItemsCenter"$)
	c8.AddCode($"div8.Caption = "content""$)
	c8.Refresh
End Sub
