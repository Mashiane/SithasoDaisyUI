﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adlistview"
	Public title As String = "AD ListView"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIListView1 As SDUIListView
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adlistviewlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIListView.SDUIListView1", "SDUIListView1", SDUIListView1.CustProps)

	SDUIListView1.AddItem("p1", "./assets/face5.jpg", "John Doe", "Missisipi", "48")
	SDUIListView1.AddItem("p2", "./assets/face1.jpg", "John Doe 1", "Missisip", "47")
	SDUIListView1.AddItem("p3", "./assets/face2.jpg", "John Doe 2", "Missisi", "46")
	SDUIListView1.AddItem("p4", "./assets/face3.jpg", "John Doe 3", "Missis", "")
	SDUIListView1.AddItem("p5", "./assets/face4.jpg", "John Doe 3", "Missi", "44")
	
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIListView1_Click (item As String)
	app.ShowSwal(item)
End Sub