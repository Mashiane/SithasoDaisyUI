﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables9"
	Public title As String = "Table 9"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
	Private tb4 As SDUITable
	Private timeUpdate As Timer
	Private tblPos As Int
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "gender":"male", "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"", "tob":"", "agroup":"","tags":"b4x:primary;b4a:success;b4i:secondary;b4r:error;b4j:accent"))
	Items.Add(CreateMap("hours": 5, "gender":"female", "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Anna Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/Anna.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"","tob":"","agroup":"","tags":"b4x:primary;b4a:success"))
	Items.Add(CreateMap("hours": 8, "gender":"male", "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"","tob":"","agroup":"","tags":"b4x;b4a;b4i;b4r;b4j"))
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table5
	Table5Code
End Sub

Sub Table5Code
	Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
	c5.AddCode($"Sub Build_Table5"$)
	c5.AddCode($"tb4 = page.Cell(1, 1).AddTable("tb4")"$)
	c5.AddCode($"tb4.AddColumnBadgeAvatarTitle("avatar", "Resource", "10", "name", "")"$)
	c5.AddCode($"tb4.AddColumnBadgeGroup("tags", "Tags", "10")"$)
	c5.AddCode($"banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate"$)
	c5.AddCode($"tb4.SetRowColumn("tags", 1, ~"a:success; n:warning; e:primary; l:neutral; e:error"~)"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
End Sub

Sub Build_Table5
	tb4 = page.Cell(1, 1).AddTable("tb4")
	tb4.AddColumnBadgeAvatarTitle("avatar", "Resource", "10", "name", "")
	tb4.AddColumnBadgeGroup("tags", "Tags", "10")
	'
	tb4.AddColumnFileInputProgress("pfile", "File Progress", "lg", "40px", "fa-solid fa-arrow-up-from-bracket", "secondary")
	tb4.AddColumnFileInputProgressCamera("fcamera", "Camera", "lg", "40px", "success")
	tb4.AddColumnFileInputProgressCamCorder("fCamCorder", "CamCorder", "lg", "40px", "primary")
	tb4.AddColumnFileInputProgressMicrophone("fMicrophone", "Microphone", "lg", "40px", "warning")
	'
	banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate
	tb4.SetRowColumn("tags", 1, $"a:success; n:warning; e:primary; l:neutral; e:error"$)
End Sub

Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	Select Case Column
	Case "pfile", "fcamera", "fcamcorder", "fmicrophone"
		'get file details
		Dim fileDet As FileObject
		fileDet = SDUIShared.GetFileDetails(Value)
		Log(fileDet)
		'get the file name
		Dim fn As String = fileDet.FileName
		'you can check the size here
		Dim fs As Long = fileDet.FileSize
		If fs >= 5000 Then
		End If
		'read the file details as JSON
		'Dim fText As String = banano.Await(SDUIShared.GetFileAsDataURL(value))
		'Dim fJSON As Map = BANano.Await(SDUIShared.readAsJsonWait(value))
		'Dim fBuffer As Object = BANano.Await(SDUIShared.readAsArrayBufferWait(value))
		'Dim fText As String = BANano.Await(SDUIShared.readAsTextWait(value))
		'Dim fText As String = BANano.Await(SDUIShared.readAsDataURLWait(value))
	End Select
End Sub