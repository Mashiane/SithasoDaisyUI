﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "checkboxes"
	Public title As String = "CheckBoxes"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private chk1 As SDUICheckbox
	Private chk2 As SDUICheckbox
	Private chk3 As SDUICheckbox
	Private chk4 As SDUICheckbox
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows10.AddColumns4p8
	page.Root.BuildGrid
	'start adding you components here
	
	chk1 = page.Cell(1,1).AddCheckBox("chk1")
	chk1.color = app.COLOR_PRIMARY
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"chk1 = page.Cell(1,1).AddCheckBox("chk1")"$)
	c1.AddCode($"chk1.color = app.COLOR_PRIMARY"$)
	c1.AddCode("")
	c1.AddCode($"Private Sub chk1_Change (b As Boolean)"$)
	c1.AddCode($"page.Cell(1, 4).Caption = b"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode("getters & setters")
	c1.AddCode($"chk1.Checked = False"$)
	c1.AddCode($"page.Cell(1, 4).Caption = chk1.Checked"$)
	c1.Refresh
		
	chk2 = page.Cell(2,1).AddCheckBoxLabel("chk2", "Change Me", "right")
	chk2.color = app.COLOR_ACCENT
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"chk2 = page.Cell(4,1).AddCheckBoxLabel("chk2", "Change Me", "right")"$)
	c2.AddCode($"chk2.color = app.COLOR_ACCENT"$)
	c2.Refresh
	'
	
	chk3 = page.Cell(3,1).AddCheckBoxLabel("chk3", "Indeterminate", "left")
	chk3.Indeterminate = True
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"chk3 = page.Cell(3,1).AddCheckBoxLabel("chk3", "Indeterminate", "left")"$)
	c3.AddCode($"chk3.Indeterminate = True"$)
	c3.Refresh
	'
	chk4 = page.Cell(4,1).AddCheckBoxLabel("chk4", "Checked Color", "left")
	chk4.CheckedBGColor = "#99B898"
	chk4.CheckMarkColor = "#FFFFFF"
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"chk4 = page.Cell(4,1).AddCheckBoxLabel("chk4", "Checked Color", "left")"$)
	c4.AddCode($"chk4.CheckedBGColor = "#99B898""$)
	c4.AddCode($"chk4.CheckMarkColor = "#FFFFFF""$)
	c4.Refresh
	
	Dim btnGet As SDUIButton = page.Cell(5,1).AddButton("btnget", "Get")
	'
	Dim btnSet As SDUIButton = page.Cell(5,2).AddButton("btnset", "Set")
	
	Dim btnToggle As SDUIButton = page.Cell(5,1).AddButton("btntoggle", "Toggle")
End Sub


Private Sub chk2_Change (b As Boolean)
	page.Cell(6, 1).Caption = b
End Sub

Private Sub chk1_Change (b As Boolean)
	page.Cell(6, 1).Caption = b
End Sub

Private Sub btnget_Click (e As BANanoEvent)
	Dim b As Boolean = chk1.Checked
	page.Cell(6, 1).Caption = b
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	chk1.Checked = False
	page.Cell(6, 1).Caption = chk1.Checked
End Sub


Private Sub btntoggle_Click (e As BANanoEvent)
	chk1.Toggle
	chk2.Toggle
	page.Cell(6, 1).Caption = chk1.checked
	page.Cell(6, 2).Caption = chk2.checked
End Sub


