﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcarousel"
	Public title As String = "AD Carousel"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUICarousel1 As SDUICarousel
	Private SDUICarousel2 As SDUICarousel
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adcarousellayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUICarousel.SDUICarousel1", "SDUICarousel1", SDUICarousel1.CustProps)
	pgIndex.AddDesignKV1("SDUICarousel.SDUICarousel2", "SDUICarousel2", SDUICarousel2.CustProps)

	'
	SDUICarousel1.AddImage("img1", "./assets/5.jpg", "Test Image")
	SDUICarousel1.AddImage("img2", "./assets/6.jpg", "Test Image")
	SDUICarousel1.AddImage("img3", "./assets/7.jpg", "Test Image")
	SDUICarousel1.AddImage("img4", "./assets/8.jpg", "Test Image")
	SDUICarousel1.AddImage("img5", "./assets/9.jpg", "Test Image")
	'
	SDUICarousel2.AddImage("img1x", "./assets/5.jpg", "Test Image")
	SDUICarousel2.AddImage("img2x", "./assets/6.jpg", "Test Image")
	SDUICarousel2.AddImage("img3x", "./assets/7.jpg", "Test Image")
	SDUICarousel2.AddImage("img4x", "./assets/8.jpg", "Test Image")
	SDUICarousel2.AddImage("img5x", "./assets/9.jpg", "Test Image")
	
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
