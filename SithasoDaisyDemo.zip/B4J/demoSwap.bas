﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "swap"
	Public title As String = "Swap"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns8p4
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim swap As SDUISwap
	swap.AddSwap(Me, page.CellID(1,1), "swp1", "On", "Off")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim swap As SDUISwap"$)
	c1.AddCode($"swap.AddSwap(Me, page.CellID(1,1), "swp1", "On", "Off")"$)
	c1.AddCode("")
	c1.AddCode($"'when swap is ON"$)
	c1.AddCode($"Private Sub swp1_On_Click (e As BANanoEvent)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = "On""$)
	c1.AddCode($"End Sub"$)
	'
	c1.AddCode("")
	c1.AddCode($"'when swap is OFF"$)
	c1.AddCode($"Private Sub swp1_Off_Click (e As BANanoEvent)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = "Off""$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	
	
	Dim sicon As SDUISwap
	sicon.AddSwapIcon(Me, page.CellID(3, 1), "sicon", 4, "fa-solid fa-moon", "fa-regular fa-moon")
	sicon.Rotate
	'
	Dim c2 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim sicon As SDUISwap"$)
	c2.AddCode($"sicon.AddSwapIcon(Me, page.CellID(3, 1), "sicon", 4, "fa-solid fa-moon", "fa-regular fa-moon")"$)
	c2.AddCode($"sicon.Rotate"$)
	c2.AddCode("")
	c2.AddCode($"'when swap is OFF"$)
	c2.AddCode($"Private Sub sicon_On_Click (e As BANanoEvent)"$)
	c2.AddCode($"page.Cell(2, 2).Caption = "On""$)
	c2.AddCode($"End Sub"$)
	c2.AddCode("")
	c2.AddCode($"'when swap is OFF"$)
	c2.AddCode($"Private Sub sicon_Off_Click (e As BANanoEvent)"$)
	c2.AddCode($"page.Cell(2, 2).Caption = "Off""$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
End Sub

Private Sub swp1_On_Click (e As BANanoEvent)
	page.Cell(1, 2).Caption = "On"
End Sub

Private Sub swp1_Off_Click (e As BANanoEvent)
	page.Cell(1, 2).Caption = "Off"
End Sub

Private Sub sicon_On_Click (e As BANanoEvent)
	page.Cell(2, 2).Caption = "On"
End Sub

Private Sub sicon_Off_Click (e As BANanoEvent)
	page.Cell(2, 2).Caption = "Off"
End Sub