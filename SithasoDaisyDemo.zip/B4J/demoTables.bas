﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables"
	Public title As String = "Table 1"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
	Private tb1 As SDUITable
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	''banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table1
	Table1Code
End Sub

Sub Table1Code
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Sub Build_Table1"$)
	c1.AddCode($"Dim tb1 As SDUITable = page.Cell(1, 1).AddTable("tb1")"$)
	c1.AddCode($"tb1.Hover = True"$)
	c1.AddCode($"tb1.Zebra"$)
	c1.AddCode($"tb1.AddColumnSelecAll"$)
	c1.AddCode($"tb1.ButtonSize = app.SIZE_SM"$)
	c1.AddCode($"tb1.ButtonsOutlined = True"$)
	c1.AddCode($"tb1.BadgesSize = app.SIZE_LG"$)
	c1.AddCode($"tb1.BadgesOutlined = True"$)
	c1.AddCode($"'"$)
	c1.AddCode($"tb1.AddColumn("id", "#")"$)
	c1.AddCode($"tb1.AddColumnAvatar("avatar", "Image", 12, app.MASK_SQUIRCLE)"$)
	c1.AddCode($"tb1.AddColumn("name", "Name")"$)
	c1.AddCode($"tb1.AddColumn("job", "Job")"$)
	c1.AddCode($"'add a badge and use a color from the row"$)
	c1.AddCode($"tb1.AddColumnBadge("color", "Favourate Color", "item.color")"$)
	c1.AddCode($"tb1.AddColumnButton("approve", "Approve", app.COLOR_SUCCESS)"$)
	c1.AddCode($"tb1.AddColumnButton("reject", "Reject", app.color_error)"$)
	c1.AddCode($"'ad as last columns"$)
	c1.AddCode($"tb1.AddColumnEdit(app.COLOR_PRIMARY)"$)
	c1.AddCode($"tb1.AddColumnDelete(app.COLOR_SECONDARY)"$)
	c1.AddCode($"BANano.Await(tb1.SetItems(Items))"$)
	c1.AddCode($"tb1.SetRowSelectChecked(1, True)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub tb1_SelectAll (Checked As Boolean)"$)
	c1.AddCode($"Log("tb1_SelectAll")"$)
	c1.AddCode($"Log(Checked)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"'a click event on the row"$)
	c1.AddCode($"Private Sub tb1_approve (item As Map)"$)
	c1.AddCode($"Log("tb1_approve")"$)
	c1.AddCode($"Log(item)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"'a click event on the row"$)
	c1.AddCode($"Private Sub tb1_reject (item As Map)"$)
	c1.AddCode($"Log("tb1_reject")"$)
	c1.AddCode($"Log(item)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"'a click event on the row"$)
	c1.AddCode($"Private Sub tb1_edit (item As Map)"$)
	c1.AddCode($"Log("tb1_edit")"$)
	c1.AddCode($"Log(item)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub tb1_delete (item As Map)"$)
	c1.AddCode($"Log("tb1_delete")"$)
	c1.AddCode($"Log(item)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub tb1_Select (Checked As Boolean, item As Map)"$)
	c1.AddCode($"Log("tb1_Select")"$)
	c1.AddCode($"Log(Checked)"$)
	c1.AddCode($"Log(item)"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

'
Sub Build_Table1
	tb1 = page.Cell(1, 1).AddTable("tb1")
	tb1.Hover = True
	tb1.Zebra
	tb1.AddColumnSelectAll
	tb1.ButtonSize = app.SIZE_SM
	tb1.ButtonsOutlined = True
	tb1.BadgesSize = app.SIZE_LG
	tb1.BadgesOutlined = True
	tb1.ItemsPerPage = 1
	tb1.LowerCase = True
	'
	tb1.AddColumn("id", "#")
	tb1.AddColumnAvatar("avatar", "Image", "4rem", app.MASK_SQUIRCLE)		'64px
	tb1.AddColumn("name", "Name")
	tb1.AddColumn("job", "Job")
	'add a badge and use a color from the row
	tb1.AddColumnBadge("color", "Favourate Color", "item.color")
	tb1.AddColumnButton("approve", "Approve", app.COLOR_SUCCESS)
	tb1.AddColumnButton("reject", "Reject", app.color_error)
	
	'ad as last columns
	tb1.AddColumnEdit(app.COLOR_PRIMARY)
	tb1.AddColumnDelete(app.COLOR_SECONDARY)
	
	banano.Await(tb1.SetItems(Items))
	tb1.SetRowSelectChecked(1, True)
	
End Sub
'
Private Sub tb1_SelectAll (Checked As Boolean)
	Log("tb1_SelectAll")
	Log(Checked)
	Dim sItems As List = tb1.GetAllChecked(Checked)
	Log(sItems)
End Sub
'
'a click event on the row
Private Sub tb1_approve (item As Map)
	Log("tb1_approve")
	Log(item)
End Sub
'
'a click event on the row
Private Sub tb1_reject (item As Map)
	Log("tb1_reject")
	Log(item)
End Sub
'
'a click event on the row
Private Sub tb1_edit (item As Map)
	Log("tb1_edit")
	Log(item)
End Sub
'
Private Sub tb1_delete (item As Map)
	Log("tb1_delete")
	Log(item)
End Sub
'
Private Sub tb1_SelectRow (Status As Boolean, Row As Int, item As Map)
	Log("tb1_SelectRow")
	Log(Status)
	Log(Row)
	Log(item)
End Sub


'



'
