﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adaes"
	Public title As String = "CryptoJS AES"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtDecrypted As SDUITextArea
	Private txtEncrypted As SDUITextArea
	Private txtOriginal As SDUITextArea
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesAES)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adaeslayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	txtOriginal.Value = "Anele Mbanga (Mashy) conceptualized, developed and created SithasoDaisy"
	txtDecrypted.Value = ""
	txtEncrypted.Value = ""
	app.PageResume
End Sub


Private Sub txtOriginal_Append_Click (event As BANanoEvent)
	txtEncrypted.Value = SDUIShared.AESEncrypt(txtOriginal.Value, "SithasoDaisy")
End Sub

Private Sub txtEncrypted_Append_Click (event As BANanoEvent)
	txtDecrypted.Value = SDUIShared.AESDecrypt(txtEncrypted.Value, "SithasoDaisy")
End Sub