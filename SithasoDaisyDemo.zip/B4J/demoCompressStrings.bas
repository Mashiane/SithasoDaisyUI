﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "lzstringpage"
	Public title As String = "LZ String Compression"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtMessage As SDUITextArea
	Private txtConvert As SDUITextArea
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesLZCompressString)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim lbl As SDUILabel = page.Cell(1, 1).AddLabel("lbl", "")
	lbl.Caption = "In this example we are compressing strings using LZ Compression. This can be useful when storing data to LocalStorage. The API provider is 'https://github.com/pieroxy/lz-string/'"
	'
	txtMessage = page.Cell(2, 1).AddTextAreaLabel("txtmessage", "Text To Compress", "Length of string:")
	txtMessage.AppendIcon = "fa-solid fa-file-zipper"
	txtMessage.Required = True
	txtMessage.Value = SDUIShared.LoremIpsum(20)
	txtMessage.Rows = 10
	txtMessage.HintCaption = $"Length: ${txtMessage.Count}"$
	'
	txtConvert = page.Cell(2, 2).AddTextAreaLabel("txtconvert", "Compressed String", "Length of compressed string")
	txtConvert.AppendIcon = "fa-regular fa-file-zipper"
	txtConvert.Value = ""
	txtConvert.Rows = 10
	txtConvert.HintCaption = $"Length: ${txtConvert.Count}"$
	txtConvert.Value = ""
End Sub

Private Sub txtMessage_Append_Click (event As BANanoEvent)
	If txtMessage.IsBlank Then Return
	txtConvert.Value = ""
	txtMessage.AppendButton.Loading = True
	Dim res As String = app.LZCompressString(txtMessage.Value)
	txtConvert.Value = res
	txtConvert.HintCaption = $"Length: ${txtConvert.Count}"$
	txtMessage.HintCaption = $"Length: ${txtMessage.Count}"$
	txtMessage.AppendButton.Loading = False
End Sub

'decompress the converted string and compare it to original
Private Sub txtConvert_Append_Click (event As BANanoEvent)
	If txtMessage.IsBlank Then Return
	Dim original As String = txtMessage.Value
	txtConvert.AppendButton.Loading = True
	Dim res As String = app.LZDeCompressString(txtConvert.Value)
	If original = res Then
		app.ShowSwalSuccess("The string was successfully decompressed!")
	Else	
		app.ShowSwalError("The string could not be successfully decompressed!")
	End If
	txtConvert.AppendButton.Loading = False
End Sub