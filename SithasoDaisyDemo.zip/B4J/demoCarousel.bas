﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "carousel"
	Public title As String = "Carousel"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim car1 As SDUICarousel = page.Cell(1, 1).AddCarousel("car1", "400px", "300px")
	car1.roundedBox
	car1.AddImage("img1", "./assets/5.jpg", "Test Image")
	car1.AddImage("img2", "./assets/6.jpg", "Test Image")
	car1.AddImage("img3", "./assets/7.jpg", "Test Image")
	car1.AddImage("img4", "./assets/8.jpg", "Test Image")
	car1.AddImage("img5", "./assets/9.jpg", "Test Image")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim car1 As SDUICarousel = page.Cell(1, 1).AddCarousel("car1", "400px", "300px")"$)
	c1.AddCode($"car1.roundedBox"$)
	c1.AddCode($"car1.AddImage("img1", "./assets/5.jpg", "Test Image")"$)
	c1.AddCode($"car1.AddImage("img2", "./assets/6.jpg", "Test Image")"$)
	c1.AddCode($"car1.AddImage("img3", "./assets/7.jpg", "Test Image")"$)
	c1.AddCode($"car1.AddImage("img4", "./assets/8.jpg", "Test Image")"$)
	c1.AddCode($"car1.AddImage("img5", "./assets/9.jpg", "Test Image")"$)
	c1.Refresh
	'
	Dim car2 As SDUICarousel = page.Cell(3, 1).AddCarousel("car2", "400px", "300px")
	car2.roundedBox
	'important
	car2.W = 64
	car2.AddImage("img11", "./assets/5.jpg", "Test Image")
	car2.AddImage("img22", "./assets/6.jpg", "Test Image")
	car2.AddImage("img33", "./assets/7.jpg", "Test Image")
	car2.AddImage("img44", "./assets/8.jpg", "Test Image")
	car2.AddImage("img55", "./assets/9.jpg", "Test Image")
	car2.WFull = True
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim car2 As SDUICarousel = page.Cell(3, 1).AddCarousel("car2", "400px", "300px")"$)
	c2.AddCode($"car2.roundedBox"$)
	c2.AddCode($"'important"$)
	c2.AddCode($"car2.W = 64"$)
	c2.AddCode($"car2.AddImage("img11", "./assets/5.jpg", "Test Image")"$)
	c2.AddCode($"car2.AddImage("img22", "./assets/6.jpg", "Test Image")"$)
	c2.AddCode($"car2.AddImage("img33", "./assets/7.jpg", "Test Image")"$)
	c2.AddCode($"car2.AddImage("img44", "./assets/8.jpg", "Test Image")"$)
	c2.AddCode($"car2.AddImage("img55", "./assets/9.jpg", "Test Image")"$)
	c2.AddCode($"car2.WFull = True"$)
	c2.Refresh
	'
	Dim car3 As SDUICarousel = page.Cell(5, 1).AddCarousel("car3", "256px", "400px")
	car3.RoundedBox
	car3.Vertical
	'important
	car3.H = 96
	car3.AddImage("img13", "./assets/5.jpg", "Test Image")
	car3.AddImage("img23", "./assets/6.jpg", "Test Image")
	car3.AddImage("img33x", "./assets/7.jpg", "Test Image")
	car3.AddImage("img43", "./assets/8.jpg", "Test Image")
	car3.AddImage("img53", "./assets/9.jpg", "Test Image")
	car3.HFull = True
	'
	Dim c3 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim car3 As SDUICarousel = page.Cell(5, 1).AddCarousel("car3", "256px", "400px")"$)
	c3.AddCode($"car3.RoundedBox"$)
	c3.AddCode($"car3.Vertical"$)
	c3.AddCode($"'important"$)
	c3.AddCode($"car3.H = 96"$)
	c3.AddCode($"car3.AddImage("img13", "./assets/5.jpg", "Test Image")"$)
	c3.AddCode($"car3.AddImage("img23", "./assets/6.jpg", "Test Image")"$)
	c3.AddCode($"car3.AddImage("img33x", "./assets/7.jpg", "Test Image")"$)
	c3.AddCode($"car3.AddImage("img43", "./assets/8.jpg", "Test Image")"$)
	c3.AddCode($"car3.AddImage("img53", "./assets/9.jpg", "Test Image")"$)
	c3.AddCode($"car3.HFull = True"$)
	c3.Refresh
	'
	Dim car4 As SDUICarousel = page.Cell(7, 1).AddCarousel("car4", "400px", "300px")
	car4.roundedBox
	car4.Root.BGColor(app.COLOR_NEUTRAL)
	car4.AddImage("imgx1", "./assets/5.jpg", "Test Image")
	car4.AddImage("imgx2", "./assets/6.jpg", "Test Image")
	car4.AddImage("imgx3", "./assets/7.jpg", "Test Image")
	car4.AddImage("imgx4", "./assets/8.jpg", "Test Image")
	car4.AddImage("imgx5", "./assets/9.jpg", "Test Image")
	car4.FullBleed = True
	'
	Dim c4 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim car4 As SDUICarousel = page.Cell(7, 1).AddCarousel("car4", "400px", "300px")"$)
	c4.AddCode($"car4.roundedBox"$)
	c4.AddCode($"car4.Root.BGColor = app.COLOR_NEUTRAL"$)
	c4.AddCode($"car4.AddImage("imgx1", "./assets/5.jpg", "Test Image")"$)
	c4.AddCode($"car4.AddImage("imgx2", "./assets/6.jpg", "Test Image")"$)
	c4.AddCode($"car4.AddImage("imgx3", "./assets/7.jpg", "Test Image")"$)
	c4.AddCode($"car4.AddImage("imgx4", "./assets/8.jpg", "Test Image")"$)
	c4.AddCode($"car4.AddImage("imgx5", "./assets/9.jpg", "Test Image")"$)
	c4.AddCode($"car4.FullBleed = True"$)
	c4.Refresh
End Sub
