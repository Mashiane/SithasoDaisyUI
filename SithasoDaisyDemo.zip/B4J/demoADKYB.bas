﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adkbd"
	Public title As String = "AD Kbd"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIKbd1 As SDUIKbd
	Private SDUIKbd2 As SDUIKbd
	Private SDUIKbd3 As SDUIKbd
	Private SDUIKbd4 As SDUIKbd
	Private SDUIKbd5 As SDUIKbd
	Private SDUIKbd6 As SDUIKbd
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adkbdlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd1", "SDUIKbd1", SDUIKbd1.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd2", "SDUIKbd2", SDUIKbd2.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd3", "SDUIKbd3", SDUIKbd3.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd4", "SDUIKbd4", SDUIKbd4.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd5", "SDUIKbd5", SDUIKbd5.CustProps)
	pgIndex.AddDesignKV1("SDUIKbd.SDUIKbd6", "SDUIKbd6", SDUIKbd6.CustProps)

	
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
