﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "anime"
	Public title As String = "Animations"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows(20).AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	
	
	Dim d1 As SDUIDiv = page.Cell(1, 1).AddDiv("d1")
	d1.w(20).h(20).p(2).bgColorIntensity("blue", 900).rounded("md").animateSpin
	'
	Dim co1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("co1", "vb")
	co1.AddCode($"Dim d1 As SDUIDiv = page.Cell(1, 1).AddDiv("d1")"$)
	co1.AddCode($"d1.w(20).h(20).p(2).bgColorIntensity("blue", 900).rounded("md").animateSpin"$)
	co1.Refresh
	'
	Dim d2 As SDUIDiv = page.Cell(2, 1).AddDiv("d2")
	d2.w(20).h(20).p(2).bgColorIntensity("purple", 500).rounded("md").animatePing
	'
	Dim co2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("co2", "vb")
	co2.AddCode($"Dim d2 As SDUIDiv = page.Cell(2, 1).AddDiv("d2")"$)
	co2.AddCode($"d2.w(20).h(20).p(2).bgColorIntensity("purple", 500).rounded("md").animatePing"$)
	co2.Refresh
	'
	Dim d3 As SDUIDiv = page.Cell(3, 1).AddDiv("d3")
	d3.w(20).h(20).p(2).bgColorIntensity("green", 500).rounded("md").animateBounce
	'
	Dim co3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("co3", "vb")
	co3.AddCode($"Dim d3 As SDUIDiv = page.Cell(3, 1).AddDiv("d3")"$)
	co3.AddCode($"d3.w(20).h(20).p(2).bgColorIntensity("green", 500).rounded("md").animateBounce"$)
	co3.Refresh
	'
	Dim d4 As SDUIDiv = page.Cell(4, 1).AddDiv("d4")
	d4.w(20).h(20).p(2).bgColorIntensity("gray", 500).rounded("md").animatePulse
	'
	Dim co4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("co4", "vb")
	co4.AddCode($"Dim d4 As SDUIDiv = page.Cell(4, 1).AddDiv("d4")"$)
	co4.AddCode($"d4.w(20).h(20).p(2).bgColorIntensity("gray", 500).rounded("md").animatePulse"$)
	co4.Refresh
	'
	Dim d5 As SDUIDiv = page.Cell(5, 1).AddDiv("d5")
	d5.w(20).h(20).p(2).bgColorIntensity("blue", 900).rounded("md").hoveranimateSpin
	'
	Dim co5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("co5", "vb")
	co5.AddCode($"Dim d5 As SDUIDiv = page.Cell(5, 1).AddDiv("d5")"$)
	co5.AddCode($"d5.w(20).h(20).p(2).bgColorIntensity("blue", 900).rounded("md").hoveranimateSpin"$)
	co5.Refresh
	'
	Dim d6 As SDUIDiv = page.Cell(6, 1).AddDiv("d6")
	d6.w(20).h(20).p(2).bgColorIntensity("purple", 500).rounded("md").hoveranimatePing
	'
	Dim co6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("co6", "vb")
	co6.AddCode($"Dim d6 As SDUIDiv = page.Cell(6, 1).AddDiv("d6")"$)
	co6.AddCode($"d6.w(20).h(20).p(2).bgColorIntensity("purple", 500).rounded("md").hoveranimatePing"$)
	co6.AddCode($"'"$)
	co6.Refresh
	'
	Dim d7 As SDUIDiv = page.Cell(7, 1).AddDiv("d7")
	d7.w(20).h(20).p(2).bgColorIntensity("green", 500).rounded("md").hoveranimateBounce
	'
	Dim co7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("co7", "vb")
	co7.AddCode($"Dim d7 As SDUIDiv = page.Cell(7, 1).AddDiv("d7")"$)
	co7.AddCode($"d7.w(20).h(20).p(2).bgColorIntensity("green", 500).rounded("md").hoveranimateBounce"$)
	co7.Refresh
	'
	Dim d8 As SDUIDiv = page.Cell(8, 1).AddDiv("d8")
	d8.w(20).h(20).p(2).bgColorIntensity("gray", 500).rounded("md").hoveranimatePulse
	'
	Dim co8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("co8", "vb")
	co8.AddCode($"Dim d8 As SDUIDiv = page.Cell(8, 1).AddDiv("d8")"$)
	co8.AddCode($"d8.w(20).h(20).p(2).bgColorIntensity("gray", 500).rounded("md").hoveranimatePulse"$)
	co8.Refresh
	'
	Dim d9 As SDUILabel = page.Cell(9, 1).AddH3("d9", "TailwindCSS Animation")
	d9.root.textSize("3xl").fontBold.animateBounce.textColorIntensity("indigo", 500)
	'
	Dim co9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("co9", "vb")
	co9.AddCode($"Dim d9 As SDUILabel = page.Cell(9, 1).AddH3("d9", "TailwindCSS Animation")"$)
	co9.AddCode($"d9.root.textSize("3xl").fontBold.animateBounce.textColorIntensity("indigo", 500)"$)
	co9.Refresh
	'
	Dim d10 As SDUILabel = page.Cell(10, 1).AddH3("d10", "TailwindCSS Animation")
	d10.root.textSize("3xl").fontBold.animatePing.textColorIntensity("indigo", 500)
	'
	Dim co10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("co10", "vb")
	co10.AddCode($"Dim d10 As SDUILabel = page.Cell(10, 1).AddH3("d10", "TailwindCSS Animation")"$)
	co10.AddCode($"d10.root.textSize("3xl").fontBold.animatePing.textColorIntensity("indigo", 500)"$)
	co10.Refresh
	'
	Dim spinner As SDUIDiv = page.Cell(11, 1).AddDiv("d11")
	spinner.flex.itemsCenter.justifyCenter.spaceX(2).animatePulse
	spinner.AddDiv("d11_1").w(8).h(8).bgColorIntensity("indigo", 500).roundedFull
	spinner.AddDiv("d11_2").w(8).h(8).bgColorIntensity("blue", 500).roundedFull
	spinner.AddDiv("d11_3").w(8).h(8).bgColorIntensity("green", 500)
	'
	Dim co11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("co11", "vb")
	co11.AddCode($"Dim spinner As SDUIDiv = page.Cell(11, 1).AddDiv("d11")"$)
	co11.AddCode($"spinner.flex.itemsCenter.justifyCenter.spaceX(2).animatePulse"$)
	co11.AddCode($"spinner.AddDiv("d11_1").w(8).h(8).bgColorIntensity("indigo", 500).roundedFull"$)
	co11.AddCode($"spinner.AddDiv("d11_2").w(8).h(8).bgColorIntensity("blue", 500).roundedFull"$)
	co11.AddCode($"spinner.AddDiv("d11_3").w(8).h(8).bgColorIntensity("green", 500)"$)
	co11.Refresh
	
	'this is made up of 2 items
	page.Cell(12, 1).flex
	Dim avat As SDUIDiv = page.Cell(12, 1).AddDiv("d12").relative
	Dim img As SDUIImage = avat.AddImage("avat1", "./assets/mashy.jpg", "", 16, 16)
	img.RoundedFull.ObjectCover
	'
	Dim span1 As SDUILabel = avat.AddSpan("span1", "")
	span1.Root.absolute.right(0).w(4).h(4).bgColorIntensity("green", 600)
	span1.Root.border(2).borderColor("white").roundedFull
	span1.Root.top(2).animatePulse
	'
	Dim co12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("co12", "vb")
	co12.AddCode($"'this is made up of 2 items"$)
	co12.AddCode($"page.Cell(12, 1).flex"$)
	co12.AddCode($"Dim avat As SDUIDiv = page.Cell(12, 1).AddDiv("d12").relative"$)
	co12.AddCode($"Dim img As SDUIImage = avat.AddImage("avat1", "./assets/mashy.jpg", "", 16, 16)"$)
	co12.AddCode($"img.RoundedFull.ObjectCover"$)
	co12.AddCode($"'"$)
	co12.AddCode($"Dim span1 As SDUILabel = avat.AddSpan("span1", "")"$)
	co12.AddCode($"span1.Root.absolute.right(0).w(4).h(4).bgColorIntensity("green", 600)"$)
	co12.AddCode($"span1.Root.border(2).borderColor("white").roundedFull"$)
	co12.AddCode($"span1.Root.top(2).animatePulse"$)
	co12.Refresh
End Sub
