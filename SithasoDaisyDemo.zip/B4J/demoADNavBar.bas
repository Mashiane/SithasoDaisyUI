﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adnavbar"
	Public title As String = "AD NavBar"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUINavBar1 As SDUINavBar
	Private SDUIAvatar1 As SDUIAvatar
	Private SDUIButton1 As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adnavbarlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUINavBar.SDUINavBar1", "SDUINavBar1", SDUINavBar1.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar1", "SDUIAvatar1", SDUIAvatar1.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton1", "SDUIButton1", SDUIButton1.CustProps)

	SDUINavBar1.LogoAvatar.Mask.Squircle
	SDUINavBar1.LogoAvatar.Size = 12
	'
	BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub

Private Sub SDUINavBar1_Hamburger_Click (e As BANanoEvent)
	app.ShowSwal("Hamburger click!")
End Sub

Private Sub SDUINavBar1_Menu_Click (e As BANanoEvent)
	app.ShowSwal("Menu click!")
End Sub

Private Sub SDUIButton1_Click (e As BANanoEvent)
	app.ShowSwal("Button click!")
End Sub

Private Sub SDUIAvatar1_Click (e As BANanoEvent)
	app.ShowSwal("Avatar click!")
End Sub