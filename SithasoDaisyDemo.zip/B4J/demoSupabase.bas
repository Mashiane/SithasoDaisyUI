﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adsupabase"
	Public title As String = "AD SupaBase"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesSupaBase)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	'banano.LoadLayout(app.PageViewer, "adsupabaselayout")
	'...
	Dim my_url As String = "https://fycctdrbjqxgtzlgrjjh.supabase.co"
	Dim my_key As String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ5Y2N0ZHJianF4Z3R6bGdyampoIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzA5NDcwNTIsImV4cCI6MTk4NjUyMzA1Mn0.NAUFczJ5s5jQ4Y9dtzQQJOUufSr50F2j0wu57AammVY"
	'
	Dim supabase As SDUISupaBase
	supabase.Initialize(Me, "supabase", my_url, my_key)
	supabase.TableName = "books"
	supabase.Subscribe
	'
	'sign up a user using email and password
	Dim bSignUp As Boolean = banano.Await(supabase.User_SignUp("mbanga.anele@gmail.com", "password1"))
	If bSignUp = False Then
		Log(supabase.ErrorMessage)
		Return
	End If

	'sign in a user using email and password
	Dim bSign1 As Boolean = banano.Await(supabase.User_SignInWithPassword("mbanga.anele@gmail.com", "password1"))
	If bSign1 = False Then
		Log(supabase.ErrorMessage)
		Return
	End If
	Log(supabase.Profile)
	'
	'get logged in user
	Dim up As Boolean = banano.Await(supabase.User_GetProfile)
	If up = False Then
		Log(supabase.ErrorMessage)
		Return
	End If
	Log(supabase.Profile)
	
	'log outt
	'password reset
	banano.Await(supabase.User_ResetPasswordForEmail("mbanga.anele@gmail.com", "https://sithasodaisyui.netlify.app/"))
	
	'SELECT ALL
	supabase.CLEAR_WHERE
	supabase.ADD_ORDER_BY("title", True)
	banano.Await(supabase.SELECT_ALL)
	Do While supabase.NextRow
		'Log(supabase.record)
	Loop
	supabase.MoveLast
	Dim sid As String = supabase.GetString("id")
	Log(sid)
	'
	'CREATE
	supabase.PrepareRecord
	supabase.SetField("title", "Xolani Mbanga " & DateTime.Now)
	supabase.SetField("author", "Mashy")
	supabase.SetField("finished", False)
	Dim bAdded As Boolean = banano.Await(supabase.CREATE)
	Log(bAdded)
	'
	'UPDATE
	supabase.PrepareRecord
	supabase.setfield("id", sid)
	supabase.SetField("title", "Anele Mbanga " & SDUIShared.DateTimeNow)
	supabase.SetField("author", "Anie")
	supabase.SetField("finished", True)
	Dim bUpdated As Boolean = banano.Await(supabase.UPDATE)
	Log(bUpdated)
	'
	'DELETE
	Dim bDeleted As Boolean = banano.Await(supabase.DELETE(sid))
	Log(bDeleted)
	'
	'SELECT_WHERE...
	supabase.CLEAR_WHERE
	supabase.ADD_FIELD("id")
	supabase.ADD_FIELD("title")
	supabase.ADD_WHERE("finished", "=", False)
	supabase.ADD_ORDER_BY("title", False)
	Dim result As List = banano.Await(supabase.SELECT_WHERE)
	Log(result)
	'
	'READ...
	Dim rec As Map = banano.Await(supabase.READ(1))
	Log(rec)
	
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Private Sub supabase_Changes (eventType As String, New As Map, Old As Map, TableName As String)
	Select Case TableName
		Case "books"
			Select Case eventType
				Case "INSERT"
				Case "UPDATE"
					'get id that was updated
					Dim sid As String = Old.Get("id")
				Case "DELETE"
					'get id that was deleted
					Dim sid As String = Old.Get("id")
			End Select
	End Select
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
