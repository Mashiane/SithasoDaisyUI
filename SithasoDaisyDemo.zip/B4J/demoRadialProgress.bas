﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "radialprogress"
	Public title As String = "Radial Progress"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns4p8
	page.Root.BuildGrid
	'
	Dim prg1 As SDUIRadialProgress = page.Cell(1, 1).AddRadialProgress("prg1", 70)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim prg1 As SDUIRadialProgress = page.Cell(1, 1).AddRadialProgress("prg1", 70)"$)
	c1.Refresh
	'
	Dim prg2 As SDUIRadialProgress
	prg2.AddRadialProgress(Me, page.CellID(2, 1), "prg2", 40)
	prg2.Root.TextColor(app.color_Primary)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim prg2 As SDUIRadialProgress"$)
	c2.AddCode($"prg2.AddRadialProgress(Me, page.CellID(2, 1), "prg2", 40)"$)
	c2.AddCode($"prg2.Root.TextColor = app.color_Primary"$)
	c2.Refresh
	'
	Dim prg3 As SDUIRadialProgress
	prg3.AddRadialProgress(Me, page.CellID(3, 1), "prg3", 70)
	prg3.Root.BGCOlor(app.color_Primary)
	prg3.Root.TextColorIntensity(app.color_Primary,"content")
	prg3.Root.Border(4)
	prg3.Root.BorderColor(app.color_Primary)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim prg3 As SDUIRadialProgress"$)
	c3.AddCode($"prg3.AddRadialProgress(Me, page.CellID(3, 1), "prg3", 70)"$)
	c3.AddCode($"prg3.Root.BGCOlor = app.color_Primary"$)
	c3.AddCode($"prg3.Root.TextColorIntensity(app.color_Primary,"content")"$)
	c3.AddCode($"prg3.Root.Border(4)"$)
	c3.AddCode($"prg3.Root.BorderColor = app.color_Primary"$)
	c3.Refresh
	'
	Dim prg4 As SDUIRadialProgress
	prg4.AddRadialProgress(Me, page.CellID(4, 1), "prg4", 70)
	prg4.Size = "12rem"
	prg4.Thickness = "2px"
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim prg4 As SDUIRadialProgress"$)
	c4.AddCode($"prg4.AddRadialProgress(Me, page.CellID(4, 1), "prg4", 70)"$)
	c4.AddCode($"prg4.Size = "12rem""$)
	c4.AddCode($"prg4.Thickness = "2px""$)
	c4.Refresh
	
	Dim prg5 As SDUIRadialProgress
	prg5.AddRadialProgress(Me, page.CellID(5, 1), "prg5", 70)
	prg5.Size = "12rem"
	prg5.Thickness = "2rem"
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim prg5 As SDUIRadialProgress"$)
	c5.AddCode($"prg5.AddRadialProgress(Me, page.CellID(5, 1), "prg5", 70)"$)
	c5.AddCode($"prg5.Size = "12rem""$)
	c5.AddCode($"prg5.Thickness = "2rem""$)
	c5.Refresh
End Sub
