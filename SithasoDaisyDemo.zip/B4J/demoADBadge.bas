﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adbadge"
	Public title As String = "AD Badge"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIBadge1 As SDUIBadge
	Private SDUIBadge10 As SDUIBadge
	Private SDUIBadge11 As SDUIBadge
	Private SDUIBadge2 As SDUIBadge
	Private SDUIBadge3 As SDUIBadge
	Private SDUIBadge4 As SDUIBadge
	Private SDUIBadge5 As SDUIBadge
	Private SDUIBadge6 As SDUIBadge
	Private SDUIBadge7 As SDUIBadge
	Private SDUIBadge8 As SDUIBadge
	Private SDUIBadge9 As SDUIBadge
	Private SDUIBadge12 As SDUIBadge
	Private SDUIBadge13 As SDUIBadge
	Private SDUIBadge14 As SDUIBadge
	Private SDUIBadge15 As SDUIBadge
	Private SDUIBadge16 As SDUIBadge
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.LoadLayout(app.PageViewer, "adbadgelayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge1", "SDUIBadge1", SDUIBadge1.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge2", "SDUIBadge2", SDUIBadge2.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge3", "SDUIBadge3", SDUIBadge3.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge4", "SDUIBadge4", SDUIBadge4.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge5", "SDUIBadge5", SDUIBadge5.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge6", "SDUIBadge6", SDUIBadge6.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge7", "SDUIBadge7", SDUIBadge7.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge8", "SDUIBadge8", SDUIBadge8.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge9", "SDUIBadge9", SDUIBadge9.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge10", "SDUIBadge10", SDUIBadge10.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge11", "SDUIBadge11", SDUIBadge11.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge12", "SDUIBadge12", SDUIBadge12.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge13", "SDUIBadge13", SDUIBadge13.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge14", "SDUIBadge14", SDUIBadge14.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge15", "SDUIBadge15", SDUIBadge15.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge16", "SDUIBadge16", SDUIBadge16.CustProps)
	
	'BuildPage
	app.PageResume
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIBadge1_Click (e As BANanoEvent)
	app.ShowSwal("Badge...")
End Sub

Private Sub SDUIBadge16_CloseClick (e As BANanoEvent)
	app.ShowSwal("Closing...")
End Sub