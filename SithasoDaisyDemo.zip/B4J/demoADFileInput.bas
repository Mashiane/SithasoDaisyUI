﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adfileinput"
	Public title As String = "AD FileInput"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIFileInput1 As SDUIFileInput
	Private SDUIFileInput2 As SDUIFileInput
	Private SDUIFileInput3 As SDUIFileInput
	Private SDUIFileInput4 As SDUIFileInput
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adfileinputlayout")
	'build the page, via code or loadlayouts
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIFileInput.SDUIFileInput1", "SDUIFileInput1", SDUIFileInput1.CustProps)
	pgIndex.AddDesignKV1("SDUIFileInput.SDUIFileInput2", "SDUIFileInput2", SDUIFileInput2.CustProps)
	pgIndex.AddDesignKV1("SDUIFileInput.SDUIFileInput3", "SDUIFileInput3", SDUIFileInput3.CustProps)
	pgIndex.AddDesignKV1("SDUIFileInput.SDUIFileInput4", "SDUIFileInput4", SDUIFileInput4.CustProps)

	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
	'start adding you components here
End Sub


Private Sub SDUIFileInput4_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = SDUIFileInput4.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	SDUIFileInput4.LoadingFile = True
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			'*
			SDUIFileInput4.LoadingFile = False
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	'img1.Src = fp
	'cancel the loading
	SDUIFileInput4.LoadingFile = False
End Sub

Private Sub SDUIFileInput3_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = SDUIFileInput3.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			Return
		Case "success"
	End Select
	'get the upload full path
	'Dim fp As String = fileDet.FullPath
	'img1.Src = fp
End Sub

Private Sub SDUIFileInput2_Change (event As BANanoEvent)
	'has the file been specified
	Dim fileObj As Map = SDUIFileInput2.GetFile
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'read the file details as JSON
	Dim fText As String = banano.Await(SDUIShared.GetFileAsDataURL(fileObj))
	Log(fText)
	
	'img1.src = fText
	'save content to the tag
	'img1.Tag = fText
	
End Sub

Private Sub SDUIFileInput1_Change (event As BANanoEvent)
	
End Sub