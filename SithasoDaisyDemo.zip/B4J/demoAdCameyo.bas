﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcameyo"
	Public title As String = "AD Camera"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private btnStart As SDUIButton
	Private btnStop As SDUIButton
	Private btnTake As SDUIButton
	Private SDUICamera1 As SDUICamera
	Private SDUICol1 As SDUICol
	Private SDUICol2 As SDUICol
	Private SDUICol3 As SDUICol
	Private SDUICol4 As SDUICol
	Private SDUICol5 As SDUICol
	Private SDUIRow1 As SDUIRow
	Private SDUIRow2 As SDUIRow
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adcameyolayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub btnTake_Click (e As BANanoEvent)
	SDUICamera1.TakeSnap
End Sub

Private Sub btnStop_Click (e As BANanoEvent)
	banano.Await(SDUICamera1.StopCameraWait)
End Sub

Private Sub btnStart_Click (e As BANanoEvent)
	banano.Await(SDUICamera1.StartCameraWait)
End Sub

Private Sub SDUICamera1_SnapSuccess (data_URI As String)
	Log(data_URI)
End Sub

Private Sub SDUICamera1_Ready (e As BANanoEvent)
	btnTake.Enable
	btnStop.Enable
	btnStart.Disable
End Sub

Private Sub SDUICamera1_Stopped (e As BANanoEvent)
	btnTake.Disable
	btnStop.Disable
	btnStart.Enable
End Sub