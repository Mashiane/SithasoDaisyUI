﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "welcomepage"
	Public title As String = "Welcome"
	Public icon As String = "fa-solid fa-house-chimney"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'app.PagePause
	'banano.Await(app.UsesLottiePlayer)
	'build the page, via code or loadlayouts
	BuildPage
	'app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	
	'build the grid
	page.Root.BuildGrid
	
	Dim t1 As SDUILabel = page.Cell(1, 1).AddH1("t1", "Welcome to SithasoDaisy")
	t1.Root.textSize("4xl").fontBold.animateBounce.textColorIntensity("indigo", 500)
	'
	
	Dim img As SDUIImage = page.Cell(1, 1).AddImage("img1", "./assets/600by600.jpg", "", "200px", "200px")
	
	'Dim lp As SDUILottiePlayer
	'lp.AddLottiePlayer(Me, page.Cell(1, 1).Name, "lp1")
	'lp.JsonUrl = "./assets/liftoff.json"
	'lp.Width = "250px"
	'lp.Height = "250px"
	'lp.AutoPlay = False
	'lp.IsLoop = True
	'lp.Root.m(4)
	'
	Dim items As List = app.CreateList
	items.Add("What is SithasoDaisy ?")
	'items.Add("Installation")
	'items.Add("Creating your first WebApp with SithasoDaisy")
	'items.Add("Deploy your App")
	
	Dim faq As SDUICollapsePanels = page.Cell(2, 1).AddCollapsePanels("faq", False, items)
	faq.Active = 1
	'
	Dim p1 As SDUIDiv = faq.Panel(1)
	Dim faq1L As SDUIList = p1.AddList("faq1", False, 4, 4)
	faq1L.listDisc
	faq1L.AddListItemLabel("q1_1", "SithasoDaisy is the new-west b4xlib (library) from Sithaso Holdings that is based on TailwindCSS. The libray is inspired by the DaisyUI component library, to help you create your WebApps using the basic programming language called 'b4x'.")
	faq1L.AddListItemLabel("q1_2", "SithasoDaisy comes with more than 47 already built in components to help you create your next powerful Web Apps.")
	faq1L.AddListItemLabel("q1_3", "To create our Web Apps, we will use a RAD IDE tool called 'b4j' (basic4java). This uses a programming language called 'b4x', a Visual Basic variant.")
	faq1L.AddListItemLabel("q1_5", "To get our b4x source code as javascript, a b4j plugin called 'BANano' will be used. This transpiles our source code from b4x to native JavaScript, CSS and HTML.")
	faq1L.AddListItemLabel("q1_4", "With SithasoDaisy, you are unlikely to write any HTML, CSS or JavaScript.")
	faq1L.AddListItemLabelAnchor("q1_6", "Download the eBook to get started right away.", "https://github.com/Mashiane/SithasoDaisyUI/raw/main/TailwindCSS%20WebApps%20using%20B4X.pdf")
	
	'
'	Dim p2 As SDUIDiv = faq.Panel(2)
'	Dim faq2L As SDUIList = p2.AddList("faq2", False, 4, 4)
'	faq2L.listDecimal
'	faq2L.AddListItemLabel("q2_1", "To be able to create Web Apps with SithasoDaisy, you need a couple of things. These are:")
'	faq2L.AddListItemLabel("q2_2", "(a) A Windows PC with 64 bit architecture, (b) b4j, (c) Open JDK 11+, (d) BANano, (e) SithasoDaisy and a WebServer. ")
'	faq2L.AddListItemLabel("q2_3", "First, create the following folder structure in your PC (a) c:\\b4j\\workspace, (b) c:\\b4j\\libraries and (c) c:\\b4j\\shared.")
'	faq2L.AddListItemLabelAnchor("q2_4", "Download b4j (basic4java) and Open JDK 11+ from this link. Follow the instructions carefully.", "https://www.b4x.com/b4j.html")
'	faq2L.AddListItemLabelAnchor("q2_6", "Download BANano (b4x to JavaScript transpiler). Follow the instructions carefully. Unzip the download and copy the contents of the 'Libraries' folder to c:\\b4j\\libraries.", _
'	"https://www.b4x.com/android/forum/threads/banano-website-app-pwa-library-with-abstract-designer-support.99740/#content")
'	faq2L.AddListItemLabelAnchor("q2_7", "Download SithasoDaisy (b4xlib) and copy the file to c:\\b4j\\libraries.", _
'	"#")
'	faq2L.AddListItemLabelAnchor("q2_8", "If you dont have a development WebServer, you can try Laragon from here.", "https://laragon.org/")
'	faq2L.AddListItemLabel("q2_9", "Start b4j IDE and remember to set your Paths configuration correctly, as per #4 above.")
	'app.PageResume
End Sub
