﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10
@EndOfDesignText@
#IgnoreWarnings:12
#DesignerProperty: Key: ParentID, DisplayName: ParentID, FieldType: String, DefaultValue: , Description: The ParentID of this component, enter swiperID
#DesignerProperty: Key: SwiperId, DisplayName: Swiper Id, FieldType: String, DefaultValue: , Description: Swiper Id
#DesignerProperty: Key: RefreshSwiper, DisplayName: Refresh Swiper, FieldType: Boolean, DefaultValue: False, Description: Refresh Swiper after this
#DesignerProperty: Key: Visible, DisplayName: Visible, FieldType: Boolean, DefaultValue: True, Description: If visible.
#DesignerProperty: Key: ColumnName, DisplayName: Column Name, FieldType: String, DefaultValue: , Description: Column Name
#DesignerProperty: Key: ColumnType, DisplayName: Column Type, FieldType: String, DefaultValue: string, Description: Column Type, List: blob|bool|double|int|string
#DesignerProperty: Key: MarginAXYTBLR, DisplayName: Margins, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Margins A(all)-X(LR)-Y(TB)-T-B-L-R
#DesignerProperty: Key: PaddingAXYTBLR, DisplayName: Paddings, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Paddings A(all)-X(LR)-Y(TB)-T-B-L-R
#DesignerProperty: Key: RawClasses, DisplayName: Classes (;), FieldType: String, DefaultValue: , Description: Classes added to the HTML tag.
#DesignerProperty: Key: RawStyles, DisplayName: Styles (JSON), FieldType: String, DefaultValue: , Description: Styles added to the HTML tag. Must be a json String use = and ;
#DesignerProperty: Key: RawAttributes, DisplayName: Attributes (JSON), FieldType: String, DefaultValue: , Description: Attributes added to the HTML tag. Must be a json String use = and ;
'global variables in this module
Sub Class_Globals
	Public CustProps As Map 'ignore
	Private mCallBack As Object 'ignore
	Private mEventName As String 'ignore
	Private mElement As BANanoElement 'ignore
	Private mTarget As BANanoElement 'ignore
	Private mName As String 'ignore
	Private BANano As BANano   'ignore
	Private mClasses As String
	Private mStyles As String
	Private mAttributes As String
	Private mMarginAXYTBLR As String
	Private mPaddingAXYTBLR As String
	Private mParentID As String
	Private mVisible As Boolean = True
	Public Tag As Object
	Private bRefreshSwiper As Boolean = False
	Private sSwiperId As String = ""
	Private sColumnName As String = ""
	Private sColumnType As String = "string"
End Sub
'initialize the custom view class
Public Sub Initialize (Callback As Object, Name As String, EventName As String)
	mEventName = SDUIShared.CleanID(EventName)
	mName = SDUIShared.CleanID(Name)
	mCallBack = Callback
	CustProps.Initialize
End Sub
' returns the BANanoElement
Public Sub getElement() As BANanoElement
	Return mElement
End Sub
Sub AddComputedStyleMap(ms As Map)
	If ms.Size = 0 Then Return
	If mElement <> Null Then
		For Each k As String In ms.Keys
			Dim v As String = ms.Get(k)
			mElement.GetField("style").RunMethod("setProperty", Array(k, v))
		Next
	End If
End Sub
' returns the element id
Public Sub getID() As String
	Return mName
End Sub
'add this element to an existing parent element
Public Sub AddToParent(targetID As String, props As Map)
	targetID = SDUIShared.CleanID(targetID)
	If targetID = "" Then Return
	mTarget = BANano.GetElement("#" & targetID)
	DesignerCreateView(mTarget, props)
End Sub
'remove this element from the dom
Public Sub Remove()
	mElement.Remove
	BANano.SetMeToNull
End Sub
'assign another element to this element
Sub setElement(e As BANanoElement)
	mElement = e
End Sub
'empty the element and remove all children
Sub Clear
	If mElement <> Null Then mElement.Empty
End Sub
'append the specified html to the element
Sub Append(tmp As Object)
	If mElement <> Null Then mElement.Append(tmp)
End Sub
'clear and replace the html of this element
Sub SetHTML(sHTML As String)
	If mElement <> Null Then mElement.SetHTML(sHTML)
End Sub
'execute getElementByID on the existing element
Sub LinkExisting
	mElement.Initialize($"#${mName}"$)
	'mTarget = BANano.ToElement(mElement.GetField("parentNode"))
End Sub
'Sub AddOptionRecursiveEvent(targetEvent As String, event As String)
'Dim methodName As String = $"${mEventName}_${event}"$
'If SubExists(mCallBack, methodName) = False Then Return
'Dim e As BANanoEvent
'Dim cb As BANanoObject
'cb = BANano.CallBack(mCallBack, methodName, Array(e))
'PutRecursive(Options, targetEvent, cb)
'End Sub
'Sub AddOptionEvent(event As String)
'Dim methodName As String = $"${mEventName}_${event}"$
'If SubExists(mCallBack, methodName) = False Then Return
'Dim e As BANanoEvent
'Dim cb As BANanoObject
'cb = BANano.CallBack(mCallBack, methodName, Array(e))
'Options.Put(event, cb)
'End Sub
'trigger an event on the element
Public Sub TriggerEvent(event As String, params() As String)
	If mElement <> Null Then
		mElement.Trigger(event, params)
	End If
End Sub
'return the #ID of the element
Public Sub getHere() As String
	Return $"#${mName}"$
End Sub
'set an attribute to the element
Sub AddAttr(attr As String, text As Object)
	If mElement <> Null Then mElement.SetAttr(attr, text)
End Sub
'set a data attribute to the element
Sub AddDataAttr(attr As String, text As String)
	If mElement <> Null Then mElement.SetData(attr, text)
End Sub
'get a data attribute of the element
Sub GetDataAttr(attr As String) As String
	If mElement <> Null Then
		Dim text As String = mElement.GetData(attr)
		Return text
	Else
		Return ""
	End If
End Sub
Sub GetAttr(attr As String) As String
	If mElement <> Null Then
		Dim text As String = mElement.GetAttr(attr)
		Return text
	Else
		Return ""
	End If
End Sub
'add a class to the element
Sub AddClass(text As String)
	If mElement <> Null Then
		Dim lst As List = SDUIShared.StrParse(" ", text)
		For Each c As String In lst
			mElement.AddClass(c)
		Next
	End If
End Sub
'remove a class from the element
Sub RemoveClass(text As String)
	If mElement <> Null Then
		Dim lst As List = SDUIShared.StrParse(" ", text)
		For Each c As String In lst
			mElement.RemoveClass(c)
		Next
	End If
End Sub
'add multiple attributes to the element
Sub AddAttrMap(ms As Map)
	If ms.Size = 0 Then Return
	For Each k As String In ms.Keys
		Dim v As String = ms.Get(k)
		AddAttr(k, v)
	Next
End Sub
'remove an attribute from the element
Sub RemoveAttr(attr As String)
	If mElement <> Null Then
		mElement.RemoveAttr(attr)
	End If
End Sub
'add a computed style to the element
Sub AddStyleComputed(attr As String, text As String)
	If mElement <> Null Then
		mElement.GetField("style").RunMethod("setProperty", Array(attr, text))
	End If
End Sub
'add a collection of styles to the element
Sub AddStyleMap(ms As Map)
	If ms.Size = 0 Then Return
	If mElement <> Null Then
		mElement.SetStyle(BANano.ToJson(ms))
	End If
End Sub
'add a styles to the element
Sub AddStyle(k As String, v As String)
	Dim m As Map = CreateMap()
	m.Put(k, v)
	AddStyleMap(m)
End Sub
'set Visible
Sub setVisible(b As Boolean)
	mVisible = b
	CustProps.Put("Visible", b)
	If b Then
		RemoveClass("ion-hide")
	Else
		AddClass("ion-hide")
	End If
End Sub
'get Visible
Sub getVisible As Boolean
	Return mVisible
End Sub
'assign callback to "element.on()
Sub OnEventMethod(event As String, Module As Object, MethodName As String, args As List)
	Dim cb As BANanoObject = BANano.CallBack(Module, MethodName, BANano.Spread(args))
	If mElement <> Null Then mElement.RunMethod("on", Array(event, cb))
End Sub
Sub getthis As BANanoObject
	' get the current class
	Dim this As BANanoObject
	this.Initialize("this")
	Return this
End Sub
'get the base element
Sub getRoot As SDUILabel
	Dim el As SDUILabel
	el.Initialize(mCallBack, mName, mName)
	el.LinkExisting
	Return el
End Sub
'use to add an event to the element
Sub On(event As String, args As List)
	OnEvent(event, mCallBack, $"${mEventName}_${event}"$, args)
End Sub
'use to add an event to the element
Sub OnEvent(event As String, Module As Object, methodName As String, args As List)
	event = event.Replace(":","")
	event = event.Replace(".","")
	event = event.Replace("-","")
	'
	If SubExists(Module, methodName) = False Then Return
	Dim cb As BANanoObject
	cb = BANano.CallBack(Module, methodName, BANano.Spread(args))
	mElement.RemoveEventListener(event, cb, True)
	mElement.AddEventListener(event, cb, True)
End Sub
'code to design the view
Public Sub DesignerCreateView (Target As BANanoElement, Props As Map)
	mTarget = Target
	If Props <> Null Then
		CustProps = Props
		mParentID = Props.GetDefault("ParentID", "")
		mParentID = SDUIShared.CleanID(mParentID)
		mClasses = Props.GetDefault("RawClasses", "")
		mClasses = SDUIShared.CStr(mClasses)
		mStyles = Props.GetDefault("RawStyles", "")
		mStyles = SDUIShared.CStr(mStyles)
		mAttributes = Props.GetDefault("RawAttributes", "")
		mAttributes = SDUIShared.CStr(mAttributes)
		mMarginAXYTBLR = Props.GetDefault("MarginAXYTBLR","a=?; x=?; y=?; t=?; b=?; l=?; r=?")
		mMarginAXYTBLR = SDUIShared.CStr(mMarginAXYTBLR)
		mPaddingAXYTBLR = Props.GetDefault("PaddingAXYTBLR","a=?; x=?; y=?; t=?; b=?; l=?; r=?")
		mPaddingAXYTBLR = SDUIShared.CStr(mPaddingAXYTBLR)
		mVisible = Props.GetDefault("Visible", True)
		mVisible = SDUIShared.CBool(mVisible)
		bRefreshSwiper = Props.GetDefault("RefreshSwiper", False)
		bRefreshSwiper = SDUIShared.CBool(bRefreshSwiper)
		sSwiperId = Props.GetDefault("SwiperId", "")
		sSwiperId = SDUIShared.cleanid(sSwiperId)
		sColumnName = Props.GetDefault("ColumnName", "")
		sColumnName = SDUIShared.CStr(sColumnName)
		sColumnType = Props.GetDefault("ColumnType", "string")
		sColumnType = SDUIShared.CStr(sColumnType)
	End If
	'
	If mParentID <> "" Then
		If mParentID.EndsWith("slides") = False Then mParentID = mParentID & "slides"
		'does the parent exist
		If BANano.Exists($"#${mParentID}"$) = False Then
			BANano.Throw($"${mName}.DesignerCreateView: '${mParentID}' parent does not exist!"$)
			Return
		End If
		mTarget.Initialize($"#${mParentID}"$)
	End If
	Dim se As SithasoElement
	se.Initialize
	se.AddClass("swiper-slide")
	se.mClasses = mClasses
	se.mStyles = mStyles
	se.mPaddingAXYTBLR = mPaddingAXYTBLR
	se.mMarginAXYTBLR = mMarginAXYTBLR
	se.mAttributes = mAttributes
	se.BuildAttr
	If bRefreshSwiper = False Then
		'do not add this slide
		mElement = mTarget.Append($"[BANCLEAN]<div id="${mName}" ${se.exAttrs} ${se.exAttrs1}></div>"$).Get("#" & mName)
		If mVisible = False Then setVisible(mVisible)
	Else
		'refresh the swiper
		If sSwiperId = "" Then Return
		Dim swiperJSON As String = BANano.GetLocalStorage2(sSwiperId)
		Dim options As Map = BANano.FromJson(swiperJSON)
		'
		Dim swiper As BANanoObject
		Dim el As BANanoElement
		el.Initialize($"#${mName}"$)
		swiper.Initialize2("Swiper", Array(el.ToObject, options))
	End If
End Sub
'set Refresh Swiper
Sub setRefreshSwiper(b As Boolean)
	bRefreshSwiper = b
	CustProps.put("RefreshSwiper", b)
End Sub
'set Swiper Id
Sub setSwiperId(s As String)
	sSwiperId = s
	CustProps.put("SwiperId", s)
End Sub
'get Refresh Swiper
Sub getRefreshSwiper As Boolean
	Return bRefreshSwiper
End Sub
'get Swiper Id
Sub getSwiperId As String
	Return sSwiperId
End Sub
Sub setParentID(sParentID As String)
	mParentID = sParentID
	CustProps.Put("ParentID", mParentID)
End Sub
Sub setRawAttributes(s As String)
	mAttributes = s
	CustProps.Put("RawAttributes", s)
End Sub
Sub setRawStyles(s As String)
	mStyles = s
	CustProps.Put("RawStyles", s)
End Sub
Sub setRawClasses(s As String)
	mClasses = s
	CustProps.put("RawClasses", s)
End Sub
Sub setPaddingAXYTBLR(s As String)
	mPaddingAXYTBLR = s
	CustProps.Put("PaddingAXYTBLR", s)
End Sub
Sub setMarginAXYTBLR(s As String)
	mMarginAXYTBLR = s
	CustProps.Put("MarginAXYTBLR", s)
End Sub
'
'get ParentID
Sub getParentID As String
	Return mParentID
End Sub
'
'get Margins
Sub getMarginAXYTBLR As String
	Return mMarginAXYTBLR
End Sub
'
'get Paddings
Sub getPaddingAXYTBLR As String
	Return mPaddingAXYTBLR
End Sub
'
'get Classes (;)
Sub getRawClasses As String
	Return mClasses
End Sub
'
'get Styles (JSON)
Sub getRawStyles As String
	Return mStyles
End Sub
'
'get Attributes (JSON)
Sub getRawAttributes As String
	Return mAttributes
End Sub
Sub setColumnName(s As String)
	sColumnName = s
	CustProps.Put("ColumnName", sColumnName)
End Sub
Sub setColumnType(s As String)
	sColumnType = s
	CustProps.Put("ColumnType", sColumnType)
End Sub
'get ColumnName
Sub getColumnName As String
	Return sColumnName
End Sub
'get ColumnType
Sub getColumnType As String
	Return sColumnType
End Sub