﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "herodemo"
	Public title As String = "Hero"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim hero1 As SDUIHero = page.Cell(1, 1).AddHero("hero1")
	'must fit screen
	'hero1.MinHScreen
	hero1.Root.BGColorIntensity(app.COLOR_BASE, 200)
	hero1.content.textCenter
	'
	Dim he1div As SDUIDiv = hero1.Content.AddDiv("he1div")
	he1div.MaxW("md")
	'
	Dim heH1 As SDUILabel = he1div.AddH1("heh1", "Hello there")
	heH1.Root.FontBold
	heH1.Root.TextSize(app.SIZE_5XL)
	'
	Dim lip As SDUILabel = he1div.AddLoremIpsum("lip")
	lip.Root.py(6)
	'
	Dim btn As SDUIButton = he1div.AddButton("btnh1", "Get Started")
	btn.Color = app.COLOR_PRIMARY
	
	'
	Dim hero2 As SDUIHero = page.Cell(2, 1).AddHero("hero2")
	'hero2.MinHScreen
	hero2.Root.BGColorIntensity(app.COLOR_BASE, 200)
	hero2.Content.flexCol
	hero2.Content.ResponsiveOnDevice("lg", "flex-row")
	'add 2 divs to the content
	Dim hc1 As SDUIDiv = hero2.Content.AddDiv("hc1")
	Dim hc2 As SDUIDiv = hero2.Content.AddDiv("hc2")
	'DIV1
	Dim himg As SDUIImage = hc1.AddImage("himg", "./assets/arch.jpg", "", "", "")
	himg.W = "260px"
	himg.H = "400px"
	himg.Root.MaxW("sm")
	himg.Root.Rounded(app.SIZE_LG)
	himg.Root.Shadow(app.size_2xl)
	'DIV2
	Dim bon As SDUILabel = hc2.AddH1("bon", "Box Office News!")
	bon.Root.FontBold
	bon.Root.TextSize(app.SIZE_5XL)
	'
	Dim lip1 As SDUILabel = hc2.AddLoremIpsum("lip1")
	lip1.Root.py(6)
	'
	Dim btn2 As SDUIButton = hc2.AddButton("btnh2", "Get Started")
	btn2.Color = app.COLOR_PRIMARY
	'
	
	'*****
	
	Dim hero3 As SDUIHero = page.Cell(3, 1).AddHero("hero3")
	'hero3.MinHScreen
	hero3.Root.BGColorIntensity(app.COLOR_BASE, 200)
	hero3.Content.flexCol
	hero3.Content.ResponsiveOnDevice("lg", "flex-row-reverse")
	'add 2 divs to the content
	Dim h3c1 As SDUIDiv = hero3.Content.AddDiv("h3c1")
	Dim h3c2 As SDUIDiv = hero3.Content.AddDiv("h3c2")
	'DIV1
	Dim himg3 As SDUIImage = h3c1.AddImage("himg3", "./assets/arch.jpg", "", "", "")
	himg.W = "260px"
	himg.H = "400px"
	himg3.Root.MaxW("sm")
	himg3.Root.Rounded(app.SIZE_LG)
	himg3.Root.Shadow(app.size_2xl)
	'DIV2
	Dim bon3 As SDUILabel = h3c2.AddH1("bon3", "Box Office News!")
	bon3.Root.FontBold
	bon3.Root.TextSize(app.SIZE_5XL)
	'
	Dim lip3 As SDUILabel = h3c2.AddLoremIpsum("lip3")
	lip3.Root.py(6)
	'
	Dim btn3 As SDUIButton = h3c2.AddButton("btnh3", "Get Started")
	btn3.Color = app.COLOR_PRIMARY
	
	'
	Dim hero4 As SDUIHero = page.Cell(4, 1).AddHero("hero4")
	hero4.Root.MinHScreen
	hero4.BackgroundImage = "./assets/arch.jpg"
	hero4.Overlay.Show
	hero4.overlay.BGOpacity(60)
	'
	hero4.Content.textCenter
	hero4.Content.TextColorIntensity(app.COLOR_NEUTRAL,"content")
	'
	Dim h4div As SDUIDiv = hero4.Content.AddDiv("h4div")
	h4div.MaxW("md")
	'
	Dim bon4 As SDUILabel = h4div.AddH1("bon4", "Hello there")
	bon4.Root.FontBold
	bon4.Root.TextSize(app.SIZE_5XL)
	bon4.Root.MB(5)
	'
	Dim lip4 As SDUILabel = h4div.AddLoremIpsum("lip4")
	lip4.Root.mb(5)
	'
	Dim btn4 As SDUIButton = h4div.AddButton("btnh4", "Get Started")
	btn4.Color = app.COLOR_PRIMARY
	
End Sub
