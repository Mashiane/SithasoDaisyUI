﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "textarea"
	Public title As String = "Text Area"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private txta As SDUITextArea
	Private txtb As SDUITextArea
	Private txtSearch As SDUITextArea
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows1.AddColumns4x3
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows5.AddColumns4p8
	
	page.Root.BuildGrid
	'start adding you components here
		
	txta.AddTextArea(Me, page.CellID(1,1) , "txta")
	txta.Placeholder = "Bio"
	'
	Dim btnGet As SDUIButton =  page.Cell(1,2).AddButton("btnget", "Get")
	'
	Dim btnSet As SDUIButton = page.Cell(1,3).AddButton("btnset", "Set")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"txta.AddTextArea(Me, page.CellID(1,1) , "txta")"$)
	c1.AddCode($"txta.Placeholder = "Bio""$)
	c1.Refresh
	'
	txtb.AddTextAreaGroup(Me, page.CellID(3,1), "txtb", "News", "Enter your news article here")
	txtb.Placeholder = "News"
	'txtb.Root.H = 50
	Dim c2 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"txtb.AddTextAreaGroup(Me, page.CellID(3,1), "txtb", "News", "Enter your news article here")"$)
	c2.AddCode($"txtb.Placeholder = "News""$)
	c2.Refresh
		
	txtSearch.AddTextAreaGroup(Me, page.CellID(4, 1), "txtsearch", "Search", "")
	txtSearch.Placeholder = "Search"
	txtSearch.AppendIcon = "fa-solid fa-magnifying-glass"
	txtSearch.PrependIcon = "fa-solid fa-magnifying-glass"
	txtSearch.AppendButton.Size = app.SIZE_SM
	txtSearch.PrependButton.size = app.size_sm
	txtSearch.AppendButton.Color = app.color_primary
	'
	Dim c3 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"txtSearch.AddTextAreaGroup(Me, page.CellID(4, 1), "txtsearch", "Search", "")"$)
	c3.AddCode($"txtSearch.Placeholder = "Search""$)
	c3.AddCode($"txtSearch.AppendIcon = "fa-magnifying-glass""$)
	c3.AddCode($"txtSearch.PrependIcon = "fa-magnifying-glass""$)
	c3.AddCode($"txtSearch.AppendButton.Size = app.SIZE_SM"$)
	c3.AddCode($"txtSearch.PrependButton.size = app.size_sm"$)
	c3.AddCode($"txtSearch.AppendButton.Color = app.color_primary"$)
	c3.Refresh
End Sub

Private Sub btnget_Click (e As BANanoEvent)
	page.Cell(5, 1).Caption = txta.value
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	txta.Value = "Sithaso Daisy TextArea"
	page.Cell(5, 1).Caption = txta.Value
End Sub

Private Sub txtsearch_Prepend_Click (event As BANanoEvent)
	page.Cell(5, 1).Caption = "Prepend Click"
End Sub

Private Sub txtsearch_Append_Click (event As BANanoEvent)
	page.Cell(5, 1).Caption = "Append Click"
End Sub