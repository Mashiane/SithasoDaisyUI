﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcard"
	Public title As String = "AD Cards"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUICard1 As SDUICard
	Private SDUICard2 As SDUICard
	Private SDUICard3 As SDUICard
	Private SDUIAvatar1 As SDUIAvatar
	Private SDUILabel1 As SDUILabel
	Private SDUIBadge1 As SDUIBadge
	Private SDUIBadge2 As SDUIBadge
	Private SDUIBadge3 As SDUIBadge
	Private SDUILabel2 As SDUILabel
	Private SDUIButton1 As SDUIButton
	Private SDUIDivider1 As SDUIDivider
	Private SDUICard4 As SDUICard
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adcardlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUICard.SDUICard1", "SDUICard1", SDUICard1.CustProps)
	pgIndex.AddDesignKV1("SDUICard.SDUICard2", "SDUICard2", SDUICard2.CustProps)
	pgIndex.AddDesignKV1("SDUICard.SDUICard3", "SDUICard3", SDUICard3.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar1", "SDUIAvatar1", SDUIAvatar1.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel1", "SDUILabel1", SDUILabel1.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge1", "SDUIBadge1", SDUIBadge1.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge2", "SDUIBadge2", SDUIBadge2.CustProps)
	pgIndex.AddDesignKV1("SDUIBadge.SDUIBadge3", "SDUIBadge3", SDUIBadge3.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel2", "SDUILabel2", SDUILabel2.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton1", "SDUIButton1", SDUIButton1.CustProps)
	pgIndex.AddDesignKV1("SDUIDivider.SDUIDivider1", "SDUIDivider1", SDUIDivider1.CustProps)
	pgIndex.AddDesignKV1("SDUICard.SDUICard4", "SDUICard4", SDUICard4.CustProps)

	
	
	SDUICard1.AddActionButtonIcon("btnnew", "fa-solid fa-location-dot", app.COLOR_ACCENT)
	SDUICard1.AddActionButton("btnBuy", "Buy", app.COLOR_PRIMARY)
	'
	SDUICard2.AddActionButton("btnBuy1", "Get Started", app.COLOR_PRIMARY)
	'
	SDUICard4.AddActionButton("btnListen", "Listen", app.COLOR_PRIMARY)
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUICard2_Action (item As String)
	
End Sub

Private Sub SDUICard1_Action (item As String)
	
End Sub