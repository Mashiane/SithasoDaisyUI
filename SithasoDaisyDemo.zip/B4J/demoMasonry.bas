﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "masonrypage"
	Public title As String = "Masonry"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim masonry As SDUIDiv = page.Cell(1, 1).AddDiv("masonry")
	masonry.Clear
	'this will be a grid
	masonry.Grid
	'there will be 3 columns
	masonry.Gridcols(3)
	'there is a gap between items
	masonry.Gap(4)
	'set grid flow
	masonry.gridFlowRowDense
	'
	masonry.AddImage("img1", "./assets/nature_01.jpg", "", "", "").Root.ColSpan(2)
	masonry.AddImage("img2", "./assets/nature_02.jpg", "", "", "")
	masonry.AddImage("img3", "./assets/nature_03.jpg", "", "", "")
	masonry.AddImage("img4", "./assets/nature_04.jpg", "", "", "").Root.ColSpan(2)
	masonry.AddImage("img5", "./assets/nature_05.jpg", "", "", "")
	masonry.AddImage("img6", "./assets/nature_06.jpg", "", "", "")
	masonry.AddImage("img7", "./assets/12.jpg", "", "", "")
	masonry.AddImage("img8", "./assets/banner_6.jpg", "", "", "").Root.ColSpan(3)
	masonry.AddImage("img9", "./assets/nature_09.jpg", "", "", "")
	masonry.AddImage("img10", "./assets/banner_9.jpg", "", "", "").Root.ColSpan(2)
	masonry.AddImage("img11", "./assets/nature_11.jpg", "", "", "")
	masonry.AddImage("img12", "./assets/nature_12.jpg", "", "", "")
	'
	'add a theme to the app, these are classes to be applied to element
	app.AddTheme("cover", Array("h-full", "object-cover"))
	'apply these classes to each of these elements
	app.ApplyTheme("cover", Array("img1","img2","img3","img4","img5","img6","img7","img8","img9"))
	app.ApplyTheme("cover", Array("img10","img11","img12"))
	
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim masonry As SDUIDiv = page.Cell(1, 1).AddDiv("masonry")"$)
	c1.AddCode($"masonry.Clear"$)
	c1.AddCode($"'this will be a grid"$)
	c1.AddCode($"masonry.Grid"$)
	c1.AddCode($"'there will be 3 columns"$)
	c1.AddCode($"masonry.Root.Gridcols = 3"$)
	c1.AddCode($"'there is a gap between items"$)
	c1.AddCode($"masonry.Root.Gap = 4"$)
	c1.AddCode($"'set grid flow"$)
	c1.AddCode($"masonry.Root.gridFlowRowDense"$)
	c1.AddCode($"'"$)
	c1.AddCode($"masonry.AddImage("img1", "./assets/nature_01.jpg", "", "", "").Root.ColSpan = 2"$)
	c1.AddCode($"masonry.AddImage("img2", "./assets/nature_02.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img3", "./assets/nature_03.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img4", "./assets/nature_04.jpg", "", "", "").Root.ColSpan = 2"$)
	c1.AddCode($"masonry.AddImage("img5", "./assets/nature_05.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img6", "./assets/nature_06.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img7", "./assets/12.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img8", "./assets/banner_6.jpg", "", "", "").Root.ColSpan = 3"$)
	c1.AddCode($"masonry.AddImage("img9", "./assets/nature_09.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img10", "./assets/banner_9.jpg", "", "", "").Root.ColSpan = 2"$)
	c1.AddCode($"masonry.AddImage("img11", "./assets/nature_11.jpg", "", "", "")"$)
	c1.AddCode($"masonry.AddImage("img12", "./assets/nature_12.jpg", "", "", "")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"'add a theme to the app, these are classes to be applied to element"$)
	c1.AddCode($"app.AddTheme("cover", Array("h-full", "object-cover"))"$)
	c1.AddCode($"'apply these classes to each of these elements"$)
	c1.AddCode($"app.ApplyTheme("cover", Array("img1","img2","img3","img4","img5","img6","img7","img8","img9"))"$)
	c1.AddCode($"app.ApplyTheme("cover", Array("img10","img11","img12"))"$)
	c1.Refresh
End Sub
