﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "navbarpage"
	Public title As String = "NavBar"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim nb1 As SDUINavBar = page.Cell(1, 1).AddNavBar("nb1")
	nb1.Root.BGColor(app.COLOR_PRIMARY)
	nb1.Root.TextColorIntensity(app.color_primary,"content")
	nb1.Root.Shadow(app.SIZE_XL)
	nb1.Root.roundedBox
	nb1.AddTitle("SithasoDaisyUI")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim nb1 As SDUINavBar = page.Cell(1, 1).AddNavBar("nb1")"$)
	c1.AddCode($"nb1.Root.BGColor = app.COLOR_PRIMARY"$)
	c1.AddCode($"nb1.Root.TextColorIntensity(app.color_primary,"content")"$)
	c1.AddCode($"nb1.Root.ShadowSize = app.SIZE_XL"$)
	c1.AddCode($"nb1.Root.roundedBox"$)
	c1.AddCode($"nb1.AddTitle("SithasoDaisyUI")"$)
	c1.Refresh
	'
	Dim nb2 As SDUINavBar = page.Cell(2, 1).AddNavBar("nb2")
	nb2.Root.BGColorIntensity(app.COLOR_BASE, 100)
	nb2.Root.Shadow(app.SIZE_LG)
	nb2.AddHamburgerButton("")
	nb2.AddTitle("SithasoDaisyUI")
	nb2.AddMenuButton
	
	Dim c2 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim nb2 As SDUINavBar = page.Cell(2, 1).AddNavBar("nb2")"$)
	c2.AddCode($"nb2.Root.BGColorIntensity(app.COLOR_BASE, 100)"$)
	c2.AddCode($"nb2.Root.ShadowSize = app.SIZE_LG"$)
	c2.AddCode($"nb2.AddHamburgerButton"$)
	c2.AddCode($"nb2.AddTitle("SithasoDaisyUI")"$)
	c2.AddCode($"nb2.AddMenuButton"$)
	c2.Refresh
	'
	Dim nb3 As SDUINavBar = page.Cell(5, 1).AddNavBar("nb3")
	nb3.Root.BGColorIntensity(app.COLOR_BASE, 100)
	nb3.Root.Shadow(app.SIZE_LG)
	nb3.AddHamburgerButton("")
	nb3.AddTitle("SithasoDaisyUI")
	'nb3.AddMenuButton
	'
	Dim h1 As SDUIDiv = nb3.AddFlexNoneDiv(1)
	h1.Gap(2)
	
	Dim m1 As SDUIMenu = h1.AddMenu("m1")
	m1.Horizontal
	m1.Root.Shadow("")
	m1.Root.P(0)
	m1.AddItem("i1", "Item 1")
	m1.AddItemParent("i2", "Item 2")
	m1.AddItem("i3", "Item 3")
	m1.AddItemChild("i2", "i4", "Child 1")
	m1.AddItemChild("i2", "i5", "Child 2")
	m1.AddItemChild("i2", "i6", "Child 3")
	'add search box
	Dim sb As SDUITextBox = h1.AddTextBoxSearch("sb1")  'ignore
	'add drop down avatar
	Dim dda As SDUIDropDown = h1.AddDropDownAvatar("dda1", 10, "./assets/sponge.png")
	dda.AtEnd
	dda.AvatarOnline = True
	dda.Menu.Root.roundedBox
	dda.Menu.Root.MT(3)
	dda.AddItemBadge("", "profile", "Profile", "new")
	dda.AddItem("settings", "Settings")
	dda.AddItem("logout", "Logout")
	'
	
	Dim ddai As SDUIDropDown = h1.AddDropDownIcon("dda2",  app.size_lg, "fa-solid fa-cart-shopping")
	ddai.BadgeValue = 8
	ddai.AtEnd
	Dim cart As SDUICard = ddai.Container.AddCard("cart1", "", "")
	cart.Title.Hide
	cart.Compact
	cart.DropDownContent
	cart.Root.Shadow("")
	cart.W = 52
	Dim items As SDUILabel = cart.Container.AddParagraph("items", "8 items")
	items.Root.fontbold
	items.Root.TextSize(app.SIZE_LG)
	
	Dim subtotal As SDUILabel = cart.Container.AddParagraph("sub", "Sub-Total: $999")
	subtotal.Root.TextColor(app.COLOR_INFO)
	'
	Dim btn As SDUIButton = cart.Actions.AddButton("viewcart", "View Cart")
	btn.Size = app.size_sm
	btn.Color = app.color_primary
	btn.Block
	'
	Dim btnicon As SDUIButton = h1.AddButtonIcon("btnicon", app.SIZE_LG, "fa-solid fa-bell")
	btnicon.BadgeColor = app.COLOR_PRIMARY
	btnicon.Ghost.circle
	
	Dim btnSearch As SDUIButton = h1.AddButtonIcon("btnsearch", app.SIZE_LG, "fa-solid fa-magnifying-glass")
	btnSearch.Ghost.circle
			'ignore
	'
	Dim c3 As SDUIMockupCode = page.Cell(6, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim nb3 As SDUINavBar = page.Cell(5, 1).AddNavBar("nb3")"$)
	c3.AddCode($"nb3.Root.BGColorIntensity(app.COLOR_BASE, 100)"$)
	c3.AddCode($"nb3.Root.ShadowSize = app.SIZE_LG"$)
	c3.AddCode($"nb3.AddHamburgerButton"$)
	c3.AddCode($"nb3.AddTitle("SithasoDaisyUI")"$)
	c3.AddCode($"'nb3.AddMenuButton"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim h1 As SDUIDiv = nb3.AddFlexNoneDiv(1)"$)
	c3.AddCode($"h1.Root.Gap = 2"$)
	c3.AddCode($"Dim m1 As SDUIMenu = h1.AddMenu("m1")"$)
	c3.AddCode($"m1.Horizontal"$)
	c3.AddCode($"m1.Root.Shadow = False"$)
	c3.AddCode($"m1.Root.PA = 0"$)
	c3.AddCode($"m1.AddItem("i1", "Item 1")"$)
	c3.AddCode($"m1.AddItemParent("i2", "Item 2")"$)
	c3.AddCode($"m1.AddItem("i3", "Item 3")"$)
	c3.AddCode($"m1.AddItemChild("i2", "i4", "Child 1")"$)
	c3.AddCode($"m1.AddItemChild("i2", "i5", "Child 2")"$)
	c3.AddCode($"m1.AddItemChild("i2", "i6", "Child 3")"$)
	c3.AddCode($"'add search box"$)
	c3.AddCode($"Dim sb As SDUITextBox = h1.AddTextBoxSearch("sb1")  'ignore"$)
	c3.AddCode($"'add drop down avatar"$)
	c3.AddCode($"Dim dda As SDUIDropDown = h1.AddDropDownAvatar("dda1", 10, "./assets/sponge.png")"$)
	c3.AddCode($"dda.AtEnd"$)
	c3.AddCode($"dda.AvatarOnline = True"$)
	c3.AddCode($"dda.MenuList.Root.roundedBox"$)
	c3.AddCode($"dda.MenuList.Root.MT = 3"$)
	c3.AddCode($"dda.AddItemBadge("profile", "Profile", "new")"$)
	c3.AddCode($"dda.AddItem("settings", "Settings")"$)
	c3.AddCode($"dda.AddItem("logout", "Logout")"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim ddai As SDUIDropDown = h1.AddDropDownIcon("dda2",  app.size_lg, "fa-cart-shopping")"$)
	c3.AddCode($"ddai.BadgeValue = 8"$)
	c3.AddCode($"ddai.AtEnd"$)
	c3.AddCode($"Dim cart As SDUICard = ddai.Container.AddCard("cart1", "", "")"$)
	c3.AddCode($"cart.Title.Hide"$)
	c3.AddCode($"cart.Compact"$)
	c3.AddCode($"cart.DropDownContent"$)
	c3.AddCode($"cart.Root.Shadow = True"$)
	c3.AddCode($"cart.W = 52"$)
	c3.AddCode($"Dim items As SDUILabel = cart.Container.AddParagraph("items", "8 items")"$)
	c3.AddCode($"items.Root.fontbold"$)
	c3.AddCode($"items.Root.TextSize = app.SIZE_LG"$)
	c3.AddCode($"Dim subtotal As SDUILabel = cart.Container.AddParagraph("sub", "Sub-Total: ~999")"$)
	c3.AddCode($"subtotal.Root.TextColor = app.COLOR_INFO"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim btn As SDUIButton = cart.Actions.AddButton("viewcart", "View Cart")"$)
	c3.AddCode($"btn.Size = app.size_sm"$)
	c3.AddCode($"btn.Color = app.color_primary"$)
	c3.AddCode($"btn.Block"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim btnicon As SDUIButton = h1.AddButtonIcon("btnicon", app.SIZE_LG, "fa-bell")"$)
	c3.AddCode($"btnicon.BadgeColor = app.COLOR_PRIMARY"$)
	c3.AddCode($"Dim btnSearch As SDUIButton = h1.AddButtonIcon("btnsearch", app.SIZE_LG, "fa-magnifying-glass")		'ignore"$)
	c3.Refresh
End Sub

Private Sub dda1_Click (item As String)
	Log("dda1_Click...")
	Log(item)
End Sub


Private Sub m1_Click (item As String)
	Log("m1_Click...")
	Log(item)
End Sub