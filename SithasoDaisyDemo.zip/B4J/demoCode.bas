﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "mockcodepage"
	Public title As String = "Mock Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns10
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Dim code As SDUIMockupCode
	code.AddMockUpCode(Me, page.CellID(1, 1), "code1", "vb")
	code.Clear
	code.AddCode($"'This is a template for a blank page"$)
	code.AddCode($"'Static code module"$)
	code.AddCode($"Sub Process_Globals"$)
	code.AddCode($"'this is the name of the page"$)
	code.AddCode($"Public name As String = "blank""$)
	code.AddCode($"'this variable holds the page controller"$)
	code.AddCode($"Public page As SDUIPage"$)
	code.AddCode($"'this variable holds reference to the app"$)
	code.AddCode($"'usually for constants and other things"$)
	code.AddCode($"Public app As SDUIApp"$)
	code.AddCode($"'the variable referencing banano lib"$)
	code.AddCode($"Private banano As BANano		'ignore"$)
	code.AddCode($"End Sub"$)
	code.AddCode("")
	code.AddCode($"'sub to show the page"$)
	code.AddCode($"Sub Show(duiapp As SDUIApp)"$)
	code.AddCode($"'initialize the page"$)
	code.AddCode($"'this clears the 'pageview'"$)
	code.AddCode($"page.AddPage(Me, name)"$)
	code.AddCode($"'get the reference to the app"$)
	code.AddCode($"app = duiapp"$)
	code.AddCode($"'build the page, via code or loadlayouts"$)
	code.AddCode($"BuildPage"$)
	code.AddCode($"End Sub"$)
	code.AddCode("")
	'
	code.AddCode($"'start building the page"$)
	code.AddCode($"private Sub BuildPage"$)
	code.AddCode($"'set the page container to be in design mode"$)
	code.AddCode($"'this shows the row/column grid lines"$)
	code.AddCode($"page.Root.DesignMode = True"$)
	code.AddCode($"'center the page container"$)
	code.AddCode($"page.Root.MXAuto = True"$)
	code.AddCode($"'add 5 rows, each having 2 columns, each spanning 6"$)
	code.AddCode($"page.Root.AddRows5.AddColumns2x6"$)
	code.AddCode($"'build the grid"$)
	code.AddCode($"page.Root.BuildGrid"$)
	code.AddCode($"'start adding you components here"$)
	code.AddCode($"'*****"$)
	code.AddCode($"Dim b1 As SDUIBadge"$)
	code.AddCode($"b1.AddBadge(Me, page.CellID(1,1) , "b1", "Badge")"$)
	code.AddCode($"'"$)
	code.AddCode($"Dim b2 As SDUIBadge"$)
	code.AddCode($"b2.AddBadge(Me, page.CellID(2,1), "b2", "Large")"$)
	code.AddCode($"b2.Large = True"$)
	code.AddCode($"'"$)
	code.AddCode($"Dim b3 As SDUIBadge"$)
	code.AddCode($"b3.AddBadge(Me, page.CellID(3,1), "b3", "")"$)
	code.AddCode($"b3.Large = True"$)
	code.AddCode($"'"$)
	code.AddCode($"Dim b4 As SDUIBadge"$)
	code.AddCode($"b4.AddBadge(Me, page.CellID(4,1), "b4", "Mashy")"$)
	code.AddCode($"b4.Large = True"$)
	code.AddCode($"b4.RightIcon = "fa-brands fa-github""$)
	code.AddCode($"b4.color = app.COLOR_PRIMARY"$)
	code.AddCode($"End Sub"$)
	code.Refresh
End Sub
