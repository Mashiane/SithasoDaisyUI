﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adgridx"
	Public title As String = "AD CSS Grid"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private R1 As SDUIRow
	Private R1C1 As SDUICol
	Private R2 As SDUIRow
	Private R2C1 As SDUICol
	Private R2C2 As SDUICol
	Private R3 As SDUIRow
	Private R3C1 As SDUICol
	Private R3C2 As SDUICol
	Private R4 As SDUIRow
	Private R4C1 As SDUICol
	Private R4C2 As SDUICol
	Private R5 As SDUIRow
	Private R6 As SDUIRow
	Private R6C1 As SDUICol
	Private R6C2 As SDUICol
	Private R6C3 As SDUICol
	Private R5C1 As SDUICol
	Private R5C2 As SDUICol
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adgridxlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R1", "R1", R1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R1C1", "R1C1", R1C1.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R2", "R2", R2.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R2C1", "R2C1", R2C1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R2C2", "R2C2", R2C2.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R3", "R3", R3.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R3C1", "R3C1", R3C1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R3C2", "R3C2", R3C2.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R4", "R4", R4.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R4C1", "R4C1", R4C1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R4C2", "R4C2", R4C2.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R5", "R5", R5.CustProps)
	pgIndex.AddDesignKV1("SDUIRow.R6", "R6", R6.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R6C1", "R6C1", R6C1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R6C2", "R6C2", R6C2.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R6C3", "R6C3", R6C3.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R5C1", "R5C1", R5C1.CustProps)
	pgIndex.AddDesignKV1("SDUICol.R5C2", "R5C2", R5C2.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
