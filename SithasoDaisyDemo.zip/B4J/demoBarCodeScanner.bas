﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "barcodepage"
	Public title As String = "Bar Code Scanner - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private bcScanner As SDUIBarCodeReader
	Private txtResult As SDUITextBox
	Private btnScan As SDUIButton
	Private btnStop As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesBarCodeReader)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows4.AddColumns2x6
	page.Root.AddRows1.AddColumns12
	
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	txtResult = page.Cell(1, 1).AddTextBoxLabel("code1", "Scanned Code", "")
	
	btnScan = page.Cell(3, 1).AddButton("btnscan", "Start Scanning")
	btnStop = page.Cell(3, 1).AddButton("btnstop", "Stop Scanning")
	
	bcScanner.AddBarCodeReader(Me, page.Cell(2, 1).Name, "bcreader1")
	'
	page.Cell(1, 1).CenterChildren
	page.Cell(2, 1).CenterChildren
	page.Cell(2, 1).justifyAround
	page.Cell(3, 1).CenterChildren
	page.Cell(3, 1).justifyBetween.gap(1)
	'
	Dim c1 As SDUIMockupCode = page.Cell(4,1).AddMockUpCode("c1", "vb")
	c1.AddCode($"'start adding you components here"$)
	c1.AddCode($"txtResult = page.Cell(1, 1).AddTextBoxLabel("code1", "Scanned Code", "")"$)
	c1.AddCode($"btnScan = page.Cell(3, 1).AddButton("btnscan", "Start Scanning")"$)
	c1.AddCode($"btnStop = page.Cell(3, 1).AddButton("btnstop", "Stop Scanning")"$)
	c1.AddCode($"bcScanner = page.Cell(2, 1).AddBarCodeReader("bcreader1")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"page.Cell(1, 1).CenterChildren"$)
	c1.AddCode($"page.Cell(2, 1).CenterChildren"$)
	c1.AddCode($"page.Cell(2, 1).justifyAround"$)
	c1.AddCode($"page.Cell(3, 1).CenterChildren"$)
	c1.AddCode($"page.Cell(3, 1).justifyBetween.gap(1)"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnscan_click (e As BANanoEvent)"$)
	c1.AddCode($"banano.Await(bcScanner.ScanWait)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnstop_click (e As BANanoEvent)"$)
	c1.AddCode($"banano.Await(bcScanner.StopScanWait)"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub bcreader1_ScanFailure (error As Object)"$)
	c1.AddCode($"txtResult.Value = """$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub bcreader1_ScanSuccess (decodedText As String, decodedResult As Map)"$)
	c1.AddCode($"txtResult.Value = decodedText"$)
	c1.AddCode($"bcScanner.StopScanWait"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Sub btnscan_click (e As BANanoEvent)
	banano.Await(bcScanner.ScanWait)
End Sub

Sub btnstop_click (e As BANanoEvent)
	banano.Await(bcScanner.StopScanWait)
End Sub

Private Sub bcreader1_ScanFailure (error As Object)
	txtResult.Value = ""
End Sub

Private Sub bcreader1_ScanSuccess (decodedText As String, decodedResult As Map)
	txtResult.Value = decodedText
	bcScanner.StopScanWait
	app.ShowSwal(decodedText)
End Sub

