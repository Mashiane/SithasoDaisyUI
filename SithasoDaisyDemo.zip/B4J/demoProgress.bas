﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "progress"
	Public title As String = "Progress"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows10.AddColumns4p8
	page.Root.BuildGrid
	'
	Dim prg1 As SDUIProgress = page.Cell(1, 1).AddProgress("prg1", 10)
	prg1.color = app.COLOR_PRIMARY
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim prg1 As SDUIProgress = page.Cell(1, 1).AddProgress("prg1", 10)"$)
	c1.AddCode($"prg1.color = app.COLOR_PRIMARY"$)
	c1.Refresh
	'
	Dim prg2 As SDUIProgress
	prg2.AddProgress(Me, page.CellID(2, 1), "prg2", 50)
	
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim prg2 As SDUIProgress"$)
	c2.AddCode($"prg2.AddProgress(Me, page.CellID(2, 1), "prg2", 50)"$)
	c2.Refresh
	'
	Dim prg3 As SDUIProgress
	prg3.AddProgress(Me, page.CellID(3, 1), "prg3", 25)
	prg3.color = app.COLOR_SUCCESS
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim prg3 As SDUIProgress"$)
	c3.AddCode($"prg3.AddProgress(Me, page.CellID(3, 1), "prg3", 25)"$)
	c3.AddCode($"prg3.color = app.COLOR_SUCCESS"$)
	c3.Refresh
	'
	Dim prg4 As SDUIProgress
	prg4.AddProgress(Me, page.CellID(4, 1), "prg4", 20)
	prg4.color = app.COLOR_WARNING
	prg4.Indeterminate = True
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim prg4 As SDUIProgress"$)
	c4.AddCode($"prg4.AddProgress(Me, page.CellID(4, 1), "prg4", 20)"$)
	c4.AddCode($"prg4.color = app.COLOR_WARNING"$)
	c4.AddCode($"prg4.Indeterminate = True"$)
	c4.Refresh
	'
	Dim prg5 As SDUIProgress
	prg5.AddProgress(Me, page.CellID(5, 1), "prg5", 45)
	prg5.Value = 60
	prg5.Color = app.color_Error
	prg5.Root.H(5)
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim prg5 As SDUIProgress"$)
	c5.AddCode($"prg5.AddProgress(Me, page.CellID(5, 1), "prg5", 45)"$)
	c5.AddCode($"prg5.Value = 60"$)
	c5.AddCode($"prg5.Color = app.color_Error"$)
	c5.AddCode($"prg5.Root.H = 5"$)
	c5.Refresh
	'
	Dim prg6 As SDUIProgress = page.Cell(6, 1).AddProgressLabel("prg6", "Project Progress", 20, "Hint...")
	prg6.Color = app.COLOR_INFO
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim prg6 As SDUIProgress = page.Cell(6, 1).AddProgressLabel("prg6", "Project Progress", 20, "Hint...")"$)
	c6.AddCode($"prg6.Color = app.COLOR_INFO"$)
	c6.Refresh
	
End Sub

Private Sub prg6_Change (value As Int)
	page.Cell(4,2).Caption = value
End Sub