﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "toggles"
	Public title As String = "Toggle"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private tgle1 As SDUIToggle
	Private tgle2 As SDUIToggle
	Private tgle3 As SDUIToggle
	Private tgle4 As SDUIToggle
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	
	tgle1.AddToggle(Me, page.CellID(1,1), "tgle1")
	tgle1.Checked = True
	tgle1.color = app.COLOR_PRIMARY
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"tgle1.AddToggle(Me, page.CellID(1,1), "tgle1")"$)
	c1.AddCode($"tgle1.Checked = True"$)
	c1.AddCode($"tgle1.color = app.COLOR_PRIMARY"$)
	c1.AddCode($"'trap change event"$)
	c1.AddCode($"Private Sub tgle1_Change (checked As Boolean)"$)
	c1.AddCode($"page.Cell(1, 4).Caption = checked"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	'
	page.Cell(1, 1).AddBR
	Dim btnGet As SDUIButton = page.Cell(1,1).AddButton("btnget", "Get")
	'
	Dim btnSet As SDUIButton = page.Cell(1,1).AddButton("btnset", "Set")
	'
	Dim btnToggle As SDUIButton = page.Cell(1,1).AddButton("btntoggle", "Toggle")
	
	
	tgle2.AddToggleLabel(Me, page.CellID(2,1), "tgle2","Remember Me", "right")
	tgle2.color = app.COLOR_ACCENT
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"tgle2.AddToggleLabel(Me, page.CellID(2,1), "tgle2","Remember Me", "right")"$)
	c2.AddCode($"tgle2.color = app.COLOR_ACCENT"$)
	c2.Refresh
	'
	tgle3 = page.Cell(3,1).AddToggleLabel("tgle3","Remember Me", "left")
	tgle3.color = app.COLOR_PRIMARY
	
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"tgle3 = page.Cell(3,1).AddToggleLabel("tgle3","Remember Me", "left")"$)
	c3.AddCode($"tgle3.color = app.COLOR_PRIMARY"$)
	c3.Refresh
	'
	tgle4 = page.Cell(4, 1).AddToggleLabel("tgle4", "Color Coded", "right")
	'set the color
	tgle4.bgColorIntensity("red", 600)
	'set the checked color
	tgle4.checkedBgColorIntensity("green", 600)
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"tgle4 = page.Cell(4, 1).AddToggleLabel("tgle4", "Color Coded", "right")"$)
	c4.AddCode($"'set the color"$)
	c4.AddCode($"tgle4.bgColorIntensity("red", 600)"$)
	c4.AddCode($"'set the checked color"$)
	c4.AddCode($"tgle4.checkedBgColorIntensity("green", 600)"$)
	c4.Refresh
End Sub

Private Sub tgle1_Change (checked As Boolean)
	page.Cell(1, 4).Caption = checked
End Sub

Private Sub tgle2_Change (checked As Boolean)
	page.Cell(2, 4).Caption = checked
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	Dim b1 As Boolean = tgle1.Checked
	Dim b2 As Boolean = tgle2.Checked
	'
	page.Cell(1, 4).Caption = b1
	page.Cell(2, 4).Caption = b2
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	tgle1.Checked = True
	tgle2.Checked = False
	page.Cell(1, 4).Caption = tgle1.checked
	page.Cell(2, 4).Caption = tgle2.checked
End Sub

Private Sub btntoggle_Click (e As BANanoEvent)
	tgle1.Toggle
	tgle2.Toggle
	page.Cell(1, 4).Caption = tgle1.checked
	page.Cell(2, 4).Caption = tgle2.checked
End Sub

