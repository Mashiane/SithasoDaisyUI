﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adavatars"
	Public title As String = "AD Avatars"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIAvatar1 As SDUIAvatar
	Private SDUIAvatar2 As SDUIAvatar
	Private SDUIAvatar3 As SDUIAvatar
	Private SDUIAvatar4 As SDUIAvatar
	Private SDUIAvatar5 As SDUIAvatar
	Private SDUIAvatar6 As SDUIAvatar
	Private SDUIAvatar7 As SDUIAvatar
	Private SDUIAvatar8 As SDUIAvatar
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "avatarlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar1", "SDUIAvatar1", SDUIAvatar1.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar2", "SDUIAvatar2", SDUIAvatar2.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar3", "SDUIAvatar3", SDUIAvatar3.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar4", "SDUIAvatar4", SDUIAvatar4.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar5", "SDUIAvatar5", SDUIAvatar5.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar6", "SDUIAvatar6", SDUIAvatar6.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar7", "SDUIAvatar7", SDUIAvatar7.CustProps)
	pgIndex.AddDesignKV1("SDUIAvatar.SDUIAvatar8", "SDUIAvatar8", SDUIAvatar8.CustProps)
	'BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
