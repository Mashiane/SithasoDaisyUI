﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "fullcalendar"
	Public title As String = "Full Calendar - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private fc As SDUIFullCalendar
	Private lbl As SDUILabel
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesFullCalendar)
	page.AddPage(Me, name)
	page.Root.p(6)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows3.AddColumns12
	
'	'build the grid
	page.Root.BuildGrid
'	'start adding you components here
	fc.AddFullCalendar(Me, page.Cell(1, 1).Name, "fc")
	'https://fullcalendar.io/docs/locale-demo
	fc.Locale = "af"
	
	fc.AddEvent("1", "", "All Day Event", "2022-11-01", "", False, "", "", "", False, True)
	fc.AddEvent("2", "", "Long Event", "2022-11-07", "2022-11-10", False, "", "", "", False, True)
	fc.AddEvent("3", "", "Repeating Event", "2022-11-09T16:00:00-05:00", "", False, "", "", "", False,True)
	fc.AddEvent("4", "", "Conference", "2022-11-11", "2022-11-13", False, "", "", "", False, True)
	fc.AddEvent("5", "", "Meeting", "2022-11-12T10:30:00-05:00", "2022-11-12T12:30:00-05:00", False, "","", "", False, True)
	fc.AddEvent("6", "", "Lunch", "2022-11-12T12:00:00-05:00", "", True, "", "", "", False, True)
	fc.Refresh
	fc.gotoDate("2022-11-01")
	'
	lbl = page.Cell(2, 1).AddParagraph("lbl", "Event")
	'
	Dim c1 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"fc = page.Cell(1, 1).AddFullCalendar("fc")"$)
	c1.AddCode($"'https://fullcalendar.io/docs/locale-demo"$)
	c1.AddCode($"fc.Locale = "af""$)
	c1.AddCode($"fc.AddEvent("1", "", "All Day Event", "2022-11-01", "", False, "", "", "", False, True)"$)
	c1.AddCode($"fc.AddEvent("2", "", "Long Event", "2022-11-07", "2022-11-10", False, "", "", "", False, True)"$)
	c1.AddCode($"fc.AddEvent("3", "", "Repeating Event", "2022-11-09T16:00:00-05:00", "", False, "", "", "", False,True)"$)
	c1.AddCode($"fc.AddEvent("4", "", "Conference", "2022-11-11", "2022-11-13", False, "", "", "", False, True)"$)
	c1.AddCode($"fc.AddEvent("5", "", "Meeting", "2022-11-12T10:30:00-05:00", "2022-11-12T12:30:00-05:00", False, "","", "", False, True)"$)
	c1.AddCode($"fc.AddEvent("6", "", "Lunch", "2022-11-12T12:00:00-05:00", "", True, "", "", "", False, True)"$)
	c1.AddCode($"fc.Refresh"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub fc_EventClick (args As Map)"$)
	c1.AddCode($"Dim sout As String = banano.ToJson(args)"$)
	c1.AddCode($"lbl.Caption = sout"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Private Sub fc_EventClick (args As Map)
	Dim sout As String = banano.ToJson(args)
	lbl.Caption = sout
End Sub

Private Sub fc_EventDrop (args As Map)
	Log("Calendar1_EventDrop")
	Log(args)
End Sub

Private Sub fc_EventResize (args As Map)
	Log("Calendar1_EventResize")
	Log(args)
End Sub

Private Sub fc_Drop (args As Map)
	Log("Calendar1_Drop")
	Log(args)
End Sub

Private Sub fc_DateClick (args As Map)
	Log("Calendar1_DateClick")
	Log(args)
End Sub

Private Sub fc_Select (args As Map)
	Log("Calendar1_Select")
	Log(args)
End Sub