﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "addivider"
	Public title As String = "AD Divider"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIDiv1 As SDUIDiv
	Private SDUIDiv2 As SDUIDiv
	Private SDUIDiv3 As SDUIDiv
	Private SDUIDiv4 As SDUIDiv
	Private SDUIDiv5 As SDUIDiv
	Private SDUIDiv6 As SDUIDiv
	Private SDUIDivider1 As SDUIDivider
	Private SDUIDivider2 As SDUIDivider
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "addividerlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv1", "SDUIDiv1", SDUIDiv1.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv2", "SDUIDiv2", SDUIDiv2.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv3", "SDUIDiv3", SDUIDiv3.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv4", "SDUIDiv4", SDUIDiv4.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv5", "SDUIDiv5", SDUIDiv5.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv6", "SDUIDiv6", SDUIDiv6.CustProps)
	pgIndex.AddDesignKV1("SDUIDivider.SDUIDivider1", "SDUIDivider1", SDUIDivider1.CustProps)
	pgIndex.AddDesignKV1("SDUIDivider.SDUIDivider2", "SDUIDivider2", SDUIDivider2.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
