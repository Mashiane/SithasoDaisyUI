﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "listview1"
	Public title As String = "ListView 1"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim lv As SDUIListView = page.Cell(1, 1).AddListView("lv1")
	lv.RoundedBox
	lv.ImageVisible = False
	lv.LeftIconVisible = True
	lv.RightIconVisible = False
	lv.RightTextVisible = False
	lv.shadow("2xl")
	'
	lv.AddIcon("p1", "fa-solid fa-house", "John Doe 1", "Missisipi", "48")
	lv.AddIcon("p2", "fa-solid fa-user", "John Doe 1", "Missisipi", "47")
	lv.AddIcon("p3", "fa-brands fa-facebook", "John Doe 2", "Missisipi", "46")
	lv.AddIcon("p4", "fa-solid fa-download", "John Doe 3", "Missisipi", "45")
	lv.AddIcon("p5", "fa-regular fa-envelope", "John Doe 3", "Missisipi", "44")
	
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim lv As SDUIListView = page.Cell(1, 1).AddListView("lv1")"$)
	c1.AddCode($"lv.RoundedBox"$)
	c1.AddCode($"lv.ImageVisible = False"$)
	c1.AddCode($"lv.LeftIconVisible = True"$)
	c1.AddCode($"lv.RightIconVisible = False"$)
	c1.AddCode($"lv.RightTextVisible = False"$)
	c1.AddCode($"lv.shadow("2xl")"$)
	c1.AddCode($"'"$)
	c1.AddCode($"lv.AddIcon("p1", "fa-solid fa-house", "John Doe 1", "Missisipi", "48")"$)
	c1.AddCode($"lv.AddIcon("p2", "fa-solid fa-user", "John Doe 1", "Missisipi", "47")"$)
	c1.AddCode($"lv.AddIcon("p3", "fa-brands fa-facebook", "John Doe 2", "Missisipi", "46")"$)
	c1.AddCode($"lv.AddIcon("p4", "fa-solid fa-download", "John Doe 3", "Missisipi", "45")"$)
	c1.AddCode($"lv.AddIcon("p5", "fa-regular fa-envelope", "John Doe 3", "Missisipi", "44")"$)
	c1.Refresh
End Sub

Private Sub lv1_Click (item As String)
	app.ShowSwal(item)
End Sub