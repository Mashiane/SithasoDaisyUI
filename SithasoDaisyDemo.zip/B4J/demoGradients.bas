﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "grads"
	Public title As String = "Gradients"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows12.AddColumns5p7
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim g1 As SDUIDiv = page.Cell(1, 1).AddDiv("g1")
	g1.H(40).bgGradientToR.fromColorIntensity("purple", 600).toColorIntensity("blue", 600)
	'
	Dim co1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("co1", "vb")
	co1.AddCode($"Dim g1 As SDUIDiv = page.Cell(1, 1).AddDiv("g1")"$)
	co1.AddCode($"g1.H(40).bgGradientToR.fromColorIntensity("purple", 600).toColorIntensity("blue", 600)"$)
	co1.Refresh
	'
	Dim g2 As SDUIDiv = page.Cell(2, 1).AddDiv("g2")
	g2.H(40).bgGradientToB.fromColorIntensity("purple", 600).toColorIntensity("blue", 600)
	'
	Dim co2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("co2", "vb")
	co2.AddCode($"Dim g2 As SDUIDiv = page.Cell(2, 1).AddDiv("g2")"$)
	co2.AddCode($"g2.H(40).bgGradientToB.fromColorIntensity("purple", 600).toColorIntensity("blue", 600)"$)
	co2.Refresh
	'
	Dim g3 As SDUIDiv = page.Cell(3, 1).AddDiv("g3")
	g3.H(40).bgGradientToR.fromColorIntensity("purple", 600).viaColorIntensity("pink", 600).toColorIntensity("blue", 600)
	'
	Dim co3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("co3", "vb")
	co3.AddCode($"Dim g3 As SDUIDiv = page.Cell(3, 1).AddDiv("g3")"$)
	co3.AddCode($"g3.H(40).bgGradientToR.fromColorIntensity("purple", 600).viaColorIntensity("pink", 600).toColorIntensity("blue", 600)"$)
	co3.Refresh
	'
	Dim p1 As SDUILabel = page.Cell(4, 1).AddH1("p1", "Adding gradients to text!")
	p1.Root.textSize("5xl").p(4).textCenter.fontbold
	p1.Root.bggradienttor.fromColorIntensity("purple",600).viaColorIntensity("pink", 600).toColorIntensity("blue", 600)
	p1.Root.bgClipText.textTransparent
	'
	Dim co4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("co4", "vb")
	co4.AddCode($"Dim p1 As SDUILabel = page.Cell(4, 1).AddH1("p1", "Adding gradients to text!")"$)
	co4.AddCode($"p1.Root.textSize("5xl").p(4).textCenter.fontbold"$)
	co4.AddCode($"p1.Root.bggradienttor.fromColorIntensity("purple",600).viaColorIntensity("pink", 600).toColorIntensity("blue", 600)"$)
	co4.AddCode($"p1.Root.bgClipText.textTransparent"$)
	co4.Refresh

	Dim b1 As SDUIButton = page.Cell(5, 1).AddButtonNormal("b1", "")
	b1.Root.m(4).p(1).roundedfull.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	Dim s1 As SDUILabel = b1.AddSpan("b1span", "Follow Me")
	s1.root.textColor("black").px(4).py(2).roundedFull.block.fontSemiBold.bgColor("white")
	s1.Root.hover("bg-transparent").hover("text-white").transition
	'
	Dim co5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("co5", "vb")
	co5.AddCode($"Dim b1 As SDUIButton = page.Cell(5, 1).AddButtonNormal("b1", "")"$)
	co5.AddCode($"b1.Root.m(4).p(1).roundedfull.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co5.AddCode($"Dim s1 As SDUILabel = b1.AddSpan("b1span", "Follow Me")"$)
	co5.AddCode($"s1.root.textColor("black").px(4).py(2).roundedFull.block.fontSemiBold.bgColor("white")"$)
	co5.AddCode($"s1.Root.hover("bg-transparent").hover("text-white").transition"$)
	co5.Refresh

	Dim i1 As SDUIDiv = page.Cell(6, 1).AddDiv("i1")
	i1.m(4).p(1).roundedFull.maxW("sm").bgGradientToR.fromColorIntensity("rose", 400)
	i1.viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	
	'SR-ONLY BUG
	'Dim i1Label As SDUILabel = i1.AddLabelFor("i1Label", "name", "Name")
	'i1Label.Root.srOnly
	'
	Dim i1Input As SDUILabel = i1.AddInput("name", "text")
	i1Input.Root.p(3).wFull.roundedFull.focus("outline-none").placeholder("Enter Your Name")
	'
	Dim co6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("co6", "vb")
	co6.AddCode($"Dim i1 As SDUIDiv = page.Cell(6, 1).AddDiv("i1")"$)
	co6.AddCode($"i1.m(4).p(1).roundedFull.maxW("sm").bgGradientToR.fromColorIntensity("rose", 400)"$)
	co6.AddCode($"i1.viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co6.AddCode($"'SR-ONLY BUG"$)
	co6.AddCode($"'Dim i1Label As SDUILabel = i1.AddLabelFor("i1Label", "name", "Name")"$)
	co6.AddCode($"'i1Label.Root.srOnly"$)
	co6.AddCode($"'"$)
	co6.AddCode($"Dim i1Input As SDUILabel = i1.AddInput("name", "text")"$)
	co6.AddCode($"i1Input.Root.p(3).wFull.roundedFull.focus("outline-none").placeholder("Enter Your Name")"$)
	co6.Refresh

	Dim a1 As SDUILabel = page.Cell(7, 1).AddArticle("a1")
	a1.Root.p("1.5").mxAuto.my(4).maxW("sm").rounded("xl").bgGradientToR
	a1.Root.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	'
	Dim a1div1 As SDUIDiv = a1.Root.AddDiv("a1div1")
	a1div1.bgColor("white").p(5).rounded("lg")
	'
	Dim h4div1 As SDUILabel = a1div1.AddH4("h4ddiv1", "Take your Web Dev to skills to the Next Level")
	h4div1.Root.textsize("2xl").fontbold
	'
	Dim adiv1 As SDUILink = a1div1.AddAnchor("adiv1", "Visit SithasoDaisy on Netlify", "#")
	adiv1.Root.Hover("underline").textColorIntensity("gray", 600).targetBlank
	'
	Dim co7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("co7", "vb")
	co7.AddCode($"Dim a1 As SDUILabel = page.Cell(7, 1).AddArticle("a1")"$)
	co7.AddCode($"a1.Root.p("1.5").mxAuto.my(4).maxW("sm").rounded("xl").bgGradientToR"$)
	co7.AddCode($"a1.Root.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co7.AddCode($"'"$)
	co7.AddCode($"Dim a1div1 As SDUIDiv = a1.Root.AddDiv("a1div1")"$)
	co7.AddCode($"a1div1.bgColor("white").p(5).rounded("lg")"$)
	co7.AddCode($"'"$)
	co7.AddCode($"Dim h4div1 As SDUILabel = a1div1.AddH4("h4ddiv1", "Take your Web Dev to skills to the Next Level")"$)
	co7.AddCode($"h4div1.Root.textsize("2xl").fontbold"$)
	co7.AddCode($"'"$)
	co7.AddCode($"Dim adiv1 As SDUILink = a1div1.AddAnchor("adiv1", "Visit SithasoDaisy on Netlify", "#")"$)
	co7.AddCode($"adiv1.Root.Hover("underline").textColorIntensity("gray", 600).targetBlank"$)
	co7.Refresh
	
	Dim ah1 As SDUILabel = page.Cell(8, 1).AddH1("ah1", "Level up your Web Dev Skills, visit ")
	ah1.Root.textSize("3xl").fontBold.m(4)
	
	Dim an1 As SDUILink = ah1.Root.AddAnchor("an1", "SithasoDaisy", "#")
	an1.targetBlank
	an1.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	'
	Dim co8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("co8", "vb")
	co8.AddCode($"Dim ah1 As SDUILabel = page.Cell(8, 1).AddH1("ah1", "Level up your Web Dev Skills, visit ")"$)
	co8.AddCode($"ah1.Root.textSize("3xl").fontBold.m(4)"$)
	co8.AddCode($"Dim an1 As SDUILink = ah1.Root.AddAnchor("an1", "SithasoDaisy", "#")"$)
	co8.AddCode($"an1.targetBlank"$)
	co8.AddCode($"an1.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co8.Refresh
	'
	'****
	Dim ah2 As SDUILabel = page.Cell(9, 1).AddH1("ah2", "Level up your Web Dev Skills, visit ")
	ah2.Root.textSize("3xl").fontBold.m(4)
	
	Dim an2 As SDUILink = ah2.Root.AddAnchor("an2", "SithasoDaisy", "#")
	an2.targetBlank
	an2.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	an2.Root.bgArbitrary("length:100%_6px").bgNoRepeat
	'
	Dim co9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("co9", "vb")
	co9.AddCode($"Dim ah2 As SDUILabel = page.Cell(9, 1).AddH1("ah2", "Level up your Web Dev Skills, visit ")"$)
	co9.AddCode($"ah2.Root.textSize("3xl").fontBold.m(4)"$)
	co9.AddCode($"Dim an2 As SDUILink = ah2.Root.AddAnchor("an2", "SithasoDaisy", "#")"$)
	co9.AddCode($"an2.targetBlank"$)
	co9.AddCode($"an2.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co9.AddCode($"an2.Root.bgArbitrary("length:100%_6px").bgNoRepeat"$)
	co9.Refresh
	'
	'****
	Dim ah3 As SDUILabel = page.Cell(10, 1).AddH1("ah3", "Level up your Web Dev Skills, visit ")
	ah3.Root.textSize("3xl").fontBold.m(4)
	
	Dim an3 As SDUILink = ah3.Root.AddAnchor("an3", "SithasoDaisy", "#")
	an3.targetBlank
	an3.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	an3.Root.bgArbitrary("length:100%_6px").bgNoRepeat.bgBottom
	'
	Dim co10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("co10", "vb")
	co10.AddCode($"Dim co10 As SDUIMockupCode = page.Cell(10, 1).AddMockUpCode("co10", "vb")"$)
	co10.AddCode($"co10.AddCode(~"Dim ah3 As SDUILabel = page.Cell(10, 1).AddH1("ah3", "Level up your Web Dev Skills, visit ")"~)"$)
	co10.AddCode($"co10.AddCode(~"ah3.Root.textSize("3xl").fontBold.m(4)"~)"$)
	co10.AddCode($"co10.AddCode(~"Dim an3 As SDUILink = ah3.Root.AddAnchor("an3", "SithasoDaisy", "#")"~)"$)
	co10.AddCode($"co10.AddCode(~"an3.targetBlank"~)"$)
	co10.AddCode($"co10.AddCode(~"an3.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"~)"$)
	co10.AddCode($"co10.AddCode(~"an3.Root.bgArbitrary("length:100%_6px").bgNoRepeat.bgBottom"~)"$)
	co10.AddCode($"co10.Refresh"$)
	co10.Refresh
	'
	'****
	Dim i2 As SDUIDiv = page.Cell(11, 1).AddDiv("i2")
	i2.m(4).p(1).roundedFull.maxW("sm").hover("bg-gradient-to-r").focusWithin("bg-gradient-to-r").focus("").fromColorIntensity("rose", 400)
	i2.viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	
	Dim i2Input As SDUILabel = i2.AddInput("name1", "text")
	i2Input.Root.p(3).wFull.roundedFull.border("1px").borderColorIntensity("fuchsia", 500).focus("outline-none").focus("border-transparent").hover("border-transparent")
	i2Input.Root.placeholder("Enter Your Name")
	'
	Dim co11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("co11", "vb")
	co11.AddCode($"Dim i2 As SDUIDiv = page.Cell(11, 1).AddDiv("i2")"$)
	co11.AddCode($"i2.m(4).p(1).roundedFull.maxW("sm").hover("bg-gradient-to-r").focusWithin("bg-gradient-to-r").focus("").fromColorIntensity("rose", 400)"$)
	co11.AddCode($"i2.viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co11.AddCode($"Dim i2Input As SDUILabel = i2.AddInput("name1", "text")"$)
	co11.AddCode($"i2Input.Root.p(3).wFull.roundedFull.border("1px").borderColorIntensity("fuchsia", 500).focus("outline-none").focus("border-transparent").hover("border-transparent")"$)
	co11.AddCode($"i2Input.Root.placeholder("Enter Your Name")"$)
	co11.Refresh
	'
	'***
	Dim ah4 As SDUILabel = page.Cell(12, 1).AddH1("ah4", "Level up your Web Dev Skills, visit ")
	ah4.Root.textSize("3xl").fontBold.m(4)
	
	Dim an4 As SDUILink = ah4.Root.AddAnchor("an4", "SithasoDaisy", "#")
	an4.targetBlank
	an4.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)
	an4.Root.bgArbitrary("length:100%_6px").bgNoRepeat.bgBottom.hover("bg-[length:100%_100%]").transitionArbitrary("background-size")
	'
	Dim co12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("co12", "vb")
	co12.AddCode($"Dim ah4 As SDUILabel = page.Cell(12, 1).AddH1("ah4", "Level up your Web Dev Skills, visit ")"$)
	co12.AddCode($"ah4.Root.textSize("3xl").fontBold.m(4)"$)
	co12.AddCode($"Dim an4 As SDUILink = ah4.Root.AddAnchor("an4", "SithasoDaisy", "#")"$)
	co12.AddCode($"an4.targetBlank"$)
	co12.AddCode($"an4.Root.bgGradientToR.fromColorIntensity("rose", 400).viaColorIntensity("fuchsia", 500).toColorIntensity("indigo", 500)"$)
	co12.AddCode($"an4.Root.bgArbitrary("length:100%_6px").bgNoRepeat.bgBottom.hover("bg-[length:100%_100%]").transitionArbitrary("background-size")"$)
	co12.Refresh
End Sub