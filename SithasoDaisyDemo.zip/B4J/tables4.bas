﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables4"
	Public title As String = "Table 4"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table4
	Table4Code
End Sub

Sub Table4Code
	Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
	c5.AddCode($"Sub Build_Table4"$)
	c5.AddCode($"Dim tb4 As SDUITable = page.Cell(7, 1).AddTable("tb4")"$)
	c5.AddCode($"tb4.Hover = True"$)
	c5.AddCode($"tb4.Zebra"$)
	c5.AddCode($"'"$)
	c5.AddCode($"tb4.AddColumn("id", "#")"$)
	c5.AddCode($"tb4.AddColumnImage("avatar", "Image", "4rem", "4rem", app.MASK_DECAGON)"$)
	c5.AddCode($"tb4.AddColumnEmail("email", "Email", "name", app.color_accent)"$)
	c5.AddCode($"tb4.AddColumnLink("link", "Link", "link", app.color_primary)"$)
	c5.AddCode($"tb4.AddColumnClickLink("clicklink", "Aisle", "clicklink", app.color_neutral)"$)
	c5.AddCode($"tb4.AddColumnIcon("sm", "Social Media", app.SIZE_LG, "item.color")"$)
	c5.AddCode($"tb4.AddColumnRating("rate", "Satisfaction", 5, "item.color")"$)
	c5.AddCode($"tb4.AddColumnRadialProgress("progress", "Progress", "3.5rem", "item.color", "%")"$)
	c5.AddCode($"'add a badge and use a color from the row"$)
	c5.AddCode($"'tb1.AddColumnBadge("color", "Favourate Color", "item.color")"$)
	c5.AddCode($"'tb1.AddColumnButton("approve", "Approve", app.COLOR_SUCCESS)"$)
	c5.AddCode($"'tb1.AddColumnButton("reject", "Reject", app.color_error)"$)
	c5.AddCode($"'ad as last columns"$)
	c5.AddCode($"'tb1.AddColumnEdit(app.COLOR_PRIMARY)"$)
	c5.AddCode($"'tb1.AddColumnDelete(app.COLOR_SECONDARY)"$)
	c5.AddCode($"tb4.SetItemsPaginate(Items)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Private Sub tb4_Change (Value As Object, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_Change...")"$)
	c5.AddCode($"Log(Value)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Private Sub tb4_sm (item As Map)"$)
	c5.AddCode($"Log("sm...")"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Private Sub tb4_clicklink (item As Map)"$)
	c5.AddCode($"Log("clicklink...")"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
End Sub

Sub Build_Table4
	Dim tb4 As SDUITable = page.Cell(1, 1).AddTable("tb4")
	tb4.Hover = True
	tb4.Zebra
	'
	tb4.AddColumn("id", "#")
	tb4.AddColumnImage("avatar", "Image", "4rem", "4rem", app.MASK_DECAGON)
	tb4.AddColumnEmail("email", "Email", "name", app.color_accent)
	tb4.AddColumnLink("link", "Link", "link", app.color_primary)
	tb4.AddColumnClickLink("clicklink", "Aisle", "clicklink", app.color_neutral)
	tb4.AddColumnIcon("sm", "Social Media", app.SIZE_LG, "item.color")
	tb4.AddColumnRating("rate", "Satisfaction", 5, "item.color")
	tb4.AddColumnRadialProgress("progress", "Progress", "3.5rem", "item.color", "%")
	'add a badge and use a color from the row
	'tb1.AddColumnBadge("color", "Favourate Color", "item.color")
	'tb1.AddColumnButton("approve", "Approve", app.COLOR_SUCCESS)
	'tb1.AddColumnButton("reject", "Reject", app.color_error)
	
	'ad as last columns
	'tb1.AddColumnEdit(app.COLOR_PRIMARY)
	'tb1.AddColumnDelete(app.COLOR_SECONDARY)
	
	banano.Await(tb4.SetItemsPaginate(Items))
End Sub
'
Private Sub tb4_Change (Value As Object, Column As String, item As Map)
	Log("tb4_Change...")
	Log(Value)
	Log(Column)
	Log(item)
End Sub
'
Private Sub tb4_sm (item As Map)
	Log("sm...")
	Log(item)
End Sub
'
Private Sub tb4_clicklink (item As Map)
	Log("clicklink...")
	Log(item)
End Sub