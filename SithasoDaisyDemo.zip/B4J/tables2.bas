﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables2"
	Public title As String = "Table 2"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table2
	Table2Code
End Sub





Sub Table2Code
	Dim c3 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Sub Build_Table2"$)
	c3.AddCode($"Dim tb2 As SDUITable = page.Cell(3, 1).AddTable("tb2")"$)
	c3.AddCode($"tb2.Compact"$)
	c3.AddCode($"'"$)
	c3.AddCode($"tb2.AddColumn("id", "#")"$)
	c3.AddCode($"tb2.AddColumnAvatarTitle("avatar", "Employee", 12, "name", app.MASK_CIRCLE)"$)
	c3.AddCode($"tb2.AddColumnTitleSubTitle("job", "Job", "country")"$)
	c3.AddCode($"tb2.AddColumn("color", "Favourate Color")"$)
	c3.AddCode($"tb2.AddColumnProgress("progress", "Completed", 40, 100, "item.color")"$)
	c3.AddCode($"tb2.AddColumnCheckBox("active", "Active", app.COLOR_PRIMARY, False)"$)
	c3.AddCode($"tb2.AddColumnDropDown("menu", "Menu", "fa-solid fa-ellipsis-vertical", "#3f51b5", CreateMap("edit":"Edit","delete":"Delete","clone":"Clone","print":"Print"))"$)
	
	c3.AddCode($"banano.Await(tb2.SetItemsPaginate(Items))"$)
	c3.AddCode($"tb2.SetRowBackgroundColor(0, "red")"$)
	c3.AddCode($"tb2.SetRowTextColor(0, "white")"$)
	c3.AddCode($"tb2.SetRowColumnBackgroundColor("color", 1, "red")"$)
	c3.AddCode($"tb2.SetRowColumnTextColor("color", 1, "white")"$)
	c3.AddCode($"End Sub"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Private Sub tb2_change (Value As Object, Column As String, item As Map)"$)
	c3.AddCode($"Log(Value)"$)
	c3.AddCode($"Log(Column)"$)
	c3.AddCode($"Log(item)"$)
	c3.AddCode($"End Sub"$)
	'
	c3.AddCode($"Private Sub tb2_MenuItemRow (Row As Int, Action As String, item As Map)"$)
	c3.AddCode($"Log(Row)"$)
	c3.AddCode($"Log(Action)"$)
	c3.AddCode($"Log(item)"$)
	c3.AddCode($"End Sub"$)
	c3.Refresh
End Sub


Sub Build_Table2
	Dim tb2 As SDUITable = page.Cell(1, 1).AddTable("tb2")
	tb2.Compact
	'
	tb2.SetMenuItemHoverColorIntensity("blue", "100")
	tb2.SetMenuItemFocusColorIntensity("blue", "100")
	tb2.SetMenuItemActiveColorIntensity("blue", "100")
	'
	tb2.AddColumn("id", "#")
	tb2.AddColumnAvatarTitle("avatar", "Employee", "4rem", "name", app.MASK_CIRCLE)
	tb2.AddColumnTitleSubTitle("job", "Job", "country")
	tb2.AddColumn("color", "Favourate Color")
	tb2.AddColumnProgress("progress", "Completed", 40, 100, "item.color")
	tb2.AddColumnCheckBox("active", "Active", app.COLOR_PRIMARY, False)
	'
	banano.Await(tb2.SetItemsPaginate(Items))
	tb2.SetRowBackgroundColor(0, "red")
	tb2.SetRowTextColor(0, "white")
	tb2.SetRowColumnBackgroundColor("color", 1, "red")
	tb2.SetRowColumnTextColor("color", 1, "white")
End Sub
'
Private Sub tb2_change (Value As Object, Column As String, item As Map)
	Log(Value)
	Log(Column)
	Log(item)
End Sub
