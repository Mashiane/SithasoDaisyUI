﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "keys"
	Public title As String = "Keyboard"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	page.Cell(1, 1).AddH3("yourstuff", "Your content...")
	page.Cell(1, 1).JustifyCenter
	'
	page.Cell(2, 1).JustifyCenter
	page.Cell(2, 1).Flex
	page.Cell(2, 1).MY(1)
	page.Cell(2, 1).WFull
	page.Cell(2, 1).BGColorIntensity(app.COLOR_BASE, 100)
	page.Cell(2, 1).Shadow("")
	page.Cell(2, 1).Shadow(app.SIZE_2XL)
	page.Cell(2, 1).Border("1px")
	page.Cell(2, 1).RoundedBox
	page.Cell(2, 1).H(10)
	'
	page.Cell(3, 1).AddH3("morseit", "Morse Code...")
	page.Cell(3, 1).JustifyCenter
	'
	page.Cell(4, 1).JustifyCenter
	page.Cell(4, 1).Flex
	page.Cell(4, 1).MY(1)
	page.Cell(4, 1).WFull
	page.Cell(4, 1).BGColorIntensity(app.COLOR_BASE, 100)
	page.Cell(4, 1).Shadow("")
	page.Cell(4, 1).Shadow(app.SIZE_2XL)
	page.Cell(4, 1).Border("1px")
	page.Cell(4, 1).RoundedBox
	page.Cell(4, 1).H(10)
	
	Dim keyboard3 As SDUIDiv
	keyboard3.CreateDiv(Me, page.CellID(5, 1), "keyboard3")
	keyboard3.Flex
	keyboard3.Gap(1)
	keyboard3.MY(1)
	keyboard3.WFull
	keyboard3.JustifyCenter
	keyboard3.AddKeyboardKeys(Array("1", "2", "3","4", "5", "6", "7", "8","9", "0"))
	
	Dim keyboard As SDUIDiv
	keyboard.CreateDiv(Me, page.CellID(5, 1), "keyboard")
	keyboard.Flex
	keyboard.Gap(1)
	keyboard.MY(1)
	keyboard.WFull
	keyboard.JustifyCenter
	keyboard.AddKeyboardKeys(Array("q", "w", "e","r", "t", "y", "u", "i","o", "p"))
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim keyboard3 As SDUIDiv"$)
	c5.AddCode($"keyboard3.CreateDiv(Me, page.CellID(5, 1), "keyboard3")"$)
	c5.AddCode($"keyboard3.Root.Flex"$)
	c5.AddCode($"keyboard3.Root.Gap = 1"$)
	c5.AddCode($"keyboard3.Root.MY = 1"$)
	c5.AddCode($"keyboard3.Root.WFull"$)
	c5.AddCode($"keyboard3.Root.JustifyCenter"$)
	c5.AddCode($"keyboard3.AddKeyboardKeys(Array("1", "2", "3","4", "5", "6", "7", "8","9", "0"))"$)
	c5.Refresh
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Private Sub keyboard3_KeyClick (item As String)"$)
	c6.AddCode($"page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item"$)
	c6.AddCode($"page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)"$)
	c6.AddCode($"End Sub"$)
	c6.Refresh
	'
	Dim keyboard1 As SDUIDiv
	keyboard1.CreateDiv(Me, page.CellID(5, 1), "keyboard1")
	keyboard1.Flex
	keyboard1.Gap(1)
	keyboard1.MY(1)
	keyboard1.WFull
	keyboard1.JustifyCenter
	keyboard1.AddKeyboardKeys(Array("a", "s", "d","f", "g", "h", "j", "k", "l"))
	'
	Dim keyboard2 As SDUIDiv
	keyboard2.CreateDiv(Me, page.CellID(5, 1), "keyboard2")
	keyboard2.Flex
	keyboard2.Gap(1)
	keyboard2.MY(1)
	keyboard2.WFull
	keyboard2.JustifyCenter
	keyboard2.AddKeyboardKeys(Array("z", "x", "c","v", "b", "n", "m"))
	'
	Dim keyboard4 As SDUIDiv
	keyboard4.CreateDiv(Me, page.CellID(5, 1), "keyboard4")
	keyboard4.Flex
	keyboard4.Gap(1)
	keyboard4.MY(1)
	keyboard4.WFull
	keyboard4.JustifyCenter
	keyboard4.AddKeyboardKeys(Array("comma", "dot", "space", "clear"))
End Sub

Private Sub keyboard_KeyClick (item As String)
	page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item
	page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)
End Sub
'
Private Sub keyboard1_KeyClick (item As String)
	page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item
	page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)
End Sub

Private Sub keyboard2_KeyClick (item As String)
	page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item
	page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)
End Sub

Private Sub keyboard3_KeyClick (item As String)
	page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item
	page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)
End Sub

Private Sub keyboard4_KeyClick (item As String)
	Select Case item
	Case "space"
		page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & " "
	Case "dot"
		page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & "."
	Case "comma"
		page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & ","
	Case "clear"
		page.Cell(2, 1).Caption = ""
	Case Else
		page.Cell(2, 1).Caption = page.Cell(2, 1).Caption & item
	End Select
	page.Cell(4, 1).Caption = TranslateToMorse(page.Cell(2, 1).Caption)
End Sub

Sub TranslateToMorse(content As String) As String
	Dim mkeys As Map = MorseKeys
	'we will assign everything to a stringbuilder
	Dim res As StringBuilder
	res.Initialize 
	'make content uppercase
	content = content.ToUpperCase
	'length of the result
	Dim slen As Int = content.Length
	Dim i As Int = 0
	For i = 0 To slen - 1
		'get the content at position
		Dim code_in As String = content.CharAt(i)
		If mkeys.ContainsKey(code_in) Then
		 	Dim code_out As String = mkeys.Get(code_in)
			res.Append(code_out)
		End If
	Next
	Return res.ToString
End Sub

Sub MorseKeys As Map
	Dim table As Map = CreateMap()
	table.Put("A", ".-")
	table.Put("B", "-...")
	table.Put("C", "-.-.")
	table.Put("D", "-..")
	table.Put("E", ".")
	table.Put("F", "..-.")
	table.Put("G", "--.")
	table.Put("H", "....")
	table.Put("I", "..")
	table.Put("J", ".---")
	table.Put("K", "-.-")
	table.Put("L", ".-..")
	table.Put("M", "--")
	table.Put("N", "-.")
	table.Put("O", "---")
	table.Put("P", ".--.")
	table.Put("Q", "--.-")
	table.Put("R", ".-.")
	table.Put("S", "...")
	table.Put("T", "-")
	table.Put("U", "..-")
	table.Put("V", "...-")
	table.Put("W", ".--")
	table.Put("X", "-..-")
	table.Put("Y", "-.--")
	table.Put("Z", "--..")
	table.Put("Á", ".--.-")			'A with acute accent
	table.Put("Ä", ".-.-")			'A with diaeresis
	table.Put("É", "..-..")			'E with acute accent
	table.Put("Ñ", "--.--")			'N with tilde
	table.Put("Ö", "---.")			'O with diaeresis
	table.Put("Ü", "..--")			'U with diaeresis
	table.Put("1", ".----")			
	table.Put("2", "..---")
	table.Put("3", "...--")
	table.Put("4", "....-")
	table.Put("5", ".....")
	table.Put("6", "-....")
	table.Put("7", "--...")
	table.Put("8", "---..")
	table.Put("9", "----.")
	table.Put("0", "-----")
	table.Put(",", "--..--")		'comma
	table.Put(".", ".-.-.-")		'period
	table.Put("?", "..--..")		'question mark
	table.Put(";", "-.-.-")			'semicolon
	table.Put(":", "---...")		'colon
	table.Put("/", "-..-.")			'slash
	table.Put("-", "-....-")		'dash
	table.Put("'", ".----.")		'apostrophe
	table.Put("()", "-.--.-")		'parenthesis
	table.Put("_", "..--.-")		'underline
	table.Put("@", ".--.-.")		'at symbol from http://www.learnmorsecode.com/
	table.Put(" ", "&nbsp;&nbsp;&nbsp;")	'3 spaces
	Return table
End Sub