﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "demoblocks"
	Public title As String = "Existing Blocks"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	'page.Root.BGColorIntensity("blue", 100)
	
	Dim ncard As SDUIDiv = page.Cell(1, 1).AddDiv("ncard")
	ncard.AddClass("m-5 shadow rounded-lg")
	
	ncard.HTML = $"<figure class="md:flex bg-slate-100 rounded-xl p-8 md:p-0 dark:bg-slate-800">
  <img class="w-24 h-24 md:w-48 md:h-auto md:rounded-none rounded-full mx-auto" src="./assets/sarah-dayan.jpg" alt="" width="384" height="512">
  <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
    <blockquote>
      <p class="text-lg font-medium">
        “Tailwind CSS is the only framework that I've seen scale
        on large teams. It’s easy to customize, adapts to any design,
        and the build size is tiny.”
      </p>
    </blockquote>
    <figcaption class="font-medium">
      <div class="text-sky-500 dark:text-sky-400">
        Sarah Dayan
      </div>
      <div class="text-slate-700 dark:text-slate-500">
        Staff Engineer, Algolia
      </div>
    </figcaption>
  </div>
</figure>"$
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim ncard As SDUIDiv = page.Cell(1, 1).AddDiv("ncard")"$)
	c1.AddCode($"ncard.AddClass("m-5 shadow rounded-lg")"$)
	c1.AddCode($"ncard.HTML = ~"<figure class="md:flex bg-slate-100 rounded-xl p-8 md:p-0 dark:bg-slate-800">"$)
	c1.AddCode($"<img class="w-24 h-24 md:w-48 md:h-auto md:rounded-none rounded-full mx-auto" src="./assets/sarah-dayan.jpg" alt="" width="384" height="512">"$)
	c1.AddCode($"<div class="pt-6 md:p-8 text-center md:text-left space-y-4">"$)
	c1.AddCode($"<blockquote>"$)
	c1.AddCode($"<p class="text-lg font-medium">"$)
	c1.AddCode($"“Tailwind CSS is the only framework that I've seen scale"$)
	c1.AddCode($"on large teams. It’s easy to customize, adapts to any design,"$)
	c1.AddCode($"and the build size is tiny.”"$)
	c1.AddCode($"</p>"$)
	c1.AddCode($"</blockquote>"$)
	c1.AddCode($"<figcaption class="font-medium">"$)
	c1.AddCode($"<div class="text-sky-500 dark:text-sky-400">"$)
	c1.AddCode($"Sarah Dayan"$)
	c1.AddCode($"</div>"$)
	c1.AddCode($"<div class="text-slate-700 dark:text-slate-500">"$)
	c1.AddCode($"Staff Engineer, Algolia"$)
	c1.AddCode($"</div>"$)
	c1.AddCode($"</figcaption>"$)
	c1.AddCode($"</div>"$)
	c1.AddCode($"</figure>"~"$)
	c1.Refresh
	
	'
	Dim ncard1 As SDUIDiv = page.Cell(3, 1).AddDiv("ncard1")
	ncard1.HTML = $"<div class="flex font-sans border">
  <div class="flex-none w-48 relative">
    <img src="./assets/13.jpg" alt="" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />
  </div>
  <form class="flex-auto p-6">
    <div class="flex flex-wrap">
      <h1 class="flex-auto text-lg font-semibold text-slate-900">
        Classic Utility Jacket
      </h1>
      <div class="text-lg font-semibold text-slate-500">
        $110.00
      </div>
      <div class="w-full flex-none text-sm font-medium text-slate-700 mt-2">
        In stock
      </div>
    </div>
    <div class="flex items-baseline mt-4 mb-6 pb-6 border-b border-slate-200">
      <div class="space-x-2 flex text-sm">
        <label>
          <input class="sr-only peer" name="size" type="radio" value="xs" checked />
          <div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">
            XS
          </div>
        </label>
        <label>
          <input class="sr-only peer" name="size" type="radio" value="s" />
          <div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">
            S
          </div>
        </label>
        <label>
          <input class="sr-only peer" name="size" type="radio" value="m" />
          <div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">
            M
          </div>
        </label>
        <label>
          <input class="sr-only peer" name="size" type="radio" value="l" />
          <div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">
            L
          </div>
        </label>
        <label>
          <input class="sr-only peer" name="size" type="radio" value="xl" />
          <div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">
            XL
          </div>
        </label>
      </div>
    </div>
    <div class="flex space-x-4 mb-6 text-sm font-medium">
      <div class="flex-auto flex space-x-4">
        <button class="h-10 px-6 font-semibold rounded-md bg-black text-white" type="submit">
          Buy now
        </button>
        <button class="h-10 px-6 font-semibold rounded-md border border-slate-200 text-slate-900" type="button">
          Add to bag
        </button>
      </div>
      <button class="flex-none flex items-center justify-center w-9 h-9 rounded-md text-slate-300 border border-slate-200" type="button" aria-label="Like">
        <svg width="20" height="20" fill="currentColor" aria-hidden="true">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />
        </svg>
      </button>
    </div>
    <p class="text-sm text-slate-700">
      Free shipping on all continental US orders.
    </p>
  </form>
</div>"$
	'
	Dim c2 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim ncard1 As SDUIDiv = page.Cell(3, 1).AddDiv("ncard1")"$)
	c2.AddCode($"ncard1.HTML = ~"<div class="flex font-sans border">"$)
	c2.AddCode($"<div class="flex-none w-48 relative">"$)
	c2.AddCode($"<img src="./assets/13.jpg" alt="" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<form class="flex-auto p-6">"$)
	c2.AddCode($"<div class="flex flex-wrap">"$)
	c2.AddCode($"<h1 class="flex-auto text-lg font-semibold text-slate-900">"$)
	c2.AddCode($"Classic Utility Jacket"$)
	c2.AddCode($"</h1>"$)
	c2.AddCode($"<div class="text-lg font-semibold text-slate-500">"$)
	c2.AddCode($"~110.00"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<div class="w-full flex-none text-sm font-medium text-slate-700 mt-2">"$)
	c2.AddCode($"In stock"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<div class="flex items-baseline mt-4 mb-6 pb-6 border-b border-slate-200">"$)
	c2.AddCode($"<div class="space-x-2 flex text-sm">"$)
	c2.AddCode($"<label>"$)
	c2.AddCode($"<input class="sr-only peer" name="size" type="radio" value="xs" checked />"$)
	c2.AddCode($"<div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">"$)
	c2.AddCode($"XS"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</label>"$)
	c2.AddCode($"<label>"$)
	c2.AddCode($"<input class="sr-only peer" name="size" type="radio" value="s" />"$)
	c2.AddCode($"<div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">"$)
	c2.AddCode($"S"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</label>"$)
	c2.AddCode($"<label>"$)
	c2.AddCode($"<input class="sr-only peer" name="size" type="radio" value="m" />"$)
	c2.AddCode($"<div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">"$)
	c2.AddCode($"M"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</label>"$)
	c2.AddCode($"<label>"$)
	c2.AddCode($"<input class="sr-only peer" name="size" type="radio" value="l" />"$)
	c2.AddCode($"<div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">"$)
	c2.AddCode($"L"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</label>"$)
	c2.AddCode($"<label>"$)
	c2.AddCode($"<input class="sr-only peer" name="size" type="radio" value="xl" />"$)
	c2.AddCode($"<div class="w-9 h-9 rounded-lg flex items-center justify-center text-slate-700 peer-checked:font-semibold peer-checked:bg-slate-900 peer-checked:text-white">"$)
	c2.AddCode($"XL"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</label>"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<div class="flex space-x-4 mb-6 text-sm font-medium">"$)
	c2.AddCode($"<div class="flex-auto flex space-x-4">"$)
	c2.AddCode($"<button class="h-10 px-6 font-semibold rounded-md bg-black text-white" type="submit">"$)
	c2.AddCode($"Buy now"$)
	c2.AddCode($"</button>"$)
	c2.AddCode($"<button class="h-10 px-6 font-semibold rounded-md border border-slate-200 text-slate-900" type="button">"$)
	c2.AddCode($"Add to bag"$)
	c2.AddCode($"</button>"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<button class="flex-none flex items-center justify-center w-9 h-9 rounded-md text-slate-300 border border-slate-200" type="button" aria-label="Like">"$)
	c2.AddCode($"<svg width="20" height="20" fill="currentColor" aria-hidden="true">"$)
	c2.AddCode($"<path fill-rule="evenodd" clip-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />"$)
	c2.AddCode($"</svg>"$)
	c2.AddCode($"</button>"$)
	c2.AddCode($"</div>"$)
	c2.AddCode($"<p class="text-sm text-slate-700">"$)
	c2.AddCode($"Free shipping on all continental US orders."$)
	c2.AddCode($"</p>"$)
	c2.AddCode($"</form>"$)
	c2.AddCode($"</div>"~"$)
	c2.Refresh
	
End Sub
