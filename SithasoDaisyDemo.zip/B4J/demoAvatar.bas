﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "avatars"
	Public title As String = "Avatars"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 10 rows, each having 2 columns, each spanning 6
	page.Root.AddRows(20).AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim avt As SDUIAvatar = page.Cell(1, 1).AddAvatar("avt", 24, "./assets/1.jpg")
	avt.IsRounded
	avt.BadgeColor = app.COLOR_PRIMARY
	avt.BadgeValue = "typing..."
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim avt As SDUIAvatar = page.Cell(1, 1).AddAvatar("avt", 24, "./assets/1.jpg")"$)
	c1.AddCode($"avt.IsRounded"$)
	c1.AddCode($"avt.BadgeColor = app.COLOR_PRIMARY"$)
	c1.AddCode($"avt.BadgeValue = "typing...""$)
	c1.Refresh
	'
	Dim avt1 As SDUIAvatar = page.Cell(2, 1).AddAvatar("avt1", 20, "./assets/2.jpg")
	avt1.Circle
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim avt1 As SDUIAvatar = page.Cell(2, 1).AddAvatar("avt1", 20, "./assets/2.jpg")"$)
	c2.AddCode($"avt1.Circle"$)
	c2.Refresh
	'
	Dim avt2 As SDUIAvatar = page.Cell(3, 1).AddAvatar("avt2", 20, "./assets/img8.png")
	avt2.Mask.Squircle
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim avt2 As SDUIAvatar = page.Cell(3, 1).AddAvatar("avt2", 20, "./assets/3.jpg")"$)
	c3.AddCode($"avt2.Mask.Squircle"$)
	c3.Refresh
	'
	Dim avt3 As SDUIAvatar = page.Cell(4, 1).AddAvatar("avt3", 12, "./assets/4.jpg")
	avt3.AvatarGroup = True
	avt3.AddItem("./assets/img1.png")
	avt3.AddItem("./assets/img2.png")
	avt3.AddItem("./assets/img3.png")
	avt3.AddItem("./assets/img4.png")
	avt3.AddItemPlaceHolder("+99")
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim avt3 As SDUIAvatar = page.Cell(4, 1).AddAvatar("avt3", 12, "./assets/4.jpg")"$)
	c4.AddCode($"avt3.AvatarGroup = True"$)
	c4.AddCode($"avt3.AddItem("./assets/img1.png")"$)
	c4.AddCode($"avt3.AddItem("./assets/img2.png")"$)
	c4.AddCode($"avt3.AddItem("./assets/img3.png")"$)
	c4.AddCode($"avt3.AddItem("./assets/img4.png")"$)
	c4.AddCode($"avt3.AddItemPlaceHolder("+99")"$)
	c4.Refresh
	'
	Dim avt4 As SDUIAvatar = page.Cell(5, 1).AddAvatar("avt4", 24, "./assets/profile10.jpg")
	avt4.Ring = True
	avt4.RingColor = app.color_Primary
	avt4.Circle
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim avt4 As SDUIAvatar = page.Cell(5, 1).AddAvatar("avt4", 24, "./assets/profile10.jpg")"$)
	c5.AddCode($"avt4.Ring = True"$)
	c5.AddCode($"avt4.RingColor = app.color_Primary"$)
	c5.AddCode($"avt4.Circle"$)
	c5.Refresh
	'
	Dim avt5 As SDUIAvatar = page.Cell(6, 1).AddAvatar("avt5", 24, "./assets/profile11.jpg")
	avt5.Circle
	avt5.Offline = True
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim avt5 As SDUIAvatar = page.Cell(6, 1).AddAvatar("avt5", 24, "./assets/profile11.jpg")"$)
	c6.AddCode($"avt5.Circle"$)
	c6.AddCode($"avt5.Offline = True"$)
	c6.Refresh
	
	Dim avt6 As SDUIAvatar = page.Cell(7, 1).AddAvatar("avt6", 24, "./assets/profile12.jpg")
	avt6.Circle
	avt6.Online = True
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim avt6 As SDUIAvatar = page.Cell(7, 1).AddAvatar("avt6", 24, "./assets/profile12.jpg")"$)
	c7.AddCode($"avt6.Circle"$)
	c7.AddCode($"avt6.Online = True"$)
	c7.Refresh
	'
	Dim a7 As SDUIAvatar = page.Cell(8, 1).AddAvatar("a7", "20", "./assets/img9.png")
	a7.Mask.Hexagon
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"Dim a7 As SDUIAvatar = page.Cell(8, 1).AddAvatar("a7", "20", "./assets/img9.png")"$)
	c8.AddCode($"a7.Mask.Hexagon"$)
	c8.Refresh
	'
	Dim a8 As SDUIAvatar = page.Cell(9, 1).AddAvatar("a8", "20", "./assets/2.png")
	a8.Caption = "AM"
	a8.CaptionColorIntensity(app.COLOR_ORANGE, 700)
	a8.Circle
	'
	Dim c9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"Dim a8 As SDUIAvatar = page.Cell(9, 1).AddAvatar("a8", "20", "./assets/2.png")"$)
	c9.AddCode($"a8.Caption = "AM""$)
	c9.AddCode($"a8.CaptionColorIntensity(app.COLOR_ORANGE, 700)"$)
	c9.AddCode($"a8.Circle"$)
	c9.Refresh
	
	'create an avatar using a normal div
	Dim na1 As SDUIDiv = page.Cell(10, 1).AddDiv("na1")
	na1.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold.textColorIntensity("blue", 800)
	na1.bgColorIntensity("blue", 100).isrounded.selectNone
	na1.Caption = "A"
	'
	Dim c10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c10", "vb")
	c10.AddCode($"'create an avatar using a normal div"$)
	c10.AddCode($"Dim na1 As SDUIDiv = page.Cell(10, 1).AddDiv("na1")"$)
	c10.AddCode($"na1.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold.textColorIntensity("blue", 800)"$)
	c10.AddCode($"na1.bgColorIntensity("blue", 100).isrounded.selectNone"$)
	c10.AddCode($"na1.Caption = "A""$)
	c10.Refresh
	'
	Dim na2 As SDUIDiv = page.Cell(11, 1).AddDiv("na2")
	na2.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold
	na2.textColorIntensity("purple", 800).bgColorIntensity("purple", 100)
	na2.selectNone.rounded("2xl").Caption = "B"
	'
	Dim c11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("c11", "vb")
	c11.AddCode($"Dim na2 As SDUIDiv = page.Cell(11, 1).AddDiv("na2")"$)
	c11.AddCode($"na2.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold"$)
	c11.AddCode($"na2.textColorIntensity("purple", 800).bgColorIntensity("purple", 100)"$)
	c11.AddCode($"na2.selectNone.rounded("2xl").Caption = "B""$)
	c11.Refresh
	
	Dim na3 As SDUIDiv = page.Cell(12, 1).AddDiv("na3")
	na3.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold
	na3.roundedFull.selectNone.textColorIntensity("cyan", 800)
	na3.bgColorIntensity("cyan", 100).Caption = "C"
	'
	Dim c12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("c12", "vb")
	c12.AddCode($"Dim na3 As SDUIDiv = page.Cell(12, 1).AddDiv("na3")"$)
	c12.AddCode($"na3.flex.itemsCenter.justifyCenter.w(12).h(12).fontBold"$)
	c12.AddCode($"na3.roundedFull.selectNone.textColorIntensity("cyan", 800)"$)
	c12.AddCode($"na3.bgColorIntensity("cyan", 100).Caption = "C""$)
	c12.Refresh
	
End Sub
