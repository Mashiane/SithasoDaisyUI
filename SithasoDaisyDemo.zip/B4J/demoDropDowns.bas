﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public name As String = "dropdowns"
	Public title As String = "Drop Downs"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns4p8
	page.Root.BuildGrid
	'start adding you components here
	
	Dim dd As SDUIDropDown = page.Cell(1, 1).AddDropDown("dd", "Click")
	dd.RoundedBox
	dd.ItemColorIntensity(app.COLOR_PINK, 200)
	dd.AddItem("item1", "Item 1")
	dd.AddItem("item2", "Item 2")
	dd.AddItem("item3", "Item 3")
	dd.AddItemIcon("item4", "fa-solid fa-house", "Item 4")
	dd.AddItemIcon("item5", "fa-solid fa-circle-info",  "Item 5")
	dd.AddItemIcon("item6", "fa-solid fa-wifi",  "Item 6")
	dd.GetItemBadge("item3").Show
	dd.GetItemBadge("item3").Caption = "20"
	dd.SetItemBadgeColor("item6", app.COLOR_WARNING)
	dd.SetItemBadgeValue("item6", 30)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim dd As SDUIDropDown = page.Cell(1, 1).AddDropDown("dd", "Click")"$)
	c1.AddCode($"dd.roundedBox"$)
	c1.AddCode($"dd.AddItem("item1", "Item 1")"$)
	c1.AddCode($"dd.AddItem("item2", "Item 2")"$)
	c1.AddCode($"dd.AddItem("item3", "Item 3")"$)
	c1.AddCode($"dd.AddItemIcon("item4", "fa-house", "Item 4")"$)
	c1.AddCode($"dd.AddItemIcon("item5", "fa-circle-info",  "Item 5")"$)
	c1.AddCode($"dd.AddItemIcon("item6", "fa-wifi",  "Item 6")"$)
	c1.AddCode($"dd.ItemBadge("item3").Show"$)
	c1.AddCode($"dd.ItemBadge("item3").Caption = "20""$)
	c1.AddCode($"dd.SetItemBadgeColor("item6", app.COLOR_WARNING)"$)
	c1.AddCode($"dd.SetItemBadgeValue("item6", 30)"$)
	c1.AddCode($"'add click event"$)
	c1.AddCode($"Private Sub dd_Click (item As String)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = item"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	
	
	'
	Dim dd1 As SDUIDropDown = page.Cell(2, 1).AddDropDown("dd1", "Hover")
	dd1.roundedBox
	dd1.Hover 
	dd1.AddItem("anele1", "Item 1")
	dd1.AddItem("anele2", "Item 2")
	dd1.AddItem("anele3", "Item 3")
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim dd1 As SDUIDropDown = page.Cell(2, 1).AddDropDown("dd1", "Hover")"$)
	c2.AddCode($"dd1.roundedBox"$)
	c2.AddCode($"dd1.Hover"$)
	c2.AddCode($"dd1.AddItem("anele1", "Item 1")"$)
	c2.AddCode($"dd1.AddItem("anele2", "Item 2")"$)
	c2.AddCode($"dd1.AddItem("anele3", "Item 3")"$)
	c2.Refresh
	
	
	'
	Dim dd2 As SDUIDropDown = page.Cell(3, 1).AddDropDown("dd2", "Right")
	dd2.roundedBox
	dd2.AtRight
	dd2.AddItem("anele1", "Item 1")
	dd2.AddItem("anele2", "Item 2")
	dd2.AddItem("anele3", "Item 3")
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim dd2 As SDUIDropDown = page.Cell(3, 1).AddDropDown("dd2", "Right")"$)
	c3.AddCode($"dd2.roundedBox"$)
	c3.AddCode($"dd2.AtRight"$)
	c3.AddCode($"dd2.AddItem("anele1", "Item 1")"$)
	c3.AddCode($"dd2.AddItem("anele2", "Item 2")"$)
	c3.AddCode($"dd2.AddItem("anele3", "Item 3")"$)
	c3.Refresh
	'
	Dim dd3 As SDUIDropDown = page.Cell(4, 1).AddDropDownAvatar("dd3", "20", "./assets/1.jpg")
	dd3.AvatarOnline = True
	dd3.Hover
	dd3.roundedBox
	dd3.AddItem("anele1", "Item 1")
	dd3.AddItem("anele2", "Item 2")
	dd3.AddItem("anele3", "Item 3")
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim dd3 As SDUIDropDown = page.Cell(4, 1).AddDropDownAvatar("dd3", "20", "./assets/1.jpg")"$)
	c4.AddCode($"dd3.AvatarOnline = True"$)
	c4.AddCode($"dd3.Hover"$)
	c4.AddCode($"dd3.roundedBox"$)
	c4.AddCode($"dd3.AddItem("anele1", "Item 1")"$)
	c4.AddCode($"dd3.AddItem("anele2", "Item 2")"$)
	c4.AddCode($"dd3.AddItem("anele3", "Item 3")"$)
	c4.Refresh
	'
	Dim ddai As SDUIDropDown = page.Cell(5, 1).AddDropDownIcon("dda2",  app.size_lg, "fa-solid fa-cart-shopping")
	ddai.AtTop
	ddai.BadgeValue = 8
	ddai.roundedBox
	ddai.AddItem("anele1", "Item 1")
	ddai.AddItem("anele2", "Item 2")
	ddai.AddItem("anele3", "Item 3")
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim ddai As SDUIDropDown = page.Cell(5, 1).AddDropDownIcon("dda2",  app.size_lg, "fa-solid fa-cart-shopping")"$)
	c5.AddCode($"ddai.AtTop"$)
	c5.AddCode($"ddai.BadgeValue = 8"$)
	c5.AddCode($"ddai.roundedBox"$)
	c5.AddCode($"ddai.AddItem("anele1", "Item 1")"$)
	c5.AddCode($"ddai.AddItem("anele2", "Item 2")"$)
	c5.AddCode($"ddai.AddItem("anele3", "Item 3")"$)
	c5.Refresh
	
End Sub

Private Sub dd_Click (item As String)
	page.Cell(6, 1).Caption = item
End Sub


Private Sub dd1_Click (item As String)
	page.Cell(6, 1).Caption = item
End Sub


Private Sub dd2_Click (item As String)
	page.Cell(6, 1).Caption = item
End Sub


Private Sub dd3_Click (item As String)
	page.Cell(6, 1).Caption = item
End Sub