﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adchat"
	Public title As String = "AD Chat"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIChat1 As SDUIChat
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adchatlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIChat.SDUIChat1", "SDUIChat1", SDUIChat1.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	SDUIChat1.Clear
	SDUIChat1.AddConversation("c1", True, "", "", "", _
	"It's over Anakin, <br/>I have the high ground.", "")
	'
	SDUIChat1.AddConversation("c2", False, "", "", "", _
	"You underestimate my power!", "")
	'
	SDUIChat1.AddConversation("c3", True, "./assets/Anna.jpg", "Anna", "45 minutes ago", _
	"It was said that you would, destroy the Sith, not join them.", "")
	'
	SDUIChat1.AddConversation("c4", True, "./assets/yadit.jpg", "Yadit", "40 minutes ago", _
	"It was you who would bring balance to the Force", "")
	'
	SDUIChat1.AddConversation("c5", True, "./assets/lula.jpg", "Lula", "35 minutes ago", _
	"Not leave it in Darkness", "")
	'
	SDUIChat1.AddConversation("c6", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "30 minutes ago", _
	"You were the Chosen One!", "").SetConversationFooter("c6", "Delivered")
	'
	SDUIChat1.AddConversation("c7", False, "./assets/face13.jpg", "Anakin", "25 minutes ago", _
	"I hate you!", "").SetConversationFooter("c7", "Seen 26 minutes ago")
	'
	SDUIChat1.AddConversation("c8", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "20 minutes ago", _
	"You were my brother, Anakin.", "").SetConversationFooter("c8", "Seen")
	'
	SDUIChat1.AddConversation("c9", True, "./assets/minion.jpg", "Obi-Wan Kenobi", "21 minutes ago", _
	"I loved you.", "").SetConversationFooter("c9", "Delivered")
	'
	SDUIChat1.AddConversationFromBasic("c10", "What kind of nonsense is this??").SetConversationColor("c10", app.COLOR_PRIMARY)
	'
	SDUIChat1.AddConversationToBasic("c11", "Calm down, Anakin.").SetConversationColor("c11", app.COLOR_SUCCESS)
	
End Sub
