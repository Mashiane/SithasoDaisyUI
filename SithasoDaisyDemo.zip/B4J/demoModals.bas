﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "modals"
	Public title As String = "Modal"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private banano As BANano		'ignore
	Private mdl As SDUIModal
	Private mdl1 As SDUIModal
End Sub

Sub Show(duiapp As SDUIApp)
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


private Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows5.AddColumns12
	page.Root.BuildGrid
	'start adding you components here
	'
	'add a modal to the page
	mdl = page.Root.AddModal( "mdl", "Congratulations", "Yes", "No", "Cancel", "1500px")
	mdl.Message = "You have won SithasoDaisy!"
	mdl.YesButton.NormalCase = True
	mdl.OverlayBGColorIntensity("transparent", "")
	'
	mdl1 = page.Root.AddModal( "mdl1", "Congratulations", "Yes", "No", "Cancel", "700px")
	mdl1.Message = "You have won SithasoDaisy!"
	mdl1.YesButton.NormalCase = True
	mdl1.OverlayBGColorIntensity("transparent", "")
	
	'add a button to show the modal
	Dim btn As SDUIButton = page.Cell(1, 1).AddButton("btn", "Open Modal @1500px")
	Dim btn1 As SDUIButton = page.Cell(2, 1).AddButton("btn1", "Open Modal @700px")
	
	'
	Dim c1 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Private mdl As SDUIModal"$)
	c1.AddCode($"mdl = page.Root.AddModal("mdl", "Congratulations", "Yes", "No", "Cancel", "700px")"$)
	c1.AddCode($"mdl.Message = "You have won SithasoDaisy!""$)
	c1.AddCode($"mdl.YesButton.NormalCase = True"$)
	c1.AddCode($"'modal events"$)
	c1.AddCode($"Private Sub mdl_Yes_Click (e As BANanoEvent)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = "Yes""$)
	c1.AddCode($"mdl.YesLoading = True"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"Private Sub mdl_No_Click (e As BANanoEvent)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = "No""$)
	c1.AddCode($"mdl.YesLoading = False"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"Private Sub mdl_Cancel_Click (e As BANanoEvent)"$)
	c1.AddCode($"page.Cell(1, 2).Caption = "Cancel""$)
	c1.AddCode($"mdl.Hide"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	
End Sub

Private Sub btn_Click (e As BANanoEvent)
	app.hideItem("c1")
	mdl.show
End Sub

Private Sub btn1_Click (e As BANanoEvent)
	app.hideItem("c1")
	mdl1.show
End Sub


Private Sub mdl_Yes_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "Yes"
	mdl.YesLoading = True
End Sub

Private Sub mdl_No_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "No"
	mdl.YesLoading = False
	app.ShowItem("c1")
End Sub

Private Sub mdl_Cancel_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "Cancel"
	mdl.Hide
	app.ShowItem("c1")
End Sub

Private Sub mdl1_Yes_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "Yes"
	mdl.YesLoading = True
End Sub

Private Sub mdl1_No_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "No"
	mdl.YesLoading = False
	app.ShowItem("c1")
End Sub

Private Sub mdl1_Cancel_Click (e As BANanoEvent)
	page.Cell(4, 1).Caption = "Cancel"
	mdl.Hide
	app.ShowItem("c1")
End Sub