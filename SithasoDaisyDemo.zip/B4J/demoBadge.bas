﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "badges"
	Public title As String = "Badges"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'*****
	
	Dim b1 As SDUIBadge = page.Cell(1,1).AddBadge("b1", "Badge")
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim b1 As SDUIBadge = page.Cell(1,1).AddBadge("b1", "Badge")"$)
	c1.Refresh
	'
	Dim b2 As SDUIBadge = page.Cell(2,1).AddBadge("b2", "Large")
	b2.size = app.SIZE_LG
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim b2 As SDUIBadge = page.Cell(2,1).AddBadge("b2", "Large")"$)
	c2.AddCode($"b2.size = app.SIZE_LG"$)
	c2.Refresh
	'
	Dim b3 As SDUIBadge = page.Cell(3,1).AddBadge("b3", "")
	b3.size = app.SIZE_LG
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim b3 As SDUIBadge = page.Cell(3,1).AddBadge("b3", "")"$)
	c3.AddCode($"b3.size = app.SIZE_LG"$)
	c3.Refresh
	'
	Dim b4 As SDUIBadge = page.Cell(4,1).AddBadge("b4", "Mashy")
	b4.size = app.SIZE_LG
	b4.RightIconName = "fa-solid fa-brands fa-github"
	b4.color = app.COLOR_PRIMARY
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim b4 As SDUIBadge = page.Cell(4,1).AddBadge("b4", "Mashy")"$)
	c4.AddCode($"b4.size = app.SIZE_LG"$)
	c4.AddCode($"b4.RightIconName = "fa-solid fa-brands fa-github""$)
	c4.AddCode($"b4.color = app.COLOR_PRIMARY"$)
	c4.Refresh
End Sub
