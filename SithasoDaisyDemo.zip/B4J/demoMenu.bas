﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "menus"
	Public title As String = "Menus"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows(20).AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	'
	Dim menu1 As SDUIMenu
	menu1.AddMenu(Me, page.CellID(1, 1), "menu1")
	menu1.AddItem("item1", "Item 1")
	menu1.AddItem("item2", "Item 2")
	menu1.AddItem("item3", "Item 3")
	menu1.AddItem("item4", "Item 4")
	menu1.SetItemBadgeValue("item2", 5)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim menu1 As SDUIMenu"$)
	c1.AddCode($"menu1.AddMenu(Me, page.CellID(1, 1), "menu1")"$)
	c1.AddCode($"menu1.AddItem("item1", "Item 1")"$)
	c1.AddCode($"menu1.AddItem("item2", "Item 2")"$)
	c1.AddCode($"menu1.AddItem("item3", "Item 3")"$)
	c1.AddCode($"menu1.AddItem("item4", "Item 4")"$)
	c1.AddCode($"menu1.SetItemBadgeValue("item2", 5)"$)
	c1.AddCode("'trap click event")
	c1.AddCode($"Private Sub menu1_Click (item As String)"$)
	c1.AddCode($"page.Root.Cell(8, 1).Caption = item"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	c1.Refresh
	'
	Dim menu2 As SDUIMenu
	menu2.AddMenu(Me, page.CellID(2, 1), "menu2")
	menu2.W = 56
	menu2.Compact
	menu2.AddItem("item1", "Item 1")
	menu2.AddItem("item2", "Item 2")
	menu2.AddItem("item3", "Item 3")
	menu2.AddItem("item4", "Item 4")
	menu2.Active = "item2"
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim menu2 As SDUIMenu"$)
	c2.AddCode($"menu2.AddMenu(Me, page.CellID(2, 1), "menu2")"$)
	c2.AddCode($"menu2.W = 56"$)
	c2.AddCode($"menu2.Compact"$)
	c2.AddCode($"menu2.AddItem("item1", "Item 1")"$)
	c2.AddCode($"menu2.AddItem("item2", "Item 2")"$)
	c2.AddCode($"menu2.AddItem("item3", "Item 3")"$)
	c2.AddCode($"menu2.AddItem("item4", "Item 4")"$)
	c2.AddCode($"menu2.Active = "item2""$)
	c2.Refresh
	'
	Dim menu3 As SDUIMenu
	menu3.AddMenu(Me, page.CellID(3, 1), "menu3")
	menu3.W = 56
	menu3.AddTitle("cat1", "Category 1")
	menu3.AddItem("item1", "Item 1")
	menu3.AddItem("item2", "Item 2")
	menu3.AddItem("item3", "Item 3")
	menu3.AddItem("item4", "Item 4")
	menu3.AddTitle("cat2", "Category 2")
	menu3.AddItem("item5", "Item 5")
	menu3.AddItem("item6", "Item 6")
	menu3.AddItem("item7", "Item 7")
	menu3.AddItem("item8", "Item 8")
	menu3.DisableItem("item6")
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim menu3 As SDUIMenu"$)
	c3.AddCode($"menu3.AddMenu(Me, page.CellID(3, 1), "menu3")"$)
	c3.AddCode($"menu3.W = 56"$)
	c3.AddCode($"menu3.AddTitle("cat1", "Category 1")"$)
	c3.AddCode($"menu3.AddItem("item1", "Item 1")"$)
	c3.AddCode($"menu3.AddItem("item2", "Item 2")"$)
	c3.AddCode($"menu3.AddItem("item3", "Item 3")"$)
	c3.AddCode($"menu3.AddItem("item4", "Item 4")"$)
	c3.AddCode($"menu3.AddTitle("cat2", "Category 2")"$)
	c3.AddCode($"menu3.AddItem("item5", "Item 5")"$)
	c3.AddCode($"menu3.AddItem("item6", "Item 6")"$)
	c3.AddCode($"menu3.AddItem("item7", "Item 7")"$)
	c3.AddCode($"menu3.AddItem("item8", "Item 8")"$)
	c3.AddCode($"menu3.DisableItem("item6")"$)
	c3.Refresh
	'
	Dim hmenu As SDUIMenu = page.Cell(4, 1).AddMenu("hmenu")
	hmenu.Horizontal
	'hmenu.Root.roundedBox
	hmenu.Root.BGColorIntensity(app.COLOR_BASE, 100)
	hmenu.AddItem("item1", "Item 1")
	hmenu.AddItem("item2", "Item 2")
	hmenu.AddItemParent("item3", "Child Menu")
	hmenu.AddItemChild("item3", "item4", "Child 1")
	hmenu.AddItemChild("item3", "item5", "Child 2")
	hmenu.AddItemChild("item3", "item6", "Child 3")
	'format child holder
	'hmenu.ItemChildren("item3").Root.roundedBox
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim hmenu As SDUIMenu = page.Cell(4, 1).AddMenu("hmenu")"$)
	c4.AddCode($"hmenu.Horizontal"$)
	c4.AddCode($"'hmenu.Root.roundedBox"$)
	c4.AddCode($"hmenu.Root.BGColorIntensity(app.COLOR_BASE, 100)"$)
	c4.AddCode($"hmenu.AddItem("item1", "Item 1")"$)
	c4.AddCode($"hmenu.AddItem("item2", "Item 2")"$)
	c4.AddCode($"hmenu.AddItemParent("item3", "Child Menu")"$)
	c4.AddCode($"hmenu.AddItemChild("item3", "item4", "Child 1")"$)
	c4.AddCode($"hmenu.AddItemChild("item3", "item5", "Child 2")"$)
	c4.AddCode($"hmenu.AddItemChild("item3", "item6", "Child 3")"$)
	c4.Refresh
	
	'
	Dim iconMenu As SDUIMenu = page.Cell(5, 1).AddMenu("iconMenu")
	iconMenu.Root.roundedBox
	iconMenu.Root.p(2)
	iconMenu.W = 56
	iconMenu.AddItemIcon("item1", "fa-solid fa-house", "Item 1")
	iconMenu.AddItemIcon("item2", "fa-solid fa-circle-info",  "Item 2")
	iconMenu.AddItemIcon("item3", "fa-solid fa-wifi",  "Item 3")
	iconMenu.SetItemBadgeValue("item2", 3)
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim iconMenu As SDUIMenu = page.Cell(5, 1).AddMenu("iconMenu")"$)
	c5.AddCode($"iconMenu.Root.roundedBox"$)
	c5.AddCode($"iconMenu.Root.pa = "2""$)
	c5.AddCode($"iconMenu.W = 56"$)
	c5.AddCode($"iconMenu.AddItemIcon("item1", "fa-solid fa-house", "Item 1")"$)
	c5.AddCode($"iconMenu.AddItemIcon("item2", "fa-solid fa-circle-info",  "Item 2")"$)
	c5.AddCode($"iconMenu.AddItemIcon("item3", "fa-solid fa-wifi",  "Item 3")"$)
	c5.AddCode($"iconMenu.SetItemBadgeValue("item2", 3)"$)
	c5.Refresh
	'
	Dim iconMenu1 As SDUIMenu = page.Cell(6, 1).AddMenu("iconMenu1")
	iconMenu1.Root.roundedBox
	iconMenu1.W = 12
	iconMenu1.AddItemIconOnly("item1", "fa-solid fa-house")
	iconMenu1.AddItemIconOnly("item2", "fa-solid fa-circle-info")
	iconMenu1.AddItemIconOnly("item3", "fa-solid fa-wifi")
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim iconMenu1 As SDUIMenu = page.Cell(6, 1).AddMenu("iconMenu1")"$)
	c6.AddCode($"iconMenu1.Root.roundedBox"$)
	c6.AddCode($"iconMenu1.W = 12"$)
	c6.AddCode($"iconMenu1.AddItemIconOnly("item1", "fa-solid fa-house")"$)
	c6.AddCode($"iconMenu1.AddItemIconOnly("item2", "fa-solid fa-circle-info")"$)
	c6.AddCode($"iconMenu1.AddItemIconOnly("item3", "fa-solid fa-wifi")"$)
	c6.Refresh
	'
	Dim iconMenu2 As SDUIMenu = page.Cell(7, 1).AddMenu("iconMenu2")
	iconMenu2.Root.roundedBox
	iconMenu2.Horizontal
	iconMenu2.Root.p(2)
	iconMenu2.AddItemIconOnly("item1", "fa-solid fa-house")
	iconMenu2.AddItemIconOnly("item2", "fa-solid fa-circle-info")
	iconMenu2.AddItemIconOnly("item3", "fa-solid fa-wifi")
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim iconMenu2 As SDUIMenu = page.Cell(7, 1).AddMenu("iconMenu2")"$)
	c7.AddCode($"iconMenu2.Root.roundedBox"$)
	c7.AddCode($"iconMenu2.Horizontal"$)
	c7.AddCode($"iconMenu2.Root.pa = 2"$)
	c7.AddCode($"iconMenu2.AddItemIconOnly("item1", "fa-solid fa-house")"$)
	c7.AddCode($"iconMenu2.AddItemIconOnly("item2", "fa-solid fa-circle-info")"$)
	c7.AddCode($"iconMenu2.AddItemIconOnly("item3", "fa-solid fa-wifi")"$)
	c7.Refresh
	
End Sub

Private Sub menu1_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub

Private Sub menu2_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub

Private Sub menu3_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub

Private Sub hmenu_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub


Private Sub iconMenu_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub


Private Sub iconMenu1_Click (item As String)
	page.Root.Cell(8, 1).Caption = item
End Sub


Private Sub iconMenu2_Click (item As String)
	page.Root.Cell(1, 4).Caption = item
End Sub

