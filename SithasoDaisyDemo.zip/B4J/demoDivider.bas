﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "divider"
	Public title As String = "Divider"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components
	
	page.Cell(1, 1).flex.flexcol.wfull
		
	Dim d1 As SDUICard = page.Cell(1, 1).AddCardEmpty("d1")
	d1.H = 20
	d1.BGColorIntensity(app.COLOR_BASE, 300)
	d1.RoundedBox
	d1.Root.placeItemsCenter
	d1.Root.Grid
	d1.DescriptionCaption = "content"
	
	Dim div1 As SDUIDivider = page.Cell(1, 1).AddDivider("div1")
	div1.Caption = "OR"
	'
	Dim d2 As SDUICard = page.Cell(1, 1).AddCardEmpty("d2")
	d2.Root.Grid
	d2.H = 20
	d2.BGColorIntensity(app.COLOR_BASE, 300)
	d2.roundedBox
	d2.Root.placeItemsCenter
	d2.DescriptionCaption = "content"
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"page.Cell(1, 1).flex.flexcol.wfull"$)
	c1.AddCode($"Dim d1 As SDUICard = page.Cell(1, 1).AddCardEmpty("d1")"$)
	c1.AddCode($"d1.H = 20"$)
	c1.AddCode($"d1.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c1.AddCode($"d1.RoundedBox"$)
	c1.AddCode($"d1.Root.placeItemsCenter"$)
	c1.AddCode($"d1.Root.Grid"$)
	c1.AddCode($"d1.DescriptionCaption = "content""$)
	c1.AddCode($"Dim div1 As SDUIDivider = page.Cell(1, 1).AddDivider("div1")"$)
	c1.AddCode($"div1.Caption = "OR""$)
	c1.AddCode($"'"$)
	c1.AddCode($"Dim d2 As SDUICard = page.Cell(1, 1).AddCardEmpty("d2")"$)
	c1.AddCode($"d2.Root.Grid"$)
	c1.AddCode($"d2.H = 20"$)
	c1.AddCode($"d2.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c1.AddCode($"d2.roundedBox"$)
	c1.AddCode($"d2.Root.placeItemsCenter"$)
	c1.AddCode($"d2.DescriptionCaption = "content""$)
	c1.Refresh
	'******
	page.Cell(2, 1).flex.wfull
	
	Dim d3 As SDUICard = page.Cell(2, 1).AddCardEmpty("d3")
	d3.Root.Grid
	d3.H = 20
	d3.Root.flexGrow
	d3.Root.BGColorIntensity(app.COLOR_BASE, 300)
	d3.Root.roundedBox
	d3.Root.placeItemsCenter
	d3.DescriptionCaption = "content"
	'
	Dim div4 As SDUIDivider = page.Cell(2, 1).AddDivider("div4")
	div4.Caption = "OR"
	div4.Horizontal
	'
	Dim d5 As SDUICard = page.Cell(2, 1).AddCardEmpty("d5")
	d5.Root.Grid
	d5.H = 20
	d5.Root.flexGrow
	d5.Root.BGColorIntensity(app.COLOR_BASE, 300)
	d5.Root.roundedBox
	d5.Root.placeItemsCenter
	d5.DescriptionCaption = "content"
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"page.Cell(2, 1).flex.wfull"$)
	c2.AddCode($"Dim d3 As SDUICard = page.Cell(2, 1).AddCardEmpty("d3")"$)
	c2.AddCode($"d3.Root.Grid"$)
	c2.AddCode($"d3.H = 20"$)
	c2.AddCode($"d3.Root.flexGrow"$)
	c2.AddCode($"d3.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c2.AddCode($"d3.Root.roundedBox"$)
	c2.AddCode($"d3.Root.placeItemsCenter"$)
	c2.AddCode($"d3.DescriptionCaption = "content""$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim div4 As SDUIDivider = page.Cell(2, 1).AddDivider("div4")"$)
	c2.AddCode($"div4.Caption = "OR""$)
	c2.AddCode($"div4.Horizontal"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Dim d5 As SDUICard = page.Cell(2, 1).AddCardEmpty("d5")"$)
	c2.AddCode($"d5.Root.Grid"$)
	c2.AddCode($"d5.H = 20"$)
	c2.AddCode($"d5.Root.flexGrow"$)
	c2.AddCode($"d5.Root.BGColorIntensity(app.COLOR_BASE, 300)"$)
	c2.AddCode($"d5.Root.roundedBox"$)
	c2.AddCode($"d5.Root.placeItemsCenter"$)
	c2.AddCode($"d5.DescriptionCaption = "content""$)
	c2.Refresh
End Sub
