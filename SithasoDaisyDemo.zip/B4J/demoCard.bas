﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "cards"
	Public title As String = "Cards"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows(20).AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim card1 As SDUICard = page.Cell(1, 1).AddCard("card1", "./assets/banner_1.jpg", "Shoes")
	card1.Root.ResponsiveOnDevice("md", "w-96")
	card1.Container.AddParagraph("p1", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow As SDUIButton = card1.AddActionButton("btnBuyNow", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim card1 As SDUICard = page.Cell(1, 1).AddCard("card1", "./assets/banner_1.jpg", "Shoes")"$)
	c1.AddCode($"card1.Root.ResponsiveOnDevice("md", "w-96")"$)
	c1.AddCode($"card1.Container.AddParagraph("p1", "If a dog chews shoes whose shoes does he choose?")"$)
	c1.AddCode($"Dim btnBuyNow As SDUIButton = card1.AddActionButton("btnBuyNow", "Buy Now")"$)
	c1.AddCode($"btnBuyNow.Color = app.COLOR_PRIMARY"$)
	c1.Refresh
	'
	Dim card2 As SDUICard = page.Cell(2, 1).AddCard("card2", "./assets/banner_2.jpg", "Shoes")
	card2.Root.ResponsiveOnDevice("md", "w-96")
	card2.Compact
	card2.Container.AddParagraph("p2", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow2 As SDUIButton = card2.AddActionButton("btnBuyNow2", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim card2 As SDUICard = page.Cell(2, 1).AddCard("card2", "./assets/banner_2.jpg", "Shoes")"$)
	c2.AddCode($"card2.Root.ResponsiveOnDevice("md", "w-96")"$)
	c2.AddCode($"card2.Compact"$)
	c2.AddCode($"card2.Container.AddParagraph("p2", "If a dog chews shoes whose shoes does he choose?")"$)
	c2.AddCode($"Dim btnBuyNow2 As SDUIButton = card2.AddActionButton("btnBuyNow2", "Buy Now")"$)
	c2.AddCode($"btnBuyNow2.Color = app.COLOR_PRIMARY"$)
	c2.Refresh
	'
	Dim card3 As SDUICard = page.Cell(3, 1).AddCard("card3", "./assets/banner_3.jpg", "Shoes")
	card3.BorderColor = app.color_secondary
	card3.Root.ResponsiveOnDevice("md", "w-96")
	card3.AddTitleBadgeColor("bnew", "New", app.COLOR_SECONDARY)
	card3.Container.AddParagraph("p3", "If a dog chews shoes whose shoes does he choose?")
	card3.AddActionBadgeColor("fashion", "Fashion", app.COLOR_SECONDARY)
	card3.AddActionBadgeCOlor("products", "Products", app.COLOR_SECONDARY)
	Dim btnBuyNow3 As SDUIButton = card3.AddActionButton("btnBuyNow3", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim card3 As SDUICard = page.Cell(3, 1).AddCard("card3", "./assets/banner_3.jpg", "Shoes")"$)
	c3.AddCode($"card3.BorderColor = app.color_secondary"$)
	c3.AddCode($"card3.Root.ResponsiveOnDevice("md", "w-96")"$)
	c3.AddCode($"card3.AddTitleBadgeColor("bnew", "New", app.COLOR_SECONDARY)"$)
	c3.AddCode($"card3.Container.AddParagraph("p3", "If a dog chews shoes whose shoes does he choose?")"$)
	c3.AddCode($"card3.AddActionBadgeColor("fashion", "Fashion", app.COLOR_SECONDARY)"$)
	c3.AddCode($"card3.AddActionBadgeColor("products", "Products", app.COLOR_SECONDARY)"$)
	c3.AddCode($"Dim btnBuyNow3 As SDUIButton = card3.AddActionButton("btnBuyNow3", "Buy Now")"$)
	c3.AddCode($"btnBuyNow3.Color = app.COLOR_PRIMARY"$)
	c3.Refresh
	'
	Dim card4 As SDUICard = page.Cell(4, 1).AddCard("card4", "./assets/banner_4.jpg", "Shoes")
	card4.Figure.PX(10)
	card4.Figure.PT(10)
	card4.Image.Root.Rounded(app.SIZE_XL)
	card4.Body.ItemsCenter
	card4.Body.TextCenter
	card4.Root.ResponsiveOnDevice("md", "w-96")
	card4.AddTitleBadgeColor("bnew1", "New", app.COLOR_SECONDARY)
	card4.Container.AddParagraph("p4", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow4 As SDUIButton = card4.AddActionButton("btnBuyNow4", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim card4 As SDUICard = page.Cell(4, 1).AddCard("card4", "./assets/banner_4.jpg", "Shoes")"$)
	c4.AddCode($"card4.Figure.Root.PX = 10"$)
	c4.AddCode($"card4.Figure.Root.PT = 10"$)
	c4.AddCode($"card4.Image.Root.RoundedSize = app.SIZE_XL"$)
	c4.AddCode($"card4.Body.Root.ItemsCenter"$)
	c4.AddCode($"card4.Body.Root.TextCenter"$)
	c4.AddCode($"card4.Root.ResponsiveOnDevice("md", "w-96")"$)
	c4.AddCode($"card4.AddTitleBadgeColor("bnew1", "New", , app.COLOR_SECONDARY)"$)
	c4.AddCode($"card4.Container.AddParagraph("p4", "If a dog chews shoes whose shoes does he choose?")"$)
	c4.AddCode($"Dim btnBuyNow4 As SDUIButton = card4.AddActionButton("btnBuyNow4", "Buy Now")"$)
	c4.AddCode($"btnBuyNow4.Color = app.COLOR_PRIMARY"$)
	c4.Refresh
	'
	Dim card5 As SDUICard = page.Cell(5, 1).AddCard("card5", "./assets/banner_5.jpg", "Shoes")
	card5.Root.ResponsiveOnDevice("md", "w-96")
	card5.ImageFull
	card5.Container.AddParagraph("p5", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow5 As SDUIButton = card5.AddActionButton("btnBuyNow5", "Buy Now", app.color_primary)
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim card5 As SDUICard = page.Cell(5, 1).AddCard("card5", "./assets/banner_5.jpg", "Shoes")"$)
	c5.AddCode($"card5.Root.ResponsiveOnDevice("md", "w-96")"$)
	c5.AddCode($"card5.ImageFull"$)
	c5.AddCode($"card5.Container.AddParagraph("p5", "If a dog chews shoes whose shoes does he choose?")"$)
	c5.AddCode($"Dim btnBuyNow5 As SDUIButton = card5.AddActionButton("btnBuyNow5", "Buy Now")"$)
	c5.AddCode($"btnBuyNow5.Color = app.COLOR_PRIMARY"$)
	c5.Refresh
	'
	Dim card6 As SDUICard = page.Cell(6, 1).AddCard("card6", "./assets/banner_6.jpg", "Shoes")
	card6.Root.ResponsiveOnDevice("md", "w-96")
	card6.Figure.Remove
	card6.Container.AddParagraph("p6", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow6 As SDUIButton = card6.AddActionButton("btnBuyNow6", "Buy Now", app.color_primary)
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim card6 As SDUICard = page.Cell(6, 1).AddCard("card6", "./assets/banner_6.jpg", "Shoes")"$)
	c6.AddCode($"card6.Root.ResponsiveOnDevice("md", "w-96")"$)
	c6.AddCode($"card6.Figure.Remove"$)
	c6.AddCode($"card6.Container.AddParagraph("p6", "If a dog chews shoes whose shoes does he choose?")"$)
	c6.AddCode($"Dim btnBuyNow6 As SDUIButton = card6.AddActionButton("btnBuyNow6", "Buy Now")"$)
	c6.AddCode($"btnBuyNow6.Color = app.COLOR_PRIMARY"$)
	c6.Refresh
	'
	Dim card8 As SDUICard = page.Cell(8, 1).AddCard("card8", "./assets/banner_8.jpg", "Shoes")
	card8.Root.ResponsiveOnDevice("md", "w-96")
	card8.Figure.Remove
	card8.BGColor = app.COLOR_PRIMARY
	card8.TextColorIntensity(app.COLOR_PRIMARY,"content")
	card8.Container.AddParagraph("p8", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow8 As SDUIButton = card8.AddActionButton("btnBuyNow8", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"Dim card8 As SDUICard = page.Cell(8, 1).AddCard("card8", "./assets/banner_8.jpg", "Shoes")"$)
	c8.AddCode($"card8.Root.ResponsiveOnDevice("md", "w-96")"$)
	c8.AddCode($"card8.Figure.Remove"$)
	c8.AddCode($"card8.BGColor = app.COLOR_PRIMARY"$)
	c8.AddCode($"card8.TextColorIntensity(app.COLOR_PRIMARY,"content")"$)
	c8.AddCode($"card8.Container.AddParagraph("p8", "If a dog chews shoes whose shoes does he choose?")"$)
	c8.AddCode($"Dim btnBuyNow8 As SDUIButton = card8.AddActionButton("btnBuyNow8", "Buy Now")"$)
	c8.AddCode($"btnBuyNow8.Color = app.COLOR_PRIMARY"$)
	c8.Refresh
	'
	Dim card9 As SDUICard = page.Cell(9, 1).AddCard("card9", "./assets/banner_9.jpg", "Shoes")
	card9.Root.ResponsiveOnDevice("md", "w-96")
	card9.Figure.Remove
	card9.BGColor = app.COLOR_NEUTRAL
	card9.TextColorIntensity(app.COLOR_NEUTRAL,"content")
	card9.Container.AddParagraph("p9", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow9 As SDUIButton = card9.AddActionButton("btnBuyNow9", "Buy Now", app.color_primary)
	'
	Dim c9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"Dim card9 As SDUICard = page.Cell(9, 1).AddCard("card9", "./assets/banner_9.jpg", "Shoes")"$)
	c9.AddCode($"card9.Root.ResponsiveOnDevice("md", "w-96")"$)
	c9.AddCode($"card9.Figure.Remove"$)
	c9.AddCode($"card9.BGColor = app.COLOR_NEUTRAL"$)
	c9.AddCode($"card9.TextColorIntensity(app.COLOR_NEUTRAL,"content")"$)
	c9.AddCode($"card9.Container.AddParagraph("p9", "If a dog chews shoes whose shoes does he choose?")"$)
	c9.AddCode($"Dim btnBuyNow9 As SDUIButton = card9.AddActionButton("btnBuyNow9", "Buy Now")"$)
	c9.AddCode($"btnBuyNow9.Color = app.COLOR_PRIMARY"$)
	c9.Refresh
	'
	Dim card10 As SDUICard = page.Cell(10, 1).AddCard("card10", "./assets/banner_10.jpg", "Shoes")
	card10.Root.ResponsiveOnDevice("md", "w-96")
	card10.Figure.Remove
	card10.Title.Remove
	card10.Container.AddParagraph("p10", "We are using cookies for no reason?")
	Dim btnBuyNow10 As SDUIButton = card10.AddActionButtonIcon("btnBuyNow10", "fa-solid fa-xmark", app.COLOR_SECONDARY)
	'
	Dim c10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c10", "vb")
	c10.AddCode($"Dim card10 As SDUICard = page.Cell(10, 1).AddCard("card10", "./assets/banner_10.jpg", "Shoes")"$)
	c10.AddCode($"card10.Root.ResponsiveOnDevice("md", "w-96")"$)
	c10.AddCode($"card10.Figure.Remove"$)
	c10.AddCode($"card10.Title.Remove"$)
	c10.AddCode($"card10.Container.AddParagraph("p10", "We are using cookies for no reason?")"$)
	c10.AddCode($"Dim btnBuyNow10 As SDUIButton = card10.AddActionButtonIcon("btnBuyNow10", "fa-solid fa-xmark")"$)
	c10.Refresh
	'
	page.Cell(11, 1).BackgroundImage("./assets/arch.jpg")
	page.Cell(11, 1).itemsCenter
	page.Cell(11, 1).justifyCenter
	page.Cell(11, 1).flexWrap
	page.Cell(11, 1).roundedBox
	Dim card11 As SDUICard = page.Cell(11, 1).AddCard("card11", "./assets/banner_1.jpg", "Shoes")
	card11.Root.ResponsiveOnDevice("md", "w-96")
	card11.Glass
	card11.Container.AddParagraph("p11", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow11 As SDUIButton = card11.AddActionButton("btnBuyNow11", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("c11", "vb")
	c11.AddCode($"page.Cell(11, 1).BackgroundImage("./assets/arch.jpg")"$)
	c11.AddCode($"Dim card11 As SDUICard = page.Cell(11, 1).AddCard("card11", "./assets/banner_1.jpg", "Shoes")"$)
	c11.AddCode($"card11.Root.ResponsiveOnDevice("md", "w-96")"$)
	c11.AddCode($"card11.Glass"$)
	c11.AddCode($"card11.Container.AddParagraph("p11", "If a dog chews shoes whose shoes does he choose?")"$)
	c11.AddCode($"Dim btnBuyNow11 As SDUIButton = card11.AddActionButton("btnBuyNow11", "Buy Now")"$)
	c11.AddCode($"btnBuyNow11.Color = app.COLOR_PRIMARY"$)
	c11.Refresh
	'
	Dim card12 As SDUICard = page.Cell(12, 1).AddCard("card12", "./assets/banner_2.jpg", "Shoes")
	card12.Root.ResponsiveOnDevice("md", "w-96")
	card12.Image.W = "200px"
	card12.Image.H = "280px"
	card12.Side
	card12.Container.AddParagraph("p12", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow12 As SDUIButton = card12.AddActionButton("btnBuyNow12", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("c12", "vb")
	c12.AddCode($"Dim card12 As SDUICard = page.Cell(12, 1).AddCard("card12", "./assets/banner_2.jpg", "Shoes")"$)
	c12.AddCode($"card12.Root.ResponsiveOnDevice("md", "w-96")"$)
	c12.AddCode($"card12.Side"$)
	c12.AddCode($"card12.Image.W = "200px""$)
	c12.AddCode($"card12.Image.H = "280px""$)
	c12.AddCode($"card12.Container.AddParagraph("p12", "If a dog chews shoes whose shoes does he choose?")"$)
	c12.AddCode($"Dim btnBuyNow12 As SDUIButton = card12.AddActionButton("btnBuyNow12", "Buy Now")"$)
	c12.AddCode($"btnBuyNow12.Color = app.COLOR_PRIMARY"$)
	c12.Refresh
	'
	Dim card13 As SDUICard = page.Cell(13, 1).AddCard("card13", "./assets/banner_3.jpg", "Shoes")
	card13.Root.ResponsiveOnDevice("md", "w-96")
	card13.Image.W = "200px"
	card13.Image.H = "280px"
	card13.SideResponsive(False, False, False, True)
	card13.Container.AddParagraph("p13", "If a dog chews shoes whose shoes does he choose?")
	Dim btnBuyNow13 As SDUIButton = card13.AddActionButton("btnBuyNow13", "Buy Now", app.COLOR_PRIMARY)
	'
	Dim c13 As SDUIMockupCode = page.Cell(13, 2).AddMockUpCode("c13", "vb")
	c13.AddCode($"Dim card13 As SDUICard = page.Cell(13, 1).AddCard("card13", "./assets/banner_3.jpg", "Shoes")"$)
	c13.AddCode($"card13.Root.ResponsiveOnDevice("md", "w-96")"$)
	c13.AddCode($"card13.Image.W = "200px""$)
	c13.AddCode($"card13.Image.H = "280px""$)
	c13.AddCode($"card13.SideResponsive(False, False, False, True, True)"$)
	c13.AddCode($"card13.AddParagraph("p13", "If a dog chews shoes whose shoes does he choose?")"$)
	c13.AddCode($"Dim btnBuyNow13 As SDUIButton = card13.AddActionButton("btnBuyNow13", "Buy Now")"$)
	c13.AddCode($"btnBuyNow13.Color = app.COLOR_PRIMARY"$)
	c13.Refresh
	
End Sub
