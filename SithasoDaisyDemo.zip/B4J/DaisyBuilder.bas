﻿B4J=true
Group=Default Group\Tools
ModulesStructureVersion=1
Type=Class
Version=9.8
@EndOfDesignText@
#IgnoreWarnings:12

Sub Class_Globals
	Dim lines As List
	Dim propName As String
	Dim prefix As String
End Sub

'Initializes the object. You can add parameters to this method if needed.
Public Sub Initialize(sTag As String, typeOf As String)
	lines.Initialize
	propName = SDUIShared.ProperCase(typeOf)
	prefix = typeOf
	'
	AddCode($"B4J=true"$)
	AddCode($"Group=Default Group"$)
	AddCode($"ModulesStructureVersion=1"$)
	AddCode($"Type=Class"$)
	AddCode($"Version=9.8"$)
	AddCode($"@EndOfDesignText@"$)

	
	AddCode($"#IgnoreWarnings:12"$)
	AddCode($"'#Event: Click (e As BANanoEvent)"$)
	
	AddCode("Sub Class_Globals")
	AddCode("Private mback As Object")
	AddCode("Private mElement As BANanoElement")
	AddCode("Private mName As String")
	AddCode("Private mParent As BANanoElement")
	AddCode("Private BANano As BANano			'ignore")
	AddCode("Public Theme As SDUITheme")
	AddCode($"Private mLastColor As String"$)
	AddCode($"Private mLastSize As String"$)
	AddCode("End Sub")
	'
	AddCode($"Public Sub Add${propName}(mCallback As Object, ParentID As String, ID As String)"$)
	AddCode($"ParentID = SDUIShared.CleanID(ParentID)"$)
	AddCode($"ID = SDUIShared.CleanID(ID)"$)
	AddCode($"mName = ID"$)
	AddCode($"mback = mCallback"$)
	AddCode($"'does the parent exist"$)
	AddCode($"If BANano.Exists(~"#~{ParentID}"~) = False Then"$)
	AddCode($"BANano.Throw(~"SDUI${propName}.Initialize: '~{ParentID}' parent does not exist!"~)"$)
	AddCode($"Return"$)
	AddCode($"End If"$)
	AddCode($"If BANano.Exists(~"#~{ID}"~) Then"$)
	AddCode($"mElement.Initialize(~"#~{ID}"~)"$)
	AddCode($"Else"$)
	AddCode($"mParent = BANano.GetElement(~"#~{ParentID}"~)"$)
	AddCode($"mElement = mParent.Append(~"[BANCLEAN]<${sTag} id="~{ID}" class="${typeOf}"></${sTag}>"~).Get(~"#~{ID}"~)"$)
	AddCode($"'"$)
	AddCode($"'Dim ClickEvent As String = ~"~{ID}_click"~"$)
	AddCode($"'On("click", mCallback, ClickEvent)"$)
	AddCode("'OnClickInternal(mElement)")
	AddCode("'OnChangeInternal(mElement)")
	AddCode("End If")
	AddCode("Theme.Initialize(mName)")
	AddCode($"End Sub"$)
	'
	AddCode($"Public Sub InitializeLabel(mCallback As Object, ParentID As String, ID As String, Label As String)"$)
	AddCode($"ParentID = SDUIShared.CleanID(ParentID)"$)
	AddCode($"ID = SDUIShared.CleanID(ID)"$)
	AddCode($"mName = ID"$)
	AddCode($"mback = mCallback"$)
	AddCode($"'does the parent exist"$)
	AddCode($"If BANano.Exists(~"#~{ParentID}"~) = False Then"$)
	AddCode($"BANano.Throw(~"SDUI${propName}.Initialize: '~{ParentID}' parent does not exist!"~)"$)
	AddCode($"Return"$)
	AddCode($"End If"$)
	AddCode($"If BANano.Exists(~"#~{ID}"~) Then"$)
	AddCode($"mElement.Initialize(~"#~{ID}"~)"$)
	AddCode($"Else"$)
	AddCode($"mParent = BANano.GetElement(~"#~{ParentID}"~)"$)
	AddCode($"mElement = mParent.Append(~"[BANCLEAN]<${sTag} id="~{ID}" class="${typeOf}">~{Label}</${sTag}>"~).Get(~"#~{ID}"~)"$)
	AddCode($"'"$)
	AddCode($"'Dim ClickEvent As String = ~"~{ID}_click"~"$)
	AddCode($"'On("click", mCallback, ClickEvent)"$)
	AddCode("'OnClickInternal(mElement)")
	AddCode("'OnChangeInternal(mElement)")
	AddCode("End If")
	AddCode("Theme.Initialize(mName)")
	AddCode($"End Sub"$)
	'
	AddCode($"'add event"$)
	AddCode($"'<code>"$)
	AddCode($"'comp.On("click", Me, "item_click")"$)
	AddCode($"'</code>"$)
	AddCode($"Sub On(event As String, CallBack As Object, MethodName As String)"$)
	AddCode($"If SubExists(CallBack, MethodName) Then"$)
	AddCode($"mElement.On(event, CallBack, MethodName)"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'add internal click event"$)
	AddCode($"Private Sub OnClickInternal(el As BANanoElement)"$)
	AddCode($"Dim MethodName As String = ~"~{mname}_click"~"$)
	AddCode($"If SubExists(mBack, MethodName) Then"$)
	AddCode($"el.On("click", Me, "HandleClick")"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	
	AddCode($"'get the target of the component"$)
	AddCode($"Sub getHere As String"$)
	AddCode($"Return ~"#~{mName}"~"$)
	AddCode($"End Sub"$)
	AddCode($"'change the label of the component"$)
	AddCode($"Sub setCaption(l As String)"$)
	AddCode($"mElement.SetText(l)"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'get the id of the component"$)
	AddCode($"sub getName As String"$)
	AddCode($"Return ~"~{mName}"~"$)
	AddCode($"End Sub"$)

	
	AddCode($"'we use this to get the id of the clicked item"$)
	AddCode($"private Sub HandleClick(event As BANanoEvent)     'ignore"$)
	AddCode($"Dim src As String = event.OtherField("srcElement").GetField("id").Result"$)
	AddCode($"src = SDUIShared.MvField(src, 1, "_")"$)
	AddCode($"If src <> "" Then"$)
	AddCode($"BANano.CallSub(mback, mName & "_click", Array(src))"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'remove an attribe"$)
	AddCode($"Sub RemoveAttr(k As String)"$)
	AddCode($"mElement.RemoveAttr(k)"$)
	AddCode($"End Sub"$)
	
	AddCode($"'add an attribe"$)
	AddCode($"Sub AddAttr(k As String, v As String)"$)
	AddCode($"mElement.SetAttr(k, v)"$)
	AddCode($"End Sub"$)
	
	AddCode($"'add a style"$)
	AddCode($"Sub AddStyle(k As String, v As String)"$)
	AddCode($"Dim m As Map = CreateMap()"$)
	AddCode($"m.Put(k, v)"$)
	AddCode($"mElement.SetStyle(BANano.ToJson(m))"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'get disabled state"$)
	AddCode($"Sub getDisabled As Boolean"$)
	AddCode($"Dim d As String = mElement.GetAttr("disabled")"$)
	AddCode($"d = SDUIShared.CStr(d)"$)
	AddCode($"If d = "" Then Return False"$)
	AddCode($"Return True"$)
	AddCode($"End Sub"$)
	AddCode($"'set disabled state"$)
	AddCode($"Private Sub setDisabled(b As Boolean)"$)
	AddCode($"If b Then"$)
	AddCode($"mElement.SetAttr("disabled", "disabled")"$)
	AddCode($"Else"$)
	AddCode($"mElement.RemoveAttr("disabled")"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'add internal click event"$)
	AddCode($"Private Sub OnChangeInternal(el As BANanoElement)"$)
	AddCode($"Dim MethodName As String = ~"~{mName}_change"~"$)
	AddCode($"If SubExists(mback, MethodName) Then"$)
	AddCode($"el.On("change", Me, "HandleChange")"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	AddCode($"'we use this to get the id of the clicked item"$)
	AddCode($"private Sub HandleChange(event As BANanoEvent)		'ignore"$)
	AddCode($"Dim src As String = event.OtherField("srcElement").GetField("id").Result"$)
	AddCode($"src = SDUIShared.MvField(src, 1, "_")"$)
	AddCode($"If src <> "" Then"$)
	AddCode($"Dim b As Boolean = mElement.GetChecked"$)
	AddCode($"'Dim b As Boolean = mElement.GetChecked"$)
	AddCode($"BANano.CallSub(mback, mName & "_change", Array(b))"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'show component"$)
	AddCode($"Sub Show"$)
	AddCode($"setHidden(False)"$)
	AddCode($"End Sub"$)
	AddCode($"'hide component"$)
	AddCode($"Sub Hide"$)
	AddCode($"setHidden(True)"$)
	AddCode($"End Sub"$)
	AddCode($"Private sub setHidden(b As Boolean)"$)
	AddCode($"Dim c As String = "hidden""$)
	AddCode($"If b Then"$)
	AddCode($"mElement.AddClass(c)"$)
	AddCode($"Else"$)
	AddCode($"mElement.RemoveClass(c)"$)
	AddCode($"End If"$)
	AddCode($"End Sub"$)
	
	AddCode($"'enable component"$)
	AddCode($"Sub Enable"$)
	AddCode($"setDisabled(False)"$)
	AddCode($"End Sub"$)
	
	AddCode($"'disable component"$)
	AddCode($"Sub Disable"$)
	AddCode($"setDisabled(True)"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'append HTML to the container"$)
	AddCode($"Sub Append(varText As String)"$)
	AddCode($"mElement.Append(varText)"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'empty the contents of the element"$)
	AddCode($"Sub Clear"$)
	AddCode($"mElement.Empty"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'set a style property like "--value:70""$)
	AddCode($"Sub AddStyleComputed(var As String, value As String)"$)
	AddCode($"mElement.GetField("style").RunMethod("setProperty", Array(var, value))"$)
	AddCode($"End Sub"$)
	AddCode($"'get a style property like "--value""$)
	AddCode($"Sub GetStyleComputed(var As String) As Object"$)
	AddCode($"Dim computed As BANanoObject"$)
	AddCode($"computed.Initialize4("getComputedStyle", mElement.ToObject) ' note that computed is read-only!"$)
	AddCode($"Return computed.RunMethod("getPropertyValue", var)"$)
	AddCode($"End Sub"$)
	AddCode($"'remove a style property like "--value""$)
	AddCode($"Sub RemoveStyleComputed(var As String)"$)
	AddCode($"mElement.GetField("style").RunMethod("removeProperty", var)"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'set the actual html"$)
	AddCode($"Sub setHTML(h As String)"$)
	AddCode($"mElement.SetHTML(h)"$)
	AddCode($"End Sub"$)
	
	AddCode($"'color constants"$)
	AddCode($"Sub setColor(s As String)"$)
	AddCode($"mElement.RemoveClass(mLastColor)"$)
	AddCode($"Dim c As String = Theme.FixColor("radio", s)"$)
	AddCode($"mElement.AddClass(c)"$)
	AddCode($"mLastColor = c"$)
	AddCode($"End Sub"$)
	AddCode($"'size constants"$)
	AddCode($"Sub setSize(s As String)"$)
	AddCode($"mElement.RemoveClass(mLastSize)"$)
	AddCode($"Dim c As String = Theme.FixSize("radio", s)"$)
	AddCode($"mElement.AddClass(c)"$)
	AddCode($"mLastSize = c"$)
	AddCode($"End Sub"$)

End Sub

private Sub AddCode(code As String)
	lines.Add(code)
End Sub

Sub AddClasses(listOf As List)
	For Each k As String In listOf
		AddClass(k)
	Next
End Sub

Sub AddConstants(listOf As List)
	For Each k As String In listOf
		Dim original As String = k
		original = original.Replace("-","_")
		original = original.touppercase
		Dim sLine As String = $"Public Const ${original} As String = "${k}""$
		AddCode(sLine)
	Next
End Sub

Sub HasValue
	AddCode($"'set the value"$)
	AddCode($"Sub setValue(v As Object)"$)
	AddCode($"mElement.SetValue(v)"$)
	AddCode($"End Sub"$)
	'
	AddCode($"'get the value"$)
	AddCode($"Sub getValue As Object"$)
	AddCode($"dim v as Object = mElement.GetValue"$)
	AddCode($"Retun v"$)
	AddCode($"End Sub"$)
End Sub

'attr and type
Sub AddAttributes(m As Map)
	For Each k As String In m.Keys
		Dim v As String = m.Get(k)
		Dim propName As String = SDUIShared.CamelCase(k)
		'
		AddCode($"'change the ${k}"$)
		AddCode($"Sub set${propName}(v As ${SDUIShared.ProperCase(v)})"$)
		AddCode($"mElement.SetAttr(${k}, v)"$)
		AddCode($"End Sub"$)
		'
		AddCode($"'get the ${k}"$)
		AddCode($"Sub get${propName} As ${SDUIShared.ProperCase(v)}"$)
		AddCode($"dim v As ${v} = mElement.GetAttr("${k}")"$)
		AddCode($"Return v"$)
		AddCode($"End Sub"$)
	Next
End Sub


Sub AddClass(k As String) As DaisyBuilder
		Dim propName As String
		If k.Contains("-") Then
			Dim cTot As Int = SDUIShared.MvCount(k, "-")
			cTot = SDUIShared.CInt(cTot)
			Select Case cTot
			Case 2	
				Dim part1 As String = SDUIShared.MvField(k, 1, "-")
				Dim part2 As String = SDUIShared.MvField(k, 2, "-")
				If part1 = prefix Or part1 = "fa" Then
					propName = SDUIShared.ProperCase(part2)
					Select Case part2
					Case "xs"
						propName = "XSmall"
					Case "md"
						propName = "Medium"
					Case "xl"
						propName = "XLarge"
					Case "sm"		
						propName = "Small"
					Case "lg"
						propName = "Large"	
					Case "2xs"
						propName = "XXSmall"
					Case "2xl"
						propName = "XXLarge"
					End Select
				Else
					propName = SDUIShared.CamelCase(k)
				End If
				AddCode($"'change the ${prefix} to ${propName.tolowercase}"$)
				AddCode($"Sub ${propName} As SDUI${prefix}"$)
				AddCode($"Dim c As String = "${k}""$)
				'AddCode($"If b Then"$)
				AddCode($"mElement.AddClass(c)"$)
				'AddCode($"Else"$)
				'AddCode($"mElement.RemoveClass(c)"$)
				'AddCode($"End If"$)
				AddCode("Return Me")
				AddCode($"End Sub"$)
			Case Else
				Dim part2 As String = SDUIShared.MvRest("-",k, 2)
				propName = SDUIShared.CamelCase(part2)
				AddCode($"'change the ${prefix} to ${propName.tolowercase}"$)
				AddCode($"Sub ${propName} As SDUI${prefix}""$)
				AddCode($"Dim c As String = "${k}""$)
				'AddCode($"If b Then"$)
				AddCode($"mElement.AddClass(c)"$)
				'AddCode($"Else"$)
				'AddCode($"mElement.RemoveClass(c)"$)
				'AddCode($"End If"$)
				AddCode("Return Me")
				AddCode($"End Sub"$)
			End Select	
		Else
			'does not contain
			propName = SDUIShared.ProperCase(k)
			AddCode($"'change the ${prefix} to ${propName.tolowercase}"$)
			AddCode($"Sub ${propName}"$)
			AddCode($"Dim c As String = "${k}""$)
			'AddCode($"If b Then"$)
			AddCode($"mElement.AddClass(c)"$)
			'AddCode($"Else"$)
			'AddCode($"mElement.RemoveClass(c)"$)
			'AddCode($"End If"$)
			AddCode($"End Sub"$)
		End If
		Return Me
End Sub

private Sub ToString As String
	Dim allCode As String = SDUIShared.Join(CRLF, lines)
	allCode = allCode.Replace("~","$")
	Return allCode
End Sub

Sub Download
	Dim sout As String = ToString
	Dim clsName As String = $"SDUI${SDUIShared.CamelCase(prefix)}"$
	SDUIShared.DownloadText2File(sout, clsName & ".bas")
End Sub