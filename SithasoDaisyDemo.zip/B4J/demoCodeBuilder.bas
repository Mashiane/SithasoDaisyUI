﻿B4J=true
Group=Default Group\Tools
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "codebuilder"
	Public title As String = "Code Builder"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtOriginal As SDUITextArea
	Private txtCode As SDUIMockupCode
	Private txtVariable As SDUITextBox
	Private txtRC As SDUITextBox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns2x6
	page.Root.AddRows2.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	txtVariable = page.Cell(1, 1).AddTextBoxLabel("varname", "Variable Name", "Example: c1")
	txtVariable.Placeholder = "c1"
	txtRC = page.Cell(1, 2).AddTextBoxLabel("rc", "Row / Column", "Example: 1, 1")
	txtRC.Placeholder = "1, 1"
		
	txtOriginal = page.Cell(2, 1).AddTextAreaLabel("cb", "Code Builder", "Paste your code and click AppendIcon")
	txtOriginal.AppendIcon = "fa-solid fa-code"
	txtOriginal.Rows = 10
	txtOriginal.PrependIcon = "fa-solid fa-paste"
	
	txtCode = page.Cell(3, 1).AddMockUpCodeCard("tc", "vb", "Code Output")
End Sub

Private Sub tc_Action (item As String)
	
End Sub

Private Sub cb_Append_Click (event As BANanoEvent)
	Dim sb As StringBuilder
	sb.Initialize
	sb.Append($"Dim ${txtVariable.Value} As SDUIMockupCode = page.Cell(${txtRC.Value}).AddMockUpCode("${txtVariable.value}", "vb")"$).Append(CRLF)
	
	'
	Dim sc As String = txtOriginal.Value
	
	Dim dollar As String = "$"
	Dim splines As List = SDUIShared.StrParse(CRLF, sc)
	For Each strLine As String In splines
		strLine = strLine.Trim
		If strLine = "" Then Continue
		strLine = strLine.Replace(dollar, "~")
		sb.Append($"${txtVariable.value}.AddCode(^"${strLine}"^)"$).Append(CRLF)
	Next
	sb.Append($"${txtVariable.value}.Refresh"$)
	'
	Dim sout As String = sb.ToString
	sout = sout.Replace("^","$")
	txtCode.clear
	txtCode.AddCode(sout)
	txtCode.RefreshRaw
	'
	Dim code As String = txtCode.Value
	banano.Await(app.CopyToClipboard(code))
End Sub

Private Sub cb_Prepend_Click (event As BANanoEvent)
	'paste content from clipboard
	Dim txt As String = banano.Await(app.CopyFromClipBoard)
	txtOriginal.Value = txt
End Sub

Private Sub tc_Append_Click (event As BANanoEvent)
	Dim code As String = txtCode.Value
	banano.Await(app.CopyToClipboard(code))
End Sub