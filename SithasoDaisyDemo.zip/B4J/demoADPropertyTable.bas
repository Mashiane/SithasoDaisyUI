﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adpropertytable"
	Public title As String = "AD Property Table"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUITable1 As SDUITable
	Private SDUIDiv1 As SDUIDiv
	Private SDUIMockupCode1 As SDUIMockupCode
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	banano.Await(app.UsesFlatPickDateTime)
	''banano.Await(app.UsesTable)
	'banano.Await(app.UsesSignaturePad)
	banano.Await(app.UsesRollDate)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adpropertytablelayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV("SDUIPage.page", "page")
	pgIndex.AddDesignKV("SDUITable.SDUITable1", "SDUITable1")
	pgIndex.AddDesignKV("SDUIDiv.SDUIDiv1", "SDUIDiv1")
	pgIndex.AddDesignKV("SDUIMockupCode.SDUIMockupCode1", "SDUIMockupCode1")
	'
	pgIndex.SaveSettings("SDUIPage.page", page.CustProps)
	pgIndex.SaveSettings("SDUITable.SDUITable1", SDUITable1.CustProps)
	pgIndex.SaveSettings("SDUIDiv.SDUIDiv1", SDUIDiv1.CustProps)
	pgIndex.SaveSettings("SDUIMockupCode.SDUIMockupCode1", SDUIMockupCode1.CustProps)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

Private Sub SDUITable1_txtpwdgroup_Prepend_Click (event As BANanoEvent)
	app.ShowSwal("Prepend Click!")
End Sub

Private Sub SDUITable1_txtpwdgroup_Append_Click (event As BANanoEvent)
	app.ShowSwal("Append Click!")
	SDUITable1.SetPropertyToggleEyes("txtpwdgroup")
End Sub

Private Sub SDUITable1_dial1_Plus (event As BANanoEvent)
	app.ShowSwal("Plus!")
	'SDUITable1.SetPropertyDialerIncrement("dial1")
End Sub

Private Sub SDUITable1_dial1_Minus (event As BANanoEvent)
	app.ShowSwal("Minus!")
	SDUITable1.SetPropertyDialerDecrement("dial1")
End Sub

'https://play.tailwindcss.com/jSVPFpbTRX
'start building the page
private Sub BuildPage
	SDUITable1.ClearPropertyBag
	SDUITable1.AddPropertyTextBox("ParentID", "ParentID", "", "The ParentID of this div", True, "top")
	SDUITable1.AddPropertyTextBoxGroup("txtgroup", "Text Group", "", "", True, "left")
	SDUITable1.SetPropertyPrefix("txtgroup", "$")
	SDUITable1.SetPropertySuffix("txtgroup", ".00")
	'
	SDUITable1.AddPropertyPasswordGroup("txtpwdgroup", "Password Group", "password", "", True, "left")
	SDUITable1.SetPropertyPrependIcon("txtpwdgroup", "fa-solid fa-user-lock")
	'
	SDUITable1.AddPropertySelectGroup("selectgrp", "Select Group", "md", "Select Group", True, "bottom", SDUIShared.KeyValuesFromMV("|", "lg|md|sm|xs"))
	'SDUITable1.SetPropertyPrependIcon("selectgrp", "fa-solid fa-inbox")
	SDUITable1.SetPropertyAppendIcon("selectgrp", "fa-solid fa-truck-fast")
	'
	SDUITable1.AddPropertyDialer("dial1", "Quantity", "10", "", False, "left", 0, 1, 100)
	
	SDUITable1.AddPropertyTextArea("MarginAXYTBLR", "Margins", "a=?; x=?; y=?; t=?; b=?; l=?; r=?", "Margins A-X-Y-T-B-L-R", False, "bottom")
	SDUITable1.AddPropertySelect("ButtonSize", "Button Size", "md", "Button Size", True, "bottom", SDUIShared.KeyValuesFromMV("|", "lg|md|sm|xs"))
	SDUITable1.AddPropertyFileInput("pdisplay", "Profile Pic", "Upload Profile Picture", "bottom")
	SDUITable1.AddPropertyAvatar("avata1", "Display Pic", "Display Picture", "12", app.MASK_HEXAGON, "./assets/face11.jpg")
	SDUITable1.AddPropertyProgress("prg1", "Progress 1", "10", app.color_primary, _
	"1", "10", "100", "The progress", "top")
	SDUITable1.AddPropertyRange("Range1", "Range 1", "10", app.color_primary, _
	"1", "10", "100", "The Range", "top")
	SDUITable1.AddPropertyCheckBox("chk1", "CheckBox 1", True, app.COLOR_PRIMARY, "This is a checkbox")
	SDUITable1.AddPropertyToggle("toggle1", "Toggle 1", True, app.COLOR_ACCENT, "This is a toggle")
	SDUITable1.AddPropertyRadialProgress("rpog1", "Radial Progress 1", "80", app.COLOR_PRIMARY, "Project Progess")
	SDUITable1.AddPropertyRating("rating1", "Rating X", "2", app.COLOR_ORANGE, "This is a new rating...")
	SDUITable1.AddPropertyRadioGroup("rg1", "Radio Group", "male", app.COLOR_PRIMARY, "Gender", "top", _
	CreateMap("male":"Male", "female":"Female"))
	SDUITable1.AddPropertyImage("img1", "Image", "", "12", "12", "squircle", "./assets/mashy.jpg")
	SDUITable1.AddPropertyDatePicker("dp1", "Date Pick", "2022-12-18","",False,"left","Y-m-d","F j, Y")
	SDUITable1.AddPropertyDateTimePicker1("dp2", "Date Time Pick", "2022-12-18","",False,"left","Y-m-d H:i","m/d/Y H:i", True, "es")
	SDUITable1.AddPropertyTimePicker("timep1", "Time Pick", "14:58","",False,"left",False)
	SDUITable1.AddPropertyAvatar("online", "Avatar Online", "", "12", app.MASK_CIRCLE, "./assets/face11.jpg")
	SDUITable1.SetPropertyAvatarOnline("online", True, True)
	SDUITable1.AddPropertyAvatar("hasring", "Avatar ring", "", "12", app.MASK_CIRCLE, "./assets/face11.jpg")
	SDUITable1.SetPropertyAvatarRing("hasring", True, app.COLOR_PRIMARY)
	SDUITable1.AddPropertyAvatarGroup("agroup", "Avatar Group", "", "12", app.MASK_SQUIRCLE, Array("./assets/1.jpg","./assets/2.jpg","./assets/3.jpg","./assets/4.jpg", "./assets/Angela.jpg"))
	'SDUITable1.SetPropertyAvatarGroupItems("agroup", "12", app.MASK_SQUIRCLE, Array("./assets/Anna.jpg","./assets/daisywoman3.png","./assets/face25.jpg","./assets/sponge.png"))
	'
	SDUITable1.AddPropertyFileInputProgress("pfile", "File Progress", "", "", "80px", "fa-solid fa-arrow-up-from-bracket", "secondary")
	SDUITable1.AddPropertyCamera("pcamera", "Camera", "","", "80px", "success")
	SDUITable1.AddPropertyCamCorder("pcamcorder", "Camcorder", "","", "80px", "primary")
	SDUITable1.AddPropertyMicrophone("pmicrophone", "Microphone", "","", "80px", "warning")
	SDUITable1.AddPropertyAvatarPlaceholder("aplaceholder", "Avatar Placeholder", "99+", "", "80px", app.MASK_SQUIRCLE, "primary")
	SDUITable1.AddPropertyActionButton("btnSavePropBag", "Save", app.COLOR_PINK)
	SDUITable1.SetPropertyValue("aplaceholder", "100")
	'
	SDUITable1.AddPropertySignaturePad("sign1", "Signature", "Delivery Signature", True, "left", "250", "200", "jpeg")
	'
	Dim dt1Options As RollDateOptions = app.InitRollDateTime
	dt1Options.beginYear = 2000
	dt1Options.endYear = 2100
	dt1Options.DateTimeFormat = "YYYY-MM-DD"	
	
	SDUITable1.AddPropertyRollDateTime("rdate1", "RollDate", "", True, "left", dt1Options)
	'
	Dim dt2Options As RollDateOptions = app.InitRollDateTime
	dt2Options.DateTimeFormat = "hh:mm"
	dt2Options.MinStep = 5
	dt2Options.Title = "Select Time"
	
	SDUITable1.AddPropertyRollDateTime("rdate2", "Roll Time", "", True, "left", dt2Options)
	'
	SDUIMockupCode1.Clear
	SDUIMockupCode1.AddCode($"SDUITable1.ClearPropertyBag"$)
	
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyTextBoxGroup("txtgroup", "Text Group", "", "", True, "left")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyPrefix("txtgroup", "~")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertySuffix("txtgroup", ".00")"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyPasswordGroup("txtpwdgroup", "Password Group", "password", "", True, "left")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyPrependIcon("txtpwdgroup", "fa-solid fa-user-lock")"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertySelectGroup("selectgrp", "Select Group", "md", "Select Group", True, "bottom", SDUIShared.KeyValuesFromMV("|", "lg|md|sm|xs"))"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyPrependIcon("selectgrp", "fa-solid fa-inbox")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyAppendIcon("selectgrp", "fa-solid fa-truck-fast")"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyDialer("dial1", "Quantity", "10", "", False, "left", 0, 1, 100)"$)

	
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyTextBox("ParentID", "ParentID", "", "The ParentID of this div", True, "top")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyTextArea("MarginAXYTBLR", "Margins", "a=?; x=?; y=?; t=?; b=?; l=?; r=?", "Margins A-X-Y-T-B-L-R", False, "bottom")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertySelect("ButtonSize", "Button Size", "md", "Button Size", True, "bottom", SDUIShared.KeyValuesFromMV("|", "lg|md|sm|xs"))"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyFileInput("pdisplay", "Profile Pic", "Upload Profile Picture", "bottom")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyAvatar("avata1", "Display Pic", "Display Picture", "12", app.MASK_HEXAGON, "./assets/face11.jpg")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyProgress("prg1", "Progress 1", "10", app.color_primary, _"$)
	SDUIMockupCode1.AddCode($""1", "10", "100", "The progress", "top")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRange("Range1", "Range 1", "10", app.color_primary, _"$)
	SDUIMockupCode1.AddCode($""1", "10", "100", "The Range", "top")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyCheckBox("chk1", "CheckBox 1", True, app.COLOR_PRIMARY, "This is a checkbox")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyToggle("toggle1", "Toggle 1", True, app.COLOR_ACCENT, "This is a toggle")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRadialProgress("rpog1", "Radial Progress 1", "80", app.COLOR_PRIMARY, "Project Progess")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRating("rating1", "Rating X", "2", app.COLOR_ORANGE, "This is a new rating...")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRadioGroup("rg1", "Radio Group", "male", app.COLOR_PRIMARY, "Gender", "top", _"$)
	SDUIMockupCode1.AddCode($"CreateMap("male":"Male", "female":"Female"))"$)
	
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyImage("img1", "Image", "", "12", "12", "squircle", "./assets/mashy.jpg")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyDatePicker("dp1", "Date Pick", "2022-12-18","",False,"left","Y-m-d","F j, Y")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyDateTimePicker1("dp2", "Date Time Pick", "2022-12-18","",False,"left","Y-m-d H:i","m/d/Y H:i", True, "es")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyTimePicker("timep1", "Time Pick", "14:58","",False,"left",False)"$)
	'
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyAvatar("online", "Avatar Online", "", "12", app.MASK_CIRCLE, "./assets/face11.jpg")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyAvatarOnline("online", True, True)"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyAvatar("hasring", "Avatar ring", "", "12", app.MASK_CIRCLE, "./assets/face11.jpg")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyAvatarRing("hasring", True, app.COLOR_PRIMARY)"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyAvatarGroup("agroup", "Avatar Group", "", "12", app.MASK_CIRCLE, Array("./assets/1.jpg","./assets/2.jpg","./assets/3.jpg","./assets/4.jpg", "./assets/Angela.jpg"))"$)
	SDUIMockupCode1.AddCode($"' change the avatar images"$)
	SDUIMockupCode1.AddCode($"'SDUITable1.SetPropertyAvatarGroupItems("agroup", "12", app.MASK_SQUIRCLE, Array("./assets/Anna.jpg","./assets/daisywoman3.png","./assets/face25.jpg","./assets/sponge.png"))"$)
	'
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyFileInputProgress("pfile", "File Progress", "", "", "80px", "fa-solid fa-arrow-up-from-bracket", "secondary")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyCamera("pcamera", "Camera", "","", "80px", "success")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyCamCorder("pcamcorder", "Camcorder", "","", "80px", "primary")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyMicrophone("pmicrophone", "Microphone", "","", "80px", "warning")"$)
	'
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyAvatarPlaceholder("aplaceholder", "Avatar Placeholder", "99+", "", "80px", app.MASK_SQUIRCLE, "primary")"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyActionButton("btnSavePropBag", "Save", app.COLOR_PINK)"$)
	SDUIMockupCode1.AddCode($"SDUITable1.SetPropertyValue("aplaceholder", "100")"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertySignaturePad("sign1", "Signature", "Delivery Signature", True, "left", "250", "200", "jpeg")"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"Dim dt1Options As RollDateOptions = app.InitRollDateTime"$)
	SDUIMockupCode1.AddCode($"dt1Options.beginYear = 2000"$)
	SDUIMockupCode1.AddCode($"dt1Options.endYear = 2100"$)
	SDUIMockupCode1.AddCode($"dt1Options.DateTimeFormat = "YYYY-MM-DD""$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRollDateTime("rdate1", "RollDate", "", True, "left", dt1Options)"$)
	SDUIMockupCode1.AddCode($"'"$)
	SDUIMockupCode1.AddCode($"Dim dt2Options As RollDateOptions = app.InitRollDateTime"$)
	SDUIMockupCode1.AddCode($"dt2Options.DateTimeFormat = "hh:mm""$)
	SDUIMockupCode1.AddCode($"dt2Options.MinStep = 5"$)
	SDUIMockupCode1.AddCode($"dt2Options.Title = "Select Time""$)
	SDUIMockupCode1.AddCode($"SDUITable1.AddPropertyRollDateTime("rdate2", "Roll Time", "", True, "left", dt2Options)"$)
	'
	SDUIMockupCode1.Refresh
End Sub


'when button is clicked
private Sub SDUITable1_pcamera_click(e As BANanoEvent)
	e.PreventDefault
	e.StopPropagation
	'click the file input to fire change event
	banano.GetElement("#pcamera").RunMethod("click", Null)
End Sub

private Sub SDUITable1_pfile_click(e As BANanoEvent)
	e.PreventDefault
	e.StopPropagation
	'click the file input to fire change event
	banano.GetElement("#pfile").RunMethod("click", Null)
End Sub

'when button is clicked
private Sub SDUITable1_pcamcorder_click(e As BANanoEvent)
	e.PreventDefault
	e.StopPropagation
	'click the file input to fire change event
	banano.GetElement("#pcamcorder").RunMethod("click", Null)
End Sub

'when button is clicked
private Sub SDUITable1_pmicrophone_click(e As BANanoEvent)
	e.PreventDefault
	e.StopPropagation
	'click the file input to fire change event
	banano.GetElement("#pmicrophone").RunMethod("click", Null)
End Sub


Sub SDUITable1_btnSavePropBag (e As BANanoEvent)
	Dim pbag As Map = SDUITable1.GetData
	Dim sout As String = banano.ToJson(pbag)
	app.ShowSwal(sout)
End Sub

Private Sub SDUITable1_ChangeProperties (item As Map)
	Log("SDUITable1_ChangeProperties...")
	Log(item)
End Sub

'file input change event
Private Sub SDUITable1_pfile (e As BANanoEvent)
	e.PreventDefault
	'get file object from change event
	Dim fileObj As Map = SDUITable1.GetFileFromEvent(e)
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	app.PagePause
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'****
	'Dim fJSON As Map = BANano.Await(SDUIShared.readAsJsonWait(fileObj))
	'Dim fBuffer As Object = BANano.Await(SDUIShared.readAsArrayBufferWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsTextWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsDataURLWait(fileObj))
	'****
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'fileDet = SDUIShared.UploadFileOptionsWait(fileObj, "../assets", "n")
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			app.PageResume
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	SDUITable1.SetPropertyValue("img1", fp)
	app.PageResume
End Sub
'file input change event
Private Sub SDUITable1_pcamera (e As BANanoEvent)
	e.PreventDefault
	'get file object from change event
	Dim fileObj As Map = SDUITable1.GetFileFromEvent(e)
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	app.PagePause
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'****
	'Dim fJSON As Map = BANano.Await(SDUIShared.readAsJsonWait(fileObj))
	'Dim fBuffer As Object = BANano.Await(SDUIShared.readAsArrayBufferWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsTextWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsDataURLWait(fileObj))
	'****
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'fileDet = SDUIShared.UploadFileOptionsWait(fileObj, "../assets", "n")
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			app.PageResume
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	SDUITable1.SetPropertyValue("img1", fp)
	app.PageResume
End Sub
'file input change event
Private Sub SDUITable1_pcamcorder (e As BANanoEvent)
	e.PreventDefault
	'get file object from change event
	Dim fileObj As Map = SDUITable1.GetFileFromEvent(e)
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	app.PagePause
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'****
	'Dim fJSON As Map = BANano.Await(SDUIShared.readAsJsonWait(fileObj))
	'Dim fBuffer As Object = BANano.Await(SDUIShared.readAsArrayBufferWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsTextWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsDataURLWait(fileObj))
	'****
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'fileDet = SDUIShared.UploadFileOptionsWait(fileObj, "../assets", "n")
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			app.PageResume
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	SDUITable1.SetPropertyValue("img1", fp)
	app.PageResume
End Sub
'file input change event
Private Sub SDUITable1_pmicrophone (e As BANanoEvent)
	e.PreventDefault
	'get file object from change event
	Dim fileObj As Map = SDUITable1.GetFileFromEvent(e)
	If banano.IsNull(fileObj) Or banano.IsUndefined(fileObj) Then Return
	app.PagePause
	'get file details
	Dim fileDet As FileObject
	fileDet = SDUIShared.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	If fs >= 5000 Then
	End If
	'****
	'Dim fJSON As Map = BANano.Await(SDUIShared.readAsJsonWait(fileObj))
	'Dim fBuffer As Object = BANano.Await(SDUIShared.readAsArrayBufferWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsTextWait(fileObj))
	'Dim fText As String = BANano.Await(SDUIShared.readAsDataURLWait(fileObj))
	'****
	'start uploading the file to assets folder
	fileDet = SDUIShared.UploadFileWait(fileObj)
	'fileDet = SDUIShared.UploadFileOptionsWait(fileObj, "../assets", "n")
	'get the status of the upload
	Dim sstatus As String = fileDet.Status
	Select Case sstatus
		Case "error"
			app.PageResume
			Return
		Case "success"
	End Select
	'get the upload full path
	Dim fp As String = fileDet.FullPath
	SDUITable1.SetPropertyValue("img1", fp)
	app.PageResume
End Sub