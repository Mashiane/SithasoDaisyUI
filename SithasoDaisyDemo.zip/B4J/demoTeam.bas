﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "team"
	Public title As String = "AD Team"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private myteam As SDUITeam		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adteamlayout")
	'add other platforms
	myteam.AddPlatForm("wechat", "wechat", "fa-brands fa-weixin")
	myteam.AddPlatForm("apple", "apple", "fa-brands fa-apple")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	Mounted
End Sub


Sub Mounted
	app.PagePause
	myteam.Clear
	Dim profilesJSON As String = $"[
	{"fullname":"Roberta Conn","bio":"foodie, model","title":"Regional Creative Consultant","telephone":"(301) 622-2568","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/531.jpg","email":"Abdullah37@hotmail.com","github":"Vernice.Cummings@hotmail.com","linkedin":"Stephania_Hills@hotmail.com","facebook":"Maria.Kuphal@gmail.com","instagram":"Lenora_Gleason57@hotmail.com","twitter":"Vladimir91@hotmail.com","id":"5025053743775744","whatsapp":"5025053743775744","telegram":"5025053743775744"},
	{"fullname":"Kerry Cruickshank","bio":"sailor supporter","title":"National Infrastructure Associate","telephone":"1-358-265-3139","image":"https://avatars.githubusercontent.com/u/59628706","email":"Dillon_Schiller@gmail.com","github":"Maci.Schowalter@hotmail.com","linkedin":"Cheyenne_Vandervort@yahoo.com","facebook":"Julianne46@hotmail.com","instagram":"Marielle30@hotmail.com","twitter":"Austin30@gmail.com","id":"6234673120280576", "apple":"this is apple", "wechat":"wechatx"},
	{"fullname":"Donald McKenzie","bio":"insert devotee","title":"Investor Quality Associate","telephone":"433.844.2944 x01918","image":"https://avatars.githubusercontent.com/u/25983345","email":"Morton93@hotmail.com","github":"Bruce.Gleason@yahoo.com","linkedin":"Helen_Yundt77@yahoo.com","facebook":"Floy11@yahoo.com","instagram":"Aliya_Luettgen@hotmail.com","twitter":"Dell.Herman71@yahoo.com","id":"6124227929309184"},
	{"fullname":"Irvin Robel","bio":"spokeswoman advocate, engineer","title":"Forward Factors Planner","telephone":"1-433-438-6785 x2474","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/978.jpg","email":"Domenick_Huel@hotmail.com","github":"Emery_Considine47@yahoo.com","linkedin":"Yvonne_Swaniawski-White51@gmail.com","facebook":"Jaylan_Kutch92@hotmail.com","instagram":"Sofia.Schiller@hotmail.com","twitter":"Morris_DAmore@gmail.com","id":"767304543502336"},
	{"fullname":"Henrietta Strosin","bio":"patriot, dreamer, grad","title":"Global Accounts Producer","telephone":"490-353-4428 x53212","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/334.jpg","email":"Luna_Abernathy97@gmail.com","github":"Mack_Ernser72@gmail.com","linkedin":"Dayne74@yahoo.com","facebook":"Mike_Schumm47@gmail.com","instagram":"Janelle_Effertz@hotmail.com","twitter":"Green.Sawayn-Legros53@yahoo.com","id":"3189885152264192"},
	{"fullname":"Dan Hilll IV","bio":"filmmaker, person, artist","title":"Senior Optimization Architect","telephone":"267-634-8639 x397","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/713.jpg","email":"Eldora.Kulas17@gmail.com","github":"Bryce_Borer@yahoo.com","linkedin":"Sheila_Kutch96@hotmail.com","facebook":"Keith.Johnson16@gmail.com","instagram":"Lindsay.Hessel70@yahoo.com","twitter":"Mario.Schaefer@hotmail.com","id":"584719255207936"},
	{"fullname":"Jane Terry","bio":"developer, film lover","title":"Direct Mobility Agent","telephone":"592.429.8696","image":"https://avatars.githubusercontent.com/u/60035849","email":"Cordie_Lindgren@hotmail.com","github":"Ethan_Hickle@gmail.com","linkedin":"Josue_Rau56@yahoo.com","facebook":"Corene14@gmail.com","instagram":"Lily_Hane14@gmail.com","twitter":"Beverly.Deckow@yahoo.com","id":"8223428471422976"},
	{"fullname":"Francisco Smitham","bio":"experimentation supporter","title":"Central Response Assistant","telephone":"572-880-6636 x499","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/99.jpg","email":"Fidel5@hotmail.com","github":"Mabel18@hotmail.com","linkedin":"Derrick13@hotmail.com","facebook":"Citlalli23@hotmail.com","instagram":"Kiley_Sawayn@gmail.com","twitter":"Eugene33@gmail.com","id":"339260215394304"},
	{"fullname":"Mamie Parker","bio":"musician, creator","title":"Global Solutions Assistant","telephone":"1-802-922-2316","image":"https://avatars.githubusercontent.com/u/36526729","email":"Jordyn.Denesik@gmail.com","github":"Meta63@hotmail.com","linkedin":"Weldon_Bashirian35@yahoo.com","facebook":"Marjolaine40@gmail.com","instagram":"Baron_Upton@hotmail.com","twitter":"Bernardo.Lemke@hotmail.com","id":"4678595018489856"},
	{"fullname":"Mrs. Joanna Macejkovic","bio":"unique supporter","title":"Central Division Architect","telephone":"1-932-561-7730 x11801","image":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/13.jpg","email":"Davin11@hotmail.com","github":"Rahsaan_Becker-Fay27@hotmail.com","linkedin":"Marley.Ernser66@hotmail.com","facebook":"Jayda_Okuneva60@yahoo.com","instagram":"Orie22@gmail.com","twitter":"Mary_Halvorson38@hotmail.com","id":"6703357190209536"}]"$
	
	Dim profiles As List = banano.FromJson(profilesJSON)
	myteam.SetItemsPaginate(profiles)
	myteam.SetAlphaChooser(True, "8", "fullname")
	app.pageresume
End Sub

'Private Sub myteam_Click (e As BANanoEvent, Profile As Map)
'	e.PreventDefault
'	Log(Profile)
'	app.ShowToastSuccess("Click", "Card")
'End Sub

Private Sub myteam_edit (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"edit"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Edit")
End Sub

Private Sub myteam_clone (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"clone"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Clone")
End Sub

Private Sub myteam_delete (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"delete"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Delete")
End Sub

Private Sub myteam_whatsapp (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"whatsapp"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Whatsapp")
End Sub

Private Sub myteam_telegram (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"telegram"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Telegram")
End Sub

Private Sub myteam_wechat (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"wechat"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "WeChat")
End Sub

Private Sub myteam_apple (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"apple"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Apple")
End Sub


Private Sub myteam_Email (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"email"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Email")
End Sub

Private Sub myteam_Facebook (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"facebook"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Facebook")
End Sub

Private Sub myteam_Instagram (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"instagram"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Instagram")
End Sub

Private Sub myteam_Github (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"github"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Github")
End Sub

Private Sub myteam_LinkedIn (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"linkedin"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "LinkedIn")
End Sub

Private Sub myteam_Telephone (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"telephone"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Telephone")
End Sub

Private Sub myteam_Twitter (e As BANanoEvent, Profile As Map)
	e.PreventDefault
	Log($"twitter"$)
	Log(Profile)
	app.ShowToastSuccess("Click", "Twitter")
End Sub

Private Sub myteam_AlphaClick (item As String)
	app.PagePause
	Dim alphaSearch As List = myteam.SearchByAlphabet(item, "fullname")
	banano.Await(myteam.SetItems(alphaSearch))
	app.PageResume
End Sub

Private Sub myteam_Add (e As BANanoEvent)
	e.PreventDefault
	app.ShowToastSuccess("Add", "Profile")
End Sub

Private Sub myteam_Refresh (e As BANanoEvent)
	e.PreventDefault
	Mounted
End Sub

Private Sub myteam_Back (e As BANanoEvent)
	e.PreventDefault
	app.ShowToastSuccess("Back", "")
End Sub

Private Sub myteam_DeleteAll (e As BANanoEvent)
	e.PreventDefault
	app.ShowToastSuccess("DeleteAll", "")
End Sub

Private Sub myteam_FileChange (e As BANanoEvent)
	e.PreventDefault
End Sub