﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "modals1"
	Public title As String = "Modals 1"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private mdlForm As SDUIModal
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	
	''banano.Await(app.UsesFormToJSON)
	banano.Await(app.UsesFlatPickDateTime)
	banano.Await(app.UsesRollDate)
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	banano.LoadLayout(app.PageViewer, "modalslayout")
	'
	'mdlForm.Form.designMode(True)
	mdlForm.Form.ComponentSize = "md"
	mdlForm.Form.HideDetails = True
	mdlForm.Form.AddComponentTextBox(1, 1, "firstname", "First Name", "", True)
	mdlForm.Form.AddComponentTextBox(1, 2, "lastname", "Last Name", "", True)
	'
	mdlForm.Form.AddComponentDatePicker(2, 1, "dob", "Date of Birth", "", False, "Y-m-d", "F j, Y")
	mdlForm.Form.AddComponentTextBox(2, 2, "pob", "Place of Birth", "", False)
	'
	mdlForm.Form.AddComponentDateTimePicker(3, 1, "dtob", "Date / Time of Birth", "", False, "Y-m-d H:i", "F j, Y H:i", True)
	mdlForm.Form.AddComponentTimePicker(3, 2, "tob", "Time of Birth", "", False, True)
	'
	mdlForm.Form.AddComponentPassword(4, 1, "pwd1", "Password", "", False)
	mdlForm.Form.AddComponentSelect(4, 2, "cbogender1", "Gender 1", "", False, CreateMap("Male":"Male","Female":"Female","Other":"Other"))
	'
	mdlForm.Form.AddComponentDialer(5, 1, "dial1", "Quantity", "1", False, "0", "1", "100")
	mdlForm.Form.AddComponentSelect(5, 2, "cbogender", "Gender", "", False, CreateMap("Male":"Male","Female":"Female","Other":"Other"))
	'
	mdlForm.Form.AddComponentNumber(6, 1, "num1", "Number 1", "10", True, "0", "5", "20")
	mdlForm.Form.AddComponentTelephone(6, 2, "tel1", "Telephone", "081", True)
	mdlForm.Form.AddComponentEmail(6, 3, "email1", "Email", "", True)
	mdlForm.Form.AddComponentWebsite(6, 4, "website1", "Website", "", False)
	'
	mdlForm.Form.AddComponentTextArea(7, 1, "bio", "Bio", "", True)
	mdlForm.Form.AddComponentFileInput(8, 1, "upload", "Upload Image", False)
	'
	mdlForm.Form.AddComponentAvatar(9, 1, "avatar1", "./assets/mashy.jpg", "80px", app.MASK_CIRCLE)
	mdlForm.Form.AddComponentImage(9, 2, "image1", "./assets/daisywoman3.png", "80px", "80px", app.MASK_SQUIRCLE)
	'
	mdlForm.Form.AddComponentCheckBox(10, 1, "chk1", "Checkbox 1", True, "#fe8a71", "")
	mdlForm.Form.AddComponentCheckBox(10, 2, "chk2", "Checkbox 2", False, "#f6cd61", "right")
	'
	mdlForm.Form.AddComponentToggle(11, 1, "tgl1", "Toggle 1", True, "#fe8a71", "")
	mdlForm.Form.AddComponentToggle(11, 2, "tgl2", "Toggle 2", False, "#f6cd61", "right")
	'
	mdlForm.Form.AddComponentRadio(12, 1, "rad1", "Radio 1", "myradio", True, "#fe8a71", "")
	mdlForm.Form.AddComponentRadio(12, 2, "rad2", "Radio 2", "myradio", False, "#f6cd61", "right")
	'
	mdlForm.Form.AddComponentProgress(13, 1, "prg1", "Progress 1", 10, app.COLOR_PRIMARY)
	mdlForm.Form.AddComponentRadialProgress(13, 2, "prg2", 70, app.COLOR_PRIMARY, "6rem", "2px")
	'
	mdlForm.Form.AddComponentRange(14, 1, "rng1", "Range 1", 5, app.COLOR_INFO, "0", "1", "20")
	mdlForm.Form.AddComponentRating(14, 2, "rat1", "Rating 1", 2, 5, "#51074a", app.MASK_HEART)
	'
	mdlForm.Form.AddComponentRadioGroup(15, 1, "rg1", "Radio Group 1", "b4i", "#87ceeb", False, CreateMap("b4a":"b4a","b4i":"b4i","b4j":"b4j","b4r":"b4r"))
	mdlForm.Form.AddComponentRadioGroup(16, 1, "rg2", "Radio Group 2", "b4a", "#98ff98", True, CreateMap("b4a":"b4a","b4i":"b4i","b4j":"b4j","b4r":"b4r"))
	'
	mdlForm.Form.AddComponentColorPicker(17, 1, "cp1", "Color Picker 1", "", True)
	mdlForm.Form.AddComponentAvatarGroup(17, 2, "avatg1", "32px", app.MASK_HEART, Array("./assets/mashy.jpg", "./assets/daisywoman1.jpg", "./assets/daisywoman3.png"))
	'
	mdlForm.Form.AddComponentLabel(18, 1, "label1", "Label 1", app.COLOR_CYAN)
	mdlForm.Form.AddComponentLink(18, 2, "link1", "Link 1", "https://www.b4x.com", app.COLOR_PINK)
	'
	mdlForm.Form.AddComponentAvatarPlaceholder(19, 1, "aph1", "AM", "24", "3xl", app.MASK_SQUIRCLE, app.COLOR_PRIMARY, "white")
	'
	mdlForm.Form.AddComponentButton(20, 1, "hey", "Hello SithasoDaisy!", "#851e3e", "white", False, True, True)
	mdlForm.Form.AddComponentButtonIcon(20, 2, "heyicon", "fa-brands fa-discord", "#dec3c3", "black", False, True)
	'
	mdlForm.Form.AddComponentButtonIndicator(21, 1, "hey2", "Hello SithasoDaisy!", "#851e3e", "white", True, False, False)
	'
	mdlForm.Form.AddComponentCamCorder(22, 1, "cam1", "80px", app.COLOR_SECONDARY, False)
	mdlForm.Form.AddComponentCamera(22, 2, "cam2", "80px", app.COLOR_WARNING, False)
	mdlForm.Form.AddComponentMicrophone(22, 3, "mic1", "80px", app.COLOR_TEAL, False)
	mdlForm.Form.AddComponentFileInputProgress(22, 4, "fip1", "80px", "", app.COLOR_AMBER, False) 
	'
	mdlForm.Form.AddComponentBadge(23, 1, "badge1", "Badge 1", "6px", app.COLOR_PRIMARY, app.COLOR_WHITE)
	mdlForm.Form.AddComponentBadgeLeftAvatar(23, 2, "badge2", "./assets/mashy.jpg", "Anele Mashy", "32px", app.COLOR_PRIMARY, app.COLOR_WHITE)
	'
	mdlForm.Form.AddComponentBadgeRightAvatar(24, 1, "badge3", "./assets/mashy.jpg", "Anele Mbanga", "32px", app.COLOR_PRIMARY, app.COLOR_WHITE)
	mdlForm.Form.AddComponentBadgeLeftIcon(24, 2, "badge4", "fa-brands fa-discord", "Badge Icon", "24px", app.COLOR_AMBER, app.COLOR_BLACK)
	'
	mdlForm.Form.AddComponentBadgeRightIcon(25, 1, "badge5", "fa-brands fa-discord", "Badge Icon", "24px", app.COLOR_AMBER, app.COLOR_BLACK)	
	'
	banano.await(mdlForm.Form.BuildForm(True))
	'	
	mdlForm.Cell(9, 1).CenterChildren
	mdlForm.Cell(9, 2).CenterChildren
	mdlForm.Cell(13, 2).CenterChildren
	mdlForm.Cell(19, 1).CenterChildren
	
	Dim firstname As SDUITextBox = mdlForm .Form.Component("firstname")
	firstname.Value = "Anele Mbanga"
	'
	Dim cbogender As SDUISelect = mdlForm.Form.Component("cbogender")
	cbogender.AddItem("SithasoDaisy", "SithasoDaisy")
	'
	'Dim aph1 As SDUIAvatar = mdlForm.Form.Component("aph1")
	'aph1.TextColor = "white"
	'
	Dim hey2 As SDUIButton = mdlForm.Form.Component("hey2")
	hey2.BadgeValue = 10
	hey2.NormalCase = True
	'
	mdlForm.Show
End Sub


Private Sub mdlForm_Yes_Click (e As BANanoEvent)
	mdlForm.Hide
End Sub

Private Sub mdlForm_No_Click (e As BANanoEvent)
	mdlForm.Hide
End Sub