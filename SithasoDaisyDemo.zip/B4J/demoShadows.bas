﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "shadowspage"
	Public title As String = "Shadows"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim div1 As SDUIDiv = page.Cell(1, 1).AddDiv("div1")
	div1.p(6).Shadow("md").shadowColorIntensity("gray", 500)
	div1.Caption = "shadow-md gray"
	'
	Dim co1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("co1", "vb")
	co1.AddCode($"Dim div1 As SDUIDiv = page.Cell(1, 1).AddDiv("div1")"$)
	co1.AddCode($"div1.p(6).Shadow("md").shadowColorIntensity("gray", 500)"$)
	co1.AddCode($"div1.Caption = "shadow-md gray""$)
	co1.Refresh
	'
	Dim div2 As SDUIDiv = page.Cell(2, 1).AddDiv("div2")
	div2.p(6).Shadow("lg").shadowColorIntensity("green", 500)
	div2.Caption = "shadow-lg green"
	'
	Dim co2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("co2", "vb")
	co2.AddCode($"Dim div2 As SDUIDiv = page.Cell(2, 1).AddDiv("div2")"$)
	co2.AddCode($"div2.p(6).Shadow("lg").shadowColorIntensity("green", 500)"$)
	co2.AddCode($"div2.Caption = "shadow-lg green""$)
	co2.Refresh
	'
	Dim div3 As SDUIDiv = page.Cell(3, 1).AddDiv("div3")
	div3.p(6).Shadow("xl").shadowColorIntensity("red", 500)
	div3.Caption = "shadow-xl red"
	'
	Dim co3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("co3", "vb")
	co3.AddCode($"Dim div3 As SDUIDiv = page.Cell(3, 1).AddDiv("div3")"$)
	co3.AddCode($"div3.p(6).Shadow("xl").shadowColorIntensity("red", 500)"$)
	co3.AddCode($"div3.Caption = "shadow-xl red""$)
	co3.Refresh
	'
	Dim div4 As SDUIDiv = page.Cell(4, 1).AddDiv("div4")
	div4.p(6).Shadow("2xl").shadowColorIntensity("purple", 500)
	div4.Caption = "shadow-2xl purple"
	'
	Dim co4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("co4", "vb")
	co4.AddCode($"Dim div4 As SDUIDiv = page.Cell(4, 1).AddDiv("div4")"$)
	co4.AddCode($"div4.p(6).Shadow("2xl").shadowColorIntensity("purple", 500)"$)
	co4.AddCode($"div4.Caption = "shadow-2xl purple""$)
	co4.Refresh
	'
	Dim btn1 As SDUIButton = page.Cell(5, 1).AddButtonNormal("btn1", "Shadow Color Button")
	btn1.Root.px(6).py(2).textColorIntensity("purple", 100).bgColorIntensity("purple", 500).isrounded
	btn1.Root.Shadow("xl").shadowColorIntensity("purple", 400).hover("shadow-purple-100")
	'
	Dim co5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("co5", "vb")
	co5.AddCode($"Dim btn1 As SDUIButton = page.Cell(5, 1).AddButtonNormal("btn1", "Shadow Color Button")"$)
	co5.AddCode($"btn1.Root.px(6).py(2).textColorIntensity("purple", 100).bgColorIntensity("purple", 500).isrounded"$)
	co5.AddCode($"btn1.Root.Shadow("xl").shadowColorIntensity("purple", 400).hover("shadow-purple-100")"$)
	co5.Refresh
	
	'normal card
	Dim c1 As SDUIDiv = page.Cell(6, 1).AddDiv("c1")
	c1.wFull.p(6).bgColor("white").border("1px").borderColorIntensity("gray", 200).rounded("lg").Shadow("md")
	c1.shadowColorIntensity("purple", "500").responsivePer("lg", "max-w-md")
	'
	Dim c1h2 As SDUILabel = c1.AddH2("c1h2", "Tailwind CSS Card with Shadow Color")
	c1h2.Root.mb(2).textSize("2xl").fontBold.textColorIntensity("gray", 900).trackingTight
	'
	Dim c1p1 As SDUILabel = c1.AddParagraph("c1p1", "")
	c1p1.Root.textColorIntensity("gray", 700).mb(3).fontNormal.LoremIpsum
	'
	Dim c1btn As SDUILink = c1.AddAnchor("c1btn", "Read more", "#")
	c1btn.Root.inlineFlex.itemsCenter.px(3).py(2).textSize("sm").fontMedium.textCenter.textColor("white")
	c1btn.Root.bgColorIntensity("purple", 700).rounded("lg").hover("bg-purple-800").focus("outline-none")
	'
	Dim co6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("co6", "vb")
	co6.AddCode($"'normal card"$)
	co6.AddCode($"Dim c1 As SDUIDiv = page.Cell(6, 1).AddDiv("c1")"$)
	co6.AddCode($"c1.wFull.p(6).bgColor("white").border("1px").borderColorIntensity("gray", 200).rounded("lg").Shadow("md")"$)
	co6.AddCode($"c1.shadowColorIntensity("purple", "500").responsivePer("lg", "max-w-md")"$)
	co6.AddCode($"'"$)
	co6.AddCode($"Dim c1h2 As SDUILabel = c1.AddH2("c1h2", "Tailwind CSS Card with Shadow Color")"$)
	co6.AddCode($"c1h2.Root.mb(2).textSize("2xl").fontBold.textColorIntensity("gray", 900).trackingTight"$)
	co6.AddCode($"'"$)
	co6.AddCode($"Dim c1p1 As SDUILabel = c1.AddParagraph("c1p1", "")"$)
	co6.AddCode($"c1p1.Root.textColorIntensity("gray", 700).mb(3).fontNormal.LoremIpsum"$)
	co6.AddCode($"'"$)
	co6.AddCode($"Dim c1btn As SDUILink = c1.AddAnchor("c1btn", "Read more", "#")"$)
	co6.AddCode($"c1btn.Root.inlineFlex.itemsCenter.px(3).py(2).textSize("sm").fontMedium.textCenter.textColor("white")"$)
	co6.AddCode($"c1btn.Root.bgColorIntensity("purple", 700).rounded("lg").hover("bg-purple-800").focus("outline-none")"$)
	co6.Refresh
End Sub
