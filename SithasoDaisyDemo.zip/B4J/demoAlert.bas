﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "alerts"
	Public title As String = "Alerts"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	Dim altx As SDUIAlert = page.Cell(1, 1).AddAlert("altx", "12 unread messages. Tap to see.")
	altx.Root.Shadow(app.size_lg)
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim altx As SDUIAlert = page.Cell(1, 1).AddAlert("altx", "12 unread messages. Tap to see.")"$)
	c1.AddCode($"altx.Root.Shadow(app.size_lg)"$)
	c1.Refresh
	'
	Dim btnDeny As SDUIButton = altx.AddActionButton("deny", "Deny", "")
	btnDeny.Ghost
	btnDeny.Size = app.SIZE_SM
		'
	Dim btnAccept As SDUIButton = altx.AddActionButton("accept", "Accept", app.COLOR_PRIMARY)
	btnAccept.Size = app.SIZE_SM
	
	
	Dim altx1 As SDUIAlert = page.Cell(2,1).AddAlert("altx1", "New software update available.")
	altx1.Root.Shadow(app.size_lg)
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"Dim altx1 As SDUIAlert = page.Cell(2,1).AddAlert("altx1", "New software update available.")"$)
	c2.AddCode($"altx1.Root.Shadow(app.size_lg)"$)
	c2.Refresh
	'
	Dim altx2 As SDUIAlert = page.Cell(3,1).AddAlertSuccess("altx2", "Your purchase has been confirmed!")
	altx2.Root.Shadow(app.size_lg)
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim altx2 As SDUIAlert = page.Cell(3,1).AddAlertSuccess("altx2", "Your purchase has been confirmed!")"$)
	c3.AddCode($"altx2.Root.ShadowSize = app.size_lg"$)
	c3.Refresh
	'
	Dim altx3 As SDUIAlert = page.Cell(4,1).AddAlertWarning("altx3", "Invalid email address!")
	altx3.Root.Shadow(app.size_lg)
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim altx3 As SDUIAlert = page.Cell(4,1).AddAlertWarning("altx3", "Invalid email address!")"$)
	c4.AddCode($"altx3.Root.Shadow(app.size_lg)"$)
	c4.Refresh
	'
	Dim altx4 As SDUIAlert = page.Cell(5,1).AddAlertError("altx4", "Task failed successfully!")
	altx4.Root.Shadow(app.size_lg)
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"Dim altx4 As SDUIAlert = page.Cell(5,1).AddAlertError("altx4", "Task failed successfully!")"$)
	c5.AddCode($"altx4.Root.Shadow(app.size_lg)"$)
	c5.Refresh
	'
	Dim ba1 As SDUIAlert = page.Cell(6, 1).AddBigAlert("ba1", "fas fa-pump-soap", "blue", "Wash Hands", _
	SDUIShared.LoremIpsumWords(5), True)
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"Dim ba1 As SDUIAlert = page.Cell(6, 1).AddBigAlert("ba1", "fas fa-pump-soap", "blue", "Wash Hands", _"$)
	c6.AddCode($"SDUIShared.LoremIpsumWords(5), True)"$)
	c6.Refresh
	'
	Dim ba2 As SDUIAlert = page.Cell(7, 1).AddBigAlert("ba2", "fas fa-quote-left", "red", "Congratulations", _
	SDUIShared.LoremIpsumWords(10), False)
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"Dim ba2 As SDUIAlert = page.Cell(7, 1).AddBigAlert("ba2", "fas fa-quote-left", "red", "Congratulations", _"$)
	c7.AddCode($"SDUIShared.LoremIpsumWords(10), False)"$)
	c7.Refresh
	
End Sub
