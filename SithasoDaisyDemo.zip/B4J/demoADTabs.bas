﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adtabs"
	Public title As String = "AD Tabs"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUITabs1 As SDUITabs
	Private SDUITabs2 As SDUITabs
	Private SDUITabs3 As SDUITabs
	Private SDUITabs4 As SDUITabs
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adtabslayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUITabs.SDUITabs1", "SDUITabs1", SDUITabs1.CustProps)
	pgIndex.AddDesignKV1("SDUITabs.SDUITabs2", "SDUITabs2", SDUITabs2.CustProps)
	pgIndex.AddDesignKV1("SDUITabs.SDUITabs3", "SDUITabs3", SDUITabs3.CustProps)
	pgIndex.AddDesignKV1("SDUITabs.SDUITabs4", "SDUITabs4", SDUITabs4.CustProps)

	'build the page, via code or loadlayouts
	banano.LoadLayout(SDUITabs3.Panel(1).Here, "tab1child")
	banano.LoadLayout(SDUITabs3.Panel(2).Here, "tab2child")
	banano.LoadLayout(SDUITabs3.Panel(3).Here, "tab3child")
	'
	SDUITabs3.SetItemBadgeColor(3, app.COLOR_SUCCESS)
	SDUITabs3.SetItemBadgeValue(3, 3)
	
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUITabs3_Change (pos As Int)
	app.ShowSwal(pos)
End Sub

Private Sub SDUITabs2_Change (pos As Int)
	app.ShowSwal(pos)
End Sub

Private Sub SDUITabs1_Change (pos As Int)
	app.ShowSwal(pos)
End Sub