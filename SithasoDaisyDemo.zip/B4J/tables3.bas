﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables3"
	Public title As String = "Table 3"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter"))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user1@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook"))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user1@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp"))
	'
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows2.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table3
	Table3Code
End Sub

Sub Table3Code
	Dim c4 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c4", "vb")
	c4.AddCode($"Sub Build_Table3"$)
	c4.AddCode($"Dim tb3 As SDUITable = page.Cell(5, 1).AddTable("tb3")"$)
	c4.AddCode($"'"$)
	c4.AddCode($"tb3.AddColumn("id", "#")"$)
	c4.AddCode($"tb3.AddColumnAvatarTitleSubTitle("avatar", "Employee", 12, "name", "country", app.MASK_HEXAGON)"$)
	c4.AddCode($"tb3.AddColumnTitleSubTitle("job", "Job", "color")"$)
	c4.AddCode($"tb3.AddColumnRange("hours", "Hours", 8, app.COLOR_ACCENT)"$)
	c4.AddCode($"tb3.AddColumnToggle("on", "Off/On", app.COLOR_PRIMARY, False)"$)
	c4.AddCode($"'"$)
	c4.AddCode($"banano.Await(tb3.SetItemsPaginate(Items))"$)
	c4.AddCode($"Dim rCnt As Int"$)
	c4.AddCode($"For rCnt = 0 To tb3.RowCount - 1"$)
	c4.AddCode($"tb3.SetRowBackgroundColor(rCnt, "red")"$)
	c4.AddCode($"tb3.SetRowTextColor(rCnt, "white")"$)
	c4.AddCode($"Next"$)
	c4.AddCode($"End Sub"$)
	c4.AddCode($"'"$)
	c4.AddCode($"Private Sub tb3_change (Value As Object, Column As String, item As Map)"$)
	c4.AddCode($"Log(Value)"$)
	c4.AddCode($"Log(Column)"$)
	c4.AddCode($"Log(item)"$)
	c4.AddCode($"End Sub"$)
	c4.Refresh
End Sub

Sub Build_Table3
	Dim tb3 As SDUITable = page.Cell(1, 1).AddTable("tb3")
	'
	tb3.AddColumn("id", "#")
	tb3.AddColumnAvatarTitleSubTitle("avatar", "Employee", "4rem", "name", "country", app.MASK_HEXAGON)
	tb3.AddColumnTitleSubTitle("job", "Job", "color")
	tb3.AddColumnRange("hours", "Hours", 8, app.COLOR_ACCENT)
	tb3.AddColumnToggle("on", "Off/On", app.COLOR_PRIMARY, False)
	'
	banano.Await(tb3.SetItemsPaginate(Items))
	'
	Dim rCnt As Int
	
	For rCnt = 0 To tb3.RowCount - 1
		tb3.SetRowBackgroundColor(rCnt, "red")
		tb3.SetRowTextColor(rCnt, "white")
	Next
	
End Sub
'
Private Sub tb3_change (Value As Object, Column As String, item As Map)
	Log(Value)
	Log(Column)
	Log(item)
End Sub