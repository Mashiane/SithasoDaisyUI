﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adfullcalendar"
	Public title As String = "Full Calendar"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private calendar1 As SDUIFullCalendar		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesFullCalendar)
	banano.LoadLayout(app.PageViewer, "adfullcalendarlayout")
	'build the page, via code or loadlayouts
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIFullCalendar.calendar1", "calendar1", calendar1.CustProps)

	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	calendar1.AddEvent("1", "", "All Day Event",  SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-01", "", False, "", "", "", False, True)
	calendar1.AddEvent("2", "", "Long Event", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-07", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-10", False, "", "", "", False, True)
	calendar1.AddEvent("3", "", "Repeating Event", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-09T16:00:00-05:00", "", False, "", "", "", False,True)
	calendar1.AddEvent("4", "", "Conference", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-11", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-13", False, "", "", "", False, True)
	calendar1.AddEvent("5", "", "Meeting", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-12T10:30:00-05:00", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "12T12:30:00-05:00", False, "","", "", False, True)
	calendar1.AddEvent("6", "", "Lunch", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-13T12:00:00-05:00", "", True, "", "", "", False, True)
	calendar1.Refresh
	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub

Private Sub Calendar1_EventClick (args As Map)
	Log("Calendar1_EventClick")
	Log(args)
End Sub

Private Sub Calendar1_EventDrop (args As Map)
	Log("Calendar1_EventDrop")
	Log(args)
End Sub

Private Sub Calendar1_EventResize (args As Map)
	Log("Calendar1_EventResize")
	Log(args)
End Sub

Private Sub Calendar1_Drop (args As Map)
	Log("Calendar1_Drop")
	Log(args)
End Sub

Private Sub Calendar1_DateClick (args As Map)
	Log("Calendar1_DateClick")
	Log(args)
End Sub

Private Sub Calendar1_Select (args As Map)
	Log("Calendar1_Select")
	Log(args)
End Sub

Private Sub calendar1_NextMonth (e As BANanoEvent)
	Log("calendar1_NextMonth")
	Log(calendar1.CurrentStartDate)
	Log(calendar1.CurrentEndDate)
End Sub

Private Sub calendar1_PrevMonth (e As BANanoEvent)
	Log("calendar1_PrevMonth")
	Log(calendar1.CurrentStartDate)
	Log(calendar1.CurrentEndDate)
End Sub

Private Sub calendar1_NextYear (e As BANanoEvent)
	Log("calendar1_NextYear")
	Log(calendar1.CurrentStartDate)
	Log(calendar1.CurrentEndDate)
End Sub

Private Sub calendar1_PrevYear (e As BANanoEvent)
	Log("calendar1_PrevYear")
	Log(calendar1.CurrentStartDate)
	Log(calendar1.CurrentEndDate)
End Sub

'DO NOT TRAP (NextMonth, PrevMonth, NextYear, PrevYear) if you call this event
Private Sub calendar1_DateRangeChange (startDate As String, endDate As String, lastView As String)
	Log("calendar1_DateRangeChange...")
	Log("Range Start: " & startDate)
	Log("Range End: " & endDate)
	Log("Last View: " & lastView)
'	Log("Current Start Date: " & calendar1.CurrentStartDate)
'	Log("Current End Date: " & calendar1.CurrentEndDate)
'	Log("Current Date: " & calendar1.CurrentDate)
End Sub