﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adgrid02"
	Public title As String = "AD Grid 02"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private adgrid01 As SDUIDiv
	Private SDUIDiv1 As SDUIDiv
	Private SDUIDiv2 As SDUIDiv
	Private SDUIDiv3 As SDUIDiv
	Private SDUIList1 As SDUIList
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adgrid02layout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.adgrid01", "adgrid01", adgrid01.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv1", "SDUIDiv1", SDUIDiv1.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv2", "SDUIDiv2", SDUIDiv2.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv3", "SDUIDiv3", SDUIDiv3.CustProps)
	pgIndex.AddDesignKV1("SDUIList.SDUIList1", "SDUIList1", SDUIList1.CustProps)

	'build the page, via code or loadlayouts
	'lets save the element for re-use
	app.AddTemplateFromLayout("sduidiv2", True, Array("sduidiv2", "SDUIDiv3"))
	'get the template
	Dim tmpl As String = app.GetTemplate("sduidiv2")
	Dim x As Int
	For x = 1 To 11
		SDUIList1.Append(tmpl)
	Next
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
