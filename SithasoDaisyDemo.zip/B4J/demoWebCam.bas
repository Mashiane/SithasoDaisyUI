﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "webcampage"
	Public title As String = "WebCam - Code"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private bcScanner As SDUIWebcam
	Private imgPicture As SDUIImage
	Private btnScan As SDUIButton
	Private btnStart As SDUIButton
	Private btnStop As SDUIButton
	Private btnFreeze As SDUIButton
	Private btnUnFreeze As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesWebCam)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows3.AddColumns2x6
	page.Root.AddRows1.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	bcScanner.AddWebCam(Me, page.Cell(1, 1).Name, "webcam1")
	
	btnStart = page.Cell(2, 1).AddButton("btnstart", "Start")
	btnFreeze = page.Cell(2, 1).AddButton("btnfreeze", "Freeze")
	btnUnFreeze = page.Cell(2, 1).AddButton("btnunfreeze", "Un-Freeze")
	btnScan = page.Cell(2, 1).AddButton("btnscan", "Take Picture")
	btnStop = page.Cell(2, 1).AddButton("btnstop", "Stop")
	
	imgPicture = page.Cell(3, 1).AddImage("cam1", app.ImgHolder, "", "200px", "200px")
	'
	page.Cell(1, 1).CenterChildren
	page.Cell(2, 1).justifyAround.flex.flexWrap.gap(1)
	page.Cell(3, 1).CenterChildren
	'
	Dim c1 As SDUIMockupCode = page.Cell(4, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"bcScanner = page.Cell(1, 1).AddWebCam("webcam1")"$)
	c1.AddCode($"btnStart = page.Cell(2, 1).AddButton("btnstart", "Start")"$)
	c1.AddCode($"btnFreeze = page.Cell(2, 1).AddButton("btnfreeze", "Freeze")"$)
	c1.AddCode($"btnUnFreeze = page.Cell(2, 1).AddButton("btnunfreeze", "Un-Freeze")"$)
	c1.AddCode($"btnScan = page.Cell(2, 1).AddButton("btnscan", "Take Picture")"$)
	c1.AddCode($"btnStop = page.Cell(2, 1).AddButton("btnstop", "Stop")"$)
	c1.AddCode($"imgPicture = page.Cell(3, 1).AddImage("cam1", app.ImgHolder, "", "200px", "200px")"$)
	c1.AddCode($"''"$)
	c1.AddCode($"page.Cell(1, 1).CenterChildren"$)
	c1.AddCode($"page.Cell(2, 1).justifyAround.flex.flexWrap.gap(1)"$)
	c1.AddCode($"page.Cell(3, 1).CenterChildren"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnstop_click (e As BANanoEvent)"$)
	c1.AddCode($"bcScanner.StopWebCam"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnfreeze_click (e As BANanoEvent)"$)
	c1.AddCode($"bcScanner.freeze"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnunfreeze_click (e As BANanoEvent)"$)
	c1.AddCode($"bcScanner.UnFreeze"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnstart_click (e As BANanoEvent)"$)
	c1.AddCode($"bcScanner.StartWebCam"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Sub btnscan_click (e As BANanoEvent)"$)
	c1.AddCode($"bcScanner.TakePicture"$)
	c1.AddCode($"End Sub"$)
	c1.AddCode($"'"$)
	c1.AddCode($"Private Sub webcam1_SnapSuccess (data_URI As String)"$)
	c1.AddCode($"imgPicture.Src = data_URI"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
End Sub

Sub btnstop_click (e As BANanoEvent)
	bcScanner.StopWebCam
End Sub

Sub btnfreeze_click (e As BANanoEvent)
	bcScanner.freeze
End Sub

Sub btnunfreeze_click (e As BANanoEvent)
	bcScanner.UnFreeze
End Sub

Sub btnstart_click (e As BANanoEvent)
	bcScanner.StartWebCam
End Sub

Sub btnscan_click (e As BANanoEvent)
	bcScanner.TakePicture
End Sub

Private Sub webcam1_SnapSuccess (data_URI As String)
	imgPicture.Src = data_URI
End Sub
