﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "flatpicker"
	Public title As String = "FlatPick Date"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtFlickDate As SDUITextBox
	Private txtFlickTime As SDUITextBox
	Private txtFlickDateTime As SDUITextBox
	Private txtFlickDateTimeWeeks As SDUITextBox
	Private txtFlickDaterange As SDUITextBox
	Private txtFlickDateMultiple As SDUITextBox
	Private txtFlickDate7 As SDUITextBox
	Private btnGetDate As SDUIButton
	Private btnSetDate As SDUIButton
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesFlatPickDateTime)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
		
	txtFlickDate = page.Cell(2, 1).AddFlatPickDateTime("flatpickdate1", "Flat Pick Date", "", "", "", False)
	txtFlickDate.Size = txtFlickDate.SizeSM
	txtFlickDate.Color = app.COLOR_PRIMARY
	txtFlickDate.RefreshDateTimePicker
	
	txtFlickDateTime = page.Cell(3, 1).AddFlatPickDateTime("flatpickdate2", "Flat Pick Date Time", "", "", "", True)
	txtFlickTime = page.Cell(4, 1).AddDateTimePicker("flatpickdate3", "Flat Pick Time", "", "", "", True, "H:i", "none", False, "", True, False)
	
	txtFlickDateTimeWeeks = page.Cell(5, 1).AddDateTimePicker("flatpickdate4", "Flat Pick Date/Time Weeks", "", "", "", True, "Y-m-d H:i", "", False, "", False, True)
	txtFlickDaterange = page.Cell(6, 1).AddDateTimePicker("flatpickdate5", "Flat Pick Date Range", "", "", "", False, "Y-m-d", "Range", False, "", False, False)
	txtFlickDateMultiple = page.Cell(7, 1).AddDateTimePicker("flatpickdate6", "Flat Pick Date Multiple", "", "", "", False, "Y-m-d", "multiple", True, "Y-m-d", False, False)
	txtFlickDate7 = page.Cell(8,1).AddDateTimePicker1("flatpickdate7", "Flat Pick Date Locale", "", "", "", True, "Y-m-d H:i", "none", True, "F j, Y H:i", False, False, "es")
	
	btnGetDate = page.Cell(1, 1).AddButtonLabel("btnget", "Get Date")
	btnSetDate = page.Cell(1, 2).AddButtonLabel("btnset", "Set Random Date")
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"txtFlickDate = page.Cell(2, 1).AddFlatPickDateTime("flatpickdate1", "Flat Pick Date", "", "", "", False)"$)
	c2.AddCode($"txtFlickDate.Size = txtFlickTime.SizeSM"$)
	c2.AddCode($"txtFlickDate.Color = app.COLOR_PRIMARY"$)
	c2.AddCode($"txtFlickDate.RefreshDateTimePicker"$)
	c2.Refresh
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"txtFlickDateTime = page.Cell(3, 1).AddFlatPickDateTime("flatpickdate2", "Flat Pick Date Time", "", "", "", True)"$)
	c3.Refresh
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"txtFlickTime = page.Cell(4, 1).AddDateTimePicker("flatpickdate3", "Flat Pick Time", "", "", "", True, "H:i", "", False, "", True, False)"$)
	c4.Refresh
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"txtFlickDateTimeWeeks = page.Cell(5, 1).AddDateTimePicker("flatpickdate4", "Flat Pick Date/Time Weeks", "", "", "", True, "Y-m-d H:i", "", False, "", False, True)"$)
	c5.Refresh
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"txtFlickDaterange = page.Cell(6, 1).AddDateTimePicker("flatpickdate5", "Flat Pick Date Range", "", "", "", False, "Y-m-d", "Range", False, "", False, False)"$)
	c6.Refresh
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"txtFlickDateMultiple = page.Cell(7, 1).AddDateTimePicker("flatpickdate6", "Flat Pick Date Multiple", "", "", "", False, "Y-m-d", "multiple", True, "Y-m-d", False, False)"$)
	c7.Refresh
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"txtFlickDate7 = page.Cell(8, 1).AddDateTimePicker1("flatpickdate7", "Flat Pick Date Locale", "", "", "", True, "Y-m-d H:i", "none", True, "F j, Y H:i", False, False, "es")"$)
	c8.Refresh
	
	
End Sub

Sub btnget_click (e As BANanoEvent)
	Dim sdate As String = txtFlickDate.Value
	app.ShowSwalInfo(sdate)
	txtFlickDate.HintCaption = txtFlickDate.Value
	txtFlickTime.HintCaption = txtFlickTime.Value
	txtFlickDateTime.HintCaption = txtFlickDateTime.Value
	txtFlickDateTimeWeeks.HintCaption = txtFlickDateTimeWeeks.Value
	txtFlickDaterange.HintCaption = txtFlickDaterange.Value
	txtFlickDateMultiple.HintCaption = txtFlickDateMultiple.Value
	txtFlickDate7.HintCaption = txtFlickDate7.Value
End Sub


Sub btnset_click (e As BANanoEvent)
	Dim dd As String = Rnd(1, 365)
	Dim nd As String = SDUIShared.DateOnDaysFromToday(dd)
	txtFlickDate.Value = nd
End Sub