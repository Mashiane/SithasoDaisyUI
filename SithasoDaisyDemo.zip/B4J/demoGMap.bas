﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "gmap1"
	Public title As String = "GMap"
	Public icon As String = "fa-solid fa-pager"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIGMap1 As SDUIGMap			'ignore
	Private btnGeocode As SDUIButton
	Private SDUICol1 As SDUICol
	Private SDUIRow1 As SDUIRow
	Private SDUIButton1 As SDUIButton
	Private SDUIButton1 As SDUIButton
	Private btnGeoLocate As SDUIButton
	Private btnOverlay As SDUIButton
	Private SDUICol5 As SDUICol
	Private SDUIGMap2 As SDUIGMap
	Private SDUIRow2 As SDUIRow
	Private btnRenderroute As SDUIButton
	Private SDUICol6 As SDUICol
	Private directions As SDUIDiv
	Private SDUICol7 As SDUICol
	Private SDUIRow3 As SDUIRow
	Private btntravelRoute As SDUIButton
	Private SDUICol8 As SDUICol
	Private btnDrawRoute As SDUIButton
	Private SDUICol9 As SDUICol
	Private btnGetRoutes As SDUIButton
	Private SDUICol10 As SDUICol
End Sub

#if css
	.overlay {
		border: 1px solid #b71c1c;
		background: #d50000;
		padding: 5px;
		font-size: 17px;
		color: white;
	}
#End If

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'load the page layout to the pageviewer
	banano.LoadLayout(app.PageViewer, "gmap1layout")
	'SDUIGMap1.addLayer("weather", True)
	SDUIGMap1.addLayer("traffic", True)
	'SDUIGMap1.addLayer("transit", True)
	'SDUIGMap1.addLayer("bicycling", True)
	'SDUIGMap1.addLayer("clouds", True)
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	SDUIGMap1.AddMarker("m1", -12.043333, -77.03, "Lima", "", "red")
	SDUIGMap1.AddMarker("m2", -12.042, -77.028333, "Marker with InfoWindow", "<p>HTML Content</p>", "blue")
	SDUIGMap1.drawCircle("c1", -12.040504866577001, -77.02024422636042, 350, "#432070", 1, 3, "#432070", 0.6, True, True)
	'SDUIGMap1.AddRectangle("r1", -12.030397656836609,-77.02373871559225, -12.034804866577001,-77.01154422636042, "#BBD8E9", 1, 3, "#BBD8E9", 0.6)
	'
	SDUIGMap1.AddPolygon("p1", "#25D359", 1, 3, "#25D359", 0.6, False, False)
	SDUIGMap1.AddPolygonLatLng("p1", -12.040397656836609, -77.03373871559225)
	SDUIGMap1.AddPolygonLatLng("p1", -12.040248585302038, -77.03993927003302)
	SDUIGMap1.AddPolygonLatLng("p1", -12.050047116528843, -77.02448169303511)
	SDUIGMap1.AddPolygonLatLng("p1", -12.044804866577001, -77.02154422636042)
	'
	
	SDUIGMap1.AddPolyLine("pl1", "#131540", 0.6, 6, False, False)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.044012922866312, -77.02470665341184)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.05449279282314, -77.03024273281858)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.055122327623378, -77.03039293652341)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.075917129727586, -77.02764635449216)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.07635776902266, -77.02792530422971)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.076819390363665, -77.02893381481931)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.088527520066453, -77.0241058385925)
	SDUIGMap1.AddPolyLineLatLng("pl1", -12.090814532191756, -77.02271108990476)
	'
	SDUIGMap1.ReDraw
End Sub


Private Sub SDUIGMap1_Ready (e As BANanoEvent)
	Log("SDUIGMap1_Ready")
End Sub

Private Sub SDUIGMap1_Click (e As BANanoEvent)
	Log(e)
End Sub

Private Sub SDUIGMap1_MarkerClick (e As BANanoEvent)
	Log("SDUIGMap1_MarkerClick")
	Log(e)
End Sub

Private Sub SDUIGMap1_CircleClick (e As BANanoEvent)
	Log("SDUIGMap1_CircleClick")
End Sub

Private Sub SDUIGMap1_PolygonClick (e As BANanoEvent)
	Log("SDUIGMap1_PolygonClick")
End Sub

Private Sub SDUIGMap1_PolyLineClick (e As BANanoEvent)
	Log("SDUIGMap1_PolyLineClick")
End Sub

Private Sub SDUIGMap1_RectangleClick (e As BANanoEvent)
	Log("SDUIGMap1_RectangleClick")
End Sub

Private Sub btnGeocode_Click (e As BANanoEvent)
	SDUIGMap1.geocode("Stonehenge, United Kingdom")
End Sub

Private Sub SDUIGMap1_Geocode (results As List, status As String)
	If status = "OK" Then
		Dim location As GMapLatLng = SDUIGMap1.GetGeoCodeLatLng(results, 0)
		SDUIGMap1.removeMarker("st")
		SDUIGMap1.AddMarker("st", location.lat, location.lng, "Stonehenge, United Kingdom", "", "green")
		SDUIGMap1.setCenter(location.lat, location.lng)
	Else
		app.ShowSwal("No location found!")
	End If
End Sub

Private Sub SDUIButton1_Click (e As BANanoEvent)
	SDUIGMap1.removeMarker("et")
	SDUIGMap1.AddMarker1("et", 48.8583701, 2.2944813, "", "<h4>Eiffel Tower</h4><div>Paris, France</div>", 100, "", 0, 0)
	SDUIGMap1.setCenter(48.8583701, 2.2944813)
End Sub


Private Sub SDUIGMap1_GeoLocateSuccess (position As Map)
	Log("SDUIGMap1_GeoLocateSuccess")
	Dim location As GMapLatLng = SDUIGMap1.GetGeoLocateLatLng(position)
	SDUIGMap1.removeMarker("mp")
	SDUIGMap1.AddMarker1("mp", location.lat, location.lng, "My Location", "", 0, "./assets/sponge.png", 32, 32)
	SDUIGMap1.setCenter(location.lat, location.lng)
End Sub

Private Sub SDUIGMap1_GeoLocateError (error As Map)
	Log("SDUIGMap1_GeoLocateError")
	Log(error)
End Sub

Private Sub SDUIGMap1_GeoLocateNotSupported
	Log("SDUIGMap1_GeoLocateNotSupported")
End Sub

'Private Sub SDUIGMap1_GeoLocateAlways
'	Log("SDUIGMap1_GeoLocateAlways")
'End Sub

Private Sub btnGeoLocate_Click (e As BANanoEvent)
	SDUIGMap1.GeoLocate
End Sub

Private Sub btnOverlay_Click (e As BANanoEvent)
	SDUIGMap1.removeOverlay("ov1")
	SDUIGMap1.drawOverlay("ov1", 27.1733151, 78.0409684, $"<div class='overlay'>Taj Mahal</div>"$, "top", -40, 0, 0)
	SDUIGMap1.setCenter(27.1733151, 78.0409684)
End Sub

Private Sub SDUIGMap2_Ready (e As BANanoEvent)
	
End Sub

Private Sub btnrenderRoute_Click (e As BANanoEvent)
	SDUIGMap1.Clear
	SDUIGMap1.renderRoute("directions", -12.044012922866312, -77.02470665341184, -12.090814532191756, -77.02271108990476, "driving", "#131540", 0.6, 6)
End Sub

Private Sub SDUIGMap1_Routes (results As List)
	Log(results)
	'Dim r As Object = results.Get(0)
	'Dim x As BANanoObject = SDUIGMap1.AddRoute(r, "#336699", 0.5, 10)
	'SDUIGMap1.setCenter(-33.040251, 27.851291)
	'Log(x)
End Sub

Private Sub btntravelRoute_Click (e As BANanoEvent)
	SDUIGMap1.Clear
	SDUIGMap1.travelRoute(-12.044012922866312, -77.02470665341184, -12.090814532191756, -77.02271108990476, "driving")
End Sub

Private Sub SDUIGMap1_TravelStep (r As Map)
	Log(r)
End Sub

Private Sub btnDrawRoute_Click (e As BANanoEvent)
	SDUIGMap1.Clear
	SDUIGMap1.drawRoute(-12.044012922866312, -77.02470665341184, -12.090814532191756, -77.02271108990476, "driving", "#131540", 0.6, 6)
	SDUIGMap1.setCenter(-12.044012922866312, -77.02470665341184)
End Sub

Private Sub btnGetRoutes_Click (e As BANanoEvent)
	SDUIGMap1.Clear
	SDUIGMap1.getRoutes(-12.044012922866312, -77.02470665341184, -12.090814532191756, -77.02271108990476)
End Sub