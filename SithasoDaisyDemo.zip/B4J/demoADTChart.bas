﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adtchart"
	Public title As String = "AD Toast Chart"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	
	Private SDUIToastChart1 As SDUIToastChart
	Private SDUIToastChart2 As SDUIToastChart
	Private SDUIToastChart3 As SDUIToastChart
	Private SDUIToastChart4 As SDUIToastChart
	Private SDUIToastChart5 As SDUIToastChart
	Private SDUIToastChart6 As SDUIToastChart
	Private SDUIToastChart7 As SDUIToastChart
	Private SDUIToastChart8 As SDUIToastChart
	Private SDUIToastChart9 As SDUIToastChart
	Private SDUIToastChart10 As SDUIToastChart
	Private SDUIToastChart11 As SDUIToastChart
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesToastChart)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adtchartlayout")
	SDUIToastChart1.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart1.AddSeries("Budget", Array(5000, 3000, 5000, 7000, 6000, 4000, 1000))
	SDUIToastChart1.AddSeries("Income", Array(8000, 4000, 7000, 2000, 6000, 3000, 5000))
	SDUIToastChart1.AddSeries("Expenses", Array(4000, 4000, 6000, 3000, 4000, 5000, 7000))
	SDUIToastChart1.AddSeries("Debt", Array(3000, 4000, 3000, 1000, 2000, 4000, 3000))
	SDUIToastChart1.Refresh
	'
	SDUIToastChart2.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart2.AddSeries("Budget", Array(5000, 3000, 5000, 7000, 6000, 4000, 1000))
	SDUIToastChart2.AddSeries("Income", Array(8000, 4000, 7000, 2000, 6000, 3000, 5000))
	SDUIToastChart2.AddSeries("Expenses", Array(4000, 4000, 6000, 3000, 4000, 5000, 7000))
	SDUIToastChart2.AddSeries("Debt", Array(3000, 4000, 3000, 1000, 2000, 4000, 3000))
	SDUIToastChart2.Refresh
	'
	SDUIToastChart3.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart3.AddSeries("Elviations", Array(-5000, -3000, -6000, -3000, -6000, -4000))
	SDUIToastChart3.AddSeries("Junglectics", Array(-8000, -1000, -7000, -2000, -5000, -3000))
	SDUIToastChart3.AddSeries("Amazonforce", Array(-900, -6000, -1000, -9000, -3000, -1000))
	SDUIToastChart3.Refresh
	'
	SDUIToastChart4.AddCategories(Array("01/01/2020", "02/01/2020", "03/01/2020", "04/01/2020", "05/01/2020", "06/01/2020", "07/01/2020", "08/01/2020", "09/01/2020", "10/01/2020", "11/01/2020", "12/01/2020"))
	'
	SDUIToastChart4.AddSeries("Seoul", Array(-3.5, -1.1, 4.0, 11.3, 17.5, 21.5, 25.9, 27.2, 24.4, 13.9, 6.6, -0.6))
	SDUIToastChart4.AddSeries("Seattle", Array(3.8, 5.6, 7.0, 9.1, 12.4, 15.3, 17.5, 17.8, 15.0, 10.6, 6.6, 3.7))
	SDUIToastChart4.AddSeries("Sydney", Array(22.1, 22.0, 20.9, 18.3, 15.2, 12.8, 11.8, 13.0, 15.2, 17.6, 19.4, 21.2))
	SDUIToastChart4.AddSeries("Moscow", Array(-10.3, -9.1, -4.1, 4.4, 12.2, 16.3, 18.5, 16.7, 10.9, 4.2, -2.0, -7.5))
	SDUIToastChart4.AddSeries("Jungfrau", Array(-13.2, -13.7, -13.1, -10.3, -6.1, -3.2, 0.0, -0.1, -1.8, -4.5, -9.0, -10.9))
	SDUIToastChart4.Refresh
	'
	SDUIToastChart5.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov"))
	SDUIToastChart5.AddSeries("Budget", Array(5000, 3000, 5000, 7000, 6000, 4000))
	SDUIToastChart5.AddSeries("Income", Array(8000, 4000, 7000, 2000, 6000, 3000))
	SDUIToastChart5.AddSeries("Expenses", Array(4000, 4000, 6000, 3000, 4000, 5000))
	SDUIToastChart5.Refresh
	'
	SDUIToastChart6.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart6.AddSeries("Budget", Array(5000, 3000, 5000, 7000, 6000, 4000, 1000))
	SDUIToastChart6.AddSeries("Income", Array(8000, 4000, 7000, 2000, 6000, 3000, 5000))
	SDUIToastChart6.AddSeries("Expenses", Array(4000, 4000, 6000, 3000, 4000, 5000, 7000))
	SDUIToastChart6.AddSeries("Debt", Array(3000, 4000, 3000, 1000, 2000, 4000, 3000))
	SDUIToastChart6.Refresh
	'
	SDUIToastChart7.AddCategories(Array("Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart7.AddSeries("Budget", Array(5000, 3000, 5000, 7000, 6000, 4000, 1000))
	SDUIToastChart7.AddSeries("Income", Array(8000, 4000, 7000, 2000, 6000, 3000, 5000))
	SDUIToastChart7.AddSeries("Expenses", Array(4000, 4000, 6000, 3000, 4000, 5000, 7000))
	SDUIToastChart7.AddSeries("Debt", Array(3000, 4000, 3000, 1000, 2000, 4000, 3000))
	SDUIToastChart7.Refresh
	'
	SDUIToastChart8.AddCategories(Array("Browser"))
	SDUIToastChart8.AddSeriesValue("Chrome", 46.02)
	SDUIToastChart8.AddSeriesValue("IE", 20.47)
	SDUIToastChart8.AddSeriesValue("Firefox", 17.71)
	SDUIToastChart8.AddSeriesValue("Safari", 5.45)
	SDUIToastChart8.AddSeriesValue("Opera", 3.1)
	SDUIToastChart8.AddSeriesValue("Etc", 7.25)
	SDUIToastChart8.Refresh
	'
	SDUIToastChart9.AddCategories(Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart9.AddSeries("Seoul", Array(20, 40, 25, 50, 15, 45, 33, 34, 20, 30, 22, 13))
	SDUIToastChart9.AddSeries("Sydney", Array(5, 30, 21, 18, 59, 50, 28, 33, 7, 20, 10, 30))
	SDUIToastChart9.AddSeries("Moscow", Array(30, 5, 18, 21, 33, 41, 29, 15, 30, 10, 33, 5))
	SDUIToastChart9.Refresh
	'
	SDUIToastChart10.AddCategories(Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
	SDUIToastChart10.AddSeries("Seoul", Array(20, 40, 25, 50, 15, 45, 33, 34, 20, 30, 22, 13))
	SDUIToastChart10.AddSeries("Sydney", Array(5, 30, 21, 18, 59, 50, 28, 33, 7, 20, 10, 30))
	SDUIToastChart10.AddSeries("Moscow", Array(30, 5, 18, 21, 33, 41, 29, 15, 30, 10, 33, 5))
	SDUIToastChart10.Refresh
	'
	SDUIToastChart11.AddCategories(Array("Korea", "United States", "Germany", "Canada", "Austria"))
	SDUIToastChart11.AddSeries("Gold medals", Array(132, 105, 92, 73, 64))
	SDUIToastChart11.AddSeries("Silver medals", Array(125, 110, 86, 64, 81))
	SDUIToastChart11.AddSeries("Bronze medals", Array(111, 90, 60, 62, 87))
	SDUIToastChart11.Refresh
		
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub
