﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "rolldates"
	Public title As String = "Roll Date"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesRollDate)
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim dt1Options As RollDateOptions = app.InitRollDateTime
	dt1Options.beginYear = 2000
	dt1Options.endYear = 2100
	dt1Options.DateTimeFormat = "YYYY-MM-DD"
	Dim dt1 As SDUITextBox = page.Cell(1, 1).AddRollDateTime("dt1", "Date of Birth", "", "", "", dt1Options)
	dt1.Placeholder = "YYYY-MM-DD"
	'
	Dim dt2Options As RollDateOptions = app.InitRollDateTime
	dt2Options.DateTimeFormat = "hh:mm"
	dt2Options.MinStep = 5
	dt2Options.Title = "Select Time"
	Dim dt2 As SDUITextBox = page.Cell(2, 1).AddRollDateTime("dt2", "Time of Birth", "", "", "", dt2Options)
	dt2.Placeholder = "HH:MM"
	
End Sub

Private Sub dt1_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub dt1_CancelDate (event As BANanoEvent)
	Log("dt1_CancelDate")
End Sub

Private Sub dt2_ConfirmDate (dateChosen As Object)
	Log(dateChosen)
End Sub

Private Sub dt2_CancelDate (event As BANanoEvent)
	Log("dt2_CancelDate")
End Sub