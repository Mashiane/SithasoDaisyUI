﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "mockwindow"
	Public title As String = "Mock Window"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Dim mockWin As SDUIMockupWindow
	mockWin.AddMockUpWindow(Me, page.CellID(1,1), "mockwin")
	mockWin.Root.Border("1px")
	mockWin.Root.BorderColorIntensity("base", 300)
	'
	mockWin.Container.Flex
	mockWin.Container.JustifyCenter
	mockWin.Container.PX(4)
	mockWin.Container.PY(16)
	mockWin.Container.BorderT("")
	mockWin.Container.BorderColorIntensity("base", 300)
	'
	mockWin.Container.Caption = "Hello Sithaso Daisy"
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"Dim mockWin As SDUIMockupWindow"$)
	c1.AddCode($"mockWin.AddMockUpWindow(Me, page.CellID(1,1), "mockwin")"$)
	c1.AddCode($"mockWin.Root.Border"$)
	c1.AddCode($"mockWin.Root.BorderBase = 300"$)
	c1.AddCode($"'"$)
	c1.AddCode($"mockWin.Container.Root.Flex"$)
	c1.AddCode($"mockWin.Container.Root.JustifyCenter"$)
	c1.AddCode($"mockWin.Container.Root.PX = 4"$)
	c1.AddCode($"mockWin.Container.Root.PY = 16"$)
	c1.AddCode($"mockWin.Container.Root.BorderT("")"$)
	c1.AddCode($"mockWin.Container.Root.BorderBase = 300"$)
	c1.AddCode($"'"$)
	c1.AddCode($"mockWin.Container.Caption = "Hello Sithaso Daisy""$)
	c1.Refresh
End Sub
