﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adoptionscard"
	Public title As String = "AD Options Card"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIOptionsCard1 As SDUIOptionsCard
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adoptionscardlayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIOptionsCard.SDUIOptionsCard1", "SDUIOptionsCard1", SDUIOptionsCard1.CustProps)

	'
	SDUIOptionsCard1.AddItem("b4a", "b4a", "Create Android Apps", "./assets/banner_4.jpg")
	SDUIOptionsCard1.AddItem("b4j", "b4j", "Create Desktop Apps", "./assets/login-bg.jpg")
	SDUIOptionsCard1.AddItem("b4r", "b4r", "Create Arduino Apps", "./assets/banner_1.jpg")
	SDUIOptionsCard1.AddItem("b4i", "b4i", "Create iOS Apps", "./assets/img_1.jpg")
	
	BuildPage
End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub

Private Sub SDUIOptionsCard1_Change (item As String)
	app.ShowSwal(item)	
End Sub