﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adkmlmerge"
	Public title As String = "AD KML Merge"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIFileInput1 As SDUIFileInput
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adkmlmergelayout")
	'build the page, via code or loadlayouts
	BuildPage
	Log(banano.Window)
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub

Sub SDUIFileInput1_change(e As BANanoEvent)
	'has the files been selected
	Dim fileList As List = SDUIFileInput1.GetFiles
	'
	Dim kmlNodes As List
	kmlNodes.Initialize
	'
	Dim JQ As BANanoObject
	JQ.Initialize("$")
	'
	If banano.IsNull(fileList) Or banano.IsUndefined(fileList) Then Return
	'loop through each selected file
	For Each fileObj As Map In fileList
		'get the file contents without upload
		Dim fileContents As String = banano.Await(SDUIShared.GetFileAsText(fileObj))
		'
		Dim pOptions As Map = CreateMap()
		pOptions.Put("ignoreAttributes", False)
		pOptions.Put("allowBooleanAttributes", True)
		pOptions.Put("preserveOrder", True)
		pOptions.Put("attributeNamePrefix", "@_")
		'
		Dim parser As BANanoObject
		parser.Initialize2("XMLParser", pOptions)
		Dim nodes As List = parser.RunMethod("parse", fileContents)
		Dim kml As List = nodes.Get(1).As(Map).Get("kml")
		Dim root As Map = kml.Get(0)
		'get the document id
		Dim id As String = SDUIShared.GetRecursive(root, ":@.@_id")
		Log(id)
		'get the root document to find Placemarks
		Dim docs As List = root.Get("Document")
		'loop through each placemark
		For Each placemarkM As Map In docs
			If placemarkM.ContainsKey("Placemark") Then
				Dim pid As String = SDUIShared.GetRecursive(placemarkM, ":@.@_id")
				Log(pid)
				Dim Placemark As List = placemarkM.Get("Placemark")
				For Each child As Map In Placemark
					
					
				Next
				Log(Placemark)
			End If
		Next
		Continue
		
		
		
'		'jquery parseXML
'		Dim xmlDoc As BANanoObject = JQ.RunMethod("parseXML", fileContents)
'		'the root is the document
'		Dim doc As BANanoObject = JQ.Selector(xmlDoc).RunMethod("find", "Document")
'		'get the first element
'		Dim xmlNode As BANanoObject = doc.As(List).Get(0).As(BANanoObject)
'		Log(xmlNode)
'		'get the document id, we need to place it in each placemark
'		Dim docID As String = xmlNode.RunMethod("getAttribute", "id").Result
'		'get all the placemarks
'		Dim Placemarks As BANanoObject = JQ.Selector(xmlDoc).RunMethod("find", "Placemark")
'		Dim places As List = Placemarks.As(List)
'		Dim pCnt As Int = 0
'		For Each place As BANanoObject In places
'			'pCnt = pCnt + 1
'			'If pCnt = 11 Then Exit
'			'get the id of the placemark
'			Dim pmID As String = place.RunMethod("getAttribute", "id").Result
'			Log(pmID)
'			
'			'Log(pmID)
'			'Log(place)
'			'Dim placeName As BANanoObject = place.RunMethod("find", "name")
'			'Log(placeName)
'		Next
''		
'		Dim pmTot As Int = Placemarks.As(List).Size - 1
'		Dim pmCnt As Int = 0
'		For pmCnt = 0 To pmTot
'			Dim pm As BANanoObject = Placemarks.As(List).Get(pmCnt).As(BANanoObject)
'			Dim pmID As String = pm.RunMethod("getAttribute", "id").Result
'			Log(pmID)
'		Next
		
		'Log(pm)
		
		'Dim pms As List = pm.As(List)
		'Log(pms)
		'For Each place As BANanoObject In pms
		'	Log(place)
			'Dim placeName As String = place.RunMethod("getAttribute", "name").Result
			'Log(placeName)
		'Next
		
		'Dim kml As BANanoObject = doc.RunMethod("contents", Null)
		'kmlNodes.Add(kml)
	Next
	'
	Dim kmlTemplate As BANanoObject = JQ.RunMethod("parseXML", $"<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document></Document></kml>"$)
	'
	For Each kmlContents As Object In kmlNodes
		JQ.Selector(kmlTemplate).RunMethod("find", "Document").RunMethod("append", kmlContents)
	Next
	'
	Dim xmlSerializer As BANanoObject
	xmlSerializer.Initialize2("XMLSerializer", Null)
	'
	Dim mergedKml As BANanoObject = xmlSerializer.RunMethod("serializeToString", kmlTemplate)
	'
	Dim fileName As String = "mergedKML_" & SDUIShared.DateTimeNowBackUp & ".kml"
	'
	'SDUIShared.DownloadText2File(mergedKml, fileName)
	
End Sub