﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "loginpage"
	Public title As String = "Login"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	'
	Private mdlLogin As SDUIModal
	Private txtEmail As SDUITextBox
	Private txtpassword As SDUITextBox
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns12
	'build the grid
	page.Root.BuildGrid
	Dim rCnt As Int
	For rCnt = 1 To 5
		page.Cell(rCnt, 1).py(0)
	Next
	
	'add a modal to the page
	mdlLogin = page.Root.AddModal( "mdllogin", "Sign In", "Login", "Cancel", "", "500px")
	'build the grid for the modal
	'*IMPORTANT
	mdlLogin.Form.AddRows2.AddColumns12
	mdlLogin.Form.BuildGrid
	mdlLogin.Form.Shrink
	
	'add the components
	txtEmail = mdlLogin.Cell(1, 1).AddEmail("txtemail", "Email", "Enter email address")
	txtEmail.AutoComplete = False
	txtEmail.Required = True
	'
	txtpassword = mdlLogin.Cell(2, 1).AddPassword("txtpassword", "Password", "Enter password", True)
	txtpassword.AutoComplete = False
	txtpassword.Required = True
	'
	mdlLogin.Show
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Private mdlLogin As SDUIModal"$)
	c1.AddCode($"Private txtEmail As SDUITextBox"$)
	c1.AddCode($"Private txtpassword As SDUITextBox"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"mdlLogin = page.root.AddModal("mdllogin", "Sign In", "Login", "Cancel", "", "500px")"$)
	c2.AddCode($"'build the grid for the modal"$)
	c2.AddCode($"'*IMPORTANT"$)
	c2.AddCode($"mdlLogin.Container.AddRows2.AddColumns12"$)
	c2.AddCode($"mdlLogin.Container.BuildGrid"$)
	c2.AddCode($"'add the components"$)
	c2.AddCode($"txtEmail = mdlLogin.Cell(1, 1).AddEmail("txtemail", "Email", "Enter email address")"$)
	c2.AddCode($"txtEmail.AutoComplete = False"$)
	c2.AddCode($"txtEmail.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"txtpassword = mdlLogin.Cell(2, 1).AddPassword("txtpassword", "Password", "Enter password", True)"$)
	c2.AddCode($"txtpassword.AutoComplete = False"$)
	c2.AddCode($"txtpassword.Required = True"$)
	c2.AddCode($"'"$)
	c2.AddCode($"mdlLogin.Show"$)
	c2.Refresh
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Private Sub mdllogin_Yes_Click (e As BANanoEvent)"$)
	c3.AddCode($"If txtEmail.IsBlank Then Return"$)
	c3.AddCode($"If txtpassword.IsBlank Then Return"$)
	c3.AddCode($"'"$)
	c3.AddCode($"Dim record As Map = CreateMap()"$)
	c3.AddCode($"record.Put("email", txtEmail.Value)"$)
	c3.AddCode($"record.Put("password", txtpassword.Value)"$)
	c3.AddCode($"Log(record)"$)
	c3.AddCode($"'mdlLogin.Hide"$)
	c3.AddCode($"End Sub"$)
	c3.AddCode($"Private Sub mdllogin_No_Click (e As BANanoEvent)"$)
	c3.AddCode($"mdlLogin.Hide"$)
	c3.AddCode($"End Sub"$)
	c3.AddCode($"Private Sub txtpassword_Append_Click (event As BANanoEvent)"$)
	c3.AddCode($"txtpassword.toggleEyes"$)
	c3.AddCode($"End Sub"$)
	c3.Refresh
End Sub

Private Sub mdllogin_Yes_Click (e As BANanoEvent)
	If txtEmail.IsBlank Then Return
	If txtpassword.IsBlank Then Return
	'
	Dim record As Map = CreateMap()
	record.Put("email", txtEmail.Value)
	record.Put("password", txtpassword.Value)
	Log(record)
	
	'mdlLogin.Hide
End Sub

Private Sub mdllogin_No_Click (e As BANanoEvent)
	mdlLogin.Hide
End Sub

Private Sub txtpassword_Append_Click (event As BANanoEvent)
	txtpassword.toggleEyes
End Sub