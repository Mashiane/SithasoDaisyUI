﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "bottomnav"
	Public title As String = "Bottom Navigation"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private bn1 As SDUIBottomNav
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	Log("bnav show...")
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	'page.Root.DesignMode(False)
	'center the page container
	'page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	'page.Root.AddRows5.AddColumns12
	'build the grid
	'page.Root.BuildGrid
	'start adding you components here
	'	
	pgIndex.drawer.AdjustClippedLeft(True)
	bn1.AddBottomNav(Me, pgIndex.drawer.ContentID, "bn1")
	bn1.BGColorIntensity("gray", "200")
	'bn1.Bordered = True
	bn1.AddItemBadge("home", "fa-solid fa-house", "Home", app.COLOR_PRIMARY, 10)
	bn1.AddItemBadge("info", "fa-solid fa-hospital", "Hospital", app.COLOR_SUCCESS, 0)
	bn1.AddItemBadge("graph", "fa-solid fa-pen-clip", "Graph", app.COLOR_WARNING, 0)
	bn1.AddItemBadge("like", "fa-solid fa-user-friends", "Friends", app.COLOR_INFO, 0)
	bn1.AddItemBadge("comment", "fa-solid fa-pastafarianism", "Comment", app.COLOR_ERROR, 0)
	'set badge value
	bn1.SetItemBadgeValue("home", 5)
	bn1.SetItemBadgeColor("home", app.COLOR_PRIMARY)
	'
'	Dim c1 As SDUIMockupCode = page.Cell(1, 1).AddMockUpCode("c1", "vb")
'	c1.AddCode($"bn1.AddBottomNav(Me, page.here, "bn1")"$)
'	c1.AddCode($"bn1.Bordered = True"$)
'	c1.AddCode($"bn1.AddItem("home", "fa-house", "Home", app.COLOR_PRIMARY)"$)
'	c1.AddCode($"bn1.AddItem("info", "fa-hospital", "Hospital", app.COLOR_SUCCESS)"$)
'	c1.AddCode($"bn1.AddItem("graph", "fa-pen-clip", "Graph", app.COLOR_WARNING)"$)
'	c1.AddCode($"bn1.AddItem("like", "fa-user-friends", "Friends", app.COLOR_INFO)"$)
'	c1.AddCode($"bn1.AddItem("comment", "fa-pastafarianism", "Comment", app.COLOR_ERROR)"$)
'	c1.AddCode($"'set badge value"$)
'	c1.AddCode($"bn1.SetItemBadgeValue("home", 5)"$)
'	c1.AddCode($"bn1.SetItemBadgeColor("home", app.COLOR_PRIMARY)"$)
'	c1.AddCode($"'trap click event"$)
'	c1.AddCode($"Private Sub bn1_Click (Item As String)"$)
'	c1.AddCode($"page.Cell(1, 2).Caption = Item"$)
'	c1.AddCode($"Select Case Item"$)
'	c1.AddCode($"Case "home""$)
'	c1.AddCode($"Dim v As Int = Rnd(1, 100)"$)
'	c1.AddCode($"bn1.SetItemBadgeValue(Item, v)"$)
'	c1.AddCode($"bn1.SetItemBadgeColor(Item, app.COLOR_PRIMARY)"$)
'	c1.AddCode($"End Select"$)
'	c1.AddCode($"End Sub"$)
'	c1.Refresh
End Sub


Private Sub bn1_Click (Item As String)
	'page.Cell(1, 2).Caption = Item
	Select Case Item
	Case "home"
		Dim v As Int = Rnd(1, 100)
		bn1.SetItemBadgeValue(Item, v)
		bn1.SetItemBadgeColor(Item, app.COLOR_PRIMARY)	
	End Select
End Sub
