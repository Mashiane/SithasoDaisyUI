﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "steps"
	Public title As String = "Steps"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private steps1 As SDUISteps
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	'
	steps1.AddSteps(Me, page.CellID(1, 1), "step1", app.COLOR_PRIMARY)
	steps1.WFull
	steps1.AddItems(Array("Register", "Choose a plan", "Purchase", "Receive Product"))
	steps1.SetItemLineColor(2, "primary")
	steps1.SetItemLineColor(3, "secondary")
	steps1.SetItemLineColor(4, "accent")
	'
	BuildStep1
	BuildStep2
	BuildStep3
	Step1Code
	
	Dim steps2 As SDUISteps
	steps2.AddSteps(Me, page.CellID(4, 1), "step2", app.COLOR_INFO)
	steps2.Vertical
	steps2.AddItems(Array("Register", "Choose a plan", "Purchase", "Receive Product"))
	'
	Dim c3 As SDUIMockupCode = page.Cell(5, 1).AddMockUpCode("c3", "vb")
	c3.AddCode($"Dim steps2 As SDUISteps"$)
	c3.AddCode($"steps2.AddSteps(Me, page.CellID(4, 1), "step2", app.COLOR_INFO)"$)
	c3.AddCode($"steps2.Vertical"$)
	c3.AddCode($"steps2.AddItems(Array("Register", "Choose a plan", "Purchase", "Receive Product"))"$)
	c3.Refresh
	'
	Dim steps4 As SDUISteps
	steps4.AddSteps(Me, page.CellID(6, 1), "step4", app.COLOR_NEUTRAL)
	steps4.WFull
	steps4.AddItems(Array("Step 1", "Step 2", "Step 3", "Step 4", "Step 5", "Step 6","Step 7"))
	steps4.SetItemContent(1, "?")
	steps4.SetItemContent(2, "!")
	steps4.SetItemContent(3, "✓")
	steps4.SetItemContent(4, "✕")
	steps4.SetItemContent(5, "★")
	steps4.SetItemContent(6, "")
	steps4.SetItemContent(7, "●")
	steps4.SetItemCaption(3, "Mashy")
	'
	Dim c4 As SDUIMockupCode = page.Cell(7, 1).AddMockUpCode("c4", "vb")
	c4.AddCode($"Dim steps4 As SDUISteps"$)
	c4.AddCode($"steps4.AddSteps(Me, page.CellID(6, 1), "step4", app.COLOR_NEUTRAL)"$)
	c4.AddCode($"steps4.WFull"$)
	c4.AddCode($"steps4.AddItems(Array("Step 1", "Step 2", "Step 3", "Step 4", "Step 5", "Step 6","Step 7"))"$)
	c4.AddCode($"steps4.SetItemContent(1, "?")"$)
	c4.AddCode($"steps4.SetItemContent(2, "!")"$)
	c4.AddCode($"steps4.SetItemContent(3, "✓")"$)
	c4.AddCode($"steps4.SetItemContent(4, "✕")"$)
	c4.AddCode($"steps4.SetItemContent(5, "★")"$)
	c4.AddCode($"steps4.SetItemContent(6, "")"$)
	c4.AddCode($"steps4.SetItemContent(7, "●")"$)
	c4.AddCode($"steps4.SetItemCaption(3, "Mashy")"$)
	c4.Refresh
End Sub

Sub Step1Code
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"steps1.AddSteps(Me, page.CellID(1, 1), "step1", app.COLOR_PRIMARY)"$)
	c1.AddCode($"steps1.WFull"$)
	c1.AddCode($"steps1.AddItems(Array("Register", "Choose a plan", "Purchase", "Receive Product"))"$)
	c1.AddCode($"BuildStep1"$)
	c1.AddCode($"BuildStep2"$)
	c1.AddCode($"BuildStep3"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 1).AddMockUpCode("c2", "vb")
	c2.AddCode($"Sub BuildStep1"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = steps1.Panel(1)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows2.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("lastname", "Last Name", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddButtonLabel("next1", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Sub BuildStep2"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = steps1.Panel(2)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows2.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("street2", "Street Address 2", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddTextBoxLabel("street3", "Street Address 3", "")"$)
	c2.AddCode($"cont.Cell(2, 2).AddButtonLabel("next2", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Sub BuildStep3"$)
	c2.AddCode($"'get container at position"$)
	c2.AddCode($"Dim cont As SDUIDiv = steps1.Panel(3)"$)
	c2.AddCode($"cont.DesignMode = False"$)
	c2.AddCode($"cont.AddRows2.AddColumns2x6"$)
	c2.AddCode($"cont.BuildGrid"$)
	c2.AddCode($"'"$)
	c2.AddCode($"cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")"$)
	c2.AddCode($"cont.Cell(1, 2).AddTextBoxLabel("qualification", "University Qualification", "")"$)
	c2.AddCode($"cont.Cell(2, 1).AddButtonLabel("next3", "Next")"$)
	c2.AddCode($"End Sub"$)
	c2.AddCode($"'"$)
	c2.AddCode($"Private Sub step1_Change (pos As Int)"$)
	c2.AddCode($"Log(pos)"$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
End Sub


Sub BuildStep1
	'get container at position
	Dim cont As SDUIDiv = steps1.Panel(1)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("firstname", "First Name", "")
	cont.Cell(1, 2).AddTextBoxLabel("lastname", "Last Name", "")
	cont.Cell(2, 1).AddButtonLabel("next1", "Next")
End Sub

Sub BuildStep2
	'get container at position
	Dim cont As SDUIDiv = steps1.Panel(2)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("street1", "Street Address 1", "")
	cont.Cell(1, 2).AddTextBoxLabel("street2", "Street Address 2", "")
	cont.Cell(2, 1).AddTextBoxLabel("street3", "Street Address 3", "")
	cont.Cell(2, 2).AddButtonLabel("next2", "Next")
End Sub

Sub BuildStep3
	'get container at position
	Dim cont As SDUIDiv = steps1.Panel(3)
	cont.DesignMode(False)
	cont.AddRows2.AddColumns2x6
	cont.BuildGrid
	cont.shrink
	'
	cont.Cell(1, 1).AddTextBoxLabel("grade", "Highest Grade Passed", "")
	cont.Cell(1, 2).AddTextBoxLabel("qualification", "University Qualification", "")
	cont.Cell(2, 1).AddButtonLabel("next3", "Next")
End Sub

Private Sub step1_Change (pos As Int)
	Log(pos)
End Sub


Private Sub step2_Change (pos As Int)
	Log(pos)
End Sub


Private Sub step3_Change (pos As Int)
	Log(pos)
End Sub


Private Sub step4_Change (pos As Int)
	Log(pos)
End Sub