﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "gridpage"
	Public title As String = "Grid Design - More"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	'page.Root.DesignMode(False)
	'center the page container
	'page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	'page.Root.AddRows5.AddColumns2x6
	'build the grid
	'page.Root.BuildGrid
	'start adding you components here
	
	'clear the page, remove Container container
	page.Root.Clear
	'items 1 after another (in the same row)
	page.Root.flex
	
	'place all items vertical 
	page.Root.flexCol
	page.Root.H(80)
	page.Root.BGColorIntensity(app.COLOR_GRAY, 100)
	
	'place items at the center horizontally
	'page.Root.justifyCenter
	'place items at the end (right align)
	'page.Root.justifyEnd
	'place items between equally
	page.Root.justifyBetween
	'place items with spaces around each other
	'page.Root.justifyAround
	page.Root.itemsStretch
	
	'add 4 divs
	Dim b1 As SDUIDiv = page.Root.AddDiv("b1")
	'set text
	b1.Caption = "Block 1"
	'set padding
	b1.P(2)
	'set background color
	b1.BGColorIntensity(app.color_yellow, 200)
	
	Dim b2 As SDUIDiv = page.Root.AddDiv("b2")
	b2.Caption = "Block 2"
	b2.P(2)
	b2.BGColorIntensity(app.color_blue, 200)
	
	Dim b3 As SDUIDiv = page.Root.AddDiv("b3")
	b3.Caption = "Block 3"
	b3.P(2)
	b3.BGColorIntensity(app.color_green, 200)
	
	Dim b4 As SDUIDiv = page.Root.AddDiv("b4")
	b4.Caption = "Block 4"
	b4.P(2)
	b4.BGColorIntensity(app.color_red, 200)
	b4.selfCenter
	'
	Dim b5 As SDUIDiv = page.Root.AddDiv("b5")
	b5.flex
	
	Dim b6 As SDUIDiv = b5.AddDiv("b6")
	b6.W(16)
	b6.H(16)
	b6.BGColorIntensity(app.COLOR_BLUE, 200)
	b6.roundedFull
	b6.flexShrink0
	
	Dim b7 As SDUIDiv = b5.AddDiv("b7")
	b7.LoremIpsum
	'
	Dim b8 As SDUIDiv = page.Root.AddDiv("b8")
	b8.SpaceX(2)
	b8.flex
	b8.justifyBetween
	b8.itemsStretch
	
	Dim b9 As SDUIDiv = b8.AddDiv("b9")
	b9.BGColorIntensity(app.COLOR_BLUE, 200)
	b9.Caption = "Block 9"
	
	Dim b10 As SDUIDiv = b8.AddDiv("b10")
	b10.BGColorIntensity(app.COLOR_YELLOW, 200)
	b10.Caption = "Block 10"
	
	Dim b11 As SDUIDiv = b8.AddDiv("b11")
	b11.BGColorIntensity(app.COLOR_GREEN, 200)
	b11.Caption = "Block 11"
	
	
End Sub
