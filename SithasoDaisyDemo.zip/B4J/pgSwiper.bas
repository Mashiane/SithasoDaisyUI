﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.95
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "swiperx"
	Public title As String = "Swiper"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUISwiper1 As SDUISwiper		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	app = duiapp
	
	'initialize the page
	'this clears the 'pageview'
	banano.LoadLayout(app.PageViewer, "swiperlayout")
'	SDUISwiper1.Refresh
	'get the reference to the app
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'clear the slides
	SDUISwiper1.Clear
	'add 5 slides
	SDUISwiper1.AddSlides(5)
	banano.LoadLayout(SDUISwiper1.Slide(1).Here, "sliderimage1")
	banano.LoadLayout(SDUISwiper1.Slide(2).Here, "sliderimage2")
	banano.LoadLayout(SDUISwiper1.Slide(3).Here, "sliderimage3")
	banano.LoadLayout(SDUISwiper1.Slide(4).Here, "sliderimage4")
	banano.LoadLayout(SDUISwiper1.Slide(5).Here, "sliderimage5")
	'
	SDUISwiper1.AddSlideStyle(CreateMap("background-position": "center", "background-size": "cover", "width": "400px"))
	'refresh
	SDUISwiper1.Refresh
End Sub
