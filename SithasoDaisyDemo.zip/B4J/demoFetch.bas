﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "fetchapi"
	Public title As String = "Fetch A Minion"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private txtMessage As SDUITextArea
	Private txtConvert As SDUITextArea
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows5.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	Dim lbl As SDUILabel = page.Cell(1, 1).AddLabel("lbl", "")
	lbl.Caption = "In this example we are converting English Minion via REST API. The API provider is 'https://funtranslations.com/'"
	'
	txtMessage = page.Cell(2, 1).AddTextAreaLabel("txtmessage", "English Text", "")
	txtMessage.AppendIcon = "fa-solid fa-ear-listen"
	txtMessage.Required = True
	txtMessage.Value = "The weather is beautiful today"
	
	txtConvert = page.Cell(2, 2).AddTextAreaLabel("txtconvert", "Minion Taal...", "")
	txtConvert.Value = ""
End Sub


Private Sub txtMessage_Append_Click (event As BANanoEvent)
	If txtMessage.IsBlank Then Return
	txtConvert.Value = ""
	txtMessage.AppendButton.Loading = True
	'execute the fetch
	Dim j As SDUIFetch
	'initialize the fetch with the base url
	j.Initialize("https://api.funtranslations.com/translate/minion.json")
	'add a parameters
	j.AddParameter("text", txtMessage.value)
	'set content type
	j.SetContentTypeApplication_X_WWW_Form_URLEncoded
	'compulsory
	j.AddHeader("X-Funtranslations-Api-Secret", "")
	'execute the post
	banano.Await(J.PostWait)
	txtMessage.AppendButton.Loading = False
	If j.Success Then
		Dim response As Map = j.response
		If response.ContainsKey("contents") Then
			Dim minionTaal As String = SDUIShared.GetRecursive(response, "contents.translated")
			txtConvert.Value = minionTaal
		End If
	Else	
		txtConvert.Value = j.ErrorMessage
	End If
End Sub