﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adhero"
	Public title As String = "AD Hero"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIButton1 As SDUIButton
	Private SDUIDiv1 As SDUIDiv
	Private SDUIHero1 As SDUIHero
	Private SDUILabel1 As SDUILabel
	Private SDUILabel2 As SDUILabel
	Private SDUIButton2 As SDUIButton
	Private SDUIHero2 As SDUIHero
	Private SDUIImage1 As SDUIImage
	Private SDUILabel3 As SDUILabel
	Private SDUILabel4 As SDUILabel
	Private SDUILabel5 As SDUILabel
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adherolayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton1", "SDUIButton1", SDUIButton1.CustProps)
	pgIndex.AddDesignKV1("SDUIDiv.SDUIDiv1", "SDUIDiv1", SDUIDiv1.CustProps)
	pgIndex.AddDesignKV1("SDUIHero.SDUIHero1", "SDUIHero1", SDUIHero1.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel1", "SDUILabel1", SDUILabel1.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel2", "SDUILabel2", SDUILabel2.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.SDUIButton2", "SDUIButton2", SDUIButton2.CustProps)
	pgIndex.AddDesignKV1("SDUIHero.SDUIHero2", "SDUIHero2", SDUIHero2.CustProps)
	pgIndex.AddDesignKV1("SDUIImage.SDUIImage1", "SDUIImage1", SDUIImage1.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel3", "SDUILabel3", SDUILabel3.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel4", "SDUILabel4", SDUILabel4.CustProps)
	pgIndex.AddDesignKV1("SDUILabel.SDUILabel5", "SDUILabel5", SDUILabel5.CustProps)

End Sub

Sub getName As String
	Return name
End Sub

Sub getIcon As String

	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub



Private Sub SDUIButton1_Click (e As BANanoEvent)
	app.ShowSwal("A Hero")
End Sub