﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.95
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "swiper2"
	Public title As String = "Swiper 2"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUISwiper3 As SDUISwiper		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	app = duiapp
	
	'initialize the page
	'this clears the 'pageview'
	banano.LoadLayout(app.PageViewer, "swiper2layout")
'	SDUISwiper1.Refresh
	'get the reference to the app
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'clear the slides
	SDUISwiper3.Clear
	SDUISwiper3.AddStyleMap(CreateMap("position":"relative"))
	SDUISwiper3.AddSlideStyle(CreateMap("border-radius": "18px !important"))
	SDUISwiper3.AddSlideImageStyle(CreateMap("object-fit": "cover !important", "width": "100% !important", "border-radius": "18px !important"))
	'add 5 slides
	SDUISwiper3.AddImageSlide("./assets/m1.jpg")
	SDUISwiper3.AddImageSlide("./assets/m2.jpg")
	SDUISwiper3.AddImageSlide("./assets/m3.jpg")
	SDUISwiper3.AddImageSlide("./assets/m4.jpg")
	SDUISwiper3.AddImageSlide("./assets/m5.jpg")
	SDUISwiper3.AddImageSlide("./assets/m6.jpg")
	SDUISwiper3.AddImageSlide("./assets/m7.jpg")
	SDUISwiper3.AddImageSlide("./assets/m8.jpg")
	'refresh
	SDUISwiper3.Refresh
End Sub
