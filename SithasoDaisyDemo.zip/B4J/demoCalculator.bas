﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "calculatorpage"
	Public title As String = "Simple Calculator"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private previousOperand As String
	Private currentOperand As String
	Private previousOperandElement As BANanoElement
	Private currentOperandElement As BANanoElement
	Private operation As String
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns2x6
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	BuildCalculator
	AssignEvents
End Sub

Sub ClearCalculator
	previousOperand = ""
	currentOperand = ""
	operation = Null
	currentOperandElement.SetText("")
	previousOperandElement.SetText("")
End Sub


Sub BuildCalculator
	'add themes that will be applied to various sections
	app.AddTheme("buttons", Array("w-1/4", "border-r", "border-b", "border-indigo-400"))
	app.AddTheme("buttons1", Array("w-1/4", "border-r", "border-indigo-400"))
	app.AddTheme("button", Array("w-full", "h-16", "outline-none", "focus:outline-none", _
	"hover:bg-indigo-700", "hover:font-bold", "hover:bg-opacity-20", "text-white", "text-2xl"))
	
	'outer shell
	Dim cal As SDUIDiv = page.Cell(1, 1).AddDiv("calculator")
	cal.bgColorIntensity("gray", 100).flex.itemsCenter.justifyCenter.px(5).py(5).rounded("xl")
	'
	'display area
	Dim div As SDUIDiv = cal.AddDiv("div")
	div.wFull.mxAuto.rounded("xl").bgColorIntensity("gray", 100).shadow("2xl").textColorIntensity("gray", 800).relative.overflowHidden
	div.maxw("400px")
	'
	Dim douter As SDUIDiv = div.AddDiv("douter")
	douter.wfull.h(40).bgGradientToB.fromColorIntensity("gray", 800).toColorIntensity("gray", 700)
	douter.flex.itemsEnd.textRight
	'
	Dim output As SDUIDiv = douter.AddDiv("output").flex
	output.wfull.py(5).px(6).textSize("6xl").textColor("white").fontThin.textEnd
	
	output.AddDiv("previous_operand")
	previousOperandElement.Initialize($"#previous_operand"$)
	'
	output.AddDiv("current_operand")
	currentOperandElement.Initialize($"#current_operand"$)
	'
	'digit section
	Dim ds As SDUIDiv = div.AddDiv("ds")
	ds.wfull.bggradienttob.fromcolorintensity("indigo", 400).toColorIntensity("indigo", 500)
	'
	'Row 1 of digits
	Dim r1d As SDUIDiv = ds.AddDiv("r1d").flex.wfull
	'add 4 columns
	Dim r1dc1 As SDUIDiv = r1d.AddDiv("r1dc1").applyTheme(app, "buttons")
	r1dc1.AddButtonNormal("clear", "AC").Root.applyTheme(app, "button").onclick
	Dim r1dc2 As SDUIDiv = r1d.AddDiv("r1dc2").applyTheme(app, "buttons")
	r1dc2.AddButtonNormal("divisor", "÷").Root.applyTheme(app, "button").addClass("operation")
	Dim r1dc3 As SDUIDiv = r1d.AddDiv("r1dc3").applyTheme(app, "buttons")
	r1dc3.AddButtonNormal("multiply", "x").Root.applyTheme(app, "button").addClass("operation")
	Dim r1dc4 As SDUIDiv = r1d.AddDiv("r1dc4").applyTheme(app, "buttons")
	r1dc4.AddButtonNormal("del", "DEL").Root.applyTheme(app, "button").onclick
	'
	'*** Row 2
	Dim r2d As SDUIDiv = ds.AddDiv("r2d").flex.wfull
	'add 4 columns
	Dim r2dc1 As SDUIDiv = r2d.AddDiv("r2dc1").applyTheme(app, "buttons")
	r2dc1.AddButtonNormal("seven", "7").Root.applyTheme(app, "button").addClass("number")
	Dim r2dc2 As SDUIDiv = r2d.AddDiv("r2dc2").applyTheme(app, "buttons")
	r2dc2.AddButtonNormal("eight", "8").Root.applyTheme(app, "button").addClass("number")
	Dim r2dc3 As SDUIDiv = r2d.AddDiv("r2dc3").applyTheme(app, "buttons")
	r2dc3.AddButtonNormal("nine", "9").Root.applyTheme(app, "button").addClass("number")
	Dim r2dc4 As SDUIDiv = r2d.AddDiv("r2dc4").applyTheme(app, "buttons")
	r2dc4.AddButtonNormal("minus", "-").Root.applyTheme(app, "button").addClass("operation")
	
	'*** row 3
	Dim r3d As SDUIDiv = ds.AddDiv("r3d").flex.wfull
	Dim r3dc1 As SDUIDiv = r3d.AddDiv("r3dc1").applyTheme(app, "buttons")
	r3dc1.AddButtonNormal("four", "4").Root.applyTheme(app, "button").addClass("number")
	Dim r3dc2 As SDUIDiv = r3d.AddDiv("r3dc2").applyTheme(app, "buttons")
	r3dc2.AddButtonNormal("five", "5").Root.applyTheme(app, "button").addClass("number")
	Dim r3dc3 As SDUIDiv = r3d.AddDiv("r3dc3").applyTheme(app, "buttons")
	r3dc3.AddButtonNormal("six", "6").Root.applyTheme(app, "button").addClass("number")
	Dim r3dc4 As SDUIDiv = r3d.AddDiv("r3dc4").applyTheme(app, "buttons")
	r3dc4.AddButtonNormal("plus", "+").Root.applyTheme(app, "button").addClass("operation")
	
	'*** row 4
	Dim r4d As SDUIDiv = ds.AddDiv("r4d").flex.wfull
	Dim r4dc1 As SDUIDiv = r4d.AddDiv("r4dc1").applyTheme(app, "buttons")
	r4dc1.AddButtonNormal("one", "1").Root.applyTheme(app, "button").addClass("number")
	Dim r4dc2 As SDUIDiv = r4d.AddDiv("r4dc2").applyTheme(app, "buttons")
	r4dc2.AddButtonNormal("two", "2").Root.applyTheme(app, "button").addClass("number")
	Dim r4dc3 As SDUIDiv = r4d.AddDiv("r4dc3").applyTheme(app, "buttons")
	r4dc3.AddButtonNormal("three", "3").Root.applyTheme(app, "button").addClass("number")
	Dim r4dc4 As SDUIDiv = r4d.AddDiv("r4dc4").applyTheme(app, "buttons")
	r4dc4.AddButtonNormal("percent", "%").Root.applyTheme(app, "button").addClass("operation")
		
	'*** row 5
	Dim r5d As SDUIDiv = ds.AddDiv("r5d").flex.wfull
	Dim r5dc1 As SDUIDiv = r5d.AddDiv("r5dc1").applyTheme(app, "buttons1")
	r5dc1.AddButtonNormal("zero", "0").Root.applyTheme(app, "button").addClass("number")
	
	Dim r5dc2 As SDUIDiv = r5d.AddDiv("r5dc2").applyTheme(app, "buttons1")
	r5dc2.AddButtonNormal("dot", ".").Root.applyTheme(app, "button").addClass("number")
	
	Dim r5dc3 As SDUIDiv = r5d.AddDiv("r5dc3").w("2/4").borderR("").borderColorIntensity("indigo", 400)
	r5dc3.AddButtonNormal("equal", "=").Root.applyTheme(app, "button").OnClick
	
End Sub

Sub AssignEvents
	'get all elements with number class
	Dim numbers() As BANanoElement = banano.GetElements(".number")
	For Each numbero As BANanoElement In numbers
		numbero.On("click", Me, "HandleNumbers")
	Next
	'get all elements with operation class
	Dim operations() As BANanoElement = banano.GetElements(".operation")
	For Each oporasie As BANanoElement In operations
		oporasie.On("click", Me, "HandleOperation")
	Next
End Sub

Sub clear_click (e As BANanoEvent)
	ClearCalculator
End Sub

Sub equal_click(e As BANanoEvent)
	compute
	updateDisplay
End Sub

Sub del_click(e As BANanoEvent)
	
End Sub

Sub HandleNumbers(e As BANanoEvent)
	'get the id of the clicked element
	Dim btnID As String = app.GetIDFromEvent(e)
	'get the caption of the clicked button
	Dim btnCap As String = app.GetIDText(btnID)
	appendNumbers(btnCap)
	updateDisplay
End Sub

Sub HandleOperation(e As BANanoEvent)
	'get the id of the clicked element
	Dim btnID As String = app.GetIDFromEvent(e)
	'get the caption of the clicked button
	Dim btnCap As String = app.GetIDText(btnID)
	chooseOperation(btnCap)
	updateDisplay
End Sub

Sub appendNumbers(n As String)
	n = SDUIShared.CStr(n)
	If n = "." And currentOperand.Contains(".") Then Return
	currentOperand = currentOperand & n
End Sub

Sub updateDisplay() {
	currentOperandElement.SetText(getDisplayNumber(currentOperand))
	If banano.IsNull(operation)  = False Then
		previousOperandElement.SetText($"${getDisplayNumber(previousOperand)} ${operation}"$)
	Else
		previousOperandElement.SetText("")
	End If
End Sub

Sub getDisplayNumber(number As String) As String
    number = SDUIShared.CStr(number)
	If number = "" Then Return ""
	number = SDUIShared.Val(number)
	Return number
End Sub

Sub chooseOperation(oper As String)
    If currentOperand = "" Then Return
    If previousOperand <> "" Then compute
    operation = oper
    previousOperand = currentOperand
	currentOperand = ""
End Sub

Sub compute
    Dim computation As Double
    Dim prev As Double = SDUIShared.CDbl(previousOperand)
    Dim current As Double = SDUIShared.CDbl(currentOperand)
    Select Case operation
    Case "+"
        computation = banano.parseFloat(prev) + banano.parseFloat(current)
  	Case "-"
		computation = banano.parseFloat(prev) - banano.parseFloat(current)
  	Case "x", "*"
		computation = banano.parseFloat(prev) * banano.parseFloat(current)
    Case "÷":
        computation = banano.parseFloat(prev) / banano.parseFloat(current)
	Case "%"
		computation = banano.parseFloat(prev) * (banano.parseFloat(current) / 100)
	Case Else
	  Return
    End Select
    currentOperand = computation
    operation = Null
	previousOperand = ""
End Sub