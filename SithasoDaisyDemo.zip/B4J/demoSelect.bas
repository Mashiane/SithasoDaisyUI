﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "selects"
	Public title As String = "Select"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private sel As SDUISelect
	Private sel1 As SDUISelect
	Private cboGo As SDUISelect
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows5.AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here	'
	
	sel = page.Cell(1,1).AddSelect("choices","Choices","", CreateMap())
	sel.AddItem("", "---Nothing Selected---")
	sel.AddItem("homer", "Homer")
	sel.AddItem("marge", "Marge")
	sel.AddItem("bart", "Bart")
	sel.AddItem("lisa", "Lisa")
	sel.AddItem("maggie", "Maggie")
	'select the first item
	sel.Value = ""
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"sel = page.Cell(1,1).AddSelect("choices","Choices","", CreateMap())"$)
	c1.AddCode($"sel.AddItem("", "---Nothing Selected---")"$)
	c1.AddCode($"sel.AddItem("homer", "Homer")"$)
	c1.AddCode($"sel.AddItem("marge", "Marge")"$)
	c1.AddCode($"sel.AddItem("bart", "Bart")"$)
	c1.AddCode($"sel.AddItem("lisa", "Lisa")"$)
	c1.AddCode($"sel.AddItem("maggie", "Maggie")"$)
	c1.AddCode($"'select the first item"$)
	c1.AddCode($"sel.Value = """$)
	c1.Refresh
	'
	Dim btnClear As SDUIButton = page.Cell(1,1).AddButton("btnclear", "Clear")
	Dim btnAdd As SDUIButton = page.Cell(1, 1).AddButton("btnadd", "Add Items")
	Dim btnSet As SDUIButton = page.Cell(1,1).AddButton("btnset", "Set (After Add)")
	Dim btnGet As SDUIButton = page.Cell(1,1).AddButton("btnget", "Get")
	'
	sel1 = page.Cell(2,1).AddSelect("franchise", "Fantasy Franchise", "Pick a fantasy franchise", CreateMap())
	sel1.AddItem("", "---Nothing Selected---")
	sel1.AddItem("sw", "Star Wars")
	sel1.AddItem("hp", "Harry Potter")
	sel1.AddItem("lotr", "Lord of the Rings")
	sel1.AddItem("poa", "Planet of the Apes")
	sel1.AddItem("st", "Star Trek")
	sel1.color = app.COLOR_PRIMARY
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"sel1 = page.Cell(2,1).AddSelect("franchise", "Fantasy Franchise", "Pick a fantasy franchise", CreateMap())"$)
	c2.AddCode($"sel1.AddItem("", "---Nothing Selected---")"$)
	c2.AddCode($"sel1.AddItem("sw", "Star Wars")"$)
	c2.AddCode($"sel1.AddItem("hp", "Harry Potter")"$)
	c2.AddCode($"sel1.AddItem("lotr", "Lord of the Rings")"$)
	c2.AddCode($"sel1.AddItem("poa", "Planet of the Apes")"$)
	c2.AddCode($"sel1.AddItem("st", "Star Trek")"$)
	c2.AddCode($"sel1.color = app.COLOR_PRIMARY"$)
	c2.Refresh
	
	cboGo = page.Cell(3, 1).AddSelect("cboGo", "Go", "", CreateMap())
	cboGo.Placeholder = "Pick a category"
	cboGo.Suffix = "Go"
	cboGo.AddItem("tshirts", "T-Shirts")
	cboGo.AddItem("mugs", "Mugs")
	cboGo.AddItem("shoes", "Shoes")
	cboGo.AddItem("beds", "Beds")
	cboGo.AddItem("socks", "Socks")
	cboGo.PrependIcon = "fa-solid fa-mountain-city"
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"cboGo = page.Cell(3, 1).AddSelect("cboGo", "Go", "", CreateMap())"$)
	c3.AddCode($"cboGo.Placeholder = "Pick a category""$)
	c3.AddCode($"cboGo.Suffix = "Go""$)
	c3.AddCode($"cboGo.AddItem("tshirts", "T-Shirts")"$)
	c3.AddCode($"cboGo.AddItem("mugs", "Mugs")"$)
	c3.AddCode($"cboGo.PrependIcon = "fa-mountain-city""$)
	c3.Refresh
	'
	Dim ns As SDUISelect = page.Cell(4, 1).AddSelect("ns", "Multiple Select", "", CreateMap())
	ns.Multiple("items")
	ns.Placeholder = "Normal Select"
	ns.AddItem("tshirts", "T-Shirts")
	ns.AddItem("mugs", "Mugs")
	ns.AddItem("shoes", "Shoes")
	ns.AddItem("beds", "Beds")
	ns.AddItem("socks", "Socks")
End Sub

Sub btnclear_click (e As BANanoEvent)
	sel.Clear
End Sub

Sub btnadd_click (e As BANanoEvent)
	sel.Clear
	sel.AddItem("1", "One")
	sel.AddItem("2", "Two")
	sel.AddItem("3", "Three")
	sel.AddItem("4", "Four")
	sel.AddItem("5", "Five")
End Sub

Private Sub choices_Change (item As String)
	page.Cell(4, 1).Caption = item
End Sub

Private Sub franchise_Change (item As String)
	page.Cell(4, 1).Caption = item
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	Dim i As String = sel.Value
	Dim z As String = sel1.Value
	'
	page.Cell(4, 1).Caption = i
	page.Cell(5, 1).Caption = z
	
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	'set a random number between 1 and 100
	sel.value = Rnd(1, 5)
	page.Cell(4, 1).Caption = sel.value
End Sub
