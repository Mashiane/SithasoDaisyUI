﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "zuckitpage"
	Public title As String = "Stories"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIStories1 As SDUIStories 'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	banano.LoadLayout(app.PageViewer, "zucklayout")
	SDUIStories1.Clear
	SDUIStories1.AddStory("ramon", "Ramon", "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/users/1.jpg", SDUIShared.Now)
	SDUIStories1.AddPhoto("ramon", "ramon-1", 3, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/1.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/1.jpg", "", "", SDUIShared.Now)
	SDUIStories1.AddVideo("ramon", "ramon-2", 0, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/2.mp4", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/2.jpg", "", "", SDUIShared.Now)
	SDUIStories1.AddPhoto("ramon", "ramon-3", 3, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/3.png", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/3.png", "https://ramon.codes", "Visit my Portfolio", SDUIShared.Now)
	
	SDUIStories1.AddStory("gorillaz", "Gorillaz", "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/users/2.jpg", SDUIShared.Now)
	SDUIStories1.AddVideo("gorillaz", "gorillaz-1", 0, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/4.mp4", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/2.jpg", "", "", SDUIShared.Now)
	SDUIStories1.AddPhoto("gorillaz", "gorillaz-2", 3, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/4.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/4.jpg", "", "", SDUIShared.Now)
	
	
	SDUIStories1.AddStory("ladygaga", "Lady Gaga", "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/users/3.jpg", SDUIShared.Now)
	SDUIStories1.AddPhoto("ladygaga", "ladygaga-1", 5, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/6.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/6.jpg", "", "", SDUIShared.Now)
	SDUIStories1.AddPhoto("ladygaga", "ladygaga-2", 3, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/7.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/7.jpg", "", "", SDUIShared.Now)
	
	
	
	SDUIStories1.AddStory("starboy", "The Weeknd", "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/users/4.jpg", SDUIShared.Now)
	SDUIStories1.AddPhoto("starboy", "starboy-1", 5, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/8.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/8.jpg", "", "", SDUIShared.Now)
	
	
	
	SDUIStories1.AddStory("riversquomo", "Rivers Cuomo", "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/users/5.jpg", SDUIShared.Now)
	SDUIStories1.AddPhoto("riversquomo", "riversquomo-1", 10, "https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/9.jpg", _
	"https://raw.githubusercontent.com/ramonszo/assets/master/zuck.js/stories/9.jpg", "", "", SDUIShared.Now)
	
	SDUIStories1.Refresh
End Sub
