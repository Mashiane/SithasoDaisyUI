﻿B4J=true
Group=Default Group\Tools
ModulesStructureVersion=1
Type=Class
Version=9.8
@EndOfDesignText@
Sub Class_Globals
	Public Declarations As List
	Public DesignProps As List
	Public Getters As List
	Public Setters As List
	Public Events As List
	Public InternalSets As List
	Public Classes As List
	Public EventsD As List
	Public BANano As BANano
End Sub

'Initializes the object. You can add parameters to this method if needed.
Public Sub Initialize(records As List)
	Declarations.Initialize 
	DesignProps.Initialize 
	Getters.Initialize 
	Setters.Initialize 
	Events.Initialize
	InternalSets.Initialize
	Classes.Initialize 
	EventsD.Initialize
	'
	EventsD.Add("#IgnoreWarnings:12")
	
	'GETTERS
	Getters.Add($"Sub DesignerCreateView (Target As BANanoElement, Props As Map)"$)
	Getters.Add($"CustProps = Props"$)
	Getters.Add($"mParent = Target"$)
	Getters.Add($"If Props <> Null Then"$)
	Getters.Add($"mParentID = Props.GetDefault("ParentID", "")"$)
	Getters.Add($"mParentID = SDUIShared.CStr(mParentID)"$)
	Getters.Add($"mClasses = Props.GetDefault("RawClasses", "")"$)
	Getters.Add($"mStyles = Props.GetDefault("RawStyles", "")"$)
	Getters.Add($"mAttributes = Props.GetDefault("RawAttributes", "")"$)
	Getters.Add($"sMarginAXYTBLR = Props.GetDefault("MarginAXYTBLR","a=?; x=?; y=?; t=?; b=?; l=?; r=?")"$)
	Getters.Add($"sPaddingAXYTBLR = Props.GetDefault("PaddingAXYTBLR","a=?; x=?; y=?; t=?; b=?; l=?; r=?")"$)
	Getters.Add($"bVisible = Props.GetDefault("Visible", True)"$)
	Getters.Add($"bVisible = SDUIShared.parseBool(bVisible)"$)
	'
	DesignProps.Add($"#DesignerProperty: Key: ParentID, DisplayName: ParentID, FieldType: String, DefaultValue: , Description: The ParentID of this div"$)
	
	
	Declarations.Add("Sub Class_Globals")
	Declarations.Add("Public CustProps As Map")
	Declarations.Add("Private mback As Object")
	Declarations.Add("Private mElement As BANanoElement")
	Declarations.Add("Private mParent As BANanoElement")
	Declarations.Add("Private mName As String")
	Declarations.Add("Private BANano As BANano   'ignore")
	Declarations.Add($"Public Root As SDUIDiv"$)
	Declarations.Add($"Private mClasses As String"$)
	Declarations.Add($"Private mStyles As String"$)
	Declarations.Add($"Private mAttributes As String"$)
	Declarations.Add($"Private sMarginAXYTBLR As String"$)
	Declarations.Add($"Private sPaddingAXYTBLR As String"$)
	Declarations.Add($"Private mParentID As String"$)
	Declarations.Add($"Private bVisible As Boolean"$)
	Dim hasOptions As Int = 0
		
	For Each attrm As Map In records
		Dim sattrname As String = attrm.GetDefault("attrname", "")
		sattrname = sattrname.tolowercase
		'
		Dim sdefaultvalue As String = attrm.GetDefault("defaultvalue", "")
		Dim sattrtype As String = attrm.GetDefault("attrtype", "string")
		sattrtype = sattrtype.tolowercase
		Dim sattrdescription As String = attrm.GetDefault("attrdescription", "")
		If sattrdescription = "" Then
			sattrdescription = SDUIShared.DeCamelCaseSpace(sattrname)
		End If
		Dim sattrhasset As String = attrm.GetDefault("attrhasset", "false")
		Dim sattrhasget As String = attrm.GetDefault("attrhasget", "false")
		Dim sattroptions As String = attrm.GetDefault("attroptions", "")
		'Dim sattrmin As String = attrm.GetDefault("attrmin", "")
		'Dim sattrmax As String = attrm.GetDefault("attrmax", "")
		Dim sattrdesigner As String = attrm.GetDefault("attrdesigner", "false")
		Dim sattrclass As String = attrm.GetDefault("attrclass", "false")
		Dim sattrvariable As String = attrm.GetDefault("attrvariable", "false")
		Dim sisattr As String = attrm.GetDefault("isattr", "false")
		Dim sisoption As String = attrm.GetDefault("isoption", "false")
		Dim sattrsplit As String = attrm.GetDefault("attrsplit", "false")
		If sisoption = "true" Then 
			hasOptions = BANano.parseint(hasOptions) + 1
		End If
		'
		'Dim sattrexplode As String = attrm.GetDefault("attrexplode", "No")
		'Dim soncondition As String = attrm.GetDefault("oncondition", "No")
		'Dim sattrremoveprefix As String = attrm.GetDefault("attrremoveprefix", "No")
		'sattrremoveprefix = BANanoShared.parseNull(sattrremoveprefix)
		'Dim sattrparentobject As String = attrm.GetDefault("attrparentobject", "No")
		'sattrparentobject = BANanoShared.parseNull(sattrparentobject)
		'Dim sattrsplitvalues As String = attrm.GetDefault("attrsplitvalues", "No")
		'sattrsplitvalues = BANanoShared.parseNull(sattrsplitvalues)
		'
		Dim prefix As String = "s"
		Dim displayName As String = SDUIShared.DeCamelCaseSpace(sattrname)
		Dim keyName As String = SDUIShared.CamelCase(sattrname)
		Dim optionName As String = SDUIShared.CamelCaseOthers(sattrname)
		Dim fldType As String = "String"
		sattrdescription = SDUIShared.ProperCase(sattrdescription)
		'
		Dim internalDone As Boolean = False
		Dim kk As String = ""
		If sattrtype = "class-with" Then sattrclass = "true"
		'
		If sattrclass = "true" Then
			If sattrtype = "string" Then
				sattrtype = "boolean"
				Dim xclassName As String = SDUIShared.CamelCaseOthers(sattrname)
				If sattrdescription = "" Then SDUIShared.CamelCase(sattrname)
							'
				Classes.Add($"'change ${sattrname}"$)
				Classes.Add($"Sub ${xclassName} As SDUIDiv"$)
				Classes.Add($"mElement.AddClass("${sattrname}")"$)
				Classes.Add($"Return Me"$)
				Classes.Add($"End Sub"$)
				'
				If sattrdesigner = "true" Then 
					internalDone = True
					kk = $"b${keyName}"$
					InternalSets.Add($"If ${kk} Then "$ & xclassName)
				End If
			End If
			'
			If sattrtype = "class-with" Then
				Dim xclassName As String = SDUIShared.CamelCaseOthers(sattrname)
				If sattrdescription = "" Then SDUIShared.CamelCase(sattrname)
				'
				Classes.Add($"'change ${sattrname}"$)
				Classes.Add($"Sub ${xclassName}(s As String) As SDUIDiv"$)
				Classes.Add($"If s = "" Then Return Me"$)
				If sattrvariable = "true" Then Classes.Add($"s${sattrname} = s"$)
				Classes.Add($"mElement.AddClass("${sattrname}-" & s)"$)
				Classes.Add($"Return Me"$)
				Classes.Add($"End Sub"$)
				'
				If sattrdesigner = "true" Then
					internalDone = True
					kk = $"s${keyName}"$
					InternalSets.Add($"${xclassName}(${kk})"$)
				End If
			End If
		End If
		'
		'***** DECLARATIONS
		Select Case sattrtype
		Case "boolean"
			prefix = "b"
			kk = $"${prefix}${keyName}"$
			If sattrdesigner = "true" Then Declarations.Add($"Private ${kk} As Boolean"$)
			If sdefaultvalue = "" Then sdefaultvalue = "False"
			fldType = "Boolean"
			If sattrdesigner = "true" Then Getters.Add($"${kk} = Props.GetDefault("${keyName}", ${sdefaultvalue})"$)
			If sattrdesigner = "true" Then Getters.Add($"${kk} = SDUIShared.parseBool(${kk})"$)
			If internalDone = False Then
				If sattrdesigner = "true" Then InternalSets.Add($"set${keyName}(${kk})"$)
			End If
			'
			If sattrhasset = "true" And sattrclass <> "true" Then
				Classes.Add($"'set ${sattrdescription}"$)
				Classes.Add($"Sub set${keyName}(b As Boolean)"$)
				If sattrvariable = "true" Then Classes.Add($"b${keyName} = b"$)
				If sisoption = "true" Then Classes.Add($"Options.put("${optionName}", b)"$)
				If sisattr = "true" Then
					Classes.Add($"If b Then"$)
					Classes.Add($"mElement.SetAttr("${sattrname}", "${sattrname}")"$)
					Classes.Add($"Else"$)
					Classes.Add($"mElement.RemoveAttr("${sattrname}")"$)
					Classes.Add($"End If"$)
				End If
				Classes.Add($"Return"$)
				Classes.Add($"End Sub"$)
			End If
			
		Case "int"
			prefix = "i"
			kk = $"${prefix}${keyName}"$
			If sattrdesigner = "true" Then Declarations.Add($"Private ${kk} As Int"$)
			If sdefaultvalue = "" Then sdefaultvalue = "0"
			fldType = "Int"
			If sattrdesigner = "true" Then Getters.Add($"${kk} = Props.GetDefault("${keyName}", ${sdefaultvalue})"$)
			If sattrdesigner = "true" Then Getters.Add($"${kk} = SDUIShared.CInt(${kk})"$)
			If internalDone = False Then
			If sattrdesigner = "true" Then InternalSets.Add($"set${keyName}(${kk})"$)
			End If
				'
			If sattrhasset = "true" And sattrclass <> "true" Then
				Classes.Add($"'set ${sattrdescription}"$)
				Classes.Add($"Sub set${keyName}(i As String)"$)
				Classes.Add($"i = SDUIShared.CStr(i)"$)
				If sattrvariable = "true" Then Classes.Add($"i${keyName} = i"$)
				If sisoption = "true" Then Classes.Add($"Options.put("${optionName}", i)"$)
				If sisattr = "true" Then
					Classes.Add($"If i = "" Then Return"$)
					Classes.Add($"mElement.SetAttr("${sattrname}", i)"$)
				End If
				Classes.Add($"End Sub"$)
			End If
		Case "color"
			prefix = "s"
			kk = $"${prefix}${keyName}"$
			If sattrdesigner = "true" Then Declarations.Add($"Private ${kk} As String"$)
			If sdefaultvalue = "" Then sdefaultvalue = "0xFFCFDCDC"
			fldType = "Color"
			If sattrdesigner = "true" Then Getters.Add($"${kk} = Props.GetDefault("${keyName}", "${sdefaultvalue}")"$)
			If sattrdesigner = "true" Then Getters.Add($"${kk} = SDUIShared.CStr(${kk})"$)
			If internalDone = False Then
				If sattrdesigner = "true" Then InternalSets.Add($"set${keyName}(${kk})"$)
			End If
		Case "string", "class-with"
			prefix = "s"
			kk = $"${prefix}${keyName}"$
			If sattrdesigner = "true" Then Declarations.Add($"Private ${kk} As String"$)
			fldType = "String"
			If sattrdesigner = "true" Then Getters.Add($"${kk} = Props.GetDefault("${keyName}", "${sdefaultvalue}")"$)
			If sattrdesigner = "true" Then Getters.Add($"${kk} = SDUIShared.CStr(${kk})"$)
			If internalDone = False Then
				If sattrdesigner = "true" Then InternalSets.Add($"set${keyName}(${kk})"$)
			End If
			'
			If sattrhasset = "true" And sattrclass <> "true" Then
					Classes.Add($"'set ${sattrdescription}"$)
					Classes.Add($"Sub set${keyName}(s As String)"$)
					Classes.Add($"s = SDUIShared.CStr(s)"$)
					If sattrvariable = "true" Then Classes.Add($"s${keyName} = s"$)
					If sisoption = "true" Then Classes.Add($"Options.put("${optionName}", s)"$)
					If sisattr = "true" Then
						Classes.Add($"If s = "" Then Return"$)
						Classes.Add($"mElement.SetAttr("${sattrname}", s)"$)
					End If
					'
					If sattrsplit = "true" Then
						Classes.Add($"Dim lst${keyName} As List = SDUIShared.StrParseComma(";", s)"$)
						Classes.Add($"lst${keyName} = SDUIShared.ListTrimItems(lst${keyName})"$)
						Classes.Add($"Dim tot${keyName} As Int = lst${keyName}.Size - 1"$)
						Classes.Add($"Dim cnt${keyName} As Int"$)
						Classes.Add($"For cnt${keyName} = 0 To tot${keyName}"$)
						Classes.Add($"Dim lstVal As String = lst${keyName}.Get(cnt${keyName})"$)
						Classes.Add($"lstVal = lstVal.Trim"$)
						Classes.Add($"If lstVal = "" Then Continue"$)
						Classes.Add($"Next"$)
					End If					
					Classes.Add($"End Sub"$)
				End If
		Case "event"
			EventsD.Add($"#Event: ${keyName} (e As BANanoEvent)"$)
		End Select
		'
		'DESIGNER PROPERTIES
		If sattrdesigner = "true" Then
			Dim sitem As String = $"#DesignerProperty: Key: ${keyName}, DisplayName: ${displayName}, FieldType: ${fldType}, DefaultValue: ${sdefaultvalue}, Description: ${sattrdescription}"$
			If sattroptions <> "" Then
				Dim opts As List = SDUIShared.StrParse("|", sattroptions)
				opts = SDUIShared.ListTrimItems(opts)
				opts.Sort(True)
				Dim xList As String = $", List: ${SDUIShared.Join("|", opts)}"$
				sitem = sitem & xList
			End If
			DesignProps.Add(sitem)
		End If
	Next
	'
	If hasOptions > 0 Then Declarations.Add($"Private Options As Map"$)
	Declarations.Add("End Sub")
	'
	DesignProps.Add($"#DesignerProperty: Key: Visible, DisplayName: Visible, FieldType: Boolean, DefaultValue: True, Description: If visible."$)
	DesignProps.Add($"#DesignerProperty: Key: MarginAXYTBLR, DisplayName: Margins, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Margins A-X-Y-T-B-L-R"$)
	DesignProps.Add($"#DesignerProperty: Key: PaddingAXYTBLR, DisplayName: Paddings, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Paddings A-X-Y-T-B-L-R"$)
	DesignProps.Add($"#DesignerProperty: Key: RawClasses, DisplayName: Classes, FieldType: String, DefaultValue: , Description: Classes added to the HTML tag."$)
	DesignProps.Add($"#DesignerProperty: Key: RawStyles, DisplayName: Styles, FieldType: String, DefaultValue: , Description: Styles added to the HTML tag. Must be a json String- use ="$)
	DesignProps.Add($"#DesignerProperty: Key: RawAttributes, DisplayName: Attributes, FieldType: String, DefaultValue: , Description: Attributes added to the HTML tag. Must be a json String- use ="$)
	'
	Getters.Add($"End If"$)
	Getters.Add($"'"$)
	Getters.Add($"If mParentID = "" Then mParentID = mParent.Name"$)
	Getters.Add($"Add???(mback, mParentID, mName)"$)
	Getters.Add($"Root.classes(mClasses)"$)
	Getters.Add($"Root.attributes(mAttributes)"$)
	Getters.Add($"Root.styles(mStyles)"$)
	Getters.Add($"Root.PaddingAXYTBLR(sPaddingAXYTBLR)"$)
	Getters.Add($"Root.MarginAXYTBLR(sMarginAXYTBLR)"$)
	Getters.Add($"If bVisible = False Then Hide"$)
	Getters.AddAll(InternalSets)
	Getters.Add($"End Sub"$)
	'
	
	'
	Setters.Add($"Sub Initialize (CallBack As Object, cName As String, EventName As String)"$)
	Setters.Add($"mName = SDUIShared.CleanID(cName)"$)
	Setters.Add($"mback = CallBack"$)
	If hasOptions > 0 Then Setters.Add($"Options.Initialize"$)
	Setters.Add($"End Sub"$)
	Setters.Add("'")
	'
	Setters.Add($"Public Sub Add???(mCallback As Object, ParentID As String, ID As String)"$)
	Setters.Add($"ParentID = SDUIShared.CleanID(ParentID)"$)
	Setters.Add($"ID = SDUIShared.CleanID(ID)"$)
	Setters.Add($"mName = ID"$)
	Setters.Add($"mback = mCallback"$)
	Setters.Add($"'does the parent exist"$)
	Setters.Add($"If BANano.Exists(~"#~{ParentID}"~) = False Then"$)
	Setters.Add($"BANano.Throw(~"SDUI???.Initialize: '~{ParentID}' parent does not exist!"~)"$)
	Setters.Add($"Return"$)
	Setters.Add($"End If"$)
	Setters.Add($"If BANano.Exists(~"#~{ID}"~) Then"$)
	Setters.Add($"mElement.Initialize(~"#~{ID}"~)"$)
	Setters.Add($"Else"$)
	Setters.Add($"mParent = BANano.GetElement(~"#~{ParentID}"~)"$)
	Setters.Add($"mElement = mParent.Append(~"[BANCLEAN]<div id="~{ID}"></div>"~).Get(~"#~{ID}"~)"$)
	Setters.Add($"End If"$)
	Setters.Add($"AssignElement(mCallback, mName)"$)
	If hasOptions > 0 Then Setters.Add($"Options.Initialize"$)
	Setters.Add($"End Sub"$)
	Setters.Add("'")
	
	
	Setters.Add($"Sub shadow(s As String)"$)
	Setters.Add($"Root.shadow(s)"$)
	Setters.Add($"End Sub"$)
	'
	Setters.Add($"Sub RoundedBox"$)
	Setters.Add($"Root.roundedBox"$)
	Setters.Add($"End Sub"$)
	'
	Setters.Add($"Sub TextColorIntensity(hcolor As String, intensity As String)"$)
	Setters.Add($"Root.TextColorIntensity(hcolor, intensity)"$)
	Setters.Add($"End Sub"$)
	'
	Setters.Add($"Sub BGColorIntensity(c As String, s As String)"$)
	Setters.Add($"Root.BGColorIntensity(c, s)"$)
	Setters.Add($"End Sub"$)
	'
	Events.Add($"Sub AssignElement(mCallBack As Object, ID As String)"$)
	Events.Add($"ID = SDUIShared.CleanID(ID)"$)
	Events.Add($"If BANano.Exists(~"#~{ID}"~) = False Then"$)
	Events.Add($"Return"$)
	Events.Add($"End If"$)
	Events.Add($"mName = ID"$)
	Events.Add($"mback = mCallBack"$)
	Events.Add($"mElement.Initialize(~"#~{ID}"~)"$)
	Events.Add($"Root.AssignElement(mback, mName)"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"'enable"$)
	Events.Add($"Sub Enable"$)
	Events.Add($"Root.Disabled(False)"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"'disable"$)
	Events.Add($"Sub Disable"$)
	Events.Add($"Root.Disabled(True)"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"Sub getName As String"$)
	Events.Add($"Return ~"~{mName}"~"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"'get the id of the component"$)
	Events.Add($"Sub getHere As String"$)
	Events.Add($"Return ~"#~{mName}"~"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"Sub Show"$)
	Events.Add($"Root.Hidden(False)"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"Sub Hide"$)
	Events.Add($"Root.Hidden(True)"$)
	Events.Add($"End Sub"$)
	'
	Events.Add($"public Sub AddToParent(targetID As String, props As Map)"$)
	Events.Add($"targetID = SDUIShared.CleanID(targetID)"$)
	Events.Add($"mParent = BANano.GetElement("#" & targetID)"$)
	Events.Add($"DesignerCreateView(mParent, props)"$)
	Events.Add($"End Sub"$)
End Sub


Sub ToString As String
	Dim sb As StringBuilder
	sb.Initialize 
	Dim d1 As String = SDUIShared.Join(CRLF, Declarations)
	Dim d2 As String = SDUIShared.Join(CRLF, DesignProps)
	Dim d3 As String = SDUIShared.Join(CRLF, Getters)
	Dim d4 As String = SDUIShared.Join(CRLF, Setters)
	Dim d5 As String = SDUIShared.Join(CRLF, Classes)
	Dim d6 As String = SDUIShared.Join(CRLF, Events)
	Dim d7 As String = SDUIShared.Join(CRLF, EventsD)
	
	'
	sb.Append(d7)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d2)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d1)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d3)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d4)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d5)
	sb.Append(CRLF)
	sb.Append(CRLF)
	sb.Append(d6)
	sb.Append(CRLF)
	sb.Append(CRLF)
	
	Return sb.tostring
End Sub
