﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adtoggle"
	Public title As String = "AD Toggle"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIToggle1 As SDUIToggle
	Private SDUIToggle2 As SDUIToggle
	Private SDUIToggle3 As SDUIToggle
	Private SDUIToggle4 As SDUIToggle
	Private SDUIToggle5 As SDUIToggle
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	banano.LoadLayout(app.PageViewer, "adtogglelayout")
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIToggle.SDUIToggle1", "SDUIToggle1", SDUIToggle1.CustProps)
	pgIndex.AddDesignKV1("SDUIToggle.SDUIToggle2", "SDUIToggle2", SDUIToggle2.CustProps)
	pgIndex.AddDesignKV1("SDUIToggle.SDUIToggle3", "SDUIToggle3", SDUIToggle3.CustProps)
	pgIndex.AddDesignKV1("SDUIToggle.SDUIToggle4", "SDUIToggle4", SDUIToggle4.CustProps)
	pgIndex.AddDesignKV1("SDUIToggle.SDUIToggle5", "SDUIToggle5", SDUIToggle5.CustProps)

	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIToggle5_Change (checked As Boolean)
	app.ShowSwal(checked)
End Sub

Private Sub SDUIToggle4_Change (checked As Boolean)
	app.ShowSwal(checked)
End Sub

Private Sub SDUIToggle3_Change (checked As Boolean)
	app.ShowSwal(checked)
End Sub

Private Sub SDUIToggle2_Change (checked As Boolean)
	app.ShowSwal(checked)
End Sub

Private Sub SDUIToggle1_Change (checked As Boolean)
	app.ShowSwal(checked)
End Sub