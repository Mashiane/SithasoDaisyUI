﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "basicmenus"
	Public title As String = "Basic Menus"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano			'ignore
	Private SDUIMenu1 As SDUIMenu		'ignore
	Private SDUIMenu2 As SDUIMenu		'ignore
	Private SDUIMDToast1 As SDUIMDToast	'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "basicmenuslayout")
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
	Dim names As List
	names.Initialize 
	names.AddAll(Array("A","B","C","D","E"))
	'
	For Each item As String In names
		Dim index As Long = banano.LoadLayoutArray(SDUIMenu1.Here, "menuitemline", False)
		Dim views As Map = banano.GetAllViewsFromLayoutArray(Me, "menuitemline", index)
		Dim menuItem As SDUIMenuItem = views.Get("menuitem")
		Dim menuitemtitle As SDUILabel = views.Get("menuitemtitle")
		menuitemtitle.Caption = $"Item - ${item}"$
		menuItem.Tag = item
		Dim e As BANanoEvent
		menuItem.OnEvent("click", Me, "sduimenu1_itemclick", Array(e))
	Next
	
	For Each item As String In names
		Dim index1 As Long = banano.LoadLayoutArray(SDUIMenu2.Here, "menuitemline1", False)
		Dim views1 As Map = banano.GetAllViewsFromLayoutArray(Me, "menuitemline1", index1)
		'		
		Dim itemlabel1 As SDUILabel = views1.Get("itemlabel1")
		Dim button1 As SDUIButton = views1.Get("button1")
		Dim toggle1 As SDUIToggle = views1.Get("toggle1")
		'
		itemlabel1.Caption = $"Item - ${item}"$
		button1.Caption = item
		toggle1.Caption = ""
		toggle1.Checked = False
		
		button1.Tag = item
		toggle1.Tag = item
		'
		Dim e As BANanoEvent
		button1.OnEvent("click", Me, "button1_click", Array(e))
		'
		toggle1.OnEvent("change", Me, "toggle1_change", Array(e))
	Next
	
	'
End Sub

Sub sduimenu1_itemclick(e As BANanoEvent)
	Dim menuitem As SDUIMenuItem = Sender
	SDUIMDToast1.ShowInfo(menuitem.Tag)
End Sub


Sub button1_click(e As BANanoEvent)
	Dim button1 As SDUIButton = Sender
	SDUIMDToast1.ShowInfo(button1.Tag)
End Sub

Sub toggle1_change(e As BANanoEvent)
	Dim toggle1 As SDUIToggle = Sender
	SDUIMDToast1.ShowInfo($"${toggle1.tag} - ${toggle1.Checked}"$)
End Sub
