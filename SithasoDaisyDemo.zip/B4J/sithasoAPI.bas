﻿B4J=true
Group=Default Group\Tools
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "sithasoapi"
	Public title As String = "SithasoDaisy API"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Public CompName As String
	Private apigrid As SDUIGrid
	Private apiprops As SDUITable
	Private lblName As SDUILabel
	Private apievents As SDUITable
	Private apimethods As SDUITable
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	''banano.Await(app.UsesFormToJSON)
	''banano.Await(app.UsesTable)
	banano.LoadLayout(app.PageViewer, "sithasoapilayout")
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

Sub apiprops_doc (e As BANanoEvent)
	apiprops.SetToolbarButtonLoading("doc", True)
	Dim jsonFile As Map = banano.Await(banano.GetFileAsJSON($"./assets/${CompName}.json"$, Null))
	
	Dim properties As List = jsonFile.Get("properties")
	Dim events As List = jsonFile.Get("events")
	Dim methods As List = jsonFile.Get("methods")
	'
	Dim doc As SDUIDocxTemplator
	doc.Initialize(Me, "docx", "./assets/api.docx", $"${CompName}.docx"$)
	doc.SetField("component", CompName.ToUpperCase)
	doc.SetField("properties", properties)
	doc.SetField("events", events)
	doc.SetField("methods", methods)
	banano.Await(doc.BuildWait)
	
	apiprops.SetToolbarButtonLoading("doc", False)
End Sub

'start building the page
private Sub BuildPage
	CompName = SDUIShared.MvField(CompName, 2, "-")
	lblName.Caption = CompName
	apiprops.Title = CompName & " properties"
	apievents.Title = CompName & " events"
	apimethods.Title = CompName & " methods"
	'
	apiprops.AddToolbarActionButtonIcon("doc", "fa-regular fa-file-word", app.COLOR_BLUE)
	apiprops.ClearHeadings
	apiprops.AddColumnTitleSubTitle("DisplayName", "Property & Description", "Description")
	apiprops.AddColumnTitleSubTitle("DefaultValue", "Default Value & Type", "FieldType")
	apiprops.AddColumn("List", "Options")
	apiprops.SetColumnMinMaxWidth("DisplayName", "10rem", "15rem")
	apiprops.SetColumnMinMaxWidth("List", "10rem", "15rem")
	apiprops.SetColumnWrapText(Array("List", "DisplayName"))
	apiprops.ApplyLowerCase = True
	'
	apievents.ClearHeadings
	apievents.AddColumn("name", "Event")
	apievents.SetColumnWrapText(Array("name"))
	apievents.ApplyLowerCase = True
	'
	apimethods.ClearHeadings
	apimethods.AddColumnTitleSubTitle("name", "Method & Signature", "signature")
	apimethods.SetColumnWrapText(Array("name"))
	apimethods.ApplyLowerCase = True
	'
	banano.Await(mounted)
End Sub

Sub mounted
	apiprops.refreshloading = True
	Dim jsonFile As Map = banano.Await(banano.GetFileAsJSON($"./assets/${CompName}.json"$, Null))
	Log(jsonFile)
	Dim properties As List = jsonFile.Get("properties")
	Dim events As List = jsonFile.Get("events")
	Dim methods As List = jsonFile.Get("methods")
	'
	apiprops.SetItemsPaginate(properties)
	apievents.SetItemsPaginate(events)
	apimethods.SetItemsPaginate(methods)
	apiprops.refreshloading = False	
End Sub

Private Sub apiprops_Refresh (e As BANanoEvent)
	banano.Await(mounted)
End Sub

Private Sub apimethods_Refresh (e As BANanoEvent)
	
End Sub

Private Sub apievents_Refresh (e As BANanoEvent)
	
End Sub