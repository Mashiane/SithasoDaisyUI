﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:9, 12
Sub Process_Globals
	Public name As String = "dinputgroups"
	Public title As String = "Input Groups"
	Public icon As String = "fa-solid fa-swatchbook"
	Public page As SDUIPage
	Public app As SDUIApp
	Private txtIG As SDUITextBox
	Private txtAmount As SDUITextBox
	Private txtAmount1 As SDUITextBox
	Private txtEmail As SDUITextBox
	Private txtLarge As SDUITextBox
	Private txtMedium As SDUITextBox
	Private txtSmall As SDUITextBox
	Private txtXSmall As SDUITextBox
	Private txtSearch As SDUITextBox
	Private banano As BANano		'ignore
End Sub

Sub Show(duiapp As SDUIApp)
	'empty the parent to host the page
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'initialize the pagee
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


Sub BuildPage
	page.Root.DesignMode(False)
	page.Root.MXAuto
	page.Root.AddRows1.AddColumns4x3
	page.Root.AddRows1.AddColumns12
	page.Root.AddRows12.AddColumns4p8
	page.Root.AddRows3.AddColumns4p8
	page.Root.BuildGrid
	'
	txtIG.AddTextBoxGroup(Me, page.CellID(1, 1), "txtig", "Your Email", "Enter your email", "Email", "")
	txtIG.Placeholder = "Enter your email"
	'
	Dim btnGet As SDUIButton = page.Cell(1,2).AddButton("btnget", "Get Text")
	'
	Dim btnSet As SDUIButton = page.Cell(1,3).AddButton("btnset", "Set Text")
	'
	Dim c1 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c1", "vb")
	c1.AddCode($"Private txtIG As SDUIText"$)
	c1.AddCode($"txtIG.AddTextBoxGroup(Me, page.CellID(1, 1), "txtig", "Your Email", "Enter your email", "Email", "")"$)
	c1.AddCode($"txtIG.Placeholder = "Enter your email""$)
	c1.Refresh
	'
	txtAmount.AddTextBoxGroup(Me, page.CellID(3, 1), "txtamount", "Enter Amount", "", "", "BTC")
	txtAmount.Placeholder = "0.01"
	'
	Dim c2 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"txtAmount.AddTextBoxGroup(Me, page.CellID(3, 1), "txtamount", "Enter Amount", "", "", "BTC")"$)
	c2.AddCode($"txtAmount.Placeholder = "0.01""$)
	c2.Refresh
	'
	txtAmount1.AddTextBoxGroup(Me, page.CellID(4, 1), "txtamount1", "Enter Amount", "", "Price", "USD")
	txtAmount1.Placeholder = "10"
	'
	Dim c3 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c3.AddCode($"txtAmount1.AddTextBoxGroup(Me, page.CellID(4, 1), "txtamount1", "Enter Amount", "", "Price", "USD")"$)
	c3.AddCode($"txtAmount1.Placeholder = "10""$)
	c3.Refresh
	'
	txtEmail.AddTextBoxGroup(Me, page.CellID(5, 1), "txtemail", "Your Email", "", "Email", "")
	txtEmail.Placeholder = "Enter your email"
	txtEmail.InputGroupVertical = True
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"txtEmail.AddTextBoxGroup(Me, page.CellID(5, 1), "txtemail", "Your Email", "", "Email", "")"$)
	c5.AddCode($"txtEmail.Placeholder = "Enter your email""$)
	c5.AddCode($"txtEmail.InputGroupVertical = True"$)
	c5.Refresh
	'
	txtLarge.AddTextBoxGroup(Me, page.CellID(6, 1), "txtlarge", "Large", "", "LG", "")
	txtLarge.Placeholder = "Type Here"
	'txtLarge.InputGroupSize = app.SIZE_LG
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"txtLarge.AddTextBoxGroup(Me, page.CellID(6, 1), "txtlarge", "Large", "", "LG", "")"$)
	c6.AddCode($"txtLarge.Placeholder = "Type Here""$)
	c6.AddCode($"txtLarge.InputGroupSize = app.SIZE_LG"$)
	c6.Refresh
	'
	txtMedium.AddTextBoxGroup(Me, page.CellID(7, 1), "txtmedium", "Medium", "", "MD", "")
	txtMedium.Placeholder = "Type Here"
	'txtMedium.InputGroupSize = app.SIZE_MD
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"txtMedium.AddTextBoxGroup(Me, page.CellID(7, 1), "txtmedium", "Medium", "", "MD", "")"$)
	c7.AddCode($"txtMedium.Placeholder = "Type Here""$)
	c7.AddCode($"txtMedium.InputGroupSize = app.SIZE_MD"$)
	c7.Refresh
	'
	txtSmall.AddTextBoxGroup(Me, page.CellID(8, 1), "txtsmall", "Small","", "SM", "")
	txtSmall.Placeholder = "Type Here"
	'txtSmall.InputGroupSize = app.SIZE_SM
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"txtSmall.AddTextBoxGroup(Me, page.CellID(8, 1), "txtsmall", "Small","", "SM", "")"$)
	c8.AddCode($"txtSmall.Placeholder = "Type Here""$)
	c8.AddCode($"txtSmall.InputGroupSize = app.SIZE_SM"$)
	c8.Refresh
	'
	
	txtXSmall.AddTextBoxGroup(Me, page.CellID(9, 1), "txtxsmall", "XSmall","", "XS", "")
	txtXSmall.Placeholder = "Type Here"
	'txtXSmall.InputGroupSize = app.SIZE_XS
	'
	Dim c9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"txtXSmall.AddTextBoxGroup(Me, page.CellID(9, 1), "txtxsmall", "XSmall","", "XS", "")"$)
	c9.AddCode($"txtXSmall.Placeholder = "Type Here""$)
	c9.AddCode($"txtXSmall.InputGroupSize = app.SIZE_XS"$)
	c9.Refresh
	'
	txtSearch.AddTextBoxGroup(Me, page.CellID(10, 1), "txtsearch", "Search", "", "", "")
	txtSearch.Placeholder = "Search"
	txtSearch.AppendIcon = "fa-solid fa-magnifying-glass"
	'
	Dim c10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c10", "vb")
	c10.AddCode($"txtSearch.AddTextBoxGroup(Me, page.CellID(10, 1), "txtsearch", "Search", "", "", "")"$)
	c10.AddCode($"txtSearch.Placeholder = "Search""$)
	c10.AddCode($"txtSearch.AppendIcon = "fa-solid fa-magnifying-glass""$)
	c10.Refresh
	'
	Dim txtGo As SDUITextBox = page.Cell(11, 1).AddTextBoxGroup("txtGo", "Go", "", "", "Go")
	txtGo.Placeholder = "Pick a category"
	txtGo.PrependIcon = "fa-solid fa-mountain-city"
	'
	Dim c11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("c11", "vb")
	c11.AddCode($"Dim txtGo As SDUITextBox = page.Cell(11, 1).AddTextBoxGroup("txtGo", "Go", "", "", "Go")"$)
	c11.AddCode($"txtGo.Placeholder = "Pick a category""$)
	c11.AddCode($"txtGo.PrependIcon = "fa-solid fa-mountain-city""$)
	c11.Refresh
End Sub

Private Sub txtsearch_append_click (event As BANanoEvent)
	page.Cell(12, 1).Caption = "Searching..."
End Sub


Private Sub btnget_Click (e As BANanoEvent)
	page.Cell(12, 1).caption	= txtIG.Value
End Sub

Private Sub btnset_Click (e As BANanoEvent)
	txtIG.Value = "email@gmail.com"
End Sub
