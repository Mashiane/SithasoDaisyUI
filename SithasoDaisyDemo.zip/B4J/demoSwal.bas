﻿B4J=true
Group=Default Group\CodedPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "swals2"
	Public title As String = "Sweet Alert"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	'build the page, via code or loadlayouts
	BuildPage
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows(20).AddColumns4p8
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	
	app.SwalPosition = app.SWAL_BOTTOM_END
	app.SwalTimer = 2000
	
	page.Cell(1, 1).AddButton("swal1", "Alert")
	page.Cell(2, 1).AddButton("alertwait4", "Alert Wait")
	page.Cell(3, 1).AddButton("swal2", "Confirm Wait")
	page.Cell(4, 1).AddButton("swal3", "Error")
	page.Cell(5, 1).AddButton("swal4", "Information")
	page.Cell(6, 1).AddButton("swal5", "Input Dialog")
	page.Cell(7, 1).AddButton("swal6", "Success")
	page.Cell(8, 1).AddButton("swal7", "Warning")
	page.Cell(9, 1).AddButton("swal8", "Error Toast - 2 sec")
	page.Cell(10, 1).AddButton("swal9", "Info Toast - 2 sec")
	page.Cell(11, 1).AddButton("swal10", "Success Toast - 2 sec")
	page.Cell(12, 1).AddButton("swal11", "Warning Toast - 2 sec")
	page.Cell(13, 1).AddButton("swal12", "Info Notification - 2 sec")
	page.Cell(14, 1).AddButton("swal13", "Warning Notification - 2 sec")
	page.Cell(15, 1).AddButton("swal14", "Success Notification - 2 sec")
	page.Cell(16, 1).AddButton("swal15", "Error Notification - 2 sec")
	
	'
	Dim c1 As SDUIMockupCode = page.Cell(1, 2).AddMockUpCode("c1", "vb")
	c1.AddCode($"'global settings"$)
	c1.AddCode($"'app.SwalPosition = app.SWAL_BOTTOM_END"$)
	c1.AddCode($"'app.SwalTimer = 2000"$)
	c1.AddCode($"'page.Cell(1, 1).AddButton("swal1", "Alert")"$)
	c1.AddCode($"Sub swal1_Click (e As BANanoEvent)"$)
	c1.AddCode($"app.ShowSwal("This is a swal!")"$)
	c1.AddCode($"End Sub"$)
	c1.Refresh
	'
	Dim c2 As SDUIMockupCode = page.Cell(2, 2).AddMockUpCode("c2", "vb")
	c2.AddCode($"'page.Cell(2, 1).AddButton("alertwait4", "Alert Wait")"$)
	c2.AddCode($"Sub alertwait4_Click (e As BANanoEvent)"$)
	c2.AddCode($"banano.Await(app.ShowSwalAlertWait("SithasoDaisy", "A UI toolbox without Swal2 is incomplete!", "Ok"))"$)
	c2.AddCode($"End Sub"$)
	c2.Refresh
	'
	Dim c3 As SDUIMockupCode = page.Cell(3, 2).AddMockUpCode("c3", "vb")
	c3.AddCode($"'page.Cell(3, 1).AddButton("swal2", "Confirm Wait")"$)
	c3.AddCode($"Sub swal2_Click (e As BANanoEvent)"$)
	c3.AddCode($"Dim resp As Boolean = banano.Await(app.ShowSwalConfirmWait("SithasoDaisy", "Do you want to download SithasoDaisy?", "Yes", "No"))"$)
	c3.AddCode($"app.ShowSwal("Your answer was: " & resp)"$)
	c3.AddCode($"End Sub"$)
	c3.Refresh
	'
	Dim c4 As SDUIMockupCode = page.Cell(4, 2).AddMockUpCode("c4", "vb")
	c4.AddCode($"'page.Cell(4, 1).AddButton("swal3", "Error")"$)
	c4.AddCode($"Sub swal3_Click (e As BANanoEvent)"$)
	c4.AddCode($"app.ShowSwalError("An error happened!")"$)
	c4.AddCode($"End Sub"$)
	c4.Refresh
	'
	Dim c5 As SDUIMockupCode = page.Cell(5, 2).AddMockUpCode("c5", "vb")
	c5.AddCode($"'page.Cell(5, 1).AddButton("swal4", "Information")"$)
	c5.AddCode($"Sub swal4_Click (e As BANanoEvent)"$)
	c5.AddCode($"app.ShowSwalInfo("This is information!")"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
	'
	Dim c6 As SDUIMockupCode = page.Cell(6, 2).AddMockUpCode("c6", "vb")
	c6.AddCode($"'page.Cell(6, 1).AddButton("swal5", "Input Dialog")"$)
	c6.AddCode($"Sub swal5_Click (e As BANanoEvent)"$)
	c6.AddCode($"Dim resp As String = banano.Await(app.ShowSwalInputWait("Name", "Please enter your name below.", "Ok", "Cancel"))"$)
	c6.AddCode($"app.ShowSwal(~"Your response: ~{resp}"~)"$)
	c6.AddCode($"End Sub"$)
	c6.Refresh
	'
	Dim c7 As SDUIMockupCode = page.Cell(7, 2).AddMockUpCode("c7", "vb")
	c7.AddCode($"'page.Cell(7, 1).AddButton("swal6", "Success")"$)
	c7.AddCode($"Sub swal6_Click (e As BANanoEvent)"$)
	c7.AddCode($"app.ShowSwalSuccess("It was a success!")"$)
	c7.AddCode($"End Sub"$)
	c7.Refresh
	'
	Dim c8 As SDUIMockupCode = page.Cell(8, 2).AddMockUpCode("c8", "vb")
	c8.AddCode($"'page.Cell(8, 1).AddButton("swal7", "Warning")"$)
	c8.AddCode($"Sub swal7_Click (e As BANanoEvent)"$)
	c8.AddCode($"app.ShowSwalWarning("This is a warning!")"$)
	c8.AddCode($"End Sub"$)
	c8.Refresh
	'
	Dim c9 As SDUIMockupCode = page.Cell(9, 2).AddMockUpCode("c9", "vb")
	c9.AddCode($"'page.Cell(9, 1).AddButton("swal8", "Error Toast - 2 sec")"$)
	c9.AddCode($"Sub swal8_Click (e As BANanoEvent)"$)
	c9.AddCode($"app.ShowSwalErrorToast("Error toast...", 2000)"$)
	c9.AddCode($"End Sub"$)
	c9.Refresh
	
	Dim c10 As SDUIMockupCode = page.Cell(10, 2).AddMockUpCode("c10", "vb")
	c10.AddCode($"'page.Cell(10, 1).AddButton("swal9", "Info Toast - 2 sec")"$)
	c10.AddCode($"Sub swal9_Click (e As BANanoEvent)"$)
	c10.AddCode($"app.ShowSwalInfoToast("Infor toast...", 2000)"$)
	c10.AddCode($"End Sub"$)
	c10.Refresh
	'
	Dim c11 As SDUIMockupCode = page.Cell(11, 2).AddMockUpCode("c11", "vb")
	c11.AddCode($"'page.Cell(11, 1).AddButton("swal10", "Success Toast - 2 sec")"$)
	c11.AddCode($"Sub swal10_Click (e As BANanoEvent)"$)
	c11.AddCode($"app.ShowSwalSuccessToast("Success toast...", 2000)"$)
	c11.AddCode($"End Sub"$)
	c11.Refresh
	'
	Dim c12 As SDUIMockupCode = page.Cell(12, 2).AddMockUpCode("c12", "vb")
	c12.AddCode($"'page.Cell(12, 1).AddButton("swal11", "Warning Toast - 2 sec")"$)
	c12.AddCode($"Sub swal11_Click (e As BANanoEvent)"$)
	c12.AddCode($"app.ShowSwalWarningToast("Warning toast...", 2000)"$)
	c12.AddCode($"End Sub"$)
	c12.Refresh
	'
	Dim c13 As SDUIMockupCode = page.Cell(13, 2).AddMockUpCode("c13", "vb")
	c13.AddCode($"'page.Cell(13, 1).AddButton("swal12", "Info Notification - 2 sec")"$)
	c13.AddCode($"Sub swal12_Click (e As BANanoEvent)"$)
	c13.AddCode($"app.ShowSwalInfoNotification("Infor notification", 2000)"$)
	c13.AddCode($"End Sub"$)
	c13.Refresh
	'
	Dim c14 As SDUIMockupCode = page.Cell(14, 2).AddMockUpCode("c14", "vb")
	c14.AddCode($"'page.Cell(14, 1).AddButton("swal13", "Warning Notification - 2 sec")"$)
	c14.AddCode($"Sub swal13_Click (e As BANanoEvent)"$)
	c14.AddCode($"app.ShowSwalWarningNotification("Warning notification", 2000)"$)
	c14.AddCode($"End Sub"$)
	c14.Refresh
	'
	Dim c15 As SDUIMockupCode = page.Cell(15, 2).AddMockUpCode("c15", "vb")
	c15.AddCode($"'page.Cell(15, 1).AddButton("swal14", "Success Notification - 2 sec")"$)
	c15.AddCode($"Sub swal14_Click (e As BANanoEvent)"$)
	c15.AddCode($"app.ShowSwalSuccessNotification("Success notification", 2000)"$)
	c15.AddCode($"End Sub"$)
	c15.Refresh
	'
	Dim c16 As SDUIMockupCode = page.Cell(16, 2).AddMockUpCode("c16", "vb")
	c16.AddCode($"'page.Cell(16, 1).AddButton("swal15", "Error Notification - 2 sec")"$)
	c16.AddCode($"Sub swal15_Click (e As BANanoEvent)"$)
	c16.AddCode($"app.ShowSwalErrorNotification("Error notification", 2000)"$)
	c16.AddCode($"End Sub"$)
	c16.Refresh
End Sub

'global settings
'app.SwalPosition = app.SWAL_BOTTOM_END
'app.SwalTimer = 2000  
'page.Cell(1, 1).AddButton("swal1", "Alert")
Sub swal1_Click (e As BANanoEvent)
	app.ShowSwal("This is a swal!")
End Sub

'page.Cell(2, 1).AddButton("alertwait4", "Alert Wait")
Sub alertwait4_Click (e As BANanoEvent)
	banano.Await(app.ShowSwalAlertWait("SithasoDaisy", "A UI toolbox without Swal2 is incomplete!", "Ok"))
End Sub

'page.Cell(3, 1).AddButton("swal2", "Confirm Wait")
Sub swal2_Click (e As BANanoEvent)
	Dim resp As Boolean = banano.Await(app.ShowSwalConfirmWait("SithasoDaisy", "Do you want to download SithasoDaisy?", "Yes", "No"))
	app.ShowSwal("Your answer was: " & resp)
End Sub

'page.Cell(4, 1).AddButton("swal3", "Error")
Sub swal3_Click (e As BANanoEvent)
	app.ShowSwalError("An error happened!")
End Sub

'page.Cell(5, 1).AddButton("swal4", "Information")
Sub swal4_Click (e As BANanoEvent)
	app.ShowSwalInfo("This is information!")
End Sub

'page.Cell(6, 1).AddButton("swal5", "Input Dialog")
Sub swal5_Click (e As BANanoEvent)
	Dim resp As String = banano.Await(app.ShowSwalInputWait("Name", "Please enter your name below.", "Ok", "Cancel"))
	app.ShowSwal($"Your response: ${resp}"$)
End Sub

'page.Cell(7, 1).AddButton("swal6", "Success")
Sub swal6_Click (e As BANanoEvent)
	app.ShowSwalSuccess("It was a success!")
End Sub

'page.Cell(8, 1).AddButton("swal7", "Warning")
Sub swal7_Click (e As BANanoEvent)
	app.ShowSwalWarning("This is a warning!")
End Sub

'page.Cell(9, 1).AddButton("swal8", "Error Toast - 2 sec")
Sub swal8_Click (e As BANanoEvent)
	app.ShowSwalErrorToast("Error toast...", 2000)
End Sub

'page.Cell(10, 1).AddButton("swal9", "Info Toast - 2 sec")
Sub swal9_Click (e As BANanoEvent)
	app.ShowSwalInfoToast("Infor toast...", 2000)
End Sub

'page.Cell(11, 1).AddButton("swal10", "Success Toast - 2 sec")
Sub swal10_Click (e As BANanoEvent)
	app.ShowSwalSuccessToast("Success toast...", 2000)
End Sub

'page.Cell(12, 1).AddButton("swal11", "Warning Toast - 2 sec")
Sub swal11_Click (e As BANanoEvent)
	app.ShowSwalWarningToast("Warning toast...", 2000)
End Sub

'page.Cell(13, 1).AddButton("swal12", "Info Notification - 2 sec")
Sub swal12_Click (e As BANanoEvent)
	app.ShowSwalInfoNotification("Infor notification", 2000)
End Sub

'page.Cell(14, 1).AddButton("swal13", "Warning Notification - 2 sec")
Sub swal13_Click (e As BANanoEvent)
	app.ShowSwalWarningNotification("Warning notification", 2000)
End Sub

'page.Cell(15, 1).AddButton("swal14", "Success Notification - 2 sec")
Sub swal14_Click (e As BANanoEvent)
	app.ShowSwalSuccessNotification("Success notification", 2000)
End Sub

'page.Cell(16, 1).AddButton("swal15", "Error Notification - 2 sec")
Sub swal15_Click (e As BANanoEvent)
	app.ShowSwalErrorNotification("Error notification", 2000)
End Sub