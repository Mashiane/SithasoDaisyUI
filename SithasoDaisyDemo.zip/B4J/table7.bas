﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	'this is the name of the page
	Public name As String = "tables7"
	Public title As String = "Table 7"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private Items As List
	Private tb4 As SDUITable
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'initialize the page
	'this clears the 'pageview'
	page.AddPage(Me, name)
	page.Root.p(6)
	'get the reference to the app
	app = duiapp
	app.PagePause
	'banano.Await(app.UsesFormToJSON)
	'banano.Await(app.UsesTable)
	'build the page, via code or loadlayouts
	'
	Items.Initialize
	Items.Add(CreateMap("hours":4, "on":True, "id":1, "rate":2, "email":"user1@gmail.com", "link":"https://tailwindcomponents.com/", "progress":10, "active":False, "name":"Cy Ganderton", "job":"Quality Control Specialist", "color":"Error", "avatar":"./assets/face1.jpg", "country":"USA", "clicklink":56, "sm": "fa-brands fa-twitter","dob":"", "tob":""))
	Items.Add(CreateMap("hours": 5, "on":False, "id":2, "rate":4, "progress":20, "active":True, "link":"https://daisyui.com/", "email":"user2@gmail.com", "name":"Hart Hagerty", "job":"Desktop Support Technician", "color":"Secondary", "avatar":"./assets/face17.jpg", "country":"Nigeria","clicklink":90, "sm": "fa-brands fa-facebook","dob":"","tob":""))
	Items.Add(CreateMap("hours": 8, "on":True, "id":3, "rate":3, "progress":90, "active":True, "link":"https://github.com/Mashiane", "email":"user3@gmail.com", "name":"Anele Mbanga", "job":"Software Engineer", "color":"Primary", "avatar":"./assets/mashy.jpg","country":"South Africa","clicklink":100, "sm": "fa-brands fa-whatsapp","dob":"","tob":""))
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub


'start building the page
private Sub BuildPage
	'set the page container to be in design mode
	'this shows the row/column grid lines
	page.Root.DesignMode(False)
	'center the page container
	page.Root.MXAuto
	'add 5 rows, each having 2 columns, each spanning 6
	page.Root.AddRows10.AddColumns12
	'build the grid
	page.Root.BuildGrid
	'start adding you components here
	Build_Table5
	Table5Code
End Sub

Sub Table5Code
	Dim c5 As SDUIMockupCode = page.Cell(2, 1).AddMockUpCode("c5", "vb")
	c5.AddCode($"Sub Build_Table5"$)
	c5.AddCode($"tb4 = page.Cell(1, 1).AddTable("tb4")"$)
	c5.AddCode($"'tb4.Hover = True"$)
	c5.AddCode($"'tb4.Zebra"$)
	c5.AddCode($"'"$)
	c5.AddCode($"tb4.AddColumnTextBoxGroup("id", "Price", True, "~", "", "00", "")"$)
	c5.AddCode($"tb4.SetColumnAlign("id", "r")"$)
	c5.AddCode($"tb4.AddColumnDialer("clicklink", "Qty", False, 0, 1, 100)"$)
	c5.AddCode($"tb4.AddColumnPasswordGroup("name", "Password", False)"$)
	c5.AddCode($"tb4.AddColumnSelectGroup("country", "County", False, True, CreateMap(), "", "fa-brands fa-linkedin", "", "fa-regular fa-flag")"$)
	c5.AddCode($"tb4.AddColumnButton("btnload", "Process", app.COLOR_INDIGO)"$)
	c5.AddCode($"tb4.AddColumnButton("btnicon", "Flag", app.COLOR_BLUE)"$)
	c5.AddCode($"'ad as last columns"$)
	c5.AddCode($"tb4.AddColumnEdit(app.COLOR_PRIMARY)"$)
	c5.AddCode($"tb4.AddColumnDelete(app.COLOR_SECONDARY)"$)
	c5.AddCode($"banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate"$)
	c5.AddCode($"'"$)
	c5.AddCode($"'change the select items for all rows"$)
	c5.AddCode($"banano.Await(tb4.SetSelectListItems("country", Array("Afghanistan", "Albania", "Australia", "USA", "Brazil", "Chile", "Guinea", "South Africa", "Nigeria")))"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"''"$)
	c5.AddCode($"Private Sub tb4_btnicon (item As Map)"$)
	c5.AddCode($"'get the id of the record"$)
	c5.AddCode($"Dim sid As String = item.Get("id")"$)
	c5.AddCode($"'find the position of the record using the id"$)
	c5.AddCode($"Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))"$)
	c5.AddCode($"'get the caption of the button"$)
	c5.AddCode($"Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnicon", pos))"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Select Case btnCaption"$)
	c5.AddCode($"Case "Flag""$)
	c5.AddCode($"'change the caption to"$)
	c5.AddCode($"tb4.SetRowColumn("btnicon", pos, "Insta")"$)
	c5.AddCode($"'set the append icon to insta"$)
	c5.AddCode($"tb4.SetRowColumnAppendIcon("country", pos, "fa-brands fa-instagram")"$)
	c5.AddCode($"tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-twitter")"$)
	c5.AddCode($"Case "Insta""$)
	c5.AddCode($"'change the caption to"$)
	c5.AddCode($"tb4.SetRowColumn("btnicon", pos, "Flag")"$)
	c5.AddCode($"'set the append icon to flag"$)
	c5.AddCode($"tb4.SetRowColumnAppendIcon("country", pos, "fa-regular fa-flag")"$)
	c5.AddCode($"tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-linkedin")"$)
	c5.AddCode($"End Select"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_btnload (item As Map)"$)
	c5.AddCode($"'get the id of the record"$)
	c5.AddCode($"Dim sid As String = item.Get("id")"$)
	c5.AddCode($"'find the position of the record using the id"$)
	c5.AddCode($"Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))"$)
	c5.AddCode($"'get the caption of the button"$)
	c5.AddCode($"Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnload", pos))"$)
	c5.AddCode($"'"$)
	c5.AddCode($"Select Case btnCaption"$)
	c5.AddCode($"Case "Process""$)
	c5.AddCode($"'change the caption to"$)
	c5.AddCode($"tb4.SetRowColumn("btnload", pos, "Loading")"$)
	c5.AddCode($"'set the append icon to loading"$)
	c5.AddCode($"tb4.SetRowColumnAppendLoading("country", pos, True)"$)
	c5.AddCode($"tb4.SetRowColumnPrependLoading("country", pos, True)"$)
	c5.AddCode($"Case "Loading""$)
	c5.AddCode($"'change the caption to"$)
	c5.AddCode($"tb4.SetRowColumn("btnload", pos, "Process")"$)
	c5.AddCode($"'set the append icon to not-loading"$)
	c5.AddCode($"tb4.SetRowColumnAppendLoading("country", pos, False)"$)
	c5.AddCode($"tb4.SetRowColumnPrependLoading("country", pos, False)"$)
	c5.AddCode($"End Select"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_PasswordPrependClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_PasswordPrependClick...")"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_PasswordAppendClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_PasswordAppendClick...")"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Decrement (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_Decrement....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Increment (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_Increment....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_PrependClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"app.ShowSwal(~"tb4_PrependClick: ~{Column}"~)"$)
	c5.AddCode($"Log("tb4_PrependClick....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_AppendClick (Row As Int, Column As String, item As Map)"$)
	c5.AddCode($"app.ShowSwal(~"tb4_AppendClick: ~{Column}"~)"$)
	c5.AddCode($"Log("tb4_AppendClick....")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)"$)
	c5.AddCode($"Log("tb4_ChangeRow...")"$)
	c5.AddCode($"Log(Row)"$)
	c5.AddCode($"Log(Value)"$)
	c5.AddCode($"Log(Column)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Edit (item As Map)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.AddCode($"Private Sub tb4_Delete (item As Map)"$)
	c5.AddCode($"Log(item)"$)
	c5.AddCode($"End Sub"$)
	c5.Refresh
End Sub

Sub Build_Table5
	tb4 = page.Cell(1, 1).AddTable("tb4")
	'tb4.Hover = True
	'tb4.Zebra
	'
	tb4.AddColumnTextBoxGroup("id", "Price", True, "$", "", "00", "")
	tb4.SetColumnAlign("id", "r")
	tb4.AddColumnDialer("clicklink", "Qty", False, 0, 1, 100)
	tb4.AddColumnPasswordGroup("name", "Password", False)
	tb4.AddColumnSelectGroup("country", "County", False, True, CreateMap(), "", "fa-brands fa-linkedin", "", "fa-regular fa-flag")
	tb4.AddColumnButton("btnload", "Process", app.COLOR_INDIGO)
	tb4.AddColumnButton("btnicon", "Flag", app.COLOR_BLUE)
	'ad as last columns
	tb4.AddColumnEdit(app.COLOR_PRIMARY)
	tb4.AddColumnDelete(app.COLOR_SECONDARY)
	
	banano.Await(tb4.SetItemsPaginate(Items))  'or SetItemsPaginate
	'
	'change the select items for all rows
	banano.Await(tb4.SetColumnItemsFromList("country", Array("Afghanistan", "Albania", "Australia", "USA", "Brazil", "Chile", "Guinea", "South Africa", "Nigeria")))
End Sub
''
Private Sub tb4_btnicon (item As Map)
	'get the id of the record
	Dim sid As String = item.Get("id")
	'find the position of the record using the id
	Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))
	'get the caption of the button
	Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnicon", pos))
	'
	Select Case btnCaption
	Case "Flag"
		'change the caption to
		tb4.SetRowColumn("btnicon", pos, "Insta")
		'set the append icon to insta
		tb4.SetRowColumnAppendIcon("country", pos, "fa-brands fa-instagram")
		tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-twitter")
	Case "Insta"
		'change the caption to
		tb4.SetRowColumn("btnicon", pos, "Flag")
		'set the append icon to flag
		tb4.SetRowColumnAppendIcon("country", pos, "fa-regular fa-flag")
		tb4.SetRowColumnPrependIcon("country", pos, "fa-brands fa-linkedin")
	End Select
End Sub


Private Sub tb4_btnload (item As Map)
	'get the id of the record
	Dim sid As String = item.Get("id")
	'find the position of the record using the id
	Dim pos As Int = banano.Await(tb4.FindRowByColumn("id", sid))
	'get the caption of the button
	Dim btnCaption As String = banano.Await(tb4.GetRowColumn("btnload", pos))
	'
	Select Case btnCaption
	Case "Process"
		'change the caption to
		tb4.SetRowColumn("btnload", pos, "Loading")
		'set the append icon to loading
		tb4.SetRowColumnAppendLoading("country", pos, True)
		tb4.SetRowColumnPrependLoading("country", pos, True)
	Case "Loading"
		'change the caption to
		tb4.SetRowColumn("btnload", pos, "Process")
		'set the append icon to not-loading
		tb4.SetRowColumnAppendLoading("country", pos, False)
		tb4.SetRowColumnPrependLoading("country", pos, False)
	End Select
End Sub

Private Sub tb4_PasswordPrependClick (Row As Int, Column As String, item As Map)
	Log("tb4_PasswordPrependClick...")
End Sub

Private Sub tb4_PasswordAppendClick (Row As Int, Column As String, item As Map)
	Log("tb4_PasswordAppendClick...")
End Sub

Private Sub tb4_Decrement (Row As Int, Column As String, item As Map)
	Log("tb4_Decrement....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_Increment (Row As Int, Column As String, item As Map)
	Log("tb4_Increment....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub


Private Sub tb4_PrependClick (Row As Int, Column As String, item As Map)
	app.ShowSwal($"tb4_PrependClick: ${Column}"$)
	Log("tb4_PrependClick....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_AppendClick (Row As Int, Column As String, item As Map)
	app.ShowSwal($"tb4_AppendClick: ${Column}"$)
	Log("tb4_AppendClick....")
	Log(Row)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	Log("tb4_ChangeRow...")
	Log(Row)
	Log(Value)
	Log(Column)
	Log(item)
End Sub

Private Sub tb4_Edit (item As Map)
	Log(item)
End Sub

Private Sub tb4_Delete (item As Map)
	Log(item)
End Sub