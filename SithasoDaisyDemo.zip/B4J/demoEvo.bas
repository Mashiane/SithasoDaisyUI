﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adevo"
	Public title As String = "AD EvoCalendar"
	Public icon As String = "fa-solid fa-pager"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	Private SDUIEvoCalendar1 As SDUIEvoCalendar
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesEvoCalendar)
	'load the page layout to the pageviewer
	banano.LoadLayout(app.PageViewer, "adevolayout")
	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
	SDUIEvoCalendar1.Clear
	Dim stoday As String = SDUIShared.DateNow
	'
	Dim e1 As Map = CreateMap()
	e1.Put("id", "imwyx6S")
	e1.Put("name", "Event #3")
	e1.Put("description", "Lorem ipsum dolor sit amet.")
	e1.Put("date", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-18 18:45")
	e1.Put("type", "event")
	SDUIEvoCalendar1.AddEvent1(e1)
	'
	Dim e2 As Map = CreateMap()
	e2.Put("id", "9jU6g6f")
	e2.Put("name", "Holiday #1")
	e2.Put("description", "Lorem ipsum dolor sit amet.")
	e2.Put("date", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-10 20:00")
	e2.Put("type", "holiday")
	SDUIEvoCalendar1.AddEvent1(e2)
	'
	Dim e3 As Map = CreateMap()
	e3.Put("id", "0g5G6ja")
	e3.Put("name", "Event #1")
	e3.Put("description", "Lorem ipsum dolor sit amet.")
	Dim d1 As String = SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-02 08:00"
	Dim d2 As String = SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-05 16:00"
	Dim dates As List
	dates.Initialize 
	dates.Add(d1)
	dates.Add(d2)
	e3.Put("date", dates)
	e3.Put("type", "event")
	e3.Put("everyYear", True)
	SDUIEvoCalendar1.AddEvent1(e3)
	'
	Dim e4 As Map = CreateMap()
	e4.Put("id", "y2u7UaF")
	e4.Put("name", "Holiday #3")
	e4.Put("description", "Lorem ipsum dolor sit amet.")
	e4.Put("date", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-23 12:00")
	e4.Put("type", "holiday")
	SDUIEvoCalendar1.AddEvent1(e4)
	'
	Dim e5 As Map = CreateMap()
	e5.Put("id", "dsu7HUc")
	e5.Put("name", "Birthday #1")
	e5.put("description", "Lorem ipsum dolor sit amet.")
	e5.Put("date", stoday)
	e5.Put("type", "birthday")
	SDUIEvoCalendar1.AddEvent1(e5)
	'
	
	Dim e6 As Map = CreateMap()
	e6.Put("id", "dsu7HUc")
	e6.Put("name", "Birthday #2")
	e6.Put("description", "Lorem ipsum dolor sit amet.")
	e6.Put("date", SDUIShared.YearNow & "-" & SDUIShared.MonthNow & "-27 09:00")
	e6.Put("type", "birthday")
	SDUIEvoCalendar1.AddEvent1(e6)
	'	
	SDUIEvoCalendar1.Refresh
End Sub


Private Sub SDUIEvoCalendar1_selectDate (oldDate As Object, newDate As Object)
	Log("SDUIEvoCalendar1_selectDate")
	Log(oldDate)
	Log(newDate)
End Sub

Private Sub SDUIEvoCalendar1_selectEvent (event As Map, newEvent As Object)
	Log("SDUIEvoCalendar1_selectEvent")
	Log(event)
	Log(newEvent)
End Sub