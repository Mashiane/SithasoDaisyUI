﻿B4J=true
Group=Default Group\AbstractDesignPages
ModulesStructureVersion=1
Type=StaticCode
Version=9.8
@EndOfDesignText@
'***** DO NOT DELETE OR CHANGE THIS FILE *****
#IgnoreWarnings:12, 9
Sub Process_Globals
	'this is the name of the page
	Public name As String = "adcam"
	Public title As String = "AD WebCamera"
	Public icon As String = "fa-solid fa-swatchbook"
	'this variable holds the page controller
	Public page As SDUIPage
	'this variable holds reference to the app
	'usually for constants and other things
	Public app As SDUIApp
	'the variable referencing banano lib
	Private banano As BANano		'ignore
	
	Private btnStart As SDUIButton
	Private btnTakePhoto As SDUIButton
	Private SDUIGrid1 As SDUIGrid
	Private SDUIGrid2 As SDUIGrid
	Private SDUIImage1 As SDUIImage
	Private SDUIWebcam1 As SDUIWebcam
End Sub

'sub to show the page
Sub Show(duiapp As SDUIApp)			'ignore
	'get the reference to the app
	app = duiapp
	app.PagePause
	banano.Await(app.UsesWebCam)
	'page.AddPage(Me, name)
	'page.Root.p(6)
	banano.LoadLayout(app.PageViewer, "adcamlayout")
	'
	pgIndex.ShowDesign
	pgIndex.ClearDesign
	pgIndex.AddDesignKV("", "--Nothing Selected--")
	pgIndex.AddDesignKV1("SDUIPage.page", "page", page.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnStart", "btnStart", btnStart.CustProps)
	pgIndex.AddDesignKV1("SDUIButton.btnTakePhoto", "btnTakePhoto", btnTakePhoto.CustProps)
	pgIndex.AddDesignKV1("SDUIGrid.SDUIGrid1", "SDUIGrid1", SDUIGrid1.CustProps)
	pgIndex.AddDesignKV1("SDUIGrid.SDUIGrid2", "SDUIGrid2", SDUIGrid2.CustProps)
	pgIndex.AddDesignKV1("SDUIImage.SDUIImage1", "SDUIImage1", SDUIImage1.CustProps)
	pgIndex.AddDesignKV1("SDUIWebcam.SDUIWebcam1", "SDUIWebcam1", SDUIWebcam1.CustProps)

	

	'build the page, via code or loadlayouts
	BuildPage
	app.PageResume
End Sub


Sub getName As String
	Return name
End Sub

Sub getIcon As String
	Return icon
End Sub

Sub getTitle As String
	Return title
End Sub

'start building the page
private Sub BuildPage
'	'set the page container to be in design mode
'	'this shows the row/column grid lines
'	page.Root.DesignMode(False)
'	'center the page container
'	page.Root.MXAuto
'	'add 5 rows, each having 2 columns, each spanning 6
'	page.Root.AddRows5.AddColumns2x6
'	'build the grid
'	page.Root.BuildGrid
'	'start adding you components here
End Sub


Private Sub SDUIWebcam1_SnapSuccess (data_URI As String)
	SDUIImage1.Src = data_URI
	banano.Await(SDUIWebcam1.StopWebCam)
End Sub

Private Sub btnTakePhoto_Click (e As BANanoEvent)
	banano.Await(SDUIWebcam1.TakePicture)	
End Sub

Private Sub btnStart_Click (e As BANanoEvent)
	banano.Await(SDUIWebcam1.StartWebCam)
End Sub